program Gravitation;

uses
  Forms,
  Cell in 'Cell.pas',
  Node in 'Node.pas',
  GravForm in 'GravForm.pas' {Form1};

{$R *.res}

begin
  Application.Initialize;
  Application.CreateForm(TForm1, Form1);
  Application.Run;
end.

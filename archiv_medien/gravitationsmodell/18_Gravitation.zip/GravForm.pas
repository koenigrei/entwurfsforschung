(********************************************************************)
(*                                                                  *) 
(*                                                                  *)
(*                     Erreichbarkeitsanalyse                       *)
(*                          Version 1.1                             *)
(*                                                                  *) 
(*     Programmierer: Reinhard K�nig                  November 2005 *)
(*                    http://www.entwurfsforschung.de/              *)
(*                                                                  *)
(*     Last Update: Nov-17, 2005                                    *)
(*     Last Update: Nov-23, 2005                                    *)
(*                                                                  *)
(********************************************************************) 
{revision history:

1.0     [Nov-17, 2005]
        first release to the public
1.1     [Nov-23, 2005]
        gravitation function was added
}

unit GravForm;

interface

uses
  Windows, Messages, SysUtils, Variants, Classes, Graphics, Controls, Forms,
  Dialogs, StdCtrls, Cell, node, ExtCtrls, ButtonGroup, ComCtrls, Math, ToolWin,
  ImgList;

type
  TForm1 = class(TForm)
    ZeichenPanel : TPanel;
    DataView     : TListView;
    GB_Data      : TGroupBox;
    B_DataDelete : TButton;
    GB_Zellen    : TGroupBox;
    Lbl_ZellTest1: TLabel;
    Lbl_ZellTest2: TLabel;
    sb_Zellen    : TScrollBar;
    lbl_zM       : TLabel;
    BG_Nodes     : TGroupBox;
    Lbl_NodeText1: TLabel;
    Lbl_NodeText2: TLabel;
    Lbl_NodeText3: TLabel;
    ToolBar1     : TToolBar;
    ToolButton1  : TToolButton;
    TB_findPath  : TToolButton;
    ToolButton3  : TToolButton;
    ImageList1   : TImageList;
    TB_Stoeme: TToolButton;
    ToolButton4: TToolButton;
    Label1: TLabel;
    procedure TB_StoemeClick(Sender: TObject);
    procedure ToolButton1Click(Sender: TObject);
    procedure FormDestroy(Sender: TObject);
    procedure TB_findPathClick(Sender: TObject);
    procedure sb_ZellenChange(Sender: TObject);
    procedure B_DataDeleteClick(Sender: TObject);
    procedure FormCreate(Sender: TObject);
  private
    openList     : TList;
    pfadList     : TList;
    NodeList     : TList;
    function  CalcDistance(pAX: Integer; pAY: Integer; pBX: Integer; pBY: Integer): Integer;
    procedure RasterCreate;
    procedure NodeCreate;
    procedure createPaintImg;
    procedure verbindeNodes;
    procedure showListView(obj: TCell);
    procedure Cell_MouseMove(Sender: TObject; Shift: TShiftState; X, Y: Integer);
    procedure Cell_MouseUp(Sender: TObject; Button: TMouseButton; Shift: TShiftState; X, Y: Integer);
    procedure Node_MouseMove(Sender: TObject; Shift: TShiftState; X, Y: Integer);
    procedure Node_MouseUp(Sender: TObject; Button: TMouseButton; Shift: TShiftState; X, Y: Integer);
    procedure Node_MouseDown(Sender: TObject; Button: TMouseButton; Shift: TShiftState; X, Y: Integer);
    procedure checkNeighbour (parAgent : TNode);
    procedure calcF (vorg: TNode; me: TNode);
    procedure findPath;
    procedure deletePath;
  public

  end;

var
  Form1: TForm1;
  paintImg : TImage;

implementation

{$R *.dfm}

const                      //-- globale Konstanten
  cellScal  = 20;          //-- Zellen gr��e

var                        //-- globale Variablen
  reih        : Integer;   //-- Zellen-Reihen gesamt
  spalt       : Integer;   //-- Zellen-Spalten gesamt
  lblNr       : Integer;   //-- fortlaufender Name der Zellen
  msPt        : TPoint;    //-- Mausposition innerhalb des ZeichenPanels
  nodePressed : Boolean;   //-- Wenn MausDown auf Node
  startNode   : Integer;   //-- Startnode f�r Drag&Drop Verbindung
  fertig        : Boolean; // --- schaltet das ApplicationEvents1 ein / aus
  foundPath     : Boolean; // --- true, wenn zielNode in OpenList => Pfad gefunden
  beginNode     : TNode;   // --- startPunkt des Pfades
  zielNode      : TNode;   // --- zielPunkt  des Pfades

// ---------------------------------------------------------------------------//
// *** Initialisierung ***
procedure TForm1.FormCreate(Sender: TObject);
begin
  Scaled         := False;
  NodeList       := TList.Create;
  openList       := TList.Create;
  pfadList       := TList.Create;
  spalt          := round (ZeichenPanel.Width / cellScal);
  reih           := round (ZeichenPanel.Height / cellScal);
  lbl_zM.Caption := IntToStr(sb_Zellen.Position -50 );
  nodePressed    := false;
  RasterCreate;
  createPaintImg;
  ZeichenPanel.DoubleBuffered := True;       //-- Verhindert Flackern der Zellen
end;

// ---------------------------------------------------------------------------//
// ---------------------------------------------------------------------------//
// *** Erstellt das Raster ***
procedure TForm1.RasterCreate;
var
  curCell : TCell;
  I: Integer;
  K: Integer;
begin
  for I := 0 to reih -1 do
  begin
    for K := 0 to spalt -1 do
    begin
      curCell := TCell.Create(self);
      curCell.Parent := ZeichenPanel;
      curCell.Show;
      curCell.Name := 'tc'+IntToStr(lblNr);
      lblNr := lblNr +1;
      curCell.canvas.Pen.Color := clWhite;
      curCell.SetBounds (0,0,cellScal,cellScal);
      curCell.Canvas.Rectangle(0 , 0, cellScal, cellScal);
      curCell.top := I * cellScal;
      curCell.Left := K * cellScal;
      curCell.OnMouseMove := Cell_MouseMove;
      curCell.OnMouseUp := Cell_MouseUp;
    end;
  end;
end;

// *** Erzeugt die Nodes ***
procedure TForm1.NodeCreate;
var
  curNode : TNode;
  lrgn : hrgn;
begin
   curNode := TNode.Create(self);
   curNode.Parent := ZeichenPanel;
   curNode.Show;
   curNode.top  := msPt.y - round(curNode.Width / 2);
   curNode.Left := msPt.x - round(curNode.Height / 2);
   LRgn := CreateEllipticRgn(0, 0, curNode.Width, curNode.Height);
   SetWindowRgn(curNode.Handle, LRgn, True);  //-- Runde Aktive Fl�che der Node-Schalter
   DeleteObject(LRgn);
   curNode.OnMouseMove := Node_MouseMove;
   curNode.OnMouseUp   := Node_MouseUp;
   curNode.OnMouseDown := Node_MouseDown;
   curNode.setPos;
   NodeList.Add (curNode);
   curNode.idx := NodeList.indexOf(curNode);
end;

// *** Legt eine leere Zeichenfl�che �ber das Zeichenpanel ***
procedure TForm1.createPaintImg;
begin
  paintImg := TImage.Create(self);
  paintImg.Parent  := ZeichenPanel;
  paintImg.Enabled := False;       //-- PaintImg reagiert nicht auf Mausereignisse
  paintImg.Transparent:= true;    //-- und ist transparent
  paintImg.top        := 0;
  paintImg.Left       := 0;
  paintImg.Height     := ZeichenPanel.Height;
  paintImg.Width      := ZeichenPanel.Width;
end;

// *** zeichne Verbindungslinien ***
procedure TForm1.verbindeNodes;
var
  J       : Integer;
  K       : Integer;
  curNode : TNode;
  toNode  : TNode;
  posA    : TPoint;
  posB    : TPoint;
  rect    : TRect;
begin
  // --- Zeichenfl�che l�schen ---
  rect.Left := 0; rect.Top := 0; rect.Right := ZeichenPanel.Width; rect.Bottom := ZeichenPanel.Height;
  paintImg.Canvas.Brush.Color := clWhite;
  paintImg.Canvas.FillRect(rect);
  // --- Pen Initialisieren ---
  paintImg.Canvas.Pen.Width := 2;
  paintImg.Canvas.Pen.Color := clMaroon;
  paintImg.Canvas.Pen.Style := psSolid;
  // --- Linien zu Nachbarn zeichnen ---
  for J := 0 to NodeList.Count -1 do
  begin
    curNode := NodeList.Items [J];
    K := 0;
    While  K < length(curNode.NachbList) Do
    Begin
      toNode := NodeList.Items [curNode.NachbList[K].Nr];

      If (TB_Stoeme.Down = true) Then begin  // -- Wenn Gravitations-Schalter an
        curNode.NachbList[K].dist := CalcDistance (curNode.pos.X, curNode.pos.Y, toNode.pos.X, toNode.pos.Y); //-- Distanzen berechnen
        // --- Gravitationsformel zur Berechnung der Str�me ---
        If not (curNode.NachbList[K].dist = 0) Then begin
          curNode.NachbList[K].Usage := (curNode.popul * toNode.popul) / curNode.NachbList[K].dist;
        end;
        paintImg.Canvas.Pen.Width := 1 + round(curNode.NachbList[K].Usage); 
      end;
      posA.X := curNode.Left + round(curNode.Height / 2);
      posA.Y := curNode.Top  + round(curNode.Width / 2);
      posB.X := toNode.Left  + round(toNode.Height / 2);
      posB.Y := toNode.Top   + round(toNode.Width / 2);
      paintImg.Canvas.MoveTo(posA.X, posA.Y);
      paintImg.Canvas.LineTo(posB.X, posB.Y);
      K := K + 1;
    end;
  end;
  // --- zeichne Pfad ---
  {If foundPath = true Then
  begin
    curNode := pfadList.Items [0]; // --- beginne bei ZielNode
    While Not (curNode = beginNode) Do
    begin
      toNode := curNode.vorg;
      // --- Pfadbenutzung speichern ---
      idx := NodeList.IndexOf(curNode);
      //If toNode.Usage[idx] < 15 then
      //toNode.Usage[idx] :=  toNode.Usage[idx] + (Sb_Mark.Position / 10);
      // --- Pfad zeichnen ---
      paintImg.Canvas.Pen.Color := clYellow;
      paintImg.Canvas.Pen.Style := psSolid;
      paintImg.Canvas.Pen.Width := 3; //+ round(toNode.Usage[idx]) ;
      //
      paintImg.Canvas.MoveTo(curNode.Pos.X, curNode.Pos.Y);
      paintImg.Canvas.LineTo(toNode.Pos.X, toNode.Pos.Y);
      curNode := curNode.vorg;
    end;
  end;}
end;

function TForm1.CalcDistance(pAX: Integer; pAY: Integer; pBX: Integer; pBY: Integer): Integer;
  var temp: double;
  begin
  temp := sqrt(Power((pAX - pBX), 2) + Power((pAY - pBY), 2));
  Result := Round(temp);
end;

// ---------------------------------------------------------------------------//
// ***************** Maus-Ereignisse f�r die Nodes ***************************//
// ---------------------------------------------------------------------------//
procedure TForm1.Node_MouseDown(Sender: TObject; Button: TMouseButton; Shift: TShiftState; X, Y: Integer);
begin
  nodePressed := true;                             //-- Maustaste wird gedr�ckt
  startNode   := NodeList.IndexOf(sender as TNode);//-- StartNode f�r Drag&Drop Verbindung
end;

procedure TForm1.Node_MouseUp(Sender: TObject; Button: TMouseButton; Shift: TShiftState; X, Y: Integer);
var
  curNode   : TNode;
  endNode   : Integer;
  tmpCrt    : TControl;
  finder    : TNode;
  PA        : TPoint;
  PB        : TPoint;
  Distance  : Integer;
  dragNodes : array [0..1] of TNode;
begin
  PA.x := X;
  PA.Y := Y;
  curNode := Sender as TNode;
  PA := ZeichenPanel.ScreenToClient(curNode.ClientToScreen(PA));
  nodePressed := false;                            //-- Maustaste wird losgelassen
  tmpCrt := ZeichenPanel.controlAtPos(PA, false, true);
  If not(tmpCrt = nil) and (tmpCrt is TNode) Then  //-- wenn Node an MouseUp-Position
  begin
    finder := tmpCrt as TNode;
    endNode := NodeList.IndexOf(finder);;          //-- EndNode f�r Drag&Drop Verbindung
    If not (startNode = endNode) Then begin        //-- wenn SartNode nicht EndNode dann
      dragNodes[0] := NodeList.Items [startNode];
      dragNodes[1] := NodeList.Items [endNode];
      // --- den jeweils anderen Node als Nachbar speichern (mit NodeList Nr und Dist) ---
      SetLength(dragNodes[0].NachbList, length(dragNodes[0].NachbList) + 1);
      SetLength(dragNodes[1].NachbList, length(dragNodes[1].NachbList) + 1);
      PA.X := dragNodes[0].Left + round(dragNodes[0].Height / 2);
      PA.Y := dragNodes[0].Top  + round(dragNodes[0].Width / 2);
      PB.X := dragNodes[1].Left + round(dragNodes[1].Height / 2);
      PB.Y := dragNodes[1].Top  + round(dragNodes[1].Width / 2);
      Distance := CalcDistance (PA.X, PA.Y, PB.X, PB.Y);
      dragNodes[0].NachbList[High(dragNodes[0].NachbList)].Nr   := endNode;
      dragNodes[0].NachbList[High(dragNodes[0].NachbList)].Dist := Distance;
      dragNodes[1].NachbList[High(dragNodes[1].NachbList)].Nr   := startNode;
      dragNodes[1].NachbList[High(dragNodes[1].NachbList)].Dist := Distance;
    end;
    verbindeNodes;
  end;
  verbindeNodes;
end;

procedure TForm1.Node_MouseMove(Sender: TObject; Shift: TShiftState; X, Y: Integer);
var
  curNode : TNode;
  P       : TPoint;
  rect    : TRect;
  lrgn    : hrgn;
begin
  If nodePressed = true then
  begin
    verbindeNodes;
    curNode := sender as TNode;
    P.x := X;
    P.Y := Y;
    P := ZeichenPanel.ScreenToClient(curNode.ClientToScreen(P));
    if (ssAlt in shift) then                       //-- wenn ALT Taste gedr�ck
    begin                                          //-- Verbindung herstellen und Linie zeichnens
      rect.Left := 0; rect.Top := 0; rect.Right := ZeichenPanel.Width; rect.Bottom := ZeichenPanel.Height;
      paintImg.Canvas.Brush.Color := clWhite;
      paintImg.Canvas.FillRect(rect);
      paintImg.Transparent := true;
      verbindeNodes;
      paintImg.Canvas.Pen.Color := clGreen;
      paintImg.Canvas.Pen.Style := psSolid;
      paintImg.Canvas.Pen.Width := 1;
      paintImg.Canvas.MoveTo(curNode.Left + round(curNode.Height / 2), curNode.Top + round(curNode.Width / 2));
      paintImg.Canvas.LineTo(P.X, P.Y);
    end else
    if (ssCtrl in shift) then                      //-- wenn Strg Taste gedr�ck
    begin                                          //-- Node vergr��ern
      If (Y >  round(curNode.Height / 2)) and (curNode.Popul < 200) then begin
        curNode.Popul  := curNode.Popul  +1;
      end else
      If (Y <  round(curNode.Height / 2)) and (curNode.Popul > 15) then begin
        curNode.Popul := curNode.Popul - 1;
      end;
      curNode.Width  := curNode.Popul;
      curNode.Height := curNode.Popul;
      LRgn := CreateEllipticRgn(0, 0, curNode.Width, curNode.Height);
      SetWindowRgn(curNode.Handle, LRgn, True);  //-- Runde Aktive Fl�che der Node-Schalter
      DeleteObject(LRgn);
      curNode.setPos;
      curNode.update;
    end else
    begin
      curNode.top  := P.Y - round(curNode.Width / 2); //-- Punkt per Drag&drop verschieben
      curNode.Left := P.X - round(curNode.Height / 2);
    end;
    curNode.setPos;
    If not (curNode.KonSum = nil) then curNode.setKon(ZeichenPanel);
  end;
end;

// ---------------------------------------------------------------------------//
// ******************** Maus-Ereignisse f�r die Zellen ***********************//
// ---------------------------------------------------------------------------//
procedure TForm1.Cell_MouseUp(Sender: TObject; Button: TMouseButton; Shift: TShiftState; X, Y: Integer);
var
  curCell : TCell;
begin
  curCell := sender as TCell;
  if Button = mbRight then begin                   //-- rechte Maustaste zeigt Eigenschaften
    showListView(curCell);
  end;
  if Button = mbLeft then begin                    //-- linke Maustaste erzeugt Node
    NodeCreate;
  end;
end;

procedure TForm1.Cell_MouseMove(Sender: TObject; Shift: TShiftState; X, Y: Integer);
var
  curCell : TCell;
  chgW    : Integer;
  P : TPoint;
begin
  curCell := sender as TCell;
  if (ssShift in shift) then                       //-- bei gedr�ckter Shifttaste werden
  if not (curCell = nil) then                      //-- die Zellen beim dar�berfahren eingef�rbt
  begin
    chgW := sb_Zellen.Position - 50;
    curCell.used := curCell.used - chgW;
    if (curCell.used < 0) then curCell.used := 0
    else if (curCell.used > 255) then curCell.used := 255;
    curCell.Repaint;
  end;
  P.x := X;
  P.Y := Y;
  P := ZeichenPanel.ScreenToClient(curCell.ClientToScreen(P));
  msPt.x := P.X;                                   //-- rechnet Koordinaten auf das System
  msPt.y := P.Y;                                   //-- des Zeichenpanels um.
end;

// ---------------------------------------------------------------------------//
// *** Eigenschafts-Listenfeld ***
procedure TForm1.showListView(obj: TCell);
var
  Item1: TListItem;
begin
  DataView.Columns.Clear;
  DataView.Items.Clear;
  DataView.Columns.Add;
  DataView.Columns.Items[0].Caption := 'Objekt';
  DataView.Columns.Items[0].Width := -2;
  DataView.Columns.Add;
  DataView.Columns.Items[1].Caption := 'Eigenschaft';
  DataView.Columns.Items[1].Width := -2;
  DataView.Columns.Add;
  DataView.Columns.Items[2].Caption := 'Wert';
  DataView.Columns.Items[2].Width := -2;
  DataView.GridLines := True;
  DataView.ViewStyle := vsReport;
  Item1:=DataView.Items.Add;
  Item1.Caption := obj.name;
  Item1.SubItems.Add('Farbwert');
  Item1.SubItems.Add(intToStr(obj.used));
end;

procedure TForm1.B_DataDeleteClick(Sender: TObject);
begin
  DataView.Items.Clear();
end;

procedure TForm1.sb_ZellenChange(Sender: TObject);
begin
  lbl_zM.Caption := IntToStr(sb_Zellen.Position -50);
end;

// *****************************************************************************
// ************** Schalter f�r Berechnung und Anzeige der Str�me ***************
// *****************************************************************************

procedure TForm1.TB_StoemeClick(Sender: TObject);
var
  J       : Integer;
  I       : Integer;
  ANode   : TNode;
  BNode   : TNode;
begin
  // ---- Berechnen der Konnektivit�t ---------
  {ZeichenPanel.Invalidate;
  If NodeList.Count > 1 Then
  begin

    For I := 0 to NodeList.count-1 Do
    begin
      ANode := NodeList.Items[I];
      For J := 0 To NodeList.count-1 Do
      begin            //--- jeder (begin)Node wird mit jedem Anderen verglichen
        If not (I = J) Then
        begin
          BNode := NodeList.Items[J];
          ANode.NachbList[J].dist := CalcDistance (ANode.pos.X, ANode.pos.Y, BNode.pos.X, BNode.pos.Y); //-- Distanzen berechnen
          // --- Gravitationsformel zur Berechnung der Str�me ---
          If not (ANode.NachbList[J].dist = 0) Then begin
            ANode.NachbList[J].Usage := (ANode.popul * BNode.popul) / ANode.NachbList[J].dist;
          end;
        end;
      end;
    end;

  end; }
  verbindeNodes;
end;

// *****************************************************************************
// ****************** Schalter f�r Konnektivit�tsberrechnung *******************
// *************************** und Anzeige *************************************
procedure TForm1.TB_findPathClick(Sender: TObject);
var
  J       : Integer;
  L       : Integer;
  K       : Integer;
  idx     : Integer;
  ItemKon : Array of TListItem;
  I       : Integer;
  ZeilSum : Integer;
  allcount: Integer;
  counter : Integer;
  dWert   : Double;
  lWert   : Double;
begin
  //----- �berschrift der DataView-Ausgabe -----
  DataView.Columns.Clear;
  DataView.Items.Clear;
  DataView.Columns.Add;
  DataView.Columns.Items[0].Alignment := taCenter;
  DataView.Columns.Items[0].Caption := 'von - nach ->';
  DataView.Columns.Items[0].Width := -2;
  // ---- Berechnen der Konnektivit�t ---------
  ZeichenPanel.Invalidate;
  foundPath := false;
  ZeilSum := 0;
  allcount := 0;
  If NodeList.Count > 1 Then
  begin
    For I := 0 to NodeList.count-1 Do
    begin
      beginNode := NodeList.Items[I];
      SetLength(ItemKon, NodeList.count +1);
      DataView.Columns.Add;
      DataView.Columns.Items[I+1].Caption := IntToStr(I);
      DataView.Columns.Items[I+1].Width := -2;
      ItemKon[I]:=DataView.Items.Add;     // --- Neues Item pro Node
      ItemKon[I].Caption := IntToStr(NodeList.IndexOf(beginNode));
      SetLength(beginNode.KonSum, 0);
      SetLength(beginNode.KonSum, NodeList.count +1);
      counter := 0;
      For J := 0 To NodeList.count-1 Do
      begin       //--- jeder (begin)Node wird mit jedem Anderen verglichen
        If not (I = J) Then
        begin
          zielNode := NodeList.Items[J];
          findPath;                              //-- Pathfinding zu allen anderen Knoten
          verbindeNodes;                         //-- Verbindungslinien werden gezeichnet
          beginNode.KonSum[I] := pfadList.Count; //-- Anzahl der durchlaufenden Knoten = Entfernung
          //-- Ausgabe der Anzahl durchlaufener Knoten in DataVieiw
          ItemKon[I].SubItems.Add(IntToStr(beginNode.KonSum[I]));
          If beginNode.KonSum[I] >0 Then counter := counter +1;  //-- positive Werte je Zeile werden Gez�hlt
        end else begin
          beginNode.KonSum[I] := 0;
          ItemKon[I].SubItems.Add(IntToStr(beginNode.KonSum[I]));//-- Ausgabe 0
        end;
        For K := 0 to NodeList.count-1 Do        //-- Summe der durchlaufenen Knoten wird berechnet
        begin
          idx := High(beginNode.KonSum);         //-- und im letzten Arrayfeld gespeichert
          beginNode.KonSum[idx] := beginNode.KonSum[idx] + beginNode.KonSum[K];
        end;
      end;
      ItemKon[I].SubItems.Add(IntToStr(beginNode.KonSum[High(beginNode.KonSum)])); //-- Zeilensumme ausgeben
      ZeilSum := ZeilSum + beginNode.KonSum[High(beginNode.KonSum)];  //-- Zeilensummen zu Gesamtsumme zusammenz�hlen
      If counter > 0 Then begin                  //-- Berechnet Durchschnittsl�ngen
        dWert := beginNode.KonSum[High(beginNode.KonSum)]/counter;
      end else begin dWert := 0;;
      end;
      allcount := allcount + counter;            //-- Z�hlt alle positiven Werte zusammen
      dWert := RoundTo(dWert, -2);               //-- rundet die Durchnittsl�ngen
      ItemKon[I].SubItems.Add(FloatToStr(dWert));//-- Gibt die Durchschnittsl�ngen aus
      beginNode.setKon (ZeichenPanel);           //-- Zeigt die Verkn�fungswerte an
      beginNode.setNr;                           //-- Zeigt die Knotennummern an
    end;
    DataView.Columns.Add;   // --- �berschrift f�r Zeilensummen der Verbindungen
    DataView.Columns.Items[NodeList.count+1].Alignment := taCenter;
    DataView.Columns.Items[NodeList.count+1].Caption := 'Summe';
    DataView.Columns.Items[NodeList.count+1].Width := -2;
    DataView.Columns.Add;   // --- durchschn. L�nge der Verbindungswege
    DataView.Columns.Items[NodeList.count+2].Alignment := taCenter;
    DataView.Columns.Items[NodeList.count+2].Caption := 'dL�nge';
    DataView.Columns.Items[NodeList.count+2].Width := -2;
  end;
    if (NodeList.count > 1) then // -- Nur wenn mehr als ein Node vorhanden.
    begin
    ItemKon[NodeList.count]:=DataView.Items.Add;
    For I := 0 To NodeList.count-1 Do
    begin
      ItemKon[NodeList.count].SubItems.Add('-');
    end;
    ItemKon[NodeList.count].SubItems.Add(IntToStr(ZeilSum)); //-- Gesamtsumme wird in DataView ausgegeben
    If allcount > 0 Then begin
      lWert := ZeilSum / allcount;                           //-- Ma� f�r durchschn. Verbind. L�nge des Graphen wird berechnet
    end else lWert := 0;
    lWert := RoundTo(lWert, -2);
    ItemKon[NodeList.count].SubItems.Add(FloatToStr(lWert)); //-- Ma� f�r durchschn. Verbind. L�nge des Graphen wird in DataView ausgegeben
  end;
end;


// *****************************************************************************
// ****************             A-Stern Berechnungen            ****************
// *****************************************************************************
//
// *** Node wird expandiert --- die neuen Nodes werden gepr�ft ***
procedure TForm1.checkNeighbour (parAgent : TNode);
var
  I       : Integer;
  U       : Integer;
  altG    : Integer;
  altH    : Integer;
  altF    : Integer;
  inOpen  : Boolean;
  cildAgent : TNode;
begin
  for I := 0 To length(parAgent.NachbList)-1 Do
  begin
    cildAgent := NodeList.Items [parAgent.NachbList[I].Nr];
    // --- nicht untersucht werden W�nde und closed Nodes
    If ((cildAgent.State < 999) and (cildAgent.Closed = false)) then
    begin
      inOpen := false;
      for U := 0 To openList.count -1 do  // --- pr�ft, ob Knoten bereits in openList
      begin
        If (openList.Items[U] = cildAgent) then begin
          inOpen := true;
        end;
      end;
      If inOpen = false then         // --- wenn Node noch nicht in open List
      begin
        calcF (parAgent, cildAgent); // --- berechnet die Sch�tzwerte (Heuristik)
        cildAgent.Vorg := parAgent;  // --- bestimmt den Vog�nger-VerweisNode
        openList.Add(cildAgent);     // --- nimmt Node in Openlist auf
        If (cildAgent = zielNode) Then begin
          foundPath := true;         // --- Ziel erreicht!
        end;
      end else begin         // --- wenn Node bereits in open List
                             // --- pr�fe, ob G g�nstiger => ver�ndere Vorg
        altG := cildAgent.G; // +
        altH := cildAgent.H; // + speichert Werte vor der neuBerechnung
        altF := cildAgent.F; // +
        calcF (parAgent, cildAgent);
        If (altG < cildAgent.G) Then begin // --- setze alte Werte wieder ein
          cildAgent.G := altG;
          cildAgent.H := altH;
          cildAgent.F := altF;
        end else begin
          cildAgent.Vorg := parAgent; // --- falls neuer G-Wert g�nstiger, neuer Verweis auf Vorg�nger-Node
        end;
      end;
    end;
  end;
end;

// *** Berechnung der Heuristik: F = G + H ***
procedure TForm1.calcF (vorg: TNode; me: TNode);
var
  dist     : Integer;
begin
  // ----- Berechne G -----
  dist := calcDistance(vorg.Pos.X, vorg.Pos.Y, me.Pos.X, me.Pos.Y);
  me.G := vorg.G + dist;
  // ----- Berechne H -----
  me.H := calcDistance(zielNode.Pos.X, zielNode.Pos.Y, me.Pos.X, me.Pos.Y);
  // ----- Berechne F -----
  me.F := me.G + me.H;
end;

// TList sort routine : compare customers by name
// --------------------------------------------//
// The returned integer has the following value :
//   > 0 : (positive) Item1 is less than Item2 //
//     0 : Item1 is equal to Item2             //
//   < 0 : (negative) Item1 is greater than Item2
function compareByF(Item1 : Pointer; Item2 : Pointer) : Integer;
var
  customer1, customer2 : TNode;
begin
  // We start by viewing the object pointers as TNode objects
  customer1 := TNode(Item1);
  customer2 := TNode(Item2);
  // Now compare by F - complete Kosts
  if   customer1.F < customer2.F
    then Result := 1
  else if customer1.F = customer2.F
    then Result := 0
  else   Result := -1;
end;

// *** geht die Nodes durch ***
procedure TForm1.findPath;
var
  explNode : TNode;
begin
If Not (beginNode = nil) Then begin
  foundPath := false;
  deletePath;
  openList.Add(beginNode);
  // --- Wdh. bis openList vollst�ndig �berpr�ft => kein Pfad m�glich!
  // --- oder bis zielNode erreicht => pfad gefunden.
  While ((openList.count > 0) And (foundPath = false)) Do
  begin
    explNode := openList.Items[openList.count -1];
    explNode.closed := true;
    checkNeighbour (explNode);
    openList.Sort(compareByF);
    openList.Remove(explNode);
  end;
  // --- speichere den Pfad ---
  explNode := zielNode;
  If foundPath = true Then begin
    repeat
      pfadList.Add (explNode);
      explNode := explNode.Vorg;
    Until (explNode = beginNode);
  end;
end;
end;

// *** Pfade l�schen ***
procedure TForm1.deletePath;
var
  I : Integer;
  AShape : TNode;
begin
  openList.Free;
  pfadList.Free;
  openList := TList.Create;
  pfadList := TList.Create;
  for I := 0 to NodeList.Count - 1 do
  begin
    AShape   := NodeList.Items [I];
    AShape.F := 0;
    AShape.G := 0;
    AShape.H := 0;
    AShape.closed := false;
    If AShape.State > 0 then AShape.State := 0;
    beginNode.State := 1;
    zielNode.State  := 2;
  end;
end;
// ---------------------------------------------------------------------------//
// ---------------------------------------------------------------------------//
procedure TForm1.FormDestroy(Sender: TObject);
begin
  paintImg.Free;
  NodeList.Free;
  ZeichenPanel.Free;
end;

procedure TForm1.ToolButton1Click(Sender: TObject);
var
  I       : Integer;
  curNode : TNode;
  rect    : TRect;
begin
  For I := 0 To NodeList.Count -1 Do
  begin
    curNode   := NodeList.Items [I];
    curNode.Destroy;
  end;
  NodeList.Free;
  NodeList := TList.Create;
  ZeichenPanel.Invalidate;
  rect.Left := 0; rect.Top := 0; rect.Right := ZeichenPanel.Width; rect.Bottom := ZeichenPanel.Height;
  paintImg.Canvas.Brush.Color := clWhite;
  paintImg.Canvas.FillRect(rect);
end;

end.

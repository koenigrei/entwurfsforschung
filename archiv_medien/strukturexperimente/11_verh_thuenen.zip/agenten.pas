unit agenten;

interface

uses
  Windows, Graphics, Classes, Math;

type
  TBaseShape = class
  private
    procedure Anlagern (const I: Integer; const AgentList: TList);
  public
    FPositionX    : Integer;  // XKoordinate
    FPositionY    : Integer;  // YKoordinate
    FSize         : Integer;  // Gr��e des Agenten
    FStepX        : Double;   // X-Anteil des Bewegungsvektors
    FStepY        : Double;   // Y-Anteil des Bewegungsvektors
    FFillColor    : Integer;  // Farbe des Agenten
    FState        : Integer;  // Art des Agenten
    FAnlDist      : Integer;  // Radius innerhalb dessen sich gleichfarbige Agenten agstossen = Repel
    FRepelDist    : Integer;  // Radius innerhalb dessen eine Anlagerung m�glich ist
    FBindungSet   : Integer;  // Anzahl der freien Bindungen f�r gleiche Agenten
    FBindungMax   : Integer;  // Anzahl der freien Bindungen f�r untergeordnete Agenten
    FShortestD    : Double;   // K�rzester Abstand zu einem beliebigen Nachbarn
    FShortestDSelf: Double;   // K�rzester Abstand zu einem gleichen Nachbarn
    FConnect      : Integer;  // Gibt an, ob ein Agent gebunden ist
    FDistance     : Integer;
    FNeigborList  : Array of Integer;
    FBindListSelf : Array of Integer;
    FBindListOther: Array of Integer;
    procedure Paint           (Canvas: TCanvas); virtual;
    procedure SetNeigbor      (Index: Integer; Value: Integer);
    function  GetNeigbor      (Index: Integer): Integer;
    procedure SetBindListSelf (Index: Integer; Value: Integer);
    function  GetBindListSelf (Index: Integer): Integer;
    procedure SetBindListOther(Index: Integer; Value: Integer);
    function  GetBindListOther(Index: Integer): Integer;
    property  NeigborList     [Index: Integer]: Integer read GetNeigbor write SetNeigbor;
    property  BindListSelf    [Index: Integer]: Integer read GetBindListSelf write SetBindListSelf;
    property  BindListOther   [Index: Integer]: Integer read GetBindListOther write SetBindListOther;
    function  CalcDistance    (pX, pY: Integer):Integer;
    procedure SetBindungSet   (const Value: Integer);
    procedure SetBindungMax   (const Value: Integer);
    procedure SetPositionX    (const Value: Integer);
    procedure SetPositionY    (const Value: Integer);
    procedure SetStepX        (const Value: Double);
    procedure SetStepY        (const Value: Double);
    procedure SetSize         (const Value: Integer);
    procedure SetDistance     (const Value: Integer);
    procedure SetAnlDist      (const Value: Integer);
    procedure SetRepelDist    (const Value: Integer);
    procedure SetRndDir       (const damp: Double);
    procedure SetAnlDir       (const damp: Double; const AgentList: TList);
    procedure SetFillColor    (const Value: Integer);
    procedure SetState        (const Value: Integer);
    procedure SetConnect      (const Value: Integer);
    procedure SetShortestD    (const Value: Double);
    procedure SetShortestDSelf(const Value: Double);
  published
    procedure NeigborCheck(const AgentList: TList; const I: Integer;
                           const MindDist: Integer; var limboPos: Array of Double);
    property PositionX   : Integer read FPositionX    write SetPositionX;
    property PositionY   : Integer read FPositionY    write SetPositionY;
    property StepX       : Double  read FStepX        write SetStepX;
    property StepY       : Double  read FStepY        write SetStepY;
    property Size        : Integer read FSize         write SetSize;
    property Distance    : Integer read FDistance     write SetDistance;
    property FillColor   : Integer read FFillColor    write SetFillColor;
    property State       : Integer read FState        write SetState;
    property BindungSet  : Integer read FBindungSet   write SetBindungSet;
    property BindungMax  : Integer read FBindungMax   write SetBindungMax;
    property AnlDist     : Integer read FAnlDist      write SetAnlDist;
    property RepelDist   : Integer read FRepelDist    write SetRepelDist;
    property ShortestD   : Double  read FShortestD    write SetShortestD;
    property ShortestDSelf: Double  read FShortestDSelf write SetShortestDSelf;
    property Connect     : Integer read FConnect      write SetConnect;
  end;

type
  TAgent = class (TBaseShape)
    procedure Paint (Canvas: TCanvas); override;

  end;

implementation

const PI = 3.14159265358979323846;
//*********************************************************************************************//
// ********** Berechnet Nachbarn und Abst�nde zu den anderen Agenten **************************//
//*********************************************************************************************//
// --- Eingagen : Abstand   : Interaktionsradius der Agenten                                   //
//                MinAbstand: Mindestabstand zwischen den Agenten                              //
//                AgentList : Liste mit allen Agenten                                          //
//                I         : Nr des Aktuellen Agenten um Doppelvergleiche zu vermeiden (K+I)  //
// --- Ausgaben : NeigborList   : Nr.-Liste mit den Nachbarn innerhalb des Radius              //
//                NeigborList[0]: Nr. des n�chsten Nachbarn                                    //
//                ShortestD     : Entfernung zum n�chsten Nachbarn                             //
//*********************************************************************************************//
procedure TBaseShape.NeigborCheck (const AgentList: TList; const I: Integer;
                                   const MindDist: Integer; var limboPos: Array of Double);
var
  K        : Integer;
  AShape   : TAgent;
  BShape   : TAgent;
begin
  SetLength(FNeigborList,   2);
  SetLength(FBindListOther, 0);
  SetLength(FBindListSelf,  0);
  ShortestD    := 1000;
  AShape := AgentList.Items[I];
  //limboPos[0] := FStepX;
  //limboPos[1] := FStepY;
  //For K := I+1 to AgentList.Count - 1 do
  For K := 0 to AgentList.Count - 1 do
  begin
    If (Not (K = I)) then // -- Vergleichen wenn unterschiedlich  //And (NOT AShape.Connect))
    begin
      BShape := AgentList.Items[K];
      AShape.Distance := CalcDistance(BShape.PositionX, BShape.PositionY);
      If AShape.Distance < AShape.AnlDist then // --- sammelt Nachbarn innerhalb Radius
      begin
        SetLength(FNeigborList, length(FNeigborList) + 1);
        NeigborList[High(FNeigborList)] := K;
      end;
      If AShape.Distance < AShape.ShortestD    // --- bestimme den n�chsten Nachbarn
      then begin
        AShape.ShortestD := AShape.Distance;
        AShape.NeigborList[0] := K;            // Index 0 = nearestNeigbor
        If (BShape.State = AShape.State) Then Begin
          AShape.ShortestDSelf := AShape.Distance;
          AShape.NeigborList[1] := K; // Index 1 = nearestNeigbor gleicher Farbe
        end;
      end;
    end;
  end;

  If (AShape.ShortestD < AShape.AnlDist) Then  // --- Anlagerung wenn innerhalb Anlagerungsradius
  begin
    Anlagern (I, AgentList);
  end;
  If (AShape.ShortestD < MindDist) then SetRndDir(0.8);  
end;

// ********************* Agenten anlagern ************************************//
procedure TBaseShape.Anlagern (const I: Integer; const AgentList: TList);
var
  K      : Integer;
  BShape : TAgent;
  AShape : TAgent;
begin
  Connect := 0;
  For K := 2 To length(FNeigborList)-1 Do  //--- beginn nach n�chsten Nachbarn => K := 2
  Begin
    BShape := AgentList[FNeigborList[K]];           //--- Parent
    If ((BShape.State = State -1) and (State > 0))  //--- Agenten untergeordneten Typs
    and (BShape.BindungSet < BShape.BindungMax)Then Begin
      BShape.BindungSet := BShape.BindungSet + 1;
      Connect := 1;
      SetAnlDir (1, AgentList);                     //--- Bewegung �bernehmen
      SetLength(FBindListOther, length(FBindListOther) + 1); //--- in BindListe aufnehmen
      BindListOther[High(FBindListOther)] := FNeigborList[K];
    end
    else If ((State = BShape.State) and (State = 0))//--- Agenten vom gleichen Typ
    Then Begin  //And (BShape.BindungSelf > 0)
      //BindungSelf := BindungSelf - 1;
      //BShape.BindungSelf := BShape.BindungSelf - 1;
      Connect := 2;
      BShape.Connect := 2;
      StepX := 0;                                   //--- Bewegung anhalten
      StepY := 0;
      SetLength(FBindListSelf, length(FBindListSelf) + 1);   //--- in BindListe aufnehmen
      BindListSelf[High(FBindListSelf)] := FNeigborList[K];
    end
    else begin
      If Connect = 0 Then SetRndDir(1.1);
    end;

    //--- Repel ---
    AShape := AgentList[FNeigborList[1]];
    If (State = AShape.State) Then Begin
      If (ShortestDSelf < AnlDist -  RepelDist) Then Begin  //(State = 0) And
        //---repel
        StepX := (random(3) - 1) + (-1 * (AShape.PositionX - PositionX)) / 20;
        StepY := (random(3) - 1) + (-1 * (AShape.PositionY - PositionY)) / 20;
      end;
    end;
  end;
end;

// ********************* Position in Abh. von Anlagerung *********************//
procedure TBaseShape.SetAnlDir (const damp: Double; const AgentList: TList); // --- damp bestimmt die St�rke des Richtungswechsels
var
  AShape : TAgent;
  BShape : TAgent;
  K      : Integer;
  who    : Integer;
begin
  who := 0;
  For K := 1 To length(FNeigborList)-1 Do
  Begin
    AShape:= AgentList[NeigborList[K]];
    BShape:= AgentList[NeigborList[who]];
    If AShape.State < BShape.State then who := K;
  end;
  AShape:= AgentList[NeigborList[who]];
  StepX := AShape.StepX;
  StepY := AShape.StepY;
end;

// ********************* Zuf�llige Richtungs�nderung *************************//
procedure TBaseShape.SetRndDir (const damp: Double); // --- damp bestimmt die St�rke des Richtungswechsels
begin
  StepX := (FStepX + (random(3) - 1)) * damp;
  StepY := (FStepY + (random(3) - 1)) * damp;
end;

// **************** Funktion zur Entfernungsberechnung **********************//
function TBaseShape.CalcDistance(pX: Integer; pY: Integer): Integer;
  var temp: double;
  begin
  temp := sqrt(Power((pX - FPositionX), 2) + Power((pY - FPositionY), 2));
  Result := Round(temp);
end;

// ********* Zeichnungseinstellungen f�r die Agentenrepr�sentation **********//
procedure TAgent.Paint(Canvas: TCanvas);
begin
  inherited Paint (Canvas);
  Canvas.Pen.Color := clGreen;
  Canvas.Pen.Style := psSolid; //(=psSolid, psDash, psDot, psClear)
  If State = 0 then FillColor := clRed;   //Canvas.Brush.Color := clRed;
  If State = 1 then FillColor := clBlue;
  If State = 2 then FillColor := clYellow;
  //Canvas.Brush.Color := FFillColor;
  Canvas.Ellipse (FPositionX - FSize , FPositionY - (FSize), FPositionX + (FSize), FPositionY + (FSize));
end;

procedure TBaseShape.SetConnect (const Value: Integer);
begin
  FConnect := Value;
end;

procedure TBaseShape.SetBindListSelf (Index: Integer; Value: Integer);
begin
  FBindListSelf[Index] := Value;
end;

function  TBaseShape.GetBindListSelf  (Index: Integer): Integer;
begin
  Result := FBindListSelf[index];
end;

procedure TBaseShape.SetBindlistOther (Index: Integer; Value: Integer);
begin
  FBindListOther[Index] := Value;
end;

function  TBaseShape.GetBindListOther  (Index: Integer): Integer;
begin
  Result := FBindListOther[index];
end;

procedure TBaseShape.SetNeigbor (Index: Integer; Value: Integer);
begin
  FNeigborList[Index] := Value;
end;

function  TBaseShape.GetNeigbor  (Index: Integer): Integer;
begin
  Result := FNeigborList[index];
end;

procedure TBaseShape.Paint (Canvas: TCanvas);
begin
  Canvas.Brush.Color := FFillColor;
  Canvas.Pen.Width := 1;
end;

procedure TBaseShape.SetBindungSet (const Value: Integer);
begin
  FBindungSet := Value;
end;

procedure TBaseShape.SetBindungMAx (const Value: Integer);
begin
  FBindungMax := Value;
end;

procedure TBaseShape.SetAnlDist (const Value: Integer);
begin
  FAnlDist := Value;
end;

procedure TBaseShape.SetRepelDist (const Value: Integer);
begin
  FRepelDist := Value;
end;

procedure TBaseShape.SetShortestD (const Value: Double);
begin
  FShortestD := Value;
end;

procedure TBaseShape.SetShortestDSelf (const Value: Double);
begin
  FShortestDSelf := Value;
end;

procedure TBaseShape.SetStepX(const Value: Double);
begin
  FStepX := Value;
end;

procedure TBaseShape.SetStepY(const Value: Double);
begin
  FStepY := Value;
end;

procedure TBaseShape.SetPositionX(const Value: Integer);
begin
  FPositionX := Value;
end;

procedure TBaseShape.SetPositionY(const Value: Integer);
begin
  FPositionY := Value;
end;

procedure TBaseShape.SetDistance(const Value: Integer);
begin
  FDistance := Value;
end;

procedure TBaseShape.SetSize(const Value: Integer);
begin
  FSize := Value;
end;

procedure TBaseShape.SetFillColor(const Value: Integer);
begin
  FFillColor := Value;
end;

procedure TBaseShape.SetState(const Value: Integer);
begin
  FState := Value;
end;

end.

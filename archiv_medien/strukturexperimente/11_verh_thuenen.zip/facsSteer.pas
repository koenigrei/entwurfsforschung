(********************************************************************)
(*                                                                  *) 
(*                                                                  *)
(*                       VERHANDLUNGSMODELL                         *)
(*               Landnutzungsmodell nach von Th�nen                 *)
(*                          Version 1.0                             *)
(*                                                                  *) 
(*     Programmierer: Reinhard K�nig                     July 2005  *)
(*                    http://www.entwurfsforschung.de/              *)
(*                                                                  *)
(*     Last Update: July-06, 2005                                   *)
(*                                                                  *) 
(********************************************************************) 
{revision history:

1.0     [July-06, 2005] 
        first release to the public
}

unit facsSteer;

interface

uses
  Windows, Messages, SysUtils, Variants, Classes, Graphics, Controls, Forms, cell,
  Dialogs, ExtCtrls, Grids, agenten, Math, ConvUtils, StdCtrls, AppEvnts, Types,
  Menus, calcer;

type
  TMovePlate = class(TForm)
    ScrollBar1         : TScrollBar;
    ApplicationEvents1 : TApplicationEvents;
    Label1             : TLabel;
    Label2             : TLabel;
    Button2            : TButton;
    Label3             : TLabel;
    Label_Radius       : TLabel;
    CB_moveMarkt       : TCheckBox;
    ButtonPause        : TButton;
    CB_Distanz         : TCheckBox;
    GroupBox1          : TGroupBox;
    ImagePaint         : TImage;
    GroupBox2          : TGroupBox;
    Label11            : TLabel;
    Lbl_AnbauErtr      : TLabel;
    SB_AnbauErtr       : TScrollBar;
    Label8             : TLabel;
    Lbl_ErzeugKost     : TLabel;
    SB_ErzeugKost      : TScrollBar;
    Label6             : TLabel;
    Lbl_MarktPr        : TLabel;
    SB_MarktPr         : TScrollBar;
    Label14            : TLabel;
    Lbl_TranspKost     : TLabel;
    SB_TranspKost      : TScrollBar;
    GroupBox3          : TGroupBox;
    Label4             : TLabel;
    Lbl_AnbauErtr2     : TLabel;
    Label9             : TLabel;
    Lbl_ErzeugKost2    : TLabel;
    Label12            : TLabel;
    Lbl_MarktPr2       : TLabel;
    Label15            : TLabel;
    Lbl_TranspKost2    : TLabel;
    SB_AnbauErtr2      : TScrollBar;
    SB_ErzeugKost2     : TScrollBar;
    SB_MarktPr2        : TScrollBar;
    SB_TranspKost2     : TScrollBar;
    GroupBox4          : TGroupBox;
    Label17            : TLabel;
    Lbl_AnbauErtr3     : TLabel;
    Label19            : TLabel;
    Lbl_ErzeugKost3    : TLabel;
    Label21            : TLabel;
    Lbl_MarktPr3       : TLabel;
    Label23            : TLabel;
    Lbl_TranspKost3    : TLabel;
    SB_AnbauErtr3      : TScrollBar;
    SB_ErzeugKost3     : TScrollBar;
    SB_MarktPr3        : TScrollBar;
    SB_TranspKost3     : TScrollBar;
    CB_Lagerente       : TCheckBox;
    B_delMarkt         : TButton;
    SB_TRad: TScrollBar;
    Lbl_TRad: TLabel;
    Label7: TLabel;
    Lbl_AnzGelb: TLabel;
    Label10: TLabel;
    SB_AnzGelb: TScrollBar;
    Lbl_AnzGruen: TLabel;
    Label16: TLabel;
    SB_AnzGruen: TScrollBar;
    Lbl_AnzWeiss: TLabel;
    Label20: TLabel;
    SB_AnzWeiss: TScrollBar;
    procedure SB_AnzGelbChange(Sender: TObject);
    procedure SB_AnzGruenChange(Sender: TObject);
    procedure SB_AnzWeissChange(Sender: TObject);
    procedure SB_TRadChange(Sender: TObject);
    procedure B_delMarktClick(Sender: TObject);
    procedure SB_TranspKost3Change(Sender: TObject);
    procedure SB_MarktPr3Change(Sender: TObject);
    procedure SB_TranspKost2Change(Sender: TObject);
    procedure SB_MarktPr2Change(Sender: TObject);
    procedure SB_ErzeugKost3Change(Sender: TObject);
    procedure SB_ErzeugKost2Change(Sender: TObject);
    procedure SB_AnbauErtr3Change(Sender: TObject);
    procedure SB_AnbauErtr2Change(Sender: TObject);
    procedure SB_TranspKostChange(Sender: TObject);
    procedure SB_MarktPrChange(Sender: TObject);
    procedure SB_ErzeugKostChange(Sender: TObject);
    procedure SB_AnbauErtrChange(Sender: TObject);
    procedure ImagePaintClick(Sender: TObject);
    procedure ButtonPauseClick(Sender: TObject);
    procedure Button2MouseUp(Sender: TObject; Button: TMouseButton;
      Shift: TShiftState; X, Y: Integer);
    procedure FormDestroy(Sender: TObject);
    procedure ImagePaintMouseMove(Sender: TObject; Shift: TShiftState; X,
      Y: Integer);
    procedure ApplicationEvents1Idle(Sender: TObject; var Done: Boolean);
    procedure PaintBox1Paint(Sender: TObject);
    procedure ScrollBar1Change(Sender: TObject);
    procedure FormCreate(Sender: TObject);
  private
    { Private declarations }
    ShapesList: TList;
    BewerberList: Array of Array of TList;
    CurrShape : TBaseShape;
    procedure CommonPaint (Canvas: TCanvas);
    procedure RegionPaint (Canvas: TCanvas; AShape: TAgent);
    procedure checkNeighbour (Canvas: TCanvas; xPos : Integer; yPos : Integer);
    procedure lookCell (Canvas: TCanvas);
    procedure cellStates (Canvas: TCanvas);
    procedure ChooseChange();
    procedure MakeMarkt      (mX: Integer; mY: Integer);
    procedure RectanglPaint  (Canvas: TCanvas);
    procedure RectanglCreate (Canvas: TCanvas);
    procedure SetzeErtrag    (const J : Integer);
    procedure SetzeErzeugKost(const J : Integer);
    procedure SetzeMarktPr   (const J : Integer);
    procedure SetzeTranspKost(const J : Integer);
    procedure makeOffer;
    procedure acceptOffer;
    procedure resetLists;
    procedure deleteZells;
    procedure checkVert(const wer: Integer);
  public
    { Public declarations }
  end;

var
  MovePlate: TMovePlate;

implementation

{$R *.dfm}

const
    NUM_BALLS = 100;
    cellScal  = 10;
    NumProd   = 3;
var
  reih      : Integer;
  spalt     : Integer;
  Dir       : Integer = 1;
  StepX     : Integer;
  StepY     : Integer;
  LEFT_BORDER   : Integer;
  TOP_BORDER    : Integer;
  RIGHT_BORDER  : Integer;
  BOTTOM_BORDER : Integer;
  Mouse_Rad     : Integer;
  MouseX        : Integer;
  MouseY        : Integer;
  Backpuffer    : TBitmap;
  cellList      : Array of Array of TCell;
  Abstand       : Integer;
  Sichtfeld     : Integer;
  test          : Integer;
  fertig        : Boolean;

function distance(pX1: Integer; pY1: Integer; pX2: Integer; pY2: Integer): Integer;
  var temp: double;
  begin
  temp := sqrt(Power((pX1 - pX2), 2) + Power((pY1 - pY2), 2));
  distance := Round(temp);
end;

procedure TMovePlate.FormCreate(Sender: TObject);
begin
  fertig := false;
  // --- deklarieren des Arrays f�r die 'Cellen' -------------------------------
  spalt := round (ImagePaint.Width / cellScal);
  reih  := round (ImagePaint.Height / cellScal);
  SetLength(cellList, reih, spalt);
  // --- initialization and creation of the list -------------------------------
  ShapesList                    := TList.Create;
  MovePlate.Color               := clBlack;
  MovePlate.Canvas.Pen.Color    := clred;
  MovePlate.Canvas.Brush.Color  := clred;
  LEFT_BORDER                   := ImagePaint.Left-5;
  TOP_BORDER                    := ImagePaint.Top-5;
  RIGHT_BORDER                  := ImagePaint.Width-5;
  BOTTOM_BORDER                 := ImagePaint.Height-5;
  // --- Slider & Label --------------------------------------------------------
  Mouse_Rad                     := ScrollBar1.Position;
  Label_Radius.Caption          := IntToStr(Mouse_Rad);
  Lbl_AnbauErtr.Caption         := IntToStr(SB_AnbauErtr.Position);
  Lbl_ErzeugKost.Caption        := IntToStr(SB_ErzeugKost.Position);
  Lbl_MarktPr.Caption           := IntToStr(SB_MarktPr.Position);
  Lbl_TranspKost.Caption        := IntToStr(SB_TranspKost.Position);
  //---
  Lbl_AnbauErtr2.Caption        := IntToStr(SB_AnbauErtr2.Position);
  Lbl_ErzeugKost2.Caption       := IntToStr(SB_ErzeugKost2.Position);
  Lbl_MarktPr2.Caption          := IntToStr(SB_MarktPr2.Position);
  Lbl_TranspKost2.Caption       := IntToStr(SB_TranspKost2.Position);
  //---
  Lbl_AnbauErtr3.Caption        := IntToStr(SB_AnbauErtr3.Position);
  Lbl_ErzeugKost3.Caption       := IntToStr(SB_ErzeugKost3.Position);
  Lbl_MarktPr3.Caption          := IntToStr(SB_MarktPr3.Position);
  Lbl_TranspKost3.Caption       := IntToStr(SB_TranspKost3.Position);
  //---
  Lbl_TRad.Caption              := IntToStr(SB_TRad.Position);
  Lbl_AnzGruen.Caption          := IntToStr(SB_AnzGruen.Position);
  Lbl_AnzGelb.Caption           := IntToStr(SB_AnzGelb.Position);
  Lbl_AnzWeiss.Caption          := IntToStr(SB_AnzWeiss.Position);
  // --- Zwischenspeicher f�r die Bildaktualisierung ---------------------------
  Backpuffer                    := TBitmap.create;
  Backpuffer.width              := ImagePaint.width;
  Backpuffer.height             := ImagePaint.height;
  Backpuffer.canvas.brush.color := clgreen;
  Backpuffer.canvas.rectangle   (10,10,Backpuffer.width,Backpuffer.height);
  RectanglCreate (Backpuffer.Canvas);
  MakeMarkt (400, 300);
end;

// *********************************
// *** ------- Agenten --------- ***
// *********************************
// *** Zeichnet die Agenten ***
procedure TMovePlate.PaintBox1Paint(Sender: TObject);
begin
  MovePlate.Color := clBlack;
  MovePlate.canvas.brush.color := clgreen;
  MovePlate.canvas.pen.color := clgreen;
  MovePlate.canvas.pen.width := 2;
  MovePlate.canvas.rectangle(5,5,810,610);
  MovePlate.refresh;
  CommonPaint (Canvas);
end;

procedure TMovePlate.CommonPaint (Canvas: TCanvas);
var
  I     : Integer;
  AShape: TAgent;
begin
  // repaint each shape of the list
  for I := 0 to ShapesList.Count - 1 do
  begin
    AShape := ShapesList.Items [I];
    AShape.BindungSet := 0; // --- Anzahl Bindungen je Typ zur�cksetzen
    AShape.Paint (Canvas);
  end;
end;

procedure TMovePlate.RegionPaint (Canvas: TCanvas; AShape: TAgent);
var
  I    : Integer;
  tmpD : Integer;
begin
  Canvas.Brush.Style := bsclear;  //!!!(=bsClear, bsSolid, bsCross)
  Canvas.Pen.Style := psDot;      //!!!(=psSolid, psDash, psDot, psClear, psDashDot)
  For I := 0 to 1 Do
  Begin
    tmpD := I *  AShape.RepelDist;
    Canvas.Ellipse (AShape.PositionX - AShape.AnlDist + tmpD , AShape.FPositionY - AShape.AnlDist + tmpD,
                    AShape.PositionX + AShape.AnlDist - tmpD , AShape.FPositionY + AShape.AnlDist - tmpD);
  end;
end;

// *** Aktualisierungen je Durchlauf***
procedure TMovePlate.ApplicationEvents1Idle(Sender: TObject; var Done: Boolean);
var
  I         : Integer;
  J         : Integer;
  AShape    : TAgent;
  distMouse : Integer;
  Area      : Trect;
begin
  If fertig = false then done := false;
  If fertig = true  then begin done := true; exit; end;
  //------------------------------------------//
  If (CB_moveMarkt.State = cbChecked) Then Begin
  for I := 0 to ShapesList.Count - 1 do
  begin
    AShape := ShapesList.Items [I];
    distMouse := distance (AShape.PositionX, AShape.PositionY, MouseX, MouseY);
    If (distMouse < Mouse_Rad) // --- MausInteraktion
    then begin
      AShape.FStepX := Dir * round ((AShape.PositionX - MouseX) * 0.1); //AShape.FStepX * -3;
      AShape.FStepY := Dir * round ((AShape.PositionY - MouseY) * 0.1); //AShape.FStepY * -3;
    end;
    AShape.SetRndDir (1.0001);
    // --- Randlos Torus--- // Rand nicht �berschreiten
    if AShape.PositionX < LEFT_BORDER  then
      AShape.PositionX := RIGHT_BORDER;
    if AShape.PositionX > RIGHT_BORDER then
      AShape.PositionX := LEFT_BORDER;
    if AShape.PositionY < TOP_BORDER then
      AShape.PositionY := BOTTOM_BORDER;
    if AShape.PositionY > BOTTOM_BORDER then
      AShape.PositionY := TOP_BORDER;
    // ++++ Position aktualisieren ++++
    AShape.PositionX := AShape.FPositionX + round(AShape.FStepX);
    AShape.PositionY := AShape.FPositionY + round(AShape.FStepY);
  end;
  end;

  // --- berechnen, zeichnen und verbinden ----
  RectanglPaint (Backpuffer.Canvas);  // --- L�scht Zeichung und Aktualisiert Zellen
  makeOffer;                          // --- Angebote an geeignetere Nachbarzellen senden
  acceptOffer;                        // --- Angebote auswerten und annehmen
  ChooseChange;                       // --- W�hlt und Tauscht Grdst
  resetLists;                         // --- L�scht die Vergl.- und Tauschlisten
  CommonPaint (Backpuffer.Canvas);    // --- Zeichnet die Zellen
  /// --- Bild aktualisieren ---
  //BitBlt(Backpuffer.Canvas.Handle, bildleft, bildtop, Bild.Width, Bild.Height, Bild.canvas.handle, 0, 0, SRCCOPY);//Bild auf Backpuffer kopieren
  ImagePaint.Invalidate;
  BitBlt(ImagePaint.Canvas.Handle, 0, 0, Backpuffer.Width, Backpuffer.Height, Backpuffer.canvas.handle, 0, 0, SRCCOPY);//Backpuffer auf das Formular kopieren
end;

procedure TMovePlate.ImagePaintMouseMove(Sender: TObject; Shift: TShiftState; X, Y: Integer);
begin
  MouseX := X;
  MouseY := Y;
end;


// *********************************
// *** ------- Zellen ---------- ***
//**********************************
// *** Erstellt das ZellenRaster ***
procedure TMovePlate.RectanglCreate (Canvas: TCanvas);
var
  I    : Integer;
  K    : Integer;
  J    : Integer;
  vert : Integer;
  p1   : Integer;
  p2   : Integer;
  p3   : Integer;
begin
  for I := 0 to reih -1 do
  begin
    for K := 0 to spalt -1 do
    begin
      vert := random (100);  // Gesamtzellen in %
      cellList[I,K]            := TCell.Create;
      cellList[I,K].AkzeptList := TList.Create;
      cellList[I,K].BewerbList := TList.Create;
      //--- Variablen in Abh. der Produkte dimensionieren ---
      SetLength(cellList[I,K].FLagerente,  NumProd);
      SetLength(cellList[I,K].FErtrag,     NumProd);
      SetLength(cellList[I,K].FErzeugKost, NumProd);
      SetLength(cellList[I,K].FTranspKost, NumProd);
      SetLength(cellList[I,K].FMarktPreis, NumProd);
      cellList[I,K].PositionX := K * cellScal + round(cellScal / 2);
      cellList[I,K].PositionY := I * cellScal + round(cellScal / 2);
      cellList[I,K].FReihPosY := I;
      cellList[I,K].FSpaltPosX:= K;
      cellList[I,K].Size := round (cellScal / 2)+1;
      // --- Verteilt die Anteile der versch. Fkt. -----------------------------
      p1 := SB_AnzGelb.Position;
      p2 := SB_AnzGruen.Position;
      p3 := SB_AnzWeiss.Position;
      If          vert < p1             Then begin cellList[I,K].State:= 0;
      end else If vert < (p1 + p2)      Then begin cellList[I,K].State:= 1;
      end else If vert < (p1 + p2 + p3) Then begin cellList[I,K].State:= 2;
      end else begin cellList[I,K].State := 99;
      end;
      cellList[I,K].Paint(Canvas);
    end ;
  end;
  //--- Werte in Variablen schreiben ---
  for J := 0 to NumProd -1 do
  begin
    SetzeErtrag    (J);
    SetzeErzeugKost(J);
    SetzeMarktPr   (J);
    SetzeTranspKost(J);
  end;
end;

// *** Aktualisiert das ZellenRaster ***
procedure TMovePlate.RectanglPaint (Canvas: TCanvas);
var
  I    : Integer;
  K    : Integer;
  used : Integer;
  dist : Integer;
begin
  //--- Backbuffer l�schen
  canvas.brush.color := clGreen;
  canvas.pen.color := clGreen;
  canvas.rectangle(10,10,Backpuffer.width,Backpuffer.height);
  for I := 0 to reih -1 do
  begin
    for K := 0 to spalt -1 do
    begin
      used := cellList[I,K].State;
      // --- Cellen berechnen ---
      cellList[I,K].FillColor := clBlack;  // --- Cellenfarbe l�schen
      cellList[I,K].NextMarkt(ShapesList); // --- N�chsten Markt je Celle festlegen
      //cellList[I,K].CalcOptLagerR;       // --- Lagerenten berechnen
      cellList[I,K].CalcLagerR;
      // -----------------------------------------------------------------------
      // --- Cellen anpassen ---
      // --- Wenn Schalter "Lagerente anzeigen" ein ---
      If (CB_Lagerente.State = cbChecked) Then Begin
        dist := round(cellList[I,K].MaxRente);
        If dist > 255 then dist := 255;
        If dist < 0 then dist := 0;
        dist := dist - cellList[I,K].Distance;
        If dist < 0 then dist := 0;
        cellList[I,K].FillColor := RGB (dist,dist,dist);
      end
      // --- Wenn Schalter "Distanzen anzeigen" ein ---
      else If (CB_Distanz.State = cbChecked) Then Begin
        dist := 255 - round (cellList[I,K].Distance /2);
        If dist < 0 then dist := 0;
        cellList[I,K].FillColor := RGB (dist,dist,dist);
      end
      else  begin
      // --- Wenn Schalter aus -> Th�nen Reinge zeichnen
        dist := round (cellList[I,K].MaxRente / 1);  //dist := round (cellList[I,K].Lagerente[used] / 1);
        If dist < 110 then dist := 110;
        If dist > 255 then dist := 255;
        case used of
          0: cellList[I,K].FillColor := RGB (dist,dist,0);
          1: cellList[I,K].FillColor := RGB (10,dist,10);
          2: cellList[I,K].FillColor := RGB (dist,dist,dist);
        end;
      end;
      // -----------------------------------------------------------------------
      cellList[I,K].Paint(Canvas);
    end ;
  end;
end;

//*** Grundbesitzer macht Anderen Angebote ***
procedure TMovePlate.makeOffer;
var
  U          : Integer;
  I          : Integer;
  K          : Integer;
  Ipos       : Integer; //--- Koordinaten der Nachbarn
  Kpos       : Integer; //--- Koordinaten der Nachbarn
  ind        : Integer;
  tmpLageR   : Integer;
  nachbarRent: Integer;
  Zelle      : TCell;
begin
  for I := 0 to reih -1 do
  begin
    for K := 0 to spalt -1 do
    begin
      If cellList[I,K].State < 99 Then Begin // --- Nur verhandeln, wenn Zelle mit Fkt besetzt.
        Zelle :=  cellList[I,K];
        Zelle.setNachbKoordi(reih, spalt, SB_TRad.Position); //--- berechnet die Koordinaten f�r Vergleich der Rente innerhalb des Tauschradius
        For U := 0 To 7 Do
        Begin
          Ipos := Zelle.nachbar[U].NPos.Y;
          Kpos := Zelle.nachbar[U].NPos.X;
          //--- Abst�nde der Nachbarn �bernehmen ---
          //--- Lagerente auf dem vergl Grundst�ck -----------
          Zelle.nachbar[U].NDist := cellList[Ipos, Kpos].FDistance;
          tmpLageR := Zelle.RechneLagerR(Zelle.FState, cellList[Ipos, Kpos].FDistance);
          nachbarRent := cellList[Ipos, Kpos].FMaxRente;
          //--- Wenn die Lagerente auf dem vergl Grdst h�her ist als auf dem bisherigen ---------
          If tmpLageR > cellList[I,K].FMaxRente Then Begin
            //--- Dann pr�fe, ob ebenfalls h�her als die bestehende auf dem vergl Grdst ----------
            If tmpLageR > nachbarRent Then Begin
              //--- Aufnahme in Bewerberliste ---
              cellList[Ipos,Kpos].BewerbList.Add (cellList[I,K]);
              ind :=  cellList[Ipos,Kpos].BewerbList.Count; //--- Index f�r den passenden rentenBetrag
              SetLength(cellList[Ipos,Kpos].NRent, ind);
              cellList[Ipos,Kpos].NRent[ind -1] := tmpLageR;
            end;
          end;
        end;
      end;
    end;
  end;
end;

// *** Verhandeln : Angebote auswerten, zur�cksenden und annehmen **************
procedure TMovePlate.acceptOffer;
var
  I        : Integer;
  K        : Integer;
  U        : Integer;
  ind      : Integer;
  Zelle    : TCell;
  ZelleUrsp: TCell;
  bestRt   : Integer; // -- h�chste Rente der Bewerber
  tmpLageR : Integer;
Begin
  // --- Bewerber ausw�hlen -> nach h�chste Lagerente ------------------------//
  for I := 0 to reih -1 do
  begin
    for K := 0 to spalt -1 do
    begin
      bestRt := -2147483647;
      Zelle := cellList[I,K];
      //--- Wenn Bewerber vorhanden, besten Bewerber ausw�hlen ---------------//
      If Zelle.BewerbList.Count > 0 then begin
        for U:=0 to Zelle.BewerbList.Count -1 do
        begin
          tmpLageR  := Zelle.NRent[U];
          IF tmpLageR > bestRt Then begin
            bestRt := tmpLageR;  //--- Wert der h�chsten Rente suchen
          end;
        end;
        // --- speichert beim Bewerber, wo er genommen wurde -----------------//
        for U:=0 to Zelle.BewerbList.Count -1 do
        begin
          ZelleUrsp := Zelle.BewerbList.Items[U];
          tmpLageR  := Zelle.NRent[U];
          IF tmpLageR = bestRt Then begin
            ZelleUrsp.AkzeptList.Add(Zelle);     //--- Akzeptierten Bewerbungsort zur�ckgeben
            ind := ZelleUrsp.AkzeptList.Count;   //--- Index f�r den passenden rentenBetrag
            SetLength(ZelleUrsp.ARent, ind);
            ZelleUrsp.ARent[ind -1] := tmpLageR; //--- Hier erzielbare Rente zur�ckgeben
          end;
        end;
      end;
    end;
  end;
end;

// *** Verhandeln : Zur�chgegebene Angebote annehmen und Tausch durchf�hren*****
procedure TMovePlate.ChooseChange();
var
  I        : Integer;
  K        : Integer;
  U        : Integer;
  Zelle    : TCell;
  ZelleZiel: TCell;
  bestAngeb: Integer;
  tmpAngeb : Integer;
  cngZiel  : Integer;
  tmpState : Integer;
begin
  // --- Neues Grdst ausw�hlen und tauschen --- // --- dabei alte "Adresse" hinterlassen
  for I := 0 to reih -1 do
  begin
    for K := 0 to spalt -1 do
    begin
      Zelle := cellList[I,K];
      If Zelle.AkzeptList.Count > 0 then begin   // --- Wenn Angebote akteptiert wurden,
        bestAngeb := -2147483647;              // --- bestes Ziel ausw�hlen ----------
        for U:=0 to Zelle.AkzeptList.Count -1 do
        begin
          tmpAngeb := Zelle.ARent[U];
          If tmpAngeb > bestAngeb Then begin
            bestAngeb := tmpAngeb;
            cngZiel   := U;
          end;
        end;
        // --- Fkt mit dem Ziel Grdst (cngZiel) tauschen ----
        ZelleZiel := Zelle.AkzeptList.Items [cngZiel];
        tmpState          := ZelleZiel.State;
        ZelleZiel.State   := cellList[I,K].State;
        cellList[I,K].State := tmpState;
      end;
    end;
  end;
  resetLists;
end;

// *** listen zur�cksetzen ****
procedure TMovePlate.resetLists;
var
  I : Integer;
  K : Integer;
begin
  for I := 0 to reih -1 do
  begin
    for K := 0 to spalt -1 do
    begin
      SetLength(cellList[I,K].NRent, 0);
      SetLength(cellList[I,K].ARent, 0);
      cellList[I,K].AkzeptList.Free;
      cellList[I,K].BewerbList.Free;
      cellList[I,K].AkzeptList := TList.Create;
      cellList[I,K].BewerbList := TList.Create;
    end;
  end;
end;

//*** Berechnet die Celle unter dem Agenten ***
procedure TMovePlate.lookCell (Canvas: TCanvas);
var
  I      : Integer;
  AShape : TAgent;
  XCell  : Integer;
  YCell  : Integer;
begin
  for I := 0 to ShapesList.Count - 1 do
  begin
    AShape := ShapesList.Items [I];
    XCell := round((AShape.FPositionX - (cellScal / 2)) / (cellScal));
    YCell := round((AShape.FPositionY - (cellScal / 2)) / (cellScal));
    If not (((XCell < 0) or (XCell > spalt-1)) or ((YCell < 0) or (YCell > reih-1))) then
    begin
      cellList[YCell,XCell].State := AShape.FState +1; //+ RGB (3,4,5);
    end;
  end;
end;

procedure TMovePlate.cellStates (Canvas: TCanvas);
var
  I: Integer;
  K: Integer;
begin
  for I := 1 to reih -2 do
  begin
    for K := 1 to spalt -2 do
    begin
      checkNeighbour (Backpuffer.Canvas, I, K);
    end ;
  end;
end;

procedure TMovePlate.checkNeighbour (Canvas: TCanvas; xPos : Integer; yPos : Integer);
var
  I: Integer;
  K: Integer;
  state : Integer;
begin
  state := 0;
  for I := xPos - 1 to xPos + 1 do
  begin
    for K := yPos - 1 to yPos + 1 do
    begin
      //If not ((I = xPos) and (K = yPos)) then
      If (cellList[I,K].State = 1) then state := state - 55;
      If (cellList[I,K].State = 2) then state := state + 50;
    end;
  end;
  //limboWorld[xPos,yPos] := state;
end;

// *** Zellen l�schen ***
procedure TMovePlate.deleteZells;
var
  I : Integer;
  K : Integer;
begin
  for I := reih -1 downto 0 do
  begin
    for K := spalt -1 downto 0 do
    begin
      TBaseCell (cellList[I,K]).Free;
    end;
  end;
end;

// ***************************
// ********* Buttons *********
// ***************************
//
// *** Repel - Attract - Button ***
procedure TMovePlate.Button2MouseUp(Sender: TObject; Button: TMouseButton;
  Shift: TShiftState; X, Y: Integer);
begin
  Dir := Dir * (-1);
end;

// *** einzelne Agenten erstellen ***
procedure TMovePlate.ImagePaintClick(Sender: TObject);
begin
  MakeMarkt (MouseX, MouseY);
end;

procedure TMovePlate.MakeMarkt (mX: Integer; mY: Integer);
begin
  CurrShape := TAgent.Create;
  CurrShape.PositionX :=  mX;
  CurrShape.PositionY :=  mY;
  CurrShape.StepX := (random(3) - 1);
  CurrShape.StepY := (random(3) - 1);
  CurrShape.Size := 3;
  CurrShape.Connect := 0;
  CurrShape.State := 0;
  ShapesList.Add (CurrShape);
  CommonPaint (ImagePaint.Canvas);
  Label2.Caption := IntToStr(ShapesList.Count);
end;

procedure TMovePlate.B_delMarktClick(Sender: TObject);
var
  I: Integer;
  K: Integer;
begin
  // --- delete each market ---
  ShapesList.Count := 0;
  {for I := 0 to reih -1 do
  begin
    for K := 0 to spalt -1 do
    begin
        cellList[I,K].State := 99;
    end;
  end;}
end;

// *** Pause ***
procedure TMovePlate.ButtonPauseClick(Sender: TObject);
begin
  fertig := Not fertig; //true;
  If MovePlate.Color = clRed Then begin
    MovePlate.Color := clBlack;
    exit;
  end;
  MovePlate.Color := clRed;
end;

// ***************************
// ******* ScrollBars ********
// ***************************

// *** Prozentangaben der Verteilung �berpr�fen ***
procedure TMovePlate.checkVert(const wer: Integer);
var
  p1     : Integer;
  p2     : Integer;
  p3     : Integer;
  sum    : Integer;
  differ : Integer;
  SB1    : TScrollBar;
  SB2    : TScrollBar;
  lbl1   : TLabel;
  lbl2   : TLabel;
begin
  p1 := SB_AnzGelb.Position;
  p2 := SB_AnzGruen.Position;
  p3 := SB_AnzWeiss.Position;
  sum := 0;
  differ := 0;
  sum := p1 + p2 + p3;
  If sum > 100 Then begin
    differ := sum - 100;
    If wer = 1 Then begin
      SB1  := SB_AnzGruen;
      SB2  := SB_AnzWeiss;
      lbl1 := Lbl_AnzGruen;
      lbl2 := Lbl_AnzWeiss;
    end;
    If wer = 2 Then begin
      SB1  := SB_AnzGelb;
      SB2  := SB_AnzWeiss;
      lbl1 := Lbl_AnzGelb;
      lbl2 := Lbl_AnzWeiss;
    end;
    If wer = 3 Then begin
      SB1  := SB_AnzGruen;
      SB2  := SB_AnzGelb;
      lbl1 := Lbl_AnzGruen;
      lbl2 := Lbl_AnzGelb;
    end;

    If SB1.Position > 0 Then begin
      SB1.Position := SB1.Position - round(differ/2);
      lbl1.Caption := IntToStr(SB1.Position);
    end else begin
      SB2.Position := SB2.Position - round(differ/2);
      lbl2.Caption := IntToStr(SB2.Position);
    end;
    If SB2.Position > 0 Then begin
      SB2.Position := SB2.Position - round(differ/2);
      lbl2.Caption := IntToStr(SB2.Position);
    end else begin
      SB1.Position := SB1.Position - round(differ/2);
      lbl1.Caption := IntToStr(SB1.Position);
    end;
  end;
end;

// -----------------------------------------------------------------------------
// *** Mengenverteilung der Nutzungen ******************************************
procedure TMovePlate.SB_AnzGelbChange(Sender: TObject);
begin
  Lbl_AnzGelb.Caption := IntToStr(SB_AnzGelb.Position);
  deleteZells;
  RectanglCreate (Backpuffer.Canvas);
  checkVert(1);
end;

procedure TMovePlate.SB_AnzGruenChange(Sender: TObject);
begin
  Lbl_AnzGruen.Caption := IntToStr(SB_AnzGruen.Position);
  deleteZells;
  RectanglCreate (Backpuffer.Canvas);
  checkVert(2);
end;

procedure TMovePlate.SB_AnzWeissChange(Sender: TObject);
begin
   Lbl_AnzWeiss.Caption := IntToStr(SB_AnzWeiss.Position);
   deleteZells;
   RectanglCreate (Backpuffer.Canvas);
   checkVert(3);
end;
// -----------------------------------------------------------------------------

// *** Tasuchradius ***
procedure TMovePlate.SB_TRadChange(Sender: TObject);
begin
  Lbl_TRad.Caption := IntToStr(SB_TRad.Position);
end;

// *** MausInteraktionsRadius ***
procedure TMovePlate.ScrollBar1Change(Sender: TObject);
begin
    Mouse_Rad            := ScrollBar1.Position;
    Label_Radius.Caption := IntToStr(Mouse_Rad);
end;

// *** ***
procedure TMovePlate.SB_AnbauErtrChange(Sender: TObject);
begin
  Lbl_AnbauErtr.Caption := IntToStr(SB_AnbauErtr.Position);
  SetzeErtrag (0);
end;

procedure TMovePlate.SB_AnbauErtr2Change(Sender: TObject);
begin
  Lbl_AnbauErtr2.Caption := IntToStr(SB_AnbauErtr2.Position);
  SetzeErtrag (1);
end;

procedure TMovePlate.SB_AnbauErtr3Change(Sender: TObject);
begin
  Lbl_AnbauErtr3.Caption := IntToStr(SB_AnbauErtr3.Position);
  SetzeErtrag (2);
end;

procedure TMovePlate.SetzeErtrag(const J : Integer);
var
  I : Integer;
  K : Integer;
begin
  for I := 0 to reih -1 do
  begin
    for K := 0 to spalt -1 do
    begin
      case J of
        0: cellList[I,K].Ertrag[J] := SB_AnbauErtr.Position;
        1: cellList[I,K].Ertrag[J] := SB_AnbauErtr2.Position;
        2: cellList[I,K].Ertrag[J] := SB_AnbauErtr3.Position;
      end;
    end;
  end;
end;

// ***  ***
procedure TMovePlate.SB_ErzeugKostChange(Sender: TObject);
begin
  Lbl_ErzeugKost.Caption := IntToStr(SB_ErzeugKost.Position);
  SetzeErzeugKost (0);
end;

procedure TMovePlate.SB_ErzeugKost2Change(Sender: TObject);
begin
  Lbl_ErzeugKost2.Caption := IntToStr(SB_ErzeugKost2.Position);
  SetzeErzeugKost (1);
end;

procedure TMovePlate.SB_ErzeugKost3Change(Sender: TObject);
begin
  Lbl_ErzeugKost3.Caption := IntToStr(SB_ErzeugKost3.Position);
  SetzeErzeugKost (2);
end;

procedure TMovePlate.SetzeErzeugKost(const J : Integer);
var
  I : Integer;
  K : Integer;
begin
  for I := 0 to reih -1 do
  begin
    for K := 0 to spalt -1 do
    begin
      case J of
        0: cellList[I,K].ErzeugKost[J] := SB_ErzeugKost.Position;
        1: cellList[I,K].ErzeugKost[J] := SB_ErzeugKost2.Position;
        2: cellList[I,K].ErzeugKost[J] := SB_ErzeugKost3.Position;
      end;
    end;
  end;
end;

// *** ***
procedure TMovePlate.SB_MarktPrChange(Sender: TObject);
begin
  Lbl_MarktPr.Caption := IntToStr(SB_MarktPr.Position);
  SetzeMarktPr(0);
end;

procedure TMovePlate.SB_MarktPr2Change(Sender: TObject);
begin
  Lbl_MarktPr2.Caption := IntToStr(SB_MarktPr2.Position);
  SetzeMarktPr(1);
end;

procedure TMovePlate.SB_MarktPr3Change(Sender: TObject);
begin
  Lbl_MarktPr3.Caption := IntToStr(SB_MarktPr3.Position);
  SetzeMarktPr(2);
end;

procedure TMovePlate.SetzeMarktPr(const J : Integer);
var
  I : Integer;
  K : Integer;
begin
  for I := 0 to reih -1 do
  begin
    for K := 0 to spalt -1 do
    begin
      case J of
        0: cellList[I,K].MarktPreis[J] := SB_MarktPr.Position;
        1: cellList[I,K].MarktPreis[J] := SB_MarktPr2.Position;
        2: cellList[I,K].MarktPreis[J] := SB_MarktPr3.Position;
      end;
    end;
  end;
end;

procedure TMovePlate.SB_TranspKostChange(Sender: TObject);
begin
  Lbl_TranspKost.Caption := IntToStr(SB_TranspKost.Position);
  SetzeTranspKost(0);
end;

procedure TMovePlate.SB_TranspKost2Change(Sender: TObject);
begin
  Lbl_TranspKost2.Caption := IntToStr(SB_TranspKost2.Position);
  SetzeTranspKost(1);
end;

procedure TMovePlate.SB_TranspKost3Change(Sender: TObject);
begin
  Lbl_TranspKost3.Caption := IntToStr(SB_TranspKost3.Position);
  SetzeTranspKost(2);
end;

procedure TMovePlate.SetzeTranspKost(const J : Integer);
var
  I : Integer;
  K : Integer;
begin
  for I := 0 to reih -1 do
  begin
    for K := 0 to spalt -1 do
    begin
      case J of
        0: cellList[I,K].TranspKost[J] := SB_TranspKost.Position;
        1: cellList[I,K].TranspKost[J] := SB_TranspKost2.Position;
        2: cellList[I,K].TranspKost[J] := SB_TranspKost3.Position;
      end;
    end;
  end;
end;

// ******************************
// *** Array und Liste L�schen***
// ******************************
procedure TMovePlate.FormDestroy(Sender: TObject);
var
  I: Integer;
  J: Integer;
  K: Integer;
begin
  // --- delete each agent
  for I := ShapesList.Count - 1 downto 0 do
    TBaseShape (ShapesList [I]).Free;
  ShapesList.Free;
  // --- delete each cell
  deleteZells;
end;

end.

(********************************************************************)
(*                                                                  *) 
(*                                                                  *)
(*                     Diffusion-Contact Model                      *)
(*                          Version 1.0                             *)
(*                                                                  *)
(*                                                                  *)
(*     Programmierer: Reinhard K�nig                  December 2005 *)
(*                    http://www.entwurfsforschung.de/              *)
(*                                                                  *)
(*     Last Update: Dec-17, 2005                                    *)
(*                                                                  *)
(********************************************************************) 
{revision history:

1.0     [Dec-17, 2005]
        first release to the public

}

unit CellForm;

interface

uses
  Windows, Messages, SysUtils, Variants, Classes, Graphics, Controls, Forms,
  Dialogs, StdCtrls, cell_P, ExtCtrls, ButtonGroup, ComCtrls, Math, ToolWin,
  ImgList, Epina.SDL.rchart, agenten;

type
  TForm1 = class(TForm)
    ZeichenPanel   : TPanel;
    Timer1         : TTimer;
    lbl_Steps      : TLabel;
    B_setup        : TButton;
    lbl_timesteps  : TLabel;
    Lbl_TextSwelle : TLabel;
    Edit_thresh    : TEdit;
    B_stop         : TButton;
    RChart1        : TRChart;
    Lbl_TextAnzahl : TLabel;
    Edit_anzAg     : TEdit;
    procedure B_stopClick(Sender: TObject);
    procedure B_setupClick(Sender: TObject);
    procedure Timer1Timer(Sender: TObject);
    procedure FormDestroy(Sender: TObject);
    procedure FormCreate(Sender: TObject);
  private
    AgentList    : TList;
    cellList     : Array of Array of TCell;
    limboWorld   : Array of Array of Extended;
    function  CalcDistance(pAX: Integer; pAY: Integer; pBX: Integer; pBY: Integer): Integer;
    procedure createPaintImg;
    procedure createRaster;
    procedure createAgents;
    procedure setupCells;
    procedure setupAgents;
    //procedure CommonPaint (Canvas: TCanvas);
    procedure checkNei (K, I: Integer);
    function  rndN(lower : Integer; upper : Integer):Integer;
  public
end;

var
  Form1    : TForm1;
  paintImg : TImage;

implementation

{$R *.dfm}

const                            //-- globale Konstanten
  cellScal  = 3;                 //-- Zellen  gr��e
  AgSize    = 1;                 //-- Agenten gr��e
  halfScal  = round(cellScal/2);
var                              //-- globale Variablen
  reih  : Integer;               //-- Zellen-Reihen gesamt
  spalt : Integer;               //-- Zellen-Spalten gesamt
  steps : Integer;
  Xmax  : Integer;
  Ymax  : Integer;

// ---------------------------------------------------------------------------//
// *** Initialisierung ***
procedure TForm1.FormCreate(Sender: TObject);
begin
  spalt := round (ZeichenPanel.Width / cellScal);
  reih  := round (ZeichenPanel.Height / cellScal);
  Xmax  := (spalt) * cellScal;
  Ymax  := (reih ) * cellScal;
  AgentList := TList.Create;
  SetLength(cellList, spalt, reih);
  SetLength(limboWorld, spalt, reih);
  createPaintImg;
  CreateRaster;
  CreateAgents;
  ZeichenPanel.DoubleBuffered := True;       //-- Verhindert Flackern der Zellen
  steps := 0;

  // -- Diagramm initialisieren --
  RChart1.Scale1X.RangeLow  := 0;     { range of chart area }
  RChart1.Scale1X.RangeHigh := 1000;  //-- Maximale Reichweite = 1000 bei Testversion!!!
  RChart1.Scale1Y.RangeLow  := 0;
  RChart1.Scale1Y.RangeHigh := StrToInt(Edit_anzAg.Text)+50;
end;

// ---------------------------------------------------------------------------//

// *** Legt eine leere Zeichenfl�che �ber das Zeichenpanel ***
procedure TForm1.createPaintImg;
begin
  paintImg        := TImage.Create(self);
  paintImg.Parent := ZeichenPanel;
  paintImg.top    := 0;
  paintImg.Left   := 0;
  paintImg.Height := ZeichenPanel.Height;
  paintImg.Width  := ZeichenPanel.Width;
end;

// *** Erstellt das Raster ***
function TForm1.rndN(lower : Integer; upper : Integer):Integer;
begin
  Result := round ((upper - lower + 1) * Random() + lower);
end;

procedure TForm1.CreateAgents;
var
  I        : Integer;
  curAgent : TAgent;
begin
  for I := 1 to StrToInt(Edit_anzAg.Text) do //   StrToInt(Edi_NrRed.Text) Do
  begin
    curAgent := TAgent.Create;
    AgentList.Add (curAgent);     // ---  add to the list
  end;
  setupAgents;
end;

// *** Zellen erstellen ***
procedure TForm1.CreateRaster;
var
  curCell : TCell;
  I       : Integer;
  K       : Integer;
  upperB  : Integer;
  lowerB  : Integer;
begin
  for I := 0 to reih -1 do
  begin
    for K := 0 to spalt -1 do
    begin
      curCell := TCell.Create(halfScal + K * cellScal, halfScal + I * cellScal, halfScal, 0);
      cellList[K,I] := curCell;
    end;
  end;
  setupCells;
end;

// *** Agenten initialisieren ***
procedure TForm1.setupAgents;
var
  curAgent : TAgent;
  I        : Integer;
begin
  Randomize();
  for I := 0 to AgentList.Count - 1 do
  begin
    curAgent := AgentList.Items [I];
    curAgent.PosX    := random (spalt)* cellScal + halfScal;
    curAgent.PosY    := random (reih) * cellScal + halfScal;
    curAgent.Heading := (random(8) * 45);
    curAgent.Size    := AgSize;
    curAgent.State   := 1;
    curAgent.Paint (paintImg.Canvas);
  end;
end;

// *** Zellen initialisieren ***
procedure TForm1.setupCells;
var
  curCell : TCell;
  I       : Integer;
  K       : Integer;
begin
  Randomize();
  for I := 0 to reih -1 do
  begin
    for K := 0 to spalt -1 do
    begin
      curCell       := cellList[K,I];
      curCell.State := 0;
      curCell.colr  := 0; //curCell.State;
      curCell.Paint(paintImg.Canvas);
    end;
  end;
  RChart1.ClearGraf;      { initialize chart }
  RChart1.MoveTo (0,0);
end;

// ---------------------------------------------------------------------------//
// --- Moorsche Nachbarschaft, mit den Abstand 1 �berpr�fen
procedure TForm1.checkNei (K, I: Integer);
var
  u  : Integer;
  v  : Integer;
  Xp : Integer;
  Yp : Integer;
begin
  // --- Summe berechnen ---
  for v := -1 to 1 do
  begin
    for u := -1 to 1 do
    begin
      Xp := K + u;
      Yp := I + v;
      // -- Torus --
      if Xp < 0       then Xp := spalt-1;
      if Xp > spalt-1 then Xp := 0;
      if Yp < 0       then Yp := reih-1;
      if Yp > reih-1  then Yp := 0;
      cellList[K,I].neighSum := cellList[K,I].neighSum + cellList[Xp, Yp].state;
    end;
  end;
end;

// *** Rekursive Befehle ausf�hren ***
procedure TForm1.Timer1Timer(Sender: TObject);
var
  curCell : TCell;
  curAgent: TAgent;
  I       : Integer;
  K       : Integer;
  M       : Integer;
  agCount : Integer;
  agReih  : Integer;
  agSpalt : Integer;
  fin     : Boolean;
begin
  fin := true;
  // --- Zellen zur�cksetzen und zeichnen ---
  for I := 0 to reih -1 do
  begin
    for K := 0 to spalt -1 do
    begin
      curCell := cellList[K,I];
      If curCell.colr = 0 Then curCell.State := 0;
      curCell.neighSum := 0;
      SetLength(curCell.AgNr, 0);
      curCell.Paint (paintImg.Canvas);
    end;
  end;

  agCount := 0;
  // --- Agenten �ndern und zeichnen ---
  for I := 0 to AgentList.Count - 1 do
  begin
    curAgent := AgentList.Items [I];
    If curAgent.State = 1 then       // -- Wenn Agent noch nicht angelagert,
    begin                            // -- zuf�llig weiterbewegen
      fin := false;
      agCount := agCount +1;
      curAgent.ChangeHeading(2);
      curAgent.PosX := curAgent.PosX + curAgent.stepX * cellScal;
      curAgent.PosY := curAgent.PosY + curAgent.stepY * cellScal;
      if curAgent.PosX < 0     then curAgent.PosX := Xmax     - halfScal;
      if curAgent.PosX > xMax  then curAgent.PosX := cellScal - halfScal;
      if curAgent.PosY < 0     then curAgent.PosY := Ymax     - halfScal;
      if curAgent.PosY > yMax  then curAgent.PosY := cellScal - halfScal;
    end;
    // -- Zelle unter Agent finden und markieren.
    agSpalt := round((curAgent.PosX - halfScal) / cellScal);
    agReih  := round((curAgent.PosY - halfScal) / cellScal);
    curCell := cellList[agSpalt, agReih];
    curCell.State := curCell.State + 1;
    // -- Agent auf Zelle in Zelle speichern
    SetLength(curCell.AgNr, curCell.State);
    curCell.AgNr[curCell.State-1] := I;
    // -- Agenten und Zellen zeichnen
    curCell.Paint  (paintImg.Canvas);
    curAgent.Paint (paintImg.Canvas);
  end;
  // -- Wenn alle Agenten angelagert sind, anhalten
  If fin = true then Timer1.enabled := false;

  // -- Zellennachbarschaft �berpr�fen
  for I := 0 to reih -1 do
  begin
    for K := 0 to spalt -1 do
    begin
      checkNei(K, I);             // -- Z�hlt die Agenten in der Moore Nachbarschaft
      curCell := cellList[K,I];
      If ((curCell.neighSum > StrToInt(Edit_thresh.Text)) // -- Anzahl Agenten in Nachbarshcaft > Threshold
      and (curCell.colr  = 0)                             // -- Zelle noch nicht besetzt
      and (Length(curCell.AgNr) > 0)) Then                // -- Mindestens ein Agent auf Zelle
      begin
        curCell.colr  := 255;
        for M := 0 to Length(curCell.AgNr)-1 Do
        begin
          curAgent := AgentList.Items [curCell.AgNr[M]]; // -- Agenten �ber Zelle ermitteln
          curAgent.State := 0;                           // -- Agenten anlagern
        end;
        curCell.Paint (paintImg.Canvas);
      end;
    end;
  end;

  steps := steps +1;
  lbl_Steps.Caption := intToStr (steps);

  if steps < 1000 then begin // -- Maximalwert Plotten
    //RChart1.Scale1Y.RangeHigh := maxP;
    RChart1.DataColor := clRed;
    RChart1.DrawTo (steps, agCount);
    //RChart1.DataColor := clBlack;
    //RChart1.DrawTo (steps, Pavg*10);
    RChart1.ShowGraf;
  end;                                  
end;

function TForm1.CalcDistance(pAX: Integer; pAY: Integer; pBX: Integer; pBY: Integer): Integer;
var
  temp : double;
begin
  temp := sqrt(Power((pAX - pBX), 2) + Power((pAY - pBY), 2));
  Result := Round(temp);
end;

procedure TForm1.FormDestroy(Sender: TObject);
begin
  paintImg.Free;
  ZeichenPanel.Free;
  AgentList.Destroy;
end;

procedure TForm1.B_setupClick(Sender: TObject);
begin
  steps := 0;
  AgentList.Destroy;
  AgentList := TList.Create;
  RChart1.Scale1Y.RangeHigh := StrToInt(Edit_anzAg.Text)+50;
  setupCells;
  createAgents;
end;

procedure TForm1.B_stopClick(Sender: TObject);
begin
  Timer1.enabled := not(Timer1.enabled);
end;

end.

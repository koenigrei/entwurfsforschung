unit agenten;

interface

uses
  Windows, Graphics;

type
  TAgent = class
  private
    function  rndN(lower : Integer; upper : Integer):Integer;
  public
    State      : Integer;
    FPosX      : Integer;
    FPosY      : Integer;
    FSize      : Integer;
    FHeading   : Integer;                           // -- Anfangsausrichtung
    FStepX     : Integer;
    FStepY     : Integer;
    procedure Paint       (Canvas: TCanvas);
    procedure SetPosX     (const Value: Integer);
    procedure SetPosY     (const Value: Integer);
    procedure SetStepX    (const Value: Integer);
    procedure SetStepY    (const Value: Integer);
    procedure SetHeading  (const Value: Integer);
    procedure SetSize     (const Value: Integer);
  published
    property PosX    : Integer read FPosX    write SetPosX;
    property PosY    : Integer read FPosY    write SetPosY;
    property StepX   : Integer read FStepX   write SetStepX;
    property StepY   : Integer read FStepY   write SetStepY;
    property Heading : Integer read FHeading write SetHeading;
    property Size    : Integer read FSize    write SetSize;
    procedure ChangeHeading(const Value: Integer); // -- Maximale Richtungs�nderung angeben
  end;

implementation

function TAgent.rndN(lower : Integer; upper : Integer):Integer;
begin
  Result := round ((upper - lower + 1) * Random() + lower);
end;

procedure TAgent.SetHeading(const Value: Integer);
begin
  FHeading := Value;
end;

procedure TAgent.ChangeHeading(const Value: Integer);
begin
  FHeading := FHeading + ((rndN(-1 * Value, Value)) * 45); //-- Achtung bei Value = 4 => 180� kommen �fter vor.
  SetStepX(FHeading);
  SetStepY(FHeading);
end;

procedure TAgent.SetStepX(const Value: Integer);
begin
  FStepX := round(sin(Value));
end;

procedure TAgent.SetStepY(const Value: Integer);
begin
  FStepY := round(cos(Value));
end;

procedure TAgent.SetPosX(const Value: Integer);
begin
  FPosX := Value;
end;

procedure TAgent.SetPosY(const Value: Integer);
begin
  FPosY := Value;
end;

procedure TAgent.SetSize(const Value: Integer);
begin
  FSize := Value;
end;

procedure TAgent.Paint (Canvas: TCanvas);
begin
  Canvas.Pen.Color := clRed;
  Canvas.Pen.Width := 1;
  Canvas.Brush.Color := clRed;
  Canvas.Ellipse (FPosX - FSize , FPosY - (FSize), FPosX + (FSize), FPosY + (FSize));
end;

end.

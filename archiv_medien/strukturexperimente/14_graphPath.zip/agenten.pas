unit agenten;

interface

uses
  Windows, Graphics, Classes, Math;

type TNachb = record     // --- f�r A* Heuristik
      nr: Integer;       // --- = NeigborList
      dist : Integer;    // --- entfernung zum Nachbarn
end;

type
  TBaseShape = class
  private
    procedure Anlagern (const I: Integer; const AgentList: TList);
  public
    F  : Integer;
    G  : Integer;
    H  : Integer;
    Vorg : Pointer;
    closed : Boolean;
    NachbList : Array of TNachb;
    //--------------------------------------------------------------------------
    FPositionX    : Integer;  // XKoordinate
    FPositionY    : Integer;  // YKoordinate
    FSize         : Integer;  // Gr��e des Agenten
    FStepX        : Double;   // X-Anteil des Bewegungsvektors
    FStepY        : Double;   // Y-Anteil des Bewegungsvektors
    FFillColor    : Integer;  // Farbe des Agenten
    FState        : Integer;  // Art des Agenten
    FAnlDist      : Integer;  // Radius innerhalb dessen sich gleichfarbige Agenten agstossen = Repel
    FRepelDist    : Integer;  // Radius innerhalb dessen eine Anlagerung m�glich ist
    FBindungSet   : Integer;  // Anzahl der freien Bindungen f�r gleiche Agenten
    FShortestD    : Double;   // K�rzester Abstand zu einem beliebigen Nachbarn
    FShortestDSelf: Double;   // K�rzester Abstand zu einem gleichen Nachbarn
    FConnect      : Integer;  // Gibt an, ob ein Agent gebunden ist
    FDistance     : Integer;
    FNeigborList  : Array of Integer;
    FBindListSelf : Array of Integer;
    FBindListOther: Array of Integer;
    procedure Paint           (Canvas: TCanvas); virtual;
    procedure SetNeigbor      (Index: Integer; Value: Integer);
    function  GetNeigbor      (Index: Integer): Integer;
    procedure SetBindListSelf (Index: Integer; Value: Integer);
    function  GetBindListSelf (Index: Integer): Integer;
    procedure SetBindListOther(Index: Integer; Value: Integer);
    function  GetBindListOther(Index: Integer): Integer;
    property  NeigborList     [Index: Integer]: Integer read GetNeigbor write SetNeigbor;
    property  BindListSelf    [Index: Integer]: Integer read GetBindListSelf write SetBindListSelf;
    property  BindListOther   [Index: Integer]: Integer read GetBindListOther write SetBindListOther;
    function  CalcDistance    (pX, pY: Integer):Integer;
    procedure SetBindungSet   (const Value: Integer);
    procedure SetPositionX    (const Value: Integer);
    procedure SetPositionY    (const Value: Integer);
    procedure SetStepX        (const Value: Double);
    procedure SetStepY        (const Value: Double);
    procedure SetSize         (const Value: Integer);
    procedure SetDistance     (const Value: Integer);
    procedure SetAnlDist      (const Value: Integer);
    procedure SetRepelDist    (const Value: Integer);
    procedure SetRndDir       (const damp: Double);
    procedure SetFillColor    (const Value: Integer);
    procedure SetState        (const Value: Integer);
    procedure SetConnect      (const Value: Integer);
    procedure SetShortestD    (const Value: Double);
    procedure SetShortestDSelf(const Value: Double);
  published
    procedure NeigborCheck(const AgentList: TList; const I: Integer;
                           var limboPos: Array of Double);
    property PositionX   : Integer read FPositionX    write SetPositionX;
    property PositionY   : Integer read FPositionY    write SetPositionY;
    property StepX       : Double  read FStepX        write SetStepX;
    property StepY       : Double  read FStepY        write SetStepY;
    property Size        : Integer read FSize         write SetSize;
    property Distance    : Integer read FDistance     write SetDistance;
    property FillColor   : Integer read FFillColor    write SetFillColor;
    property State       : Integer read FState        write SetState;
    property BindungSet  : Integer read FBindungSet   write SetBindungSet;
    property AnlDist     : Integer read FAnlDist      write SetAnlDist;
    property RepelDist   : Integer read FRepelDist    write SetRepelDist;
    property ShortestD   : Double  read FShortestD    write SetShortestD;
    property ShortestDSelf: Double  read FShortestDSelf write SetShortestDSelf;
    property Connect     : Integer read FConnect      write SetConnect;
  end;

type
  TAgent = class (TBaseShape)
    procedure Paint (Canvas: TCanvas); override;

  end;

implementation

const PI = 3.14159265358979323846;
//*********************************************************************************************//
// ********** Berechnet Nachbarn und Abst�nde zu den anderen Agenten **************************//
//*********************************************************************************************//
// --- Eingagen : Abstand   : Interaktionsradius der Agenten                                   //
//                MinAbstand: Mindestabstand zwischen den Agenten                              //
//                AgentList : Liste mit allen Agenten                                          //
//                I         : Nr des Aktuellen Agenten um Doppelvergleiche zu vermeiden (K+I)  //
// --- Ausgaben : NeigborList   : Nr.-Liste mit den Nachbarn innerhalb des Radius              //
//                NeigborList[0]: Nr. des n�chsten Nachbarn                                    //
//                ShortestD     : Entfernung zum n�chsten Nachbarn                             //
//*********************************************************************************************//
procedure TBaseShape.NeigborCheck (const AgentList: TList; const I: Integer;
                                   var limboPos: Array of Double);
var
  K        : Integer;
  AShape   : TAgent;
  BShape   : TAgent;
begin
  SetLength(FNeigborList,   1);
  SetLength(NachbList,      0);
  SetLength(FBindListOther, 0);
  SetLength(FBindListSelf,  0);
  ShortestD    := 1000;
  AShape := AgentList.Items[I];
  For K := 0 to AgentList.Count - 1 do
  begin
    If (Not (K = I)) then // -- Vergleichen wenn unterschiedlich  //And (NOT AShape.Connect))
    begin
      BShape := AgentList.Items[K];
      AShape.Distance := CalcDistance(BShape.PositionX, BShape.PositionY);
      If AShape.Distance < AShape.AnlDist then // --- sammelt Nachbarn innerhalb Radius
      begin
        SetLength(FNeigborList, length(FNeigborList) + 1);
        NeigborList[High(FNeigborList)] := K;
        // f�r Graphensystem: wenn innerhalb des Radius, verbinden
        SetLength(NachbList, length(NachbList) + 1);
        NachbList[High(NachbList)].Nr := K;
        NachbList[High(NachbList)].Dist := AShape.Distance;
      end;
      If AShape.Distance < AShape.ShortestD    // --- bestimme den n�chsten Nachbarn
      then begin
        AShape.ShortestD := AShape.Distance;
        AShape.NeigborList[0] := K;            // Index 0 = nearestNeigbor
      end;
    end;
  end;

  If (AShape.ShortestD < AShape.AnlDist) Then  // --- Anlagerung wenn innerhalb Anlagerungsradius
  begin
    Anlagern (I, AgentList);
  end;
end;

// ********************* Agenten anlagern ************************************//
procedure TBaseShape.Anlagern (const I: Integer; const AgentList: TList);
var
  K      : Integer;
  BShape : TAgent;
  AShape : TAgent;
begin
  Connect := 0;
  For K := 1 To length(FNeigborList)-1 Do  //--- beginn nach n�chsten Nachbarn => K := 2
  Begin
    BShape := AgentList[FNeigborList[K]];           //--- Parent
    Connect := 2;
    BShape.Connect := 2;
    StepX := 0;                                   //--- Bewegung anhalten
    StepY := 0;
    SetLength(FBindListSelf, length(FBindListSelf) + 1);   //--- in BindListe aufnehmen
    BindListSelf[High(FBindListSelf)] := FNeigborList[K];
    //--- Repel ---
    AShape := AgentList[FNeigborList[0]];
    If (ShortestD < AnlDist - RepelDist) Then Begin
      StepX := (random(3) - 1) + (-1 * (AShape.PositionX - PositionX)) / 20;
      StepY := (random(3) - 1) + (-1 * (AShape.PositionY - PositionY)) / 20;
    end;
  end;
end;

// ********************* Zuf�llige Richtungs�nderung *************************//
procedure TBaseShape.SetRndDir (const damp: Double); // --- damp bestimmt die St�rke des Richtungswechsels
begin
  StepX := (FStepX + (random(3) - 1)) * damp;
  StepY := (FStepY + (random(3) - 1)) * damp;
end;

// **************** Funktion zur Entfernungsberechnung **********************//
function TBaseShape.CalcDistance(pX: Integer; pY: Integer): Integer;
  var temp: double;
  begin
  temp := sqrt(Power((pX - FPositionX), 2) + Power((pY - FPositionY), 2));
  Result := Round(temp);
end;

// ********* Zeichnungseinstellungen f�r die Agentenrepr�sentation **********//
procedure TAgent.Paint(Canvas: TCanvas);
begin
  inherited Paint (Canvas);
  Canvas.Pen.Color := clGreen;
  Canvas.Pen.Style := psSolid; //(=psSolid, psDash, psDot, psClear)
  case State of
  0: begin
      FillColor := clRed;
      FSize := 3;
    end;
  1: begin
      FillColor := clBlue;
      Size := 5;
    end;
  2: begin
      FillColor := clLime;
      FSize := 5;
    end;
  end;
  Canvas.Ellipse (FPositionX - FSize , FPositionY - (FSize), FPositionX + (FSize), FPositionY + (FSize));
end;

procedure TBaseShape.SetConnect (const Value: Integer);
begin
  FConnect := Value;
end;

procedure TBaseShape.SetBindListSelf (Index: Integer; Value: Integer);
begin
  FBindListSelf[Index] := Value;
end;

function  TBaseShape.GetBindListSelf  (Index: Integer): Integer;
begin
  Result := FBindListSelf[index];
end;

procedure TBaseShape.SetBindlistOther (Index: Integer; Value: Integer);
begin
  FBindListOther[Index] := Value;
end;

function  TBaseShape.GetBindListOther  (Index: Integer): Integer;
begin
  Result := FBindListOther[index];
end;

procedure TBaseShape.SetNeigbor (Index: Integer; Value: Integer);
begin
  FNeigborList[Index] := Value;
end;

function  TBaseShape.GetNeigbor  (Index: Integer): Integer;
begin
  Result := FNeigborList[index];
end;

procedure TBaseShape.Paint (Canvas: TCanvas);
begin
  Canvas.Brush.Color := FFillColor;
  Canvas.Pen.Width := 1;
end;

procedure TBaseShape.SetBindungSet (const Value: Integer);
begin
  FBindungSet := Value;
end;

procedure TBaseShape.SetAnlDist (const Value: Integer);
begin
  FAnlDist := Value;
end;

procedure TBaseShape.SetRepelDist (const Value: Integer);
begin
  FRepelDist := Value;
end;

procedure TBaseShape.SetShortestD (const Value: Double);
begin
  FShortestD := Value;
end;

procedure TBaseShape.SetShortestDSelf (const Value: Double);
begin
  FShortestDSelf := Value;
end;

procedure TBaseShape.SetStepX(const Value: Double);
begin
  FStepX := Value;
end;

procedure TBaseShape.SetStepY(const Value: Double);
begin
  FStepY := Value;
end;

procedure TBaseShape.SetPositionX(const Value: Integer);
begin
  FPositionX := Value;
end;

procedure TBaseShape.SetPositionY(const Value: Integer);
begin
  FPositionY := Value;
end;

procedure TBaseShape.SetDistance(const Value: Integer);
begin
  FDistance := Value;
end;

procedure TBaseShape.SetSize(const Value: Integer);
begin
  FSize := Value;
end;

procedure TBaseShape.SetFillColor(const Value: Integer);
begin
  FFillColor := Value;
end;

procedure TBaseShape.SetState(const Value: Integer);
begin
  FState := Value;
end;

end.

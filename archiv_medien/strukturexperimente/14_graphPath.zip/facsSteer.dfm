object MovePlate: TMovePlate
  Left = 0
  Top = 0
  Width = 800
  Height = 623
  Caption = 'A* in Graph'
  Color = clSilver
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -10
  Font.Name = 'Tahoma'
  Font.Style = []
  OldCreateOrder = False
  OnCreate = FormCreate
  OnDestroy = FormDestroy
  PixelsPerInch = 96
  TextHeight = 12
  object Label1: TLabel
    Left = 6
    Top = 480
    Width = 106
    Height = 13
    Caption = 'Anzahl Knotenpunkte:'
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clWhite
    Font.Height = -11
    Font.Name = 'Tahoma'
    Font.Style = []
    ParentFont = False
  end
  object Label2: TLabel
    Left = 116
    Top = 480
    Width = 24
    Height = 13
    Caption = '0000'
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clWhite
    Font.Height = -11
    Font.Name = 'Tahoma'
    Font.Style = []
    ParentFont = False
  end
  object Label3: TLabel
    Left = 434
    Top = 485
    Width = 61
    Height = 13
    Caption = 'MausRadius:'
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clWhite
    Font.Height = -11
    Font.Name = 'Tahoma'
    Font.Style = []
    ParentFont = False
  end
  object Label_Radius: TLabel
    Left = 500
    Top = 485
    Width = 24
    Height = 13
    Caption = '____'
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clWhite
    Font.Height = -11
    Font.Name = 'Tahoma'
    Font.Style = []
    ParentFont = False
  end
  object Lbl_Pfad: TLabel
    Left = 260
    Top = 485
    Width = 86
    Height = 13
    Caption = 'kein Pfad m'#246'glich!'
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clRed
    Font.Height = -11
    Font.Name = 'Tahoma'
    Font.Style = []
    ParentFont = False
  end
  object ScrollBar1: TScrollBar
    Left = 538
    Top = 481
    Width = 97
    Height = 15
    Max = 200
    PageSize = 0
    TabOrder = 0
    OnChange = ScrollBar1Change
  end
  object Button_Delete: TButton
    Left = 6
    Top = 552
    Width = 68
    Height = 28
    Caption = 'Delete 10 Pts'
    TabOrder = 1
    OnClick = Button_DeleteClick
  end
  object Button2: TButton
    Left = 356
    Top = 481
    Width = 67
    Height = 20
    Caption = 'Attract/Repel'
    TabOrder = 2
    OnMouseUp = Button2MouseUp
  end
  object Button_Create: TButton
    Left = 152
    Top = 479
    Width = 68
    Height = 20
    Caption = 'Create Nodes'
    TabOrder = 3
    OnClick = Button_CreateClick
  end
  object ButtonPause: TButton
    Left = 6
    Top = 515
    Width = 68
    Height = 26
    Caption = 'Pause'
    TabOrder = 4
    OnClick = ButtonPauseClick
  end
  object GroupBox1: TGroupBox
    Left = 6
    Top = 0
    Width = 779
    Height = 469
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clWindowText
    Font.Height = -11
    Font.Name = 'Tahoma'
    Font.Style = []
    ParentFont = False
    TabOrder = 5
    object ImagePaint: TImage
      Left = 7
      Top = 11
      Width = 770
      Height = 451
      OnMouseMove = ImagePaintMouseMove
      OnMouseUp = ImagePaintMouseUp
    end
  end
  object Edi_NrRed: TEdit
    Left = 226
    Top = 479
    Width = 24
    Height = 20
    TabOrder = 6
    Text = '40'
  end
  object GroupBox2: TGroupBox
    Left = 434
    Top = 510
    Width = 353
    Height = 73
    Caption = 'Einstellungen Graph:'
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clWindow
    Font.Height = -11
    Font.Name = 'Tahoma'
    Font.Style = []
    ParentFont = False
    TabOrder = 7
    object Lbl_RepelDistRot: TLabel
      Left = 138
      Top = 49
      Width = 24
      Height = 13
      Caption = '____'
      Font.Charset = DEFAULT_CHARSET
      Font.Color = clWhite
      Font.Height = -11
      Font.Name = 'Tahoma'
      Font.Style = []
      ParentFont = False
    end
    object Label15: TLabel
      Left = 63
      Top = 50
      Width = 73
      Height = 13
      Caption = 'RepelDist. Rot:'
      Font.Charset = DEFAULT_CHARSET
      Font.Color = clWhite
      Font.Height = -11
      Font.Name = 'Tahoma'
      Font.Style = []
      ParentFont = False
    end
    object LabelDistRed: TLabel
      Left = 138
      Top = 25
      Width = 24
      Height = 13
      Caption = '____'
      Font.Charset = DEFAULT_CHARSET
      Font.Color = clWhite
      Font.Height = -11
      Font.Name = 'Tahoma'
      Font.Style = []
      ParentFont = False
    end
    object Label7: TLabel
      Left = 51
      Top = 25
      Width = 86
      Height = 13
      Caption = 'Anlager Dist. Rot:'
      Font.Charset = DEFAULT_CHARSET
      Font.Color = clWhite
      Font.Height = -11
      Font.Name = 'Tahoma'
      Font.Style = []
      ParentFont = False
    end
    object SB_RepelDistRot: TScrollBar
      Left = 168
      Top = 46
      Width = 97
      Height = 15
      Max = 50
      Min = 1
      PageSize = 8
      Position = 30
      TabOrder = 0
      OnChange = SB_RepelDistRotChange
    end
    object ScrollBar_DistRot: TScrollBar
      Left = 168
      Top = 22
      Width = 97
      Height = 15
      LargeChange = 5
      Max = 200
      Min = 5
      PageSize = 0
      Position = 115
      TabOrder = 1
      OnChange = ScrollBar_DistRotChange
    end
  end
  object GroupBox3: TGroupBox
    Left = 84
    Top = 510
    Width = 341
    Height = 73
    Caption = 'Bedienung:'
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clWindow
    Font.Height = -11
    Font.Name = 'Tahoma'
    Font.Style = []
    ParentFont = False
    TabOrder = 8
    object Label4: TLabel
      Left = 12
      Top = 36
      Width = 256
      Height = 13
      Caption = 'linke / rechte Maustaste : start- / zielNode bestimmen'
    end
    object Label5: TLabel
      Left = 12
      Top = 48
      Width = 216
      Height = 13
      Caption = 'mittlere Maustaste : einzelnen Node erstellen'
    end
    object Label6: TLabel
      Left = 12
      Top = 18
      Width = 237
      Height = 13
      Caption = 'zuerst mit '#39'Create Nodes'#39' einen Graphen erstellen'
    end
  end
  object ApplicationEvents1: TApplicationEvents
    OnIdle = ApplicationEvents1Idle
    Left = 120
    Top = 72
  end
end

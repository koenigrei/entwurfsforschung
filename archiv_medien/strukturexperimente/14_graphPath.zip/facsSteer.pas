(********************************************************************)
(*                                                                  *) 
(*                                                                  *)
(*                            Rythmen                               *)
(*                     im st�dtischen Verkehr                       *)
(*                          Version 1.0                             *)
(*                                                                  *) 
(*     Programmierer: Reinhard K�nig                     July 2005  *)
(*                    http://www.entwurfsforschung.de/              *)
(*                                                                  *)
(*     Last Update: July-25, 2005                                   *)
(*                                                                  *) 
(********************************************************************) 
{revision history:

1.0     [July-25, 2005]
        first release to the public
}

unit facsSteer;

interface

uses
  Windows, Messages, SysUtils, Variants, Classes, Graphics, Controls, Forms,
  Dialogs, ExtCtrls, Grids, agenten, Math, ConvUtils, StdCtrls, AppEvnts,
  Menus;

type
  TMovePlate = class(TForm)
    ScrollBar1          : TScrollBar;
    ApplicationEvents1  : TApplicationEvents;
    Label1              : TLabel;
    Label2              : TLabel;
    Button_Delete       : TButton;
    Button2             : TButton;
    Label3              : TLabel;
    Label_Radius        : TLabel;
    Button_Create       : TButton;
    ButtonPause: TButton;
    GroupBox1: TGroupBox;
    ImagePaint: TImage;
    Edi_NrRed: TEdit;
    GroupBox2: TGroupBox;
    SB_RepelDistRot: TScrollBar;
    Lbl_RepelDistRot: TLabel;
    Label15: TLabel;
    ScrollBar_DistRot: TScrollBar;
    LabelDistRed: TLabel;
    Label7: TLabel;
    Lbl_Pfad: TLabel;
    GroupBox3: TGroupBox;
    Label4: TLabel;
    Label5: TLabel;
    Label6: TLabel;
    procedure ImagePaintMouseUp(Sender: TObject; Button: TMouseButton;
      Shift: TShiftState; X, Y: Integer);
    procedure B_PathClick(Sender: TObject);
    procedure SB_RepelDistRotChange(Sender: TObject);
    procedure ScrollBar_DistRotChange(Sender: TObject);
    procedure ButtonPauseClick(Sender: TObject);
    procedure Button_DeleteClick(Sender: TObject);
    procedure Button_CreateClick(Sender: TObject);
    procedure Button2MouseUp(Sender: TObject; Button: TMouseButton;
      Shift: TShiftState; X, Y: Integer);
    procedure FormDestroy(Sender: TObject);
    procedure ImagePaintMouseMove(Sender: TObject; Shift: TShiftState; X,
      Y: Integer);
    procedure ApplicationEvents1Idle(Sender: TObject; var Done: Boolean);
    procedure ScrollBar1Change(Sender: TObject);
    procedure FormCreate(Sender: TObject);
  private
    { Private declarations }
    openList  : TList;
    pfadList  : TList;
    ShapesList: TList;
    CurrShape: TBaseShape;
    procedure CommonPaint (Canvas: TCanvas);
    procedure Verbinden();
    procedure Swarming();
    procedure checkNeighbour (parAgent : TAgent);
    procedure calcF (vorg: TAgent; me: TAgent);
    procedure findPath;
    procedure deletePath;
    procedure erstelleNode(startX: Integer; startY: Integer);
  public
    { Public declarations }
  end;

var
  MovePlate: TMovePlate;

implementation

{$R *.dfm}

const
    NUM_BALLS = 100;
    cellScal = 10;
var
  reih      : Integer;
  spalt     : Integer;
  Dir       : Integer = 1;
  LEFT_BORDER   : Integer;
  TOP_BORDER    : Integer;
  RIGHT_BORDER  : Integer;
  BOTTOM_BORDER : Integer;
  Mouse_Rad     : Integer;
  MouseX        : Integer;
  MouseY        : Integer;
  Backpuffer    : TBitmap;
  oldPos        : Array of Array of Integer;
  limboPos      : Array of Array of Double;
  fertig        : Boolean;
  foundPath     : Boolean;
  startNode     : TAgent;
  zielNode      : TAgent;

// *** funktion zur Distanzmessung ***
function distance(pX1: Integer; pY1: Integer; pX2: Integer; pY2: Integer): Integer;
  var temp: double;
  begin
  temp := sqrt(Power((pX1 - pX2), 2) + Power((pY1 - pY2), 2));
  distance := Round(temp);
end;

// *** Initialisierung ***
procedure TMovePlate.FormCreate(Sender: TObject);
begin
  scaled := false;
  fertig := false;
  // --- deklarieren des Arrays f�r die 'Cellen' -------------------------------
  spalt := round (ImagePaint.Width / cellScal);
  reih  := round (ImagePaint.Height / cellScal);
  // --- initialization and creation of the list -------------------------------
  openList                      := TList.Create;
  pfadList                      := TList.Create;
  ShapesList                    := TList.Create;
  MovePlate.Color               := clBlack;
  MovePlate.Canvas.Pen.Color    := clred;
  MovePlate.Canvas.Brush.Color  := clred;
  LEFT_BORDER                   := ImagePaint.Left-5;
  TOP_BORDER                    := ImagePaint.Top-5;
  RIGHT_BORDER                  := ImagePaint.Width-5;
  BOTTOM_BORDER                 := ImagePaint.Height-5;
  // --- Slider & Label --------------------------------------------------------
  Mouse_Rad                     := ScrollBar1.Position;
  Label_Radius.Caption          := IntToStr(Mouse_Rad);
  LabelDistRed.Caption          := IntToStr(ScrollBar_DistRot.Position);
  Lbl_RepelDistRot.Caption      := IntToStr(SB_RepelDistRot.Position);
  // --- Zwischenspeicher f�r die Bildaktualisierung ---------------------------
  Backpuffer        := TBitmap.create;
  Backpuffer.width  := ImagePaint.width;
  Backpuffer.height := ImagePaint.height;
  Backpuffer.canvas.brush.color := clgreen;
  Backpuffer.canvas.rectangle(0,0,Backpuffer.width,Backpuffer.height);
end;

// *****************************************************************************
// ****************             A-Stern Berechnungen            ****************
// *****************************************************************************
//
// *** Node wird expandiert --- die neuen Nodes werden gepr�ft ***
procedure TMovePlate.checkNeighbour (parAgent : TAgent);
var
  I       : Integer;
  U       : Integer;
  altG    : Integer;
  altH    : Integer;
  altF    : Integer;
  inOpen  : Boolean;
  cildAgent : TAgent;
begin
  for I := 0 To length(parAgent.NachbList)-1 Do
  begin
    cildAgent := ShapesList.Items [parAgent.NachbList[I].Nr];
    // --- nicht untersucht werden W�nde und closed Nodes
    If ((cildAgent.State < 999) and (cildAgent.Closed = false)) then
    begin
      inOpen := false;
      for U := 0 To openList.count -1 do  // --- pr�ft, ob Knoten bereits in openList
      begin
        If (openList.Items[U] = cildAgent) then begin
          inOpen := true;
        end;
      end;
      If inOpen = false then         // --- wenn Node noch nicht in open List
      begin
        calcF (parAgent, cildAgent); // --- berechnet die Sch�tzwerte (Heuristik)
        cildAgent.Vorg := parAgent;  // --- bestimmt den Vog�nger-VerweisNode
        openList.Add(cildAgent);     // --- nimmt Node in Openlist auf
        If (cildAgent = zielNode) Then begin
          foundPath := true;         // --- Ziel erreicht!
        end;
      end else begin         // --- wenn wenn Node bereits in open List
                             // --- pr�fe, ob G g�nstiger => ver�ndere Vorg
        altG := cildAgent.G; // +
        altH := cildAgent.H; // + speichert Werte vor der neuBerechnung
        altF := cildAgent.F; // +
        calcF (parAgent, cildAgent);
        If (altG < cildAgent.G) Then begin // --- setze alte Werte wieder ein
          cildAgent.G := altG;
          cildAgent.H := altH;
          cildAgent.F := altF;
        end else begin
          cildAgent.Vorg := parAgent; // --- falls neuer G-Wert g�nstiger, neuer Verweis auf Vorg�nger-Node
        end;
      end;
    end;
  end;
end;

// *** Berechnung der Heuristik: F = G + H ***
procedure TMovePlate.calcF (vorg: TAgent; me: TAgent);
var
  dist     : Integer;
begin
  // ----- Berechne G -----
  dist := distance(vorg.PositionX, vorg.PositionY, me.PositionX, me.PositionY);
  me.G := vorg.G + dist;
  // ----- Berechne H -----
  me.H := distance(zielNode.PositionX, zielNode.PositionY, me.PositionX, me.PositionY);
  // ----- Berechne F -----
  me.F := me.G + me.H;
end;

// TList sort routine : compare customers by name
// --------------------------------------------------------------------------
// The returned integer has the following value :
//   > 0 : (positive) Item1 is less than Item2
//     0 : Item1 is equal to Item2
//   < 0 : (negative) Item1 is greater than Item2
function compareByF(Item1 : Pointer; Item2 : Pointer) : Integer;
var
  customer1, customer2 : TAgent;
begin
  // We start by viewing the object pointers as TAgent objects
  customer1 := TAgent(Item1);
  customer2 := TAgent(Item2);
  // Now compare by F - complete Kosts
  if   customer1.F < customer2.F
    then Result := 1
  else if customer1.F = customer2.F
    then Result := 0
  else   Result := -1;
end;

// *** path find ***
procedure TMovePlate.B_PathClick(Sender: TObject);
begin
  If Not (startNode = nil) Then
    findPath; 
end;

// *** geht die Nodes durch ***
procedure TMovePlate.findPath;
var
  explNode : TAgent;
  parAgent : TAgent;
begin
If Not (startNode = nil) Then begin
  foundPath := false;
  deletePath;
  openList.Add(startNode);
  // --- Wdh. bis openList vollst�ndig �berpr�ft => kein Pfad m�glich!
  // --- oder bis zielNode erreicht => pfad gefunden.
  While ((openList.count > 0) And (foundPath = false)) Do
  begin
    explNode := openList.Items[openList.count -1];
    explNode.closed := true;
    checkNeighbour (explNode);
    openList.Sort(compareByF);
    openList.Remove(explNode);
  end;
  // --- speichere den Pfad ---
  explNode := zielNode;
  If foundPath = true Then begin
    repeat
      parAgent := explNode.Vorg;
      pfadList.Add (explNode);
      explNode := explNode.Vorg;
    Until (explNode = startNode);
  end;
end;
end;

// *** Pfade l�schen ***
procedure TMovePlate.deletePath;
var
  I : Integer;
  AShape : TAgent;
begin
  openList.Free;
  pfadList.Free;
  openList := TList.Create;
  pfadList := TList.Create;
  for I := 0 to ShapesList.Count - 1 do
  begin
    AShape := ShapesList.Items [I];
    AShape.F:= 0;
    AShape.G:= 0;
    AShape.H:= 0;
    AShape.closed:= false;
    If AShape.State > 0 then AShape.State := 0;
    startNode.State := 1;
    zielNode.State := 2;
  end;
end;

// #############################################################################
// *****************************************************************************
// ***                     ------- Agenten ---------                         ***
// *****************************************************************************
// --- Agenten zeichnen ---
procedure TMovePlate.CommonPaint (Canvas: TCanvas);
var
  I     : Integer;
  AShape: TAgent;
begin
  canvas.brush.color := clBlack;
  canvas.pen.color := clGreen;
  canvas.rectangle(0,0,Backpuffer.width,Backpuffer.height);
  // --- repaint each shape of the list ---
  for I := 0 to ShapesList.Count - 1 do
  begin
    AShape := ShapesList.Items [I];
    AShape.BindungSet := 0; // --- Anzahl Bindungen je Typ zur�cksetzen
    AShape.Paint (Canvas);
  end;
end;

// *** Verbinde n�chste Nachbarn ***
procedure TMovePlate.Verbinden();
var
  J      : Integer;
  K      : Integer;
  AShape : TAgent;
  BShape : TAgent;
begin
  // --- zeichne Verbindungslinien ---
  for J := 0 to ShapesList.Count -1 do
  begin
    AShape := ShapesList.Items [J];
    Backpuffer.Canvas.Pen.Width := 1;
    K := 0;
    While  K < length(AShape.NachbList) Do
    Begin
      Backpuffer.Canvas.Pen.Color := clMaroon;
      Backpuffer.Canvas.Pen.Style := psSolid;
      Backpuffer.Canvas.Pen.Width := 1;
      Backpuffer.Canvas.MoveTo(oldPos[J][0], oldPos[J][1]); // --- Verbindungen mit oldPosition zeichnen
      Backpuffer.Canvas.LineTo(oldPos[AShape.NachbList[K].Nr][0], oldPos[AShape.NachbList[K].Nr][1]);
      K := K + 1;
    end;
  end;
  // --- zeichne Pfad ---
  If foundPath = true Then begin
  Lbl_Pfad.Font.Color := clGreen;
  Lbl_Pfad.Caption := 'Pfad erstellt';
    AShape := pfadList.Items [0];
    While Not (AShape = startNode) Do
    begin
      BShape := AShape.vorg;
      Backpuffer.Canvas.Pen.Color := clYellow;
      Backpuffer.Canvas.Pen.Style := psSolid;
      Backpuffer.Canvas.Pen.Width := 2;
      Backpuffer.Canvas.MoveTo(AShape.PositionX, AShape.PositionY);
      Backpuffer.Canvas.LineTo(BShape.PositionX, BShape.PositionY);
      AShape := AShape.vorg;
    end
  end else begin
  Lbl_Pfad.Font.Color := clRed;
  Lbl_Pfad.Caption := 'kein Pfad m�glich!';
  end;
end;

// **** Schwarmverhalten ****
procedure TMovePlate.Swarming();
var
  J      : Integer;
  AShape : TAgent;
begin
  SetLength(limboPos, ShapesList.Count, 2); //--- definiert die Gr��e der LimboPos
  SetLength(oldPos, ShapesList.Count, 2);   //--- definiert die Gr��e der oldPos
  for J := 0 to ShapesList.Count - 1 do
  begin
    AShape := ShapesList.Items [J];
    // --- Alte Positionen Speichern
    oldPos[J][0] := AShape.PositionX;
    oldPos[J][1] := AShape.PositionY;
    begin
      AShape.NeigborCheck (ShapesList, J, limboPos[J]);  // --- Berechnet die Nachbarn
    end;
  end;
end;

// *** Aktualisierungen je Durchlauf***
procedure TMovePlate.ApplicationEvents1Idle(Sender: TObject; var Done: Boolean);
var
  I         : Integer;
  AShape    : TAgent;
  distMouse : Integer;
begin
  If fertig = false then done := false;
  If fertig = true  then begin done := true; exit; end;
  // --- Schwarmverhalten aufrufen -----------
  Swarming ();
  //------------------------------------------//
  for I := 0 to ShapesList.Count - 1 do
  begin
    AShape := ShapesList.Items [I];
    distMouse := distance (AShape.PositionX, AShape.PositionY, MouseX, MouseY);
    If (distMouse < Mouse_Rad) // --- MausInteraktion
    then begin
      AShape.FStepX := Dir * round ((AShape.PositionX - MouseX) * 0.1); //AShape.FStepX * -3;
      AShape.FStepY := Dir * round ((AShape.PositionY - MouseY) * 0.1); //AShape.FStepY * -3;
    end;
    // --- Randlos Torus ---
    if AShape.PositionX < LEFT_BORDER  then
      AShape.PositionX := RIGHT_BORDER;
    if AShape.PositionX > RIGHT_BORDER then
      AShape.PositionX := LEFT_BORDER;
    if AShape.PositionY < TOP_BORDER then
      AShape.PositionY := BOTTOM_BORDER;
    if AShape.PositionY > BOTTOM_BORDER then
      AShape.PositionY := TOP_BORDER;
    // ++++ Position aktualisieren ++++
    AShape.PositionX := AShape.FPositionX + round(AShape.FStepX);
    AShape.PositionY := AShape.FPositionY + round(AShape.FStepY);
  end;
  // --- Ausf�hren -------------------------------------------------------------
  foundPath := false;
  If ShapesList.Count > 1 Then findPath; // --- suche Pfad
  CommonPaint (Backpuffer.Canvas);
  Verbinden(); // --- Verbindungslinie wenn angedockt
  /// --- Bild aktualisieren ------------------------
  //BitBlt(Backpuffer.Canvas.Handle, bildleft, bildtop, Bild.Width, Bild.Height, Bild.canvas.handle, 0, 0, SRCCOPY);//Bild auf Backpuffer kopieren
  ImagePaint.Invalidate;
  BitBlt(ImagePaint.Canvas.Handle, 0, 0, Backpuffer.Width, Backpuffer.Height, Backpuffer.canvas.handle, 0, 0, SRCCOPY);//Backpuffer auf das Formular kopieren
end;

procedure TMovePlate.ImagePaintMouseMove(Sender: TObject; Shift: TShiftState; X, Y: Integer);
begin
  fertig := false;
  MouseX := X;
  MouseY := Y;
end;

// *****************************************************************************
// *********                        Buttons                            *********
// *****************************************************************************
//
// *** Repel - Attract - Button ***
procedure TMovePlate.Button2MouseUp(Sender: TObject; Button: TMouseButton;
  Shift: TShiftState; X, Y: Integer);
begin
  Dir := Dir * (-1);
end;

// *** Pause button ***
procedure TMovePlate.ButtonPauseClick(Sender: TObject);
begin
  fertig := Not fertig; //true;
  If MovePlate.Color = clRed Then begin
    MovePlate.Color := clBlack;
    exit;
  end;
  MovePlate.Color := clRed;
end;

// *** Initialisiert die Roten Agenten ***
procedure TMovePlate.Button_CreateClick(Sender: TObject);
var
  I: Integer;
begin
  for I := 1 to StrToInt(Edi_NrRed.Text) Do
  begin
    erstelleNode(random(ImagePaint.width), random(ImagePaint.height));
  end ;
  CommonPaint (ImagePaint.Canvas);
  Label2.Caption := IntToStr(ShapesList.Count);
  If ShapesList.Count > 0 Then
  begin
    startNode := ShapesList.Items [0];
    zielNode := ShapesList.Items [ShapesList.Count - 1];
    startNode.State := 1;
    zielNode.State := 2;
  end;
end;

// *** Nodes erstellen ***
procedure TMovePlate.erstelleNode(startX: Integer; startY: Integer);
var
  I: Integer;
begin
  CurrShape := TAgent.Create;
  CurrShape.PositionX :=  startX;
  CurrShape.PositionY :=  startY;
  CurrShape.StepX     := (random(3) - 1);
  CurrShape.StepY     := (random(3) - 1);
  CurrShape.Size      := 3;
  CurrShape.Connect   := 0;
  CurrShape.State     := 0;
  CurrShape.AnlDist   := ScrollBar_DistRot.Position;
  CurrShape.RepelDist := SB_RepelDistRot.Position;
  ShapesList.Add (CurrShape);
end;

// *** einzelne Agenten erstellen / Start- und Endpunkt festlegen ***
procedure TMovePlate.ImagePaintMouseUp(Sender: TObject; Button: TMouseButton;
  Shift: TShiftState; X, Y: Integer);
var
  K       : Integer;
  AShape  : TAgent;
  minDist : Integer;
  tmpDist : Integer;
  minNode : Integer;
begin
  If button = mbMiddle then
  begin
    erstelleNode(X, Y);
    CommonPaint (ImagePaint.Canvas);
    Label2.Caption := IntToStr(ShapesList.Count);
  end else
  begin
    minDist := 10000;
    // --- suche den n�chsten Node zur Mausklick-Position ---
    For K := 0 to ShapesList.Count - 1 do
    begin
      AShape := ShapesList.Items[K];
      tmpDist := AShape.CalcDistance(X, Y);
      If tmpDist < minDist then // --- bestimmt den n�chsten Nachbarn
      begin
        minDist := tmpDist;
        minNode := K;
      end;
    end;
    // --- linke Maustaste setzt startNode ---
    If button = mbLeft then begin
      If ShapesList.Count > 1 Then begin
        startNode := ShapesList.Items[minNode];
        startNode.State := 1;
      end;
    end else
    // --- rechte Maustaste setzt zielNode ---
    If button = mbRight then begin
      If ShapesList.Count > 1 Then begin
        zielNode := ShapesList.Items[minNode];
        zielNode.State := 2;
      end;
    end;
  end;
end;

// *** Agenten l�schen ***
procedure TMovePlate.Button_DeleteClick(Sender: TObject);
begin
  If ShapesList.Count >= 10 Then 
  ShapesList.Count := ShapesList.Count - 10;
  Label2.Caption := IntToStr(ShapesList.Count);
end;

// *****************************************************************************
// *******                       ScrollBars                             ********
// *****************************************************************************
//
// *** DistanzRot einstellen ***
procedure TMovePlate.ScrollBar_DistRotChange(Sender: TObject);
var
  J      : Integer;
  AShape : TAgent;
begin
  for J := 0 to ShapesList.Count - 1 do
  begin
    AShape := ShapesList.Items [J];
    AShape.AnlDist := ScrollBar_DistRot.Position;
    AShape.Connect := 0;
    AShape.StepX := (random(3) - 1);
    AShape.StepY := (random(3) - 1);
  end;
    LabelDistRed.Caption := IntToStr(ScrollBar_DistRot.Position);
end;

// *** MausInteraktionsRadius ***
procedure TMovePlate.ScrollBar1Change(Sender: TObject);
begin
    Mouse_Rad            := ScrollBar1.Position;
    Label_Radius.Caption := IntToStr(Mouse_Rad);
end;

// *** Repel Abstand f�r Rote Punkte ***
procedure TMovePlate.SB_RepelDistRotChange(Sender: TObject);
var
  J      : Integer;
  AShape : TAgent;
begin
  Lbl_RepelDistRot.Caption := IntToStr(SB_RepelDistRot.Position);
  for J := 0 to ShapesList.Count - 1 do
  begin
    AShape := ShapesList.Items [J];
    AShape.RepelDist := SB_RepelDistRot.Position;
  end;
end;

// ******************************
// *** Array und Liste L�schen***
// ******************************
procedure TMovePlate.FormDestroy(Sender: TObject);
var
  I: Integer;
begin
  // --- delete each agent
  for I := ShapesList.Count - 1 downto 0 do
    TBaseShape (ShapesList [I]).Free;
  ShapesList.Free;
end;


end.

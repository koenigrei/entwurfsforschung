unit cell_P;

interface

uses
  Windows, Graphics, Classes, node, Math;

type
  TCell = class
  private
  public
    colr : Integer;
    FPos : TPoint;
    FSize      : Integer;
    FFillColor : Integer;
    FState     : Real;
    procedure Paint         (Canvas: TCanvas);
    procedure SetPositionX  (const Value: Integer);
    procedure SetPositionY  (const Value: Integer);
    procedure SetSize       (const Value: Integer);
    procedure SetFillColor  (const Value: Integer);
    procedure SetState      (const Value: Real);
    constructor create      (xPos, yPos, size, colr: Integer);
  published
    property PositionX: Integer read FPos.X     write SetPositionX;
    property PositionY: Integer read FPos.Y     write SetPositionY;
    property Size     : Integer read FSize      write SetSize;
    property FillColor: Integer read FFillColor write SetFillColor;
    property State    : Real read FState     write SetState;
  end;

// ---------------------------------------------------------------------------//

implementation

constructor TCell.create(xPos, yPos, size, colr: Integer);
begin
  inherited create;
  FPos.X := xPos;
  FPos.Y := yPos;
  FSize  := size;
  FFillColor := colr;
end;

//------------------------------------------------------------------------------

procedure TCell.SetPositionX(const Value: Integer);
begin
  FPos.X := Value;
end;

procedure TCell.SetPositionY(const Value: Integer);
begin
  FPos.Y := Value;
end;

procedure TCell.SetSize(const Value: Integer);
begin
  FSize := Value;
end;

procedure TCell.SetFillColor(const Value: Integer);
begin
  FFillColor := Value;
end;

procedure TCell.SetState(const Value: Real);
begin
  FState := Value;
end;

procedure TCell.Paint(Canvas: TCanvas);

begin
  Canvas.Pen.Width := 1;
  Canvas.Pen.Color := clgreen;
  If FState <= 255 then begin
    //colr := round (FState);
    Canvas.Brush.Color := RGB (colr, colr, colr);//FState; //FFillColor;
  end else begin
    //colr := 255;
    Canvas.Brush.Color := clRed;
  end;

  Canvas.Rectangle (FPos.X - FSize , FPos.Y - FSize, FPos.X + FSize, FPos.Y + FSize);
end;

end.

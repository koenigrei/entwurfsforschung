(********************************************************************)
(*                                                                  *) 
(*                                                                  *)
(*                       Zellul�rer Automat                         *)
(*                  growth with increasing returns                  *)
(*                                                                  *) 
(*     Programmierer: Reinhard K�nig                  December 2005 *)
(*                    http://www.entwurfsforschung.de/              *)
(*                                                                  *)
(*     Last Update: Dec-13, 2005                                    *)
(*                                                                  *)
(********************************************************************) 
{revision history:

1.0     [Dec-13, 2005]
        first release to the public
        growth and spatial redistribution through increasing returns to scale.
}

unit CellForm;

interface

uses
  Windows, Messages, SysUtils, Variants, Classes, Graphics, Controls, Forms,
  Dialogs, StdCtrls, Cell_P, node, ExtCtrls, ButtonGroup, ComCtrls, Math, ToolWin,
  ImgList;

type
  TForm1 = class(TForm)
    ZeichenPanel : TPanel;
    Timer1       : TTimer;
    lbl_Steps    : TLabel;
    B_setup      : TButton;
    lbl_timesteps: TLabel;
    Label2       : TLabel;
    Edit_alpha   : TEdit;
    B_start      : TButton;
    procedure B_startClick(Sender: TObject);
    procedure Edit_alphaChange(Sender: TObject);
    procedure B_setupClick(Sender: TObject);
    procedure Timer1Timer(Sender: TObject);
    procedure FormDestroy(Sender: TObject);
    procedure FormCreate(Sender: TObject);
  private
    cellList     : Array of Array of TCell;
    limboWorld   : Array of Array of Real;
    function  CalcDistance(pAX: Integer; pAY: Integer; pBX: Integer; pBY: Integer): Integer;
    procedure RasterCreate;
    procedure setup;
    procedure createPaintImg;

  public

  end;

var
  Form1    : TForm1;
  paintImg : TImage;
  steps    : Integer;

implementation

{$R *.dfm}

const                      //-- globale Konstanten
  cellScal  = 20;          //-- Zellen gr��e

var                        //-- globale Variablen
  reih        : Integer;   //-- Zellen-Reihen gesamt
  spalt       : Integer;   //-- Zellen-Spalten gesamt

// ---------------------------------------------------------------------------//
// *** Initialisierung ***
procedure TForm1.FormCreate(Sender: TObject);
begin
  spalt          := round (ZeichenPanel.Width / cellScal);
  reih           := round (ZeichenPanel.Height / cellScal);
  SetLength(cellList, spalt, reih);
  SetLength(limboWorld, spalt, reih);
  createPaintImg;
  RasterCreate;
  ZeichenPanel.DoubleBuffered := True;       //-- Verhindert Flackern der Zellen
  steps := 0;
end;

// ---------------------------------------------------------------------------//
// ---------------------------------------------------------------------------//
// *** Erstellt das Raster ***
procedure TForm1.RasterCreate;
var
  curCell : TCell;
  size : Integer;
  I: Integer;
  K: Integer;
begin
  size := round(cellScal/2);
  Randomize();
  for I := 0 to reih -1 do
  begin
    for K := 0 to spalt -1 do
    begin
      curCell := TCell.Create(size + K * cellScal, size + I * cellScal, size, 0);
      cellList[K,I] := curCell;
      curCell.SetState(random()); //(random(200));
      curCell.colr := round (255 * curCell.state); //-- Farbe in Abh. des H�chstwerts
      curCell.Paint(paintImg.Canvas);
    end;
  end;
end;

procedure TForm1.setup;
var
  curCell : TCell;
  I: Integer;
  K: Integer;
begin
  Randomize();
  for I := 0 to reih -1 do
  begin
    for K := 0 to spalt -1 do
    begin
      curCell := cellList[K,I];
      curCell.SetState(random()); //(random(200));
      curCell.colr := round (255 * curCell.state); //-- Farbe in Abh. des H�chstwerts
      curCell.Paint(paintImg.Canvas);
    end;
  end;
end;

// *** Legt eine leere Zeichenfl�che �ber das Zeichenpanel ***
procedure TForm1.createPaintImg;
begin
  paintImg := TImage.Create(self);
  paintImg.Parent  := ZeichenPanel;
  //paintImg.Enabled := False;       //-- PaintImg reagiert nicht auf Mausereignisse
  //paintImg.Transparent:= true;    //-- und ist transparent
  paintImg.top        := 0;
  paintImg.Left       := 0;
  paintImg.Height     := ZeichenPanel.Height;
  paintImg.Width      := ZeichenPanel.Width;
end;

procedure TForm1.Timer1Timer(Sender: TObject);
var
  curCell : TCell;
  I: Integer;
  K: Integer;
  Pt   : Integer;
  Pges : Real;
  maxP : Real;
  alpha: real;
begin
  Pges := 0;
  maxP := 0;
  for I := 0 to reih -1 do
  begin
    for K := 0 to spalt -1 do
    begin
      curCell := cellList[K, I];
      Pges := Pges + curCell.State;
      if curCell.State > maxP then maxP := curCell.State;
    end;
  end;
  Pges := Pges / (reih * spalt);

  for I := 0 to reih -1 do
  begin
    for K := 0 to spalt -1 do
    begin
      curCell := cellList[K, I];
      //-- Growth - function
      alpha := StrToFloat(Edit_alpha.Text);
      curCell.State := Power((curCell.state / Pges), alpha);
      // --- Farbe bestimmen und zeichen ---
      curCell.colr := round ((255 / maxP) * curCell.state); //-- Farbe in Abh. des H�chstwerts
      curCell.Paint(paintImg.Canvas);
    end;
  end;
  steps := steps +1;
  lbl_Steps.Caption := intToStr (steps);
end;

function TForm1.CalcDistance(pAX: Integer; pAY: Integer; pBX: Integer; pBY: Integer): Integer;
var
  temp : double;
begin
  temp := sqrt(Power((pAX - pBX), 2) + Power((pAY - pBY), 2));
  Result := Round(temp);
end;

procedure TForm1.FormDestroy(Sender: TObject);
begin
  paintImg.Free;
  ZeichenPanel.Free;
end;

procedure TForm1.B_setupClick(Sender: TObject);
begin
  setup;
  steps := 0;
end;

procedure TForm1.Edit_alphaChange(Sender: TObject);
begin
  Timer1.enabled := false;
end;

procedure TForm1.B_startClick(Sender: TObject);
begin
  Timer1.enabled := true;
end;

end.

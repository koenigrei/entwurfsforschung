(********************************************************************)
(*                                                                  *)
(*                                                                  *)
(*                      1-D Cellular Automata                       *)
(*                    with entropy measurement                      *)
(*                          Version 1.0                             *)
(*                                                                  *)
(*                                                                  *)
(*     Programmierer: Reinhard K�nig                   January 2006 *)
(*                    http://www.entwurfsforschung.de               *)
(*                                                                  *)
(*     Last Update: Jan-19, 2006                                    *)
(*                                                                  *)
(********************************************************************) 
{revision history:

1.0     [Jan-19, 2006]
        first release to the public
}

unit CellForm;

interface

uses
  Windows, Messages, SysUtils, Variants, Classes, Graphics, Controls, Forms,
  Dialogs, StdCtrls, cell_P, ExtCtrls, ButtonGroup, ComCtrls, Math, ToolWin,
  ImgList, Epina.SDL.rchart;

type
  TForm1 = class(TForm)
    ZeichenPanel   : TPanel;
    Timer1         : TTimer;
    lbl_Steps      : TLabel;
    B_setup        : TButton;
    lbl_timesteps  : TLabel;
    B_stop         : TButton;
    RChart1        : TRChart;
    E_Rule         : TEdit;
    Lbl_Rule       : TLabel;
    B_setupRnd     : TButton;
    CB_pre         : TComboBox;
    procedure CB_preChange(Sender: TObject);
    procedure B_setupRndClick(Sender: TObject);
    procedure B_stopClick   (Sender: TObject);
    procedure B_setupClick  (Sender: TObject);
    procedure Timer1Timer   (Sender: TObject);
    procedure FormDestroy   (Sender: TObject);
    procedure FormCreate    (Sender: TObject);
  private
    AgentList    : TList;
    cellList     : Array of Array of TCell;
    limboWorld   : Array of Array of Integer;
    function  CalcDistance  (pAX: Integer; pAY: Integer; pBX: Integer; pBY: Integer): Integer;
    function  rndN          (lower: Integer; upper: Integer):Integer;
    procedure checkNei      (K, I: Integer);
    procedure createPaintImg;
    procedure createRaster;
    procedure setupCells;
    procedure set_binary_list (xPos: Integer; steps: Integer; var binary_list : Array of Integer);
    procedure plotEntropy     (steps: Integer);
    function  set_an_index    (binary_list : Array of Integer): Integer;
  public
end;

var
  Form1    : TForm1;
  paintImg : TImage;

implementation

{$R *.dfm}

const                            //-- globale Konstanten
  cellScal = 2;                  //-- Zellen  gr��e
  AgSize   = 1;                  //-- Agenten gr��e
  halfScal = round(cellScal/2);
var                              //-- globale Variablen
  reih    : Integer;             //-- Zellen-Reihen gesamt
  spalt   : Integer;             //-- Zellen-Spalten gesamt
  steps   : Integer;
  Xmax    : Integer;
  Ymax    : Integer;
  cellSum : Integer;
  OldY1   : Double;              //-- Speichert die Position t-1 f�r Graphen
  OldY2   : Double;              //-- Speichert die Position t-1 f�r Graphen

// ---------------------------------------------------------------------------//
// *** Initialisierung ***
procedure TForm1.FormCreate(Sender: TObject);
begin
  spalt     := round (ZeichenPanel.Width / cellScal);
  reih      := round (ZeichenPanel.Height / cellScal);
  Xmax      := (spalt) * cellScal;
  Ymax      := (reih ) * cellScal;
  steps     := 0;
  AgentList := TList.Create;
  SetLength(cellList, spalt, reih);
  SetLength(limboWorld, spalt, reih);
  createPaintImg;
  CreateRaster;
  ZeichenPanel.DoubleBuffered := True;       //-- Verhindert Flackern der Zellen
  // -- Predefinded Rules --
  CB_pre.AddItem('10001000', Sender);
  CB_pre.AddItem('00000100', Sender);
  CB_pre.AddItem('01011010', Sender);
  CB_pre.AddItem('00010010', Sender);
  CB_pre.AddItem('00011110', Sender);
  CB_pre.AddItem('01101110', Sender);
  CB_pre.AddItem('01101000', Sender);
  // -- Diagramm initialisieren --
  RChart1.Scale1X.RangeLow  := 0;     { range of chart area }
  RChart1.Scale1X.RangeHigh := 200;  //-- Maximale Reichweite = 1000 bei Testversion!!!
  RChart1.Scale1Y.RangeLow  := -0.1;   //0.45;
  RChart1.Scale1Y.RangeHigh :=  1.1; //0.55;
  RChart1.ShowGraf;
end;

// ---------------------------------------------------------------------------//
// ------------------------- Elemente erstellen ------------------------------//
// ---------------------------------------------------------------------------//

// *** Legt eine leere Zeichenfl�che �ber das Zeichenpanel ***
procedure TForm1.createPaintImg;
begin
  paintImg        := TImage.Create(self);
  paintImg.Parent := ZeichenPanel;
  paintImg.top    := 0;
  paintImg.Left   := 0;
  paintImg.Height := ZeichenPanel.Height;
  paintImg.Width  := ZeichenPanel.Width;
end;

// *** Zellen erstellen ***
procedure TForm1.CreateRaster;
var
  curCell : TCell;
  I       : Integer;
  K       : Integer;
  upperB  : Integer;
  lowerB  : Integer;
begin
  for I := 0 to reih -1 do
  begin
    for K := 0 to spalt -1 do
    begin
      curCell := TCell.Create(halfScal + K * cellScal, halfScal + I * cellScal, halfScal, 0);
      cellList[K,I] := curCell;
    end;
  end;
  setupCells;
end;

// *** Zellen initialisieren ***
procedure TForm1.setupCells;
var
  curCell : TCell;
  I       : Integer;
  K       : Integer;
begin
  OldY1   := 0; // -- Ausgangswert t=0 f�r Graphen
  OldY2   := 0;
  cellSum := spalt * reih;
  Randomize();
  for I := 0 to reih -1 do
  begin
    for K := 0 to spalt -1 do
    begin
      curCell := cellList[K,I];
      limboWorld[K, I] := 0;
      curCell.State := 0;
      curCell.colr  := curCell.State * 255;
      curCell.Paint(paintImg.Canvas);
    end;
  end;
  curCell := cellList[round(spalt/2),0];
  curCell.State := 1;                                //  -- one seed
  curCell.colr  := curCell.State * 255;
  curCell.Paint(paintImg.Canvas);
  OldY1 := OldY1 / cellSum;
  RChart1.ClearGraf;       { initialize chart }
  RChart1.MoveTo (0,0);
end;



// ---------------------------------------------------------------------------//
// ---------------------------- Berechnungen ---------------------------------//
// ---------------------------------------------------------------------------//
// --- Moorsche Nachbarschaft, mit den Abstand 1 �berpr�fen
procedure TForm1.checkNei (K, I: Integer);
var
  u  : Integer;
  v  : Integer;
  Xp : Integer;
  Yp : Integer;
  Dstr : String;
  Rule : String;
begin
  // --- Summe berechnen ---
  Dstr := '';
  u := -1;
  for v := -1 to 1 do
  begin
    Xp := K + v;
    Yp := I + u;
    // -- Torus --
    if Xp < 0       then Xp := spalt-1;
    if Xp > spalt-1 then Xp := 0;
    if Yp < 0       then Yp := reih-1;
    if Yp > reih-1  then Yp := 0;
    Dstr := Dstr + intToStr(cellList[Xp, Yp].state);  // -- states of the neighbor-cells into string
  end;
  Rule := E_Rule.Text;        // -- pick the rule-code
  If Dstr = '111' then begin  // -- compare rules and state-string
    limboWorld[K, I] := StrToInt(Rule[1]);
  end else
  If Dstr = '110' then begin
    limboWorld[K, I] := StrToInt(Rule[2]);
  end else
  If Dstr = '101' then begin
    limboWorld[K, I] := StrToInt(Rule[3]);
  end else
  If Dstr = '100' then begin
    limboWorld[K, I] := StrToInt(Rule[4]);
  end else
  If Dstr = '011' then begin
    limboWorld[K, I] := StrToInt(Rule[5]);
  end else
  If Dstr = '010' then begin
    limboWorld[K, I] := StrToInt(Rule[6]);
  end else
  If Dstr = '001' then begin
    limboWorld[K, I] := StrToInt(Rule[7]);
  end else
  If Dstr = '000' then begin
    limboWorld[K, I] := StrToInt(Rule[8]);
  end;
end;

// -----------------------------------------------------------------------------
// *** Rekursive Befehle ausf�hren ***
// -----------------------------------------------------------------------------
procedure TForm1.Timer1Timer(Sender: TObject);
var
  curCell : TCell;
  I       : Integer;
  K       : Integer;
  M       : Integer;
  agCount : Integer;
  agReih  : Integer;
  agSpalt : Integer;
begin
  // --- Zellennachbarschaft �berpr�fen ---
  If steps > reih-1 then steps := 0;
  I := steps;
  for K := 0 to spalt -1 do
  begin
    checkNei(K, I);           // -- Z�hlt die Agenten in der Moore Nachbarschaft
  end;
  // --- Zellenstatus ver�ndern ---
  for K := 0 to spalt -1 do
  begin
    curCell := cellList[K,I];
    If limboWorld[K, I] = 1 then begin        // -- System mit leeren Zellen
      If curCell.state = 0 then begin
        curCell.birth := steps;               // -- save the birthtime of development
      end;
      curCell.state    := 1;
      limboWorld[K, I] := 0;                  // -- reset LimboWorld
    end;
    curCell.colr := curCell.State * (255 - (steps - curCell.birth)); // -- color from age
    curCell.Paint(paintImg.Canvas);
  end;
  steps := steps +1;
  plotEntropy (steps);
  // -- stop condition --
  If steps = reih-1  Then begin
    Timer1.enabled := false;                  // -- stop automata
  end;
end;
// -----------------------------------------------------------------------------

procedure TForm1.plotEntropy (steps: Integer);
var
  K : Integer;
  entroTop    : Extended;
  entroMet    : Extended;
  an_index    : Integer;
  prob_list   : Array [0..15] of Real;
  counter_list: Array [0..15] of Integer;
  binary_list : Array [0..3]  of Integer;
  sum         : Integer;
begin
  for K := 0 to length(counter_list)-1 Do
  begin
    counter_list[K] := 0;
    prob_list [K] := 0;
  end;
  // fill the counter-list with the appropriate values.  that is to say, count
  // the number of occurrences of each distinct 4-patch pattern of on? values.
  for K := 0 to spalt -1 do
  begin
    set_binary_list        (K, steps, binary_list);
    an_index               := set_an_index(binary_list);
    counter_list[an_index] := counter_list[an_index] +1;
  end;
  // calculate the sum of the counter-list-items
  sum := 0;
  for K := 0 to length(counter_list)-1 Do
  begin
    sum := sum + counter_list[K];
  end;
  // make a list of the probabilities of each pattern occurring
  for K := 0 to length(counter_list)-1 Do
  begin
    prob_list [K] := counter_list[K] / sum;
  end;
  // X = 4 (correlation length): size of subsequences analyzed
  // topological entropy = 1/X * the log of the sum of the probabilities rounded up
  // metric entropy = -1/X * the sum of the products of each probability and its log
  entroTop := 0;
  entroMet := 0;
  for K := 0 to length(prob_list)-1 Do
  begin
    If prob_list[K] > 0 then
    begin
      entroTop := entroTop + 1;
      entroMet := entroMet + (prob_list[K] * log2(prob_list[K]));
    end;
  end;
  entroTop :=  1/4* log2(entroTop);
  entroMet := -1/4* entroMet;

  lbl_Steps.Caption := intToStr (steps);
  //--- Ausgabe in Graph ---
  if steps < 500 then begin // -- bis Maximalwert Plotten
    RChart1.ActiveLayer:= 1;
    RChart1.DataColor := clBlue;
    RChart1.Line(steps-1, OldY1, steps, entroTop);
    OldY1 := entroTop;
    RChart1.ActiveLayer:= 3;
    RChart1.DataColor := clGreen;
    RChart1.Line(steps-1, OldY2, steps, entroMet);
    OldY2:=entroMet;
  end;
end;

function TForm1.set_an_index(binary_list : Array of Integer): Integer;
var
  sum : Extended;
  I   : Integer;
begin
  sum := 0;
  for I := 0 To length(binary_list)-1 Do
  begin
    sum := sum + Power (2, I) * (binary_list[length(binary_list)-1-I]);
  end;
  Result := round(sum);
end;

procedure TForm1.set_binary_list (xPos: Integer; steps: Integer; var binary_list : Array of Integer);
var
  curCell : TCell;
  I : Integer;
  K : Integer;
  L : Integer;
begin
  I := steps - 1;
  for L:= 0 to 3 Do
  begin
    K := xPos + L;
    If K > spalt - 1 Then begin
      K := K - spalt;   // -- circle cells
    end;
    binary_list[L] := 0;
    binary_list[L] := cellList[K,I].state;
  end;
end;
// ---------------------------------------------------------------------------//
// -------------------------- Funktionen -------------------------------------//
// ---------------------------------------------------------------------------//
// *** Entferung berechnen ***
function TForm1.CalcDistance(pAX: Integer; pAY: Integer; pBX: Integer; pBY: Integer): Integer;
var
  temp : double;
begin
  temp := sqrt(Power((pAX - pBX), 2) + Power((pAY - pBY), 2));
  Result := Round(temp);
end;

// *** Zufallszahl innerhalb eines Bereichs berechnen ***
function TForm1.rndN(lower : Integer; upper : Integer):Integer;
begin
  Result := round ((upper - lower + 1) * Random() + lower);
end;

// ---------------------------------------------------------------------------//
// ------------------------------- Schalter ----------------------------------//
// ---------------------------------------------------------------------------//
procedure TForm1.B_setupClick(Sender: TObject);
begin
  steps := 0;
  setupCells;
  Timer1.enabled := true;
end;

procedure TForm1.B_stopClick(Sender: TObject);
begin
  Timer1.enabled := not(Timer1.enabled);
end;

procedure TForm1.FormDestroy(Sender: TObject);
begin
  paintImg.Free;
  ZeichenPanel.Free;
  AgentList.Destroy;
end;

procedure TForm1.B_setupRndClick(Sender: TObject);
var
  curCell : TCell;
  I       : Integer;
  K       : Integer;
begin
  OldY1 := 0; // -- Ausgangswert t=0 f�r Graphen
  OldY2 := 0;
  steps := 0;
  cellSum := spalt * reih;
  Randomize();
  for I := 0 to reih -1 do
  begin
    for K := 0 to spalt -1 do
    begin
      curCell := cellList[K,I];
      limboWorld[K, I] := 0;
      If I = 0 then begin
        curCell.State := random(2);            //  -- random seed in the first row
      end else begin
        curCell.State := 0;
      end;
        curCell.colr  := curCell.State * 255;
        curCell.Paint(paintImg.Canvas);
    end;
  end;
  OldY1 := OldY1 / cellSum;
  RChart1.ClearGraf;       { initialize chart }
  RChart1.MoveTo (0,0);
  Timer1.enabled := true;
end;

procedure TForm1.CB_preChange(Sender: TObject);
begin
  E_Rule.Text := CB_pre.Text;
  steps := 0;
  setupCells;
  Timer1.enabled := true;
end;

end.

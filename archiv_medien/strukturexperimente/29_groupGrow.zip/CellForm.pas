(********************************************************************)
(*                                                                  *)
(*                                                                  *)
(*                       2D Cellular Automata                       *)
(*                     group segregation model                      *)
(*                          Version 1.0                             *)
(*                                                                  *)
(*                                                                  *)
(*     Programmierer: Reinhard K�nig                   January 2006 *)
(*                    http://www.entwurfsforschung.de               *)
(*                                                                  *)
(*     Last Update: Jan-18, 2006                                    *)
(*                                                                  *)
(********************************************************************) 
{revision history:

1.0     [Jan-18, 2006]
        first release to the public
}

unit CellForm;

interface

uses
  Windows, Messages, SysUtils, Variants, Classes, Graphics, Controls, Forms,
  Dialogs, StdCtrls, cell_P, ExtCtrls, ButtonGroup, ComCtrls, Math, ToolWin,
  ImgList, Epina.SDL.rchart;

type
  TForm1 = class(TForm)
    ZeichenPanel   : TPanel;
    Timer1         : TTimer;
    lbl_Steps      : TLabel;
    B_setup        : TButton;
    lbl_timesteps  : TLabel;
    B_stop         : TButton;
    RChart1        : TRChart;
    E_probab       : TEdit;
    Lbl_Prob       : TLabel;
    Cb_rnd         : TCheckBox;
    Lbl_death      : TLabel;
    E_death        : TEdit;
    Lbl_statProb   : TLabel;
    E_statProb     : TEdit;
    Cb_aging       : TCheckBox;
    procedure B_stopClick   (Sender: TObject);
    procedure B_setupClick  (Sender: TObject);
    procedure Timer1Timer   (Sender: TObject);
    procedure FormDestroy   (Sender: TObject);
    procedure FormCreate    (Sender: TObject);
  private
    AgentList  : TList;
    cellList   : Array of Array of TCell;
    limboWorld : Array of Array of Integer;
    function  CalcDistance  (pAX: Integer; pAY: Integer; pBX: Integer; pBY: Integer): Integer;
    function  rndN          (lower: Integer; upper: Integer):Integer;
    procedure checkNei      (K, I: Integer);
    procedure createPaintImg;
    procedure createRaster;
    procedure setupCells;
    procedure plot          (stateSum: Integer; sumWhite: Integer; sumBlack: Integer);
    procedure checkVote     (K, I: Integer);
    procedure segregation;
    procedure ageCheck;
  public
end;

var
  Form1    : TForm1;
  paintImg : TImage;

implementation

{$R *.dfm}

const                            //-- globale Konstanten
  cellScal = 4;                  //-- Zellen  gr��e
  AgSize   = 1;                  //-- Agenten gr��e
  halfScal = round(cellScal/2);
var                              //-- globale Variablen
  reih    : Integer;             //-- Zellen-Reihen gesamt
  spalt   : Integer;             //-- Zellen-Spalten gesamt
  steps   : Integer;
  Xmax    : Integer;
  Ymax    : Integer;
  cellSum : Integer;
  OldY1   : Integer;              //-- Speichert die Position t-1 f�r Graphen
  OldY2   : Integer;              //-- Speichert die Position t-1 f�r Graphen
  OldY3   : Integer;

// ---------------------------------------------------------------------------//
// *** Initialisierung ***
procedure TForm1.FormCreate(Sender: TObject);
begin
  spalt     := round (ZeichenPanel.Width / cellScal);
  reih      := round (ZeichenPanel.Height / cellScal);
  Xmax      := (spalt) * cellScal;
  Ymax      := (reih ) * cellScal;
  AgentList := TList.Create;
  SetLength(cellList, spalt, reih);
  SetLength(limboWorld, spalt, reih);
  createPaintImg;
  CreateRaster;
  ZeichenPanel.DoubleBuffered := True;       //-- Verhindert Flackern der Zellen
  steps := 0;

  // -- Diagramm initialisieren --
  RChart1.Scale1X.RangeLow  := 0;     { range of chart area }
  RChart1.Scale1X.RangeHigh := 300;  //-- Maximale Reichweite = 1000 bei Testversion!!!
  RChart1.Scale1Y.RangeLow  := 0;   //0.45;
  RChart1.Scale1Y.RangeHigh := spalt * reih + 100; //0.55;
  RChart1.ShowGraf;
end;

// ---------------------------------------------------------------------------//
// ------------------------- Elemente erstellen ------------------------------//
// ---------------------------------------------------------------------------//

// *** Legt eine leere Zeichenfl�che �ber das Zeichenpanel ***
procedure TForm1.createPaintImg;
begin
  paintImg        := TImage.Create(self);
  paintImg.Parent := ZeichenPanel;
  paintImg.top    := 0;
  paintImg.Left   := 0;
  paintImg.Height := ZeichenPanel.Height;
  paintImg.Width  := ZeichenPanel.Width;
end;

// *** Zellen erstellen ***
procedure TForm1.CreateRaster;
var
  curCell : TCell;
  I       : Integer;
  K       : Integer;
  upperB  : Integer;
  lowerB  : Integer;
begin
  for I := 0 to reih -1 do
  begin
    for K := 0 to spalt -1 do
    begin
      curCell := TCell.Create(halfScal + K * cellScal, halfScal + I * cellScal, halfScal, 0);
      cellList[K,I] := curCell;
    end;
  end;
  setupCells;
end;

// *** Zellen initialisieren ***
procedure TForm1.setupCells;
var
  curCell : TCell;
  I       : Integer;
  K       : Integer;
begin
  OldY1   := 0; // -- Ausgangswert t=0 f�r Graphen
  OldY2   := 0;
  OldY3   := 0;
  cellSum := spalt * reih;
  Randomize();
  for I := 0 to reih -1 do
  begin
    for K := 0 to spalt -1 do
    begin
      curCell          := cellList[K,I];
      curCell.State    := 0;
      limboWorld[K, I] := 0;
      curCell.probab   := StrToInt(E_probab.Text)/100;
      curCell.colr     := curCell.State * 255;
      curCell.birth    := 0;
      curCell.Paint(paintImg.Canvas);
      curCell.Dist := calcDistance(curCell.FPos.X,curCell.FPos.Y, // -- distance to center for every cell
                                   cellList[round(spalt/2),round(reih/2)].Fpos.X,
                                   cellList[round(spalt/2),round(reih/2)].Fpos.Y);
    end;
  end;
  if Cb_rnd.state = cbChecked Then  // -- random distribution of initial seed-cells
  begin
    for K := 0 to 20 do
    begin
      curCell := cellList[random(reih),random(spalt)];
      curCell.state := 1;
      curCell.Paint(paintImg.Canvas);
    end;
  end;
  curCell := cellList[round(spalt/2),round(reih/2)];
  curCell.State := 1;                                //  -- one seed
  curCell.colr  := curCell.State * 255;
  curCell.Paint(paintImg.Canvas);
  RChart1.ClearGraf;                                 // -- initialize chart 
  RChart1.MoveTo (0,0);
end;

// ---------------------------------------------------------------------------//
// ---------------------------- Calculations ---------------------------------//
// ---------------------------------------------------------------------------//
// --- Moorsche Nachbarschaft, mit den Abstand 1 �berpr�fen
procedure TForm1.checkNei (K, I: Integer);
var
  u  : Integer;
  v  : Integer;
  Xp : Integer;
  Yp : Integer;
  sumState : Integer;
begin
  // --- Summe berechnen ---
  sumState := 0;
  for v := -1 to 1 do
  begin
    for u := -1 to 1 do
    begin
      Xp := K + u;
      Yp := I + v;
      // -- Torus --
      if Xp < 0       then Xp := spalt-1;
      if Xp > spalt-1 then Xp := 0;
      if Yp < 0       then Yp := reih-1;
      if Yp > reih-1  then Yp := 0;
      sumState := sumState + cellList[Xp, Yp].state;  // -- count the states of the neighbours
    end;
  end;
  sumState := sumState - cellList[K, I].state;        // -- subtract the self-state of the cell
  //If (sumState = 1) or (sumState = 2) then begin    // -- transition rule
  If (sumState >= 1) then begin
    limboWorld[K, I] := 1;
  end else begin
    limboWorld[K, I] := 0;
  end;
end;

// --- Moorsche Nachbarschaft, mit den Abstand 1 �berpr�fen
procedure TForm1.checkVote (K, I: Integer);
var
  u  : Integer;
  v  : Integer;
  Xp : Integer;
  Yp : Integer;
begin
  // --- Summe berechnen ---
  for v := -1 to 1 do
  begin
    for u := -1 to 1 do
    begin
      Xp := K + u;
      Yp := I + v;
      // -- Torus --
      if Xp < 0       then Xp := spalt-1;
      if Xp > spalt-1 then Xp := 0;
      if Yp < 0       then Yp := reih-1;
      if Yp > reih-1  then Yp := 0;
      If not ((Xp = K) and (Yp = I)) Then
      begin
        If cellList[Xp, Yp].State = 1 Then cellList[K,I].neighBlack := cellList[K,I].neighBlack + 1;
        If cellList[Xp, Yp].State = 2 Then cellList[K,I].neighWhite := cellList[K,I].neighWhite + 1;
      end;
    end;
  end;
end;

// *** check age or the developed cell ***
procedure TForm1.ageCheck;
var
  curCell : TCell;
  K, I    : Integer;
  probab  : Real;
  death   : Integer;
begin
  death  := StrToInt(E_death.Text);
  probab := StrToInt(E_probab.Text)/100;
  for I  := 0 to reih -1 do
  begin
    for K := 0 to spalt -1 do
    begin
      curCell := cellList[K,I];
      If Cb_aging.State = cbChecked Then
      begin
        curCell.age := (steps - curCell.birth);    // -- increase age every step
        If curCell.age > death Then begin          // -- Cell dies on overaging
          curCell.age    := 0;
          curCell.state  := 0;
          curCell.probab := probab;
        end;
      end;
    end;
  end;
end;

// *****************************************************************************
// *** Rekursive Befehle ausf�hren ***
procedure TForm1.Timer1Timer(Sender: TObject);
var
  curCell  : TCell;
  K, I     : Integer;
  probab   : Real;
  statProb : Real;
  stateSum : Integer;
  sumWhite : Integer;
  sumBlack : Integer;
begin
  Randomize;
  stateSum := 0;
  sumWhite := 0;
  sumBlack := 0;
  probab   := StrToInt(E_probab.Text)/100;
  statProb := StrToInt(E_statProb.Text)/100;
  // --- Zellennachbarschaft �berpr�fen ---
  for I := 0 to reih -1 do
  begin
    for K := 0 to spalt -1 do
    begin
      checkNei(K, I);                // -- Z�hlt die Agenten in der Moore Nachbarschaft
    end;
  end;
  ageCheck;                          // -- check age or the developed cell
  // -- Zellenstatus ver�ndern ---
  for I := 0 to reih -1 do
  begin
    for K := 0 to spalt -1 do
    begin
      curCell := cellList[K,I];
      // --- change the states of state-0-cells in dependence of the limboWorld = transition Rules ---
      If (limboWorld[K, I] = 1) and (curCell.state = 0) then begin
        If Random() < curCell.probab Then         // -- Probability
        begin
          // -- Wenn Zelle "geboren" wird
          curCell.birth := steps;                 // -- save the birthtime of development
          curCell.age   := 0;
          // -- Two possible states --
          If curCell.dist < 100  Then             // -- inner area
          begin
            If Random() <= statProb Then begin    // -- cess-state 1/2 Probability
              curCell.state := 1;
            end else begin
              curCell.state := 2;
            end
          end
          Else //If curCell.dist < 180 Then       // -- outer area
          begin
            If Random() <= statProb Then begin    // -- cess-state 1/2 Probability
              curCell.state := 2;
            end else begin
              curCell.state := 1;
            end;
          end;
        end else begin
          IF curCell.probab = probab Then curCell.birth := steps; // -- save also the birthtime of undeveloped cells
          curCell.probab := curCell.probab * curCell.probab;      // -- if not developed, reduce the probability
        end;
      end;
      limboWorld[K, I] := 0;                                      // -- reset LimboWorld
      If curCell.state > 0 Then stateSum := stateSum + 1;         // -- count cells
      If curCell.state = 2 Then sumWhite := sumWhite + 1;
      If curCell.state = 1 Then sumBlack := sumBlack + 1;
    end;
  end;
  segregation;                                    // -- vote dependence of the neighborstate
  steps := steps +1;                              // -- increase steps
  plot(stateSum, sumWhite, sumBlack);             // -- plot the number of cells
  If steps = 300 Then begin                       // -- stop condition
    Timer1.enabled := false;                      // -- stop automata
  end;
end;

procedure TForm1.segregation;
var
  curCell : TCell;
  I       : Integer;
  K       : Integer;
begin
  for I := 0 to reih -1 do
  begin
    for K := 0 to spalt -1 do
    begin
      curCell := cellList[K,I];
      curCell.neighBlack := 0;
      curCell.neighWhite := 0;
      checkVote(K, I);                  // -- Check states of the neighbor cells
      // -- voting Rule --
      If curCell.State > 0 Then
      If curCell.neighWhite > 4 Then begin
        curCell.State := 2;
      end else
      If curCell.neighBlack > 4 Then
      begin
        curCell.State := 1;
      end;
      curCell.colr  := curCell.State * (127 - 2*curCell.age);
      curCell.Paint (paintImg.Canvas);
    end;
  end;
end;

//*** Ausgabe in Graph ***
procedure TForm1.plot(stateSum: Integer; sumWhite: Integer; sumBlack: Integer);
begin
  lbl_Steps.Caption := intToStr (steps);
  if steps < 300 then begin                        // -- bis Maximalwert Plotten
    RChart1.ActiveLayer:= 1;
    RChart1.DataColor := clRed;
    RChart1.Line(steps-1, OldY1, steps, stateSum);
    OldY1 := stateSum;
    RChart1.ActiveLayer:= 3;
    RChart1.DataColor := clGreen;
    RChart1.Line(steps-1, OldY2, steps, sumWhite);
    OldY2:=sumWhite;
    RChart1.ActiveLayer:= 4;
    RChart1.DataColor := clBlue;
    RChart1.Line(steps-1, OldY3, steps, sumBlack);
    OldY3:=sumBlack;
  end;
end;

// ---------------------------------------------------------------------------//
// -------------------------- Funktionen -------------------------------------//
// ---------------------------------------------------------------------------//
// *** Entferung berechnen ***
function TForm1.CalcDistance(pAX: Integer; pAY: Integer; pBX: Integer; pBY: Integer): Integer;
var
  temp : double;
begin
  temp := sqrt(Power((pAX - pBX), 2) + Power((pAY - pBY), 2));
  Result := Round(temp);
end;

// *** Zufallszahl innerhalb eines Bereichs berechnen ***
function TForm1.rndN(lower : Integer; upper : Integer):Integer;
begin
  Result := round ((upper - lower + 1) * Random() + lower);
end;

// ---------------------------------------------------------------------------//
// ------------------------------- Schalter ----------------------------------//
// ---------------------------------------------------------------------------//
procedure TForm1.B_setupClick(Sender: TObject);
begin
  steps := 0;
  setupCells;
  Timer1.enabled := true;
end;

procedure TForm1.B_stopClick(Sender: TObject);
begin
  Timer1.enabled := not(Timer1.enabled);
end;

procedure TForm1.FormDestroy(Sender: TObject);
begin
  paintImg.Free;
  ZeichenPanel.Free;
  AgentList.Destroy;
end;

end.

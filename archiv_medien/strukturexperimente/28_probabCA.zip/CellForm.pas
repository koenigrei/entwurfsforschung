(********************************************************************)
(*                                                                  *)
(*                                                                  *)
(*                       2D Cellular Automata                       *)
(*                     Growth with  Probability                     *)
(*                          Version 1.0                             *)
(*                                                                  *)
(*                                                                  *)
(*     Programmierer: Reinhard K�nig                   January 2006 *)
(*                    http://www.entwurfsforschung.de               *)
(*                                                                  *)
(*     Last Update: Jan-20, 2006                                    *)
(*                                                                  *)
(********************************************************************) 
{revision history:

1.0     [Jan-20, 2006]
        first release to the public
}

unit CellForm;

interface

uses
  Windows, Messages, SysUtils, Variants, Classes, Graphics, Controls, Forms,
  Dialogs, StdCtrls, cell_P, ExtCtrls, ButtonGroup, ComCtrls, Math, ToolWin,
  ImgList, Epina.SDL.rchart;

type
  TForm1 = class(TForm)
    ZeichenPanel   : TPanel;
    Timer1         : TTimer;
    lbl_Steps      : TLabel;
    B_setup        : TButton;
    lbl_timesteps  : TLabel;
    B_stop         : TButton;
    RChart1        : TRChart;
    E_probab: TEdit;
    Label1: TLabel;
    Cb_rnd: TCheckBox;
    Lbl_death: TLabel;
    E_death: TEdit;
    procedure B_stopClick   (Sender: TObject);
    procedure B_setupClick  (Sender: TObject);
    procedure Timer1Timer   (Sender: TObject);
    procedure FormDestroy   (Sender: TObject);
    procedure FormCreate    (Sender: TObject);
  private
    AgentList    : TList;
    cellList     : Array of Array of TCell;
    limboWorld   : Array of Array of Integer;
    function  CalcDistance  (pAX: Integer; pAY: Integer; pBX: Integer; pBY: Integer): Integer;
    function  rndN          (lower: Integer; upper: Integer):Integer;
    procedure checkNei      (K, I: Integer);
    procedure createPaintImg;
    procedure createRaster;
    procedure setupCells;
  public
end;

var
  Form1    : TForm1;
  paintImg : TImage;

implementation

{$R *.dfm}

const                            //-- globale Konstanten
  cellScal = 4;                  //-- Zellen  gr��e
  AgSize   = 1;                  //-- Agenten gr��e
  halfScal = round(cellScal/2);
var                              //-- globale Variablen
  reih    : Integer;             //-- Zellen-Reihen gesamt
  spalt   : Integer;             //-- Zellen-Spalten gesamt
  steps   : Integer;
  Xmax    : Integer;
  Ymax    : Integer;
  cellSum : Integer;
  OldY1   : Double;              //-- Speichert die Position t-1 f�r Graphen
  OldY2   : Double;              //-- Speichert die Position t-1 f�r Graphen

// ---------------------------------------------------------------------------//
// *** Initialisierung ***
procedure TForm1.FormCreate(Sender: TObject);
begin
  spalt     := round (ZeichenPanel.Width / cellScal);
  reih      := round (ZeichenPanel.Height / cellScal);
  Xmax      := (spalt) * cellScal;
  Ymax      := (reih ) * cellScal;
  AgentList := TList.Create;
  SetLength(cellList, spalt, reih);
  SetLength(limboWorld, spalt, reih);
  createPaintImg;
  CreateRaster;
  ZeichenPanel.DoubleBuffered := True;       //-- Verhindert Flackern der Zellen
  steps := 0;

  // -- Diagramm initialisieren --
  RChart1.Scale1X.RangeLow  := 0;     { range of chart area }
  RChart1.Scale1X.RangeHigh := 200;   //-- Maximale Reichweite = 1000 bei Testversion!!!
  RChart1.Scale1Y.RangeLow  := 0;     //0.45;
  RChart1.Scale1Y.RangeHigh := spalt * reih +100;
  RChart1.ShowGraf;
end;

// ---------------------------------------------------------------------------//
// ------------------------- Elemente erstellen ------------------------------//
// ---------------------------------------------------------------------------//

// *** Legt eine leere Zeichenfl�che �ber das Zeichenpanel ***
procedure TForm1.createPaintImg;
begin
  paintImg        := TImage.Create(self);
  paintImg.Parent := ZeichenPanel;
  paintImg.top    := 0;
  paintImg.Left   := 0;
  paintImg.Height := ZeichenPanel.Height;
  paintImg.Width  := ZeichenPanel.Width;
end;

// *** Zellen erstellen ***
procedure TForm1.CreateRaster;
var
  curCell : TCell;
  I       : Integer;
  K       : Integer;
  upperB  : Integer;
  lowerB  : Integer;
begin
  for I := 0 to reih -1 do
  begin
    for K := 0 to spalt -1 do
    begin
      curCell := TCell.Create(halfScal + K * cellScal, halfScal + I * cellScal, halfScal, 0);
      cellList[K,I] := curCell;
    end;
  end;
  setupCells;
end;

// *** Zellen initialisieren ***
procedure TForm1.setupCells;
var
  curCell : TCell;
  I       : Integer;
  K       : Integer;
begin
  OldY1   := 0; // -- Ausgangswert t=0 f�r Graphen
  cellSum := spalt * reih;
  Randomize();
  for I := 0 to reih -1 do
  begin
    for K := 0 to spalt -1 do
    begin
      curCell          := cellList[K,I];
      curCell.State    := 0;
      limboWorld[K, I] := 0;
      curCell.probab   := StrToInt(E_probab.Text)/100;
      curCell.colr     := curCell.State * 255;
      curCell.birth    := 0;
      curCell.Paint(paintImg.Canvas);
    end;
  end;
  if Cb_rnd.state = cbChecked Then  // -- random distribution of initial seed-cells
  begin
    for K := 0 to 20 do
    begin
      curCell := cellList[random(reih),random(spalt)];
      curCell.state := 1;
      curCell.Paint(paintImg.Canvas);
    end;
  end;
  curCell := cellList[round(spalt/2),round(reih/2)];
  curCell.State := 1;                                //  -- one seed
  curCell.colr  := curCell.State * 255;
  curCell.Paint(paintImg.Canvas);

  OldY1 := OldY1 / cellSum;
  RChart1.ClearGraf;       { initialize chart }
  RChart1.MoveTo (0,0);
end;

// ---------------------------------------------------------------------------//
// ---------------------------- Berechnungen ---------------------------------//
// ---------------------------------------------------------------------------//
// --- Moorsche Nachbarschaft, mit den Abstand 1 �berpr�fen
procedure TForm1.checkNei (K, I: Integer);
var
  u  : Integer;
  v  : Integer;
  Xp : Integer;
  Yp : Integer;
  sumState : Integer;
begin
  // --- Summe berechnen ---
  sumState := 0;
  for v := -1 to 1 do
  begin
    for u := -1 to 1 do
    begin
      Xp := K + u;
      Yp := I + v;
      // -- Torus --
      if Xp < 0       then Xp := spalt-1;
      if Xp > spalt-1 then Xp := 0;
      if Yp < 0       then Yp := reih-1;
      if Yp > reih-1  then Yp := 0;
      sumState := sumState + cellList[Xp, Yp].state;  // -- count the states of the neighbours
    end;
  end;
  sumState := sumState - cellList[K, I].state;        // -- subtract the self-state of the cell
  //If (sumState = 1) or (sumState = 2) then begin                         // -- transition rule
  If (sumState >= 1) then begin
    limboWorld[K, I] := 1;
  end else begin
    limboWorld[K, I] := 0;
  end;
end;

// *** Rekursive Befehle ausf�hren ***
procedure TForm1.Timer1Timer(Sender: TObject);
var
  curCell : TCell;
  I       : Integer;
  K       : Integer;
  M       : Integer;
  agCount : Integer;
  agReih  : Integer;
  agSpalt : Integer;
  probab  : Real;
  death   : Integer;
  stateSum    : Double;
  stateSumOld : Double;
  dStateChg   : Double;
begin
  stateSum := 0;
  Randomize;
  death := StrToInt(E_death.Text);
  probab := StrToInt(E_probab.Text)/100;
  // --- Zellennachbarschaft �berpr�fen ---
  for I := 0 to reih -1 do
  begin
    for K := 0 to spalt -1 do
    begin
      checkNei(K, I);           // -- Z�hlt die Agenten in der Moore Nachbarschaft
    end;
  end;
  // -- Zellenstatus ver�ndern ---
  for I := 0 to reih -1 do
  begin
    for K := 0 to spalt -1 do
    begin
      curCell := cellList[K,I];
      // -- check age or the developed cell --
        curCell.age := (steps - curCell.birth);     // -- increase age every step
        If curCell.age > death Then begin           // -- Cell dies on overaging
          curCell.age    := 0;
          curCell.state  := 0;
          curCell.probab := probab;
        end;
      // -- change the states --
      If limboWorld[K, I] = 1 then begin            // -- System mit leeren Zellen
        If Random() < curCell.probab Then begin     // -- Probability
          If curCell.state = 0 then begin           // -- Wenn Zelle "geboren" wird
            curCell.birth := steps;                 // -- save the birthtime of development
            curCell.age   := 0;
          end;
          curCell.state := 1;
        end else begin
          IF curCell.probab = probab Then curCell.birth := steps;
          curCell.probab := curCell.probab * curCell.probab; // -- save also the birthtime of undeveloped cells
        end;
      end;
      limboWorld[K, I] := 0;                        // -- reset LimboWorld
      stateSum := stateSum + curCell.State;
      curCell.colr  := curCell.State * (255 - 5*(curCell.age)); // -- color from age
      curCell.Paint (paintImg.Canvas);
    end;
  end;
  steps := steps +1;
  lbl_Steps.Caption := intToStr (steps);
  //--- Ausgabe in Graph ---
  if steps < 1000 then begin // -- bis Maximalwert Plotten
    RChart1.ActiveLayer := 1;
    RChart1.DataColor   := clRed;
    RChart1.DrawTo(steps, stateSum);
  end;
end;

// ---------------------------------------------------------------------------//
// -------------------------- Funktionen -------------------------------------//
// ---------------------------------------------------------------------------//
// *** Entferung berechnen ***
function TForm1.CalcDistance(pAX: Integer; pAY: Integer; pBX: Integer; pBY: Integer): Integer;
var
  temp : double;
begin
  temp := sqrt(Power((pAX - pBX), 2) + Power((pAY - pBY), 2));
  Result := Round(temp);
end;

// *** Zufallszahl innerhalb eines Bereichs berechnen ***
function TForm1.rndN(lower : Integer; upper : Integer):Integer;
begin
  Result := round ((upper - lower + 1) * Random() + lower);
end;

// ---------------------------------------------------------------------------//
// ------------------------------- Schalter ----------------------------------//
// ---------------------------------------------------------------------------//
procedure TForm1.B_setupClick(Sender: TObject);
begin
  steps := 0;
  setupCells;
end;

procedure TForm1.B_stopClick(Sender: TObject);
begin
  Timer1.enabled := not(Timer1.enabled);
end;

procedure TForm1.FormDestroy(Sender: TObject);
begin
  paintImg.Free;
  ZeichenPanel.Free;
  AgentList.Destroy;
end;

end.

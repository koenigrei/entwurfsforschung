unit calcer;

interface

uses
  Windows, Graphics, Classes, agenten, Math;

type
  TCalcer = class
  private
  public
    function  CalcDistance (pX1: Integer; pY1: Integer; pX2: Integer; pY2: Integer): Integer;
  published
  end;

implementation

function TCalcer.CalcDistance(pX1: Integer; pY1: Integer; pX2: Integer; pY2: Integer): Integer;
begin
  Result := Round(sqrt(Power((pX1 - pX2), 2) + Power((pY1 - pY2), 2)));
end;

end.

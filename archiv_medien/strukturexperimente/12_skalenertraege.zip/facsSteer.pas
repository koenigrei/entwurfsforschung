(********************************************************************)
(*                                                                  *) 
(*                                                                  *)
(*                         Skalenertr�ge                            *)
(*                     und und zentrale Orte                        *)
(*                          Version 1.0                             *)
(*                                                                  *) 
(*     Programmierer: Reinhard K�nig                     July 2005  *)
(*                    http://www.entwurfsforschung.de/              *)
(*                                                                  *)
(*     Last Update: July-09, 2005                                   *)
(*                                                                  *) 
(********************************************************************) 
{revision history:

1.0     [July-09, 2005]
        first release to the public
}

unit facsSteer;

interface

uses
  Windows, Messages, SysUtils, Variants, Classes, Graphics, Controls, Forms, cell,
  Dialogs, ExtCtrls, Grids, agenten, Math, ConvUtils, StdCtrls, AppEvnts, Types,
  Menus, calcer;

type
  TMovePlate = class(TForm)
    ApplicationEvents1 : TApplicationEvents;
    Panel1: TPanel;
    ImagePaint: TImage;
    Panel2: TPanel;
    GroupBox3: TGroupBox;
    Label4: TLabel;
    Lbl_ProdKost: TLabel;
    Label9: TLabel;
    Lbl_FahrtKost: TLabel;
    Label12: TLabel;
    Lbl_Skalen: TLabel;
    SB_ProdKost: TScrollBar;
    SB_FahrtKost: TScrollBar;
    SB_Skalen: TScrollBar;
    Label1: TLabel;
    Label2: TLabel;
    CB_moveMarkt: TCheckBox;
    ButtonPause: TButton;
    procedure SB_SkalenChange(Sender: TObject);
    procedure SB_FahrtKostChange(Sender: TObject);
    procedure SB_ProdKostChange(Sender: TObject);
    procedure ButtonPauseClick(Sender: TObject);
    procedure FormDestroy(Sender: TObject);
    procedure ImagePaintMouseMove(Sender: TObject; Shift: TShiftState; X,
      Y: Integer);
    procedure ApplicationEvents1Idle(Sender: TObject; var Done: Boolean);
    procedure PaintBox1Paint(Sender: TObject);
    procedure FormCreate(Sender: TObject);
  private
    { Private declarations }
    ShapesList: TList;
    CurrShape : TBaseShape;
    procedure CommonPaint (Canvas: TCanvas);
    procedure MakeMarkt;
    procedure RectanglPaint  (Canvas: TCanvas);
    procedure RectanglCreate (Canvas: TCanvas);
    procedure calcLocalPreis;
    procedure deleteZells;
  public
    { Public declarations }
  end;

var
  MovePlate: TMovePlate;

implementation

{$R *.dfm}

const
    NUM_BALLS = 10;
    cellScal  = 8;
var
  reih      : Integer;
  spalt     : Integer;
  Dir       : Integer = 1;
  StepX     : Integer;
  StepY     : Integer;
  LEFT_BORDER   : Integer;
  TOP_BORDER    : Integer;
  RIGHT_BORDER  : Integer;
  BOTTOM_BORDER : Integer;
  Mouse_Rad     : Integer;
  MouseX        : Integer;
  MouseY        : Integer;
  Backpuffer    : TBitmap;
  cellList      : Array of Array of TCell;
  Abstand       : Integer;
  Sichtfeld     : Integer;
  test          : Integer;
  fertig        : Boolean;

function distance(pX1: Integer; pY1: Integer; pX2: Integer; pY2: Integer): Integer;
  var temp: double;
  begin
  temp := sqrt(Power((pX1 - pX2), 2) + Power((pY1 - pY2), 2));
  distance := Round(temp);
end;

procedure TMovePlate.FormCreate(Sender: TObject);
begin
  scaled := false;
  fertig := false;
  // --- deklarieren des Arrays f�r die 'Cellen' -------------------------------
  spalt := round (ImagePaint.Width / cellScal);
  reih  := round (ImagePaint.Height / cellScal);
  SetLength(cellList, reih, spalt);
  // --- initialization and creation of the list -------------------------------
  ShapesList                    := TList.Create;
  MovePlate.Color               := clBlack;
  MovePlate.Panel2.Color        := clInfoText;
  MovePlate.Canvas.Pen.Color    := clred;
  MovePlate.Canvas.Brush.Color  := clred;
  LEFT_BORDER                   := ImagePaint.Left-5;
  TOP_BORDER                    := ImagePaint.Top-5;
  RIGHT_BORDER                  := ImagePaint.Width-5;
  BOTTOM_BORDER                 := ImagePaint.Height-5;
  // --- Slider & Label --------------------------------------------------------
  //---
  Lbl_ProdKost.Caption        := IntToStr(SB_ProdKost.Position);
  Lbl_FahrtKost.Caption       := FloatToStr(SB_FahrtKost.Position * 0.001);
  Lbl_Skalen.Caption          := FloatToStr(0.996 + SB_Skalen.Position * 0.0002);
  // --- Zwischenspeicher f�r die Bildaktualisierung ---------------------------
  Backpuffer                    := TBitmap.create;
  Backpuffer.width              := ImagePaint.width;
  Backpuffer.height             := ImagePaint.height;
  Backpuffer.canvas.brush.color := clgreen;
  Backpuffer.canvas.rectangle   (10,10,Backpuffer.width,Backpuffer.height);
  RectanglCreate (Backpuffer.Canvas);
  MakeMarkt;
end;

// *********************************
// *** ------- Agenten --------- ***
// *********************************
// *** Zeichnet die Agenten ***
procedure TMovePlate.PaintBox1Paint(Sender: TObject);
begin
  MovePlate.Color := clBlack;
  MovePlate.canvas.brush.color := clgreen;
  MovePlate.canvas.pen.color := clgreen;
  MovePlate.canvas.pen.width := 2;
  MovePlate.canvas.rectangle(5,5,810,610);
  MovePlate.refresh;
  CommonPaint (Canvas);
end;

procedure TMovePlate.CommonPaint (Canvas: TCanvas);
var
  I     : Integer;
  AShape: TAgent;
begin
  // repaint each shape of the list
  for I := 0 to ShapesList.Count - 1 do
  begin
    AShape := ShapesList.Items [I];
    AShape.BindungSet := 0; // --- Anzahl Bindungen je Typ zur�cksetzen
    AShape.Paint (Canvas);
  end;
end;

// *** Aktualisierungen je Durchlauf***
procedure TMovePlate.ApplicationEvents1Idle(Sender: TObject; var Done: Boolean);
var
  I         : Integer;
  //J         : Integer;
  AShape    : TAgent;
  distMouse : Integer;
  //Area      : Trect;
begin
  If fertig = false then done := false;
  If fertig = true  then begin done := true; exit; end;
  //------------------------------------------//
  If (CB_moveMarkt.State = cbChecked) Then Begin
  for I := 0 to ShapesList.Count - 1 do
  begin
    AShape := ShapesList.Items [I];
    distMouse := distance (AShape.PositionX, AShape.PositionY, MouseX, MouseY);
    If (distMouse < Mouse_Rad) // --- MausInteraktion
    then begin
      AShape.FStepX := Dir * round ((AShape.PositionX - MouseX) * 0.1); //AShape.FStepX * -3;
      AShape.FStepY := Dir * round ((AShape.PositionY - MouseY) * 0.1); //AShape.FStepY * -3;
    end;
    AShape.SetRndDir (1.0001);
    // --- Randlos Torus--- // Rand nicht �berschreiten
    if AShape.PositionX < LEFT_BORDER  then
      AShape.PositionX := RIGHT_BORDER;
    if AShape.PositionX > RIGHT_BORDER then
      AShape.PositionX := LEFT_BORDER;
    if AShape.PositionY < TOP_BORDER then
      AShape.PositionY := BOTTOM_BORDER;
    if AShape.PositionY > BOTTOM_BORDER then
      AShape.PositionY := TOP_BORDER;
    // ++++ Position aktualisieren ++++
    AShape.PositionX := AShape.FPositionX + round(AShape.FStepX);
    AShape.PositionY := AShape.FPositionY + round(AShape.FStepY);
  end;
  end;

  // --- berechnen, zeichnen und verbinden ----
  RectanglPaint (Backpuffer.Canvas);  // --- L�scht Zeichung und Aktualisiert Zellen
  calcLocalPreis;                     // --- lokale Preise berechnen
  CommonPaint (Backpuffer.Canvas);    // --- Zeichnet die Zellen
  /// --- Bild aktualisieren ---
  //BitBlt(Backpuffer.Canvas.Handle, bildleft, bildtop, Bild.Width, Bild.Height, Bild.canvas.handle, 0, 0, SRCCOPY);//Bild auf Backpuffer kopieren
  ImagePaint.Invalidate;
  BitBlt(ImagePaint.Canvas.Handle, 0, 0, Backpuffer.Width, Backpuffer.Height, Backpuffer.canvas.handle, 0, 0, SRCCOPY);//Backpuffer auf das Formular kopieren
end;

procedure TMovePlate.ImagePaintMouseMove(Sender: TObject; Shift: TShiftState; X, Y: Integer);
begin
  MouseX := X;
  MouseY := Y;
end;


// *********************************
// *** ------- Zellen ---------- ***
//**********************************
// *** Erstellt das ZellenRaster ***
procedure TMovePlate.RectanglCreate (Canvas: TCanvas);
var
  I    : Integer;
  K    : Integer;
  J    : Integer;
begin
  for I := 0 to reih -1 do
  begin
    for K := 0 to spalt -1 do
    begin
      cellList[I,K]            := TCell.Create;
      cellList[I,K].AkzeptList := TList.Create;
      cellList[I,K].BewerbList := TList.Create;
      //--- Variablen in Abh. der Produkte dimensionieren ---
      cellList[I,K].PositionX := K * cellScal + round(cellScal / 2);
      cellList[I,K].PositionY := I * cellScal + round(cellScal / 2);
      cellList[I,K].FReihPosY := I;
      cellList[I,K].FSpaltPosX:= K;
      cellList[I,K].Size := round (cellScal / 2)+1;
      cellList[I,K].State:= 99;
      cellList[I,K].Paint(Canvas);
    end ;
  end;
end;

// *** Aktualisiert das ZellenRaster ***
procedure TMovePlate.RectanglPaint (Canvas: TCanvas);
var
  I    : Integer;
  K    : Integer;
  used : Integer;
  dist : Integer;
begin
  //--- Backbuffer l�schen
  canvas.brush.color := clGreen;
  canvas.pen.color := clGreen;
  canvas.rectangle(10,10,Backpuffer.width,Backpuffer.height);
  for I := 0 to reih -1 do
  begin
    for K := 0 to spalt -1 do
    begin
      used := cellList[I,K].State;
      // --- Cellen berechnen ---
      SetLength(cellList[I,K].DistMarkt, shapesList.Count); // --- Arryl l�nge festlegen.
      cellList[I,K].NextMarkt(ShapesList); // --- N�chsten Markt je Celle festlegen
      // -----------------------------------------------------------------------
      cellList[I,K].Paint(Canvas);
    end ;
  end;
end;

//*** lokale Preise in Abh. der Entferung werden berechnet ***
procedure TMovePlate.calcLocalPreis;
const  farhKost = 1;
var
  I          : Integer;
  K          : Integer;
  U          : Integer;
  Zelle      : TCell;
  Agent      : TAgent;
  Kosten     : Double;
  bestKost   : Double;
  raumkost   : Double;
  SkalenE    : Double;
begin
  // --- Kundenzahlen zur�cksetzen ---
  for U:= 0 To ShapesList.Count -1 do
  begin
    Agent  :=  ShapesList.Items[U];
    Agent.Kunden := 1;
  end;

  // --- Die lokalen Preise in Abh. v. der Distanz errechnen -------------------
  for I := 0 to reih -1 do
  begin
    for K := 0 to spalt -1 do
    begin
      Zelle := cellList[I,K];
      bestKost := 214748364;
      for U:= 0 To ShapesList.Count -1 do
      begin
        Agent  :=  ShapesList.Items[U];
        raumkost := Zelle.DistMarkt[U] * (SB_FahrtKost.Position * 0.001);
        Kosten :=  Agent.AngebPreis + raumkost;
        If Kosten < bestKost Then begin
          bestKost := Kosten;
          Zelle.bestMarkt := U;
        end;
      end;
      Agent :=  ShapesList.Items[Zelle.bestMarkt];
      Zelle.FillColor := Agent.FillColor;
      Agent.Kunden := Agent.Kunden + 1;
    end;
  end;

  // --- Die Preise in den M�rkten festlegen ---
  for U:= 0 To ShapesList.Count -1 do
  begin
    Agent  :=  ShapesList.Items[U];
    SkalenE := (0.996 + SB_Skalen.Position * 0.0002);
    Agent.SetAngebPreis(SkalenE, SB_ProdKost.Position);
  end;
end;

// *** Zellen l�schen ***
procedure TMovePlate.deleteZells;
var
  I : Integer;
  K : Integer;
begin
  for I := reih -1 downto 0 do
  begin
    for K := spalt -1 downto 0 do
    begin
      TBaseCell (cellList[I,K]).Free;
    end;
  end;
end;

procedure TMovePlate.MakeMarkt;
Var
  I : Integer;
begin
  For I := 1 To NUM_BALLS Do
  begin
    CurrShape := TAgent.Create;
    CurrShape.PositionX :=  random (ImagePaint.Width);
    CurrShape.PositionY :=  random (ImagePaint.Height);
    CurrShape.StepX := (random(3) - 1);
    CurrShape.StepY := (random(3) - 1);
    CurrShape.Size := 3;
    CurrShape.Kunden := 1;
    CurrShape.SetAngebPreis(1.0, SB_ProdKost.Position);
    CurrShape.State := ShapesList.Count;
    ShapesList.Add (CurrShape);
  end;
  CommonPaint (ImagePaint.Canvas);
  Label2.Caption := IntToStr(ShapesList.Count);
end;

// ***************************
// ********* Buttons *********
// ***************************
//

// *** Pause ***
procedure TMovePlate.ButtonPauseClick(Sender: TObject);
begin
  fertig := Not fertig; //true;
  If MovePlate.Color = clRed Then begin
    MovePlate.Color := clBlack;
    exit;
  end;
  MovePlate.Color := clRed;
end;

// ***************************
// ******* ScrollBars ********
// ***************************

procedure TMovePlate.SB_ProdKostChange(Sender: TObject);
begin
  Lbl_ProdKost.Caption := IntToStr(SB_ProdKost.Position);
end;

procedure TMovePlate.SB_FahrtKostChange(Sender: TObject);
begin
  Lbl_FahrtKost.Caption := FloatToStr(SB_FahrtKost.Position * 0.001);
end;

procedure TMovePlate.SB_SkalenChange(Sender: TObject);
begin
  Lbl_Skalen.Caption := FloatToStr(0.996 + SB_Skalen.Position * 0.0002);
end;

// -----------------------------------------------------------------------------


// ******************************
// *** Array und Liste L�schen***
// ******************************
procedure TMovePlate.FormDestroy(Sender: TObject);
var
  I: Integer;
  J: Integer;
  K: Integer;
begin
  // --- delete each agent
  for I := ShapesList.Count - 1 downto 0 do
    TBaseShape (ShapesList [I]).Free;
  ShapesList.Free;
  // --- delete each cell
  deleteZells;
end;

end.

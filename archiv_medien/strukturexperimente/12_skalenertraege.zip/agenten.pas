unit agenten;

interface

uses
  Windows, Graphics, Classes, Math;

type
  TBaseShape = class
  private
  public
    Kunden        : Integer;  // Anzahl der Kunden
    AngebPreis    : Double;  // Preis f�r die Angebotene Ware
    //--------------------------------------
    FPositionX    : Integer;  // XKoordinate
    FPositionY    : Integer;  // YKoordinate
    FSize         : Integer;  // Gr��e des Agenten
    FStepX        : Double;   // X-Anteil des Bewegungsvektors
    FStepY        : Double;   // Y-Anteil des Bewegungsvektors
    FFillColor    : Integer;  // Farbe des Agenten
    FState        : Integer;  // Art des Agenten
    FAnlDist      : Integer;  // Radius innerhalb dessen sich gleichfarbige Agenten agstossen = Repel
    FRepelDist    : Integer;  // Radius innerhalb dessen eine Anlagerung m�glich ist
    FBindungSet   : Integer;  // Anzahl der freien Bindungen f�r gleiche Agenten
    FBindungMax   : Integer;  // Anzahl der freien Bindungen f�r untergeordnete Agenten
    FShortestD    : Double;   // K�rzester Abstand zu einem beliebigen Nachbarn
    FShortestDSelf: Double;   // K�rzester Abstand zu einem gleichen Nachbarn
    FConnect      : Integer;  // Gibt an, ob ein Agent gebunden ist
    FDistance     : Integer;
    FNeigborList  : Array of Integer;
    FBindListSelf : Array of Integer;
    FBindListOther: Array of Integer;
    procedure Paint           (Canvas: TCanvas); virtual;
    procedure SetNeigbor      (Index: Integer; Value: Integer);
    function  GetNeigbor      (Index: Integer): Integer;
    procedure SetBindListSelf (Index: Integer; Value: Integer);
    function  GetBindListSelf (Index: Integer): Integer;
    procedure SetBindListOther(Index: Integer; Value: Integer);
    function  GetBindListOther(Index: Integer): Integer;
    property  NeigborList     [Index: Integer]: Integer read GetNeigbor write SetNeigbor;
    property  BindListSelf    [Index: Integer]: Integer read GetBindListSelf write SetBindListSelf;
    property  BindListOther   [Index: Integer]: Integer read GetBindListOther write SetBindListOther;
    function  CalcDistance    (pX, pY: Integer):Integer;
    procedure SetBindungSet   (const Value: Integer);
    procedure SetBindungMax   (const Value: Integer);
    procedure SetPositionX    (const Value: Integer);
    procedure SetPositionY    (const Value: Integer);
    procedure SetStepX        (const Value: Double);
    procedure SetStepY        (const Value: Double);
    procedure SetSize         (const Value: Integer);
    procedure SetDistance     (const Value: Integer);
    procedure SetAnlDist      (const Value: Integer);
    procedure SetRepelDist    (const Value: Integer);
    procedure SetRndDir       (const damp: Double);
    procedure SetFillColor    (const Value: Integer);
    procedure SetState        (const Value: Integer);
    procedure SetConnect      (const Value: Integer);
    procedure SetShortestD    (const Value: Double);
    procedure SetShortestDSelf(const Value: Double);
    procedure SetAngebPreis   (const Skalenertrag: Double; const Produktpreis: Integer);
  published
    property PositionX   : Integer read FPositionX    write SetPositionX;
    property PositionY   : Integer read FPositionY    write SetPositionY;
    property StepX       : Double  read FStepX        write SetStepX;
    property StepY       : Double  read FStepY        write SetStepY;
    property Size        : Integer read FSize         write SetSize;
    property Distance    : Integer read FDistance     write SetDistance;
    property FillColor   : Integer read FFillColor    write SetFillColor;
    property State       : Integer read FState        write SetState;
    property BindungSet  : Integer read FBindungSet   write SetBindungSet;
    property BindungMax  : Integer read FBindungMax   write SetBindungMax;
    property AnlDist     : Integer read FAnlDist      write SetAnlDist;
    property RepelDist   : Integer read FRepelDist    write SetRepelDist;
    property ShortestD   : Double  read FShortestD    write SetShortestD;
    property ShortestDSelf: Double read FShortestDSelf write SetShortestDSelf;
    property Connect     : Integer read FConnect      write SetConnect;
  end;
type
  TAgent = class (TBaseShape)
    procedure Paint (Canvas: TCanvas); override;

  end;

implementation
//*********************************************************************************************//
const PI = 3.14159265358979323846;

// ********************* Zuf�llige Richtungs�nderung *************************//
procedure TBaseShape.SetRndDir (const damp: Double); // --- damp bestimmt die St�rke des Richtungswechsels
begin
  StepX := (FStepX + (random(3) - 1)) * damp;
  StepY := (FStepY + (random(3) - 1)) * damp;
end;

// **************** Funktion zur Entfernungsberechnung **********************//
function TBaseShape.CalcDistance(pX: Integer; pY: Integer): Integer;
  var temp: double;
  begin
  temp := sqrt(Power((pX - FPositionX), 2) + Power((pY - FPositionY), 2));
  Result := Round(temp);
end;

// *** Berechnet den Produktpreis f�r die M�rkte in Abh. von der NAchfrage ****
procedure TBaseShape.SetAngebPreis (const Skalenertrag: Double; const Produktpreis: Integer);
begin
  AngebPreis := (Kunden / Power(Kunden, Skalenertrag)) * Produktpreis;
end;

// ********* Zeichnungseinstellungen f�r die Agentenrepr�sentation **********//
procedure TAgent.Paint(Canvas: TCanvas);
var fakt: integer;
begin
  inherited Paint (Canvas);
  Canvas.Pen.Color := clGreen;
  Canvas.Pen.Style := psSolid; //(=psSolid, psDash, psDot, psClear)
  If State = 0 then FillColor := clSkyBlue;   //Canvas.Brush.Color := clRed;
  If State = 1 then FillColor := clBlue;
  If State = 2 then FillColor := clYellow;
  If State = 3 then FillColor := clGreen;
  If State = 4 then FillColor := clTeal;
  If State = 5 then FillColor := clNavy;
  If State = 6 then FillColor := clLime;
  If State = 7 then FillColor := clFuchsia;
  If State = 8 then FillColor := clAqua;
  If State = 9 then FillColor := clPurple;
  Canvas.Brush.Color := clred;
  fakt := 2;
  Canvas.Ellipse (FPositionX - FSize -fakt , FPositionY - FSize -fakt, FPositionX + FSize +fakt, FPositionY + FSize +fakt);
  Canvas.Brush.Color := FillColor;
  Canvas.Ellipse (FPositionX - FSize , FPositionY - (FSize), FPositionX + (FSize), FPositionY + (FSize));
end;

procedure TBaseShape.Paint (Canvas: TCanvas);
begin
  Canvas.Brush.Color := FillColor;
  Canvas.Pen.Width := 1;
end;

procedure TBaseShape.SetConnect (const Value: Integer);
begin
  FConnect := Value;
end;

procedure TBaseShape.SetBindListSelf (Index: Integer; Value: Integer);
begin
  FBindListSelf[Index] := Value;
end;

function  TBaseShape.GetBindListSelf  (Index: Integer): Integer;
begin
  Result := FBindListSelf[index];
end;

procedure TBaseShape.SetBindlistOther (Index: Integer; Value: Integer);
begin
  FBindListOther[Index] := Value;
end;

function  TBaseShape.GetBindListOther  (Index: Integer): Integer;
begin
  Result := FBindListOther[index];
end;

procedure TBaseShape.SetNeigbor (Index: Integer; Value: Integer);
begin
  FNeigborList[Index] := Value;
end;

function  TBaseShape.GetNeigbor  (Index: Integer): Integer;
begin
  Result := FNeigborList[index];
end;

procedure TBaseShape.SetBindungSet (const Value: Integer);
begin
  FBindungSet := Value;
end;

procedure TBaseShape.SetBindungMAx (const Value: Integer);
begin
  FBindungMax := Value;
end;

procedure TBaseShape.SetAnlDist (const Value: Integer);
begin
  FAnlDist := Value;
end;

procedure TBaseShape.SetRepelDist (const Value: Integer);
begin
  FRepelDist := Value;
end;

procedure TBaseShape.SetShortestD (const Value: Double);
begin
  FShortestD := Value;
end;

procedure TBaseShape.SetShortestDSelf (const Value: Double);
begin
  FShortestDSelf := Value;
end;

procedure TBaseShape.SetStepX(const Value: Double);
begin
  FStepX := Value;
end;

procedure TBaseShape.SetStepY(const Value: Double);
begin
  FStepY := Value;
end;

procedure TBaseShape.SetPositionX(const Value: Integer);
begin
  FPositionX := Value;
end;

procedure TBaseShape.SetPositionY(const Value: Integer);
begin
  FPositionY := Value;
end;

procedure TBaseShape.SetDistance(const Value: Integer);
begin
  FDistance := Value;
end;

procedure TBaseShape.SetSize(const Value: Integer);
begin
  FSize := Value;
end;

procedure TBaseShape.SetFillColor(const Value: Integer);
begin
  FFillColor := Value;
end;

procedure TBaseShape.SetState(const Value: Integer);
begin
  FState := Value;
end;

end.

unit cell_P;

interface

uses
  Windows, Graphics, Classes, node, Math;

type
  TCell = class
  private
  public
    Dist       : Integer;            // -- Distance to nexgt market
    walked     : Boolean;            // -- agent walked across the cell
    colr       : Integer;            // -- color value of the cell
    mark       : Double;             // -- marking the distance landscape
    maxM       : Extended;
    minM       : Extended;
    FPos       : TPoint;
    FSize      : Integer;
    FFillColor : Integer;
    FState     : Integer;            // -- Status speichert die Anzahl der Agenten auf Zelle
    procedure Paint         (Canvas: TCanvas);
    procedure SetPositionX  (const Value: Integer);
    procedure SetPositionY  (const Value: Integer);
    procedure SetSize       (const Value: Integer);
    procedure SetFillColor  (const Value: Integer);
    constructor create      (xPos, yPos, size, colr: Integer);
  published
    property PositionX: Integer read FPos.X     write SetPositionX;
    property PositionY: Integer read FPos.Y     write SetPositionY;
    property Size     : Integer read FSize      write SetSize;
    property FillColor: Integer read FFillColor write SetFillColor;
  end;

// ---------------------------------------------------------------------------//

implementation

constructor TCell.create(xPos, yPos, size, colr: Integer);
begin
  inherited create;
  FPos.X := xPos;
  FPos.Y := yPos;
  FSize  := size;
  FFillColor := colr;
end;

//------------------------------------------------------------------------------

procedure TCell.SetPositionX(const Value: Integer);
begin
  FPos.X := Value;
end;

procedure TCell.SetPositionY(const Value: Integer);
begin
  FPos.Y := Value;
end;

procedure TCell.SetSize(const Value: Integer);
begin
  FSize := Value;
end;

procedure TCell.SetFillColor(const Value: Integer);
begin
  FFillColor := Value;
end;

procedure TCell.Paint(Canvas: TCanvas);
var
  scalF : Double;
  tmp   : Double;
begin
  Canvas.Pen.Width := 0;
  //Canvas.Pen.Color := clWhite; //clgray; //clgreen;
  scalF := 255 / (maxM-minM);
  tmp   := (mark - minM)* scalF;
  mark := mark - minM;
  colr  := ceil(255- tmp);
  If colr <  0 then begin
    colr := 0;
  end;
  If colr >  255 then begin
    colr := 255;
  end;
  Canvas.Pen.Color   := RGB (colr, colr, colr);
  Canvas.Brush.Color := RGB (colr, colr, colr);
  If walked = true then begin
    Canvas.Brush.Color := cllime;
    Canvas.Pen.Color := cllime;
  end;
  //Canvas.Pen.Color   := RGB (colr, colr, colr);
  Canvas.Rectangle (FPos.X - FSize , FPos.Y - FSize, FPos.X + FSize, FPos.Y + FSize);
end;

end.

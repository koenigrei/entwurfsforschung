object Form1: TForm1
  Left = 0
  Top = 0
  Width = 734
  Height = 455
  Caption = 'path system'
  Color = clBtnFace
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -10
  Font.Name = 'Tahoma'
  Font.Style = []
  OldCreateOrder = False
  OnCreate = FormCreate
  OnDestroy = FormDestroy
  PixelsPerInch = 96
  TextHeight = 12
  object ZeichenPanel: TPanel
    Left = 8
    Top = 9
    Width = 404
    Height = 404
    BorderStyle = bsSingle
    DockSite = True
    TabOrder = 0
  end
  object RadioGroup1: TRadioGroup
    Left = 440
    Top = 184
    Width = 257
    Height = 49
    Caption = 'sniff chemicals with'
    TabOrder = 1
  end
  object rb_rulette: TRadioButton
    Left = 448
    Top = 208
    Width = 81
    Height = 17
    Caption = 'rulette wheel'
    Enabled = False
    TabOrder = 2
  end
  object GroupBox1: TGroupBox
    Left = 440
    Top = 8
    Width = 257
    Height = 113
    Caption = 'setup settings'
    TabOrder = 3
    object Lbl_TextAnzahl: TLabel
      Left = 54
      Top = 60
      Width = 129
      Height = 12
      Caption = ': number of agents for setup'
    end
    object Label2: TLabel
      Left = 54
      Top = 84
      Width = 127
      Height = 12
      Caption = ': cell size -> number of cells '
    end
    object B_setup: TButton
      Left = 6
      Top = 16
      Width = 75
      Height = 25
      Caption = 'new Setup'
      TabOrder = 0
      OnClick = B_setupClick
    end
    object B_stop: TButton
      Left = 86
      Top = 16
      Width = 75
      Height = 25
      Caption = 'start / stop'
      TabOrder = 1
      OnClick = B_stopClick
    end
    object B_oneStep: TButton
      Left = 166
      Top = 16
      Width = 75
      Height = 25
      Caption = 'one step'
      TabOrder = 2
      OnClick = B_oneStepClick
    end
    object Edit_anzAg: TEdit
      Left = 8
      Top = 56
      Width = 41
      Height = 20
      TabOrder = 3
      Text = '10'
    end
    object Edit_size: TEdit
      Left = 8
      Top = 80
      Width = 41
      Height = 20
      TabOrder = 4
      Text = '4'
      OnChange = Edit_sizeChange
    end
  end
  object rb_hill: TRadioButton
    Left = 576
    Top = 208
    Width = 81
    Height = 17
    Caption = 'hill climbing'
    Checked = True
    TabOrder = 4
    TabStop = True
  end
  object GroupBox2: TGroupBox
    Left = 440
    Top = 136
    Width = 257
    Height = 41
    Caption = 'timesteps'
    TabOrder = 5
    object lbl_Steps: TLabel
      Left = 72
      Top = 18
      Width = 39
      Height = 12
      Alignment = taCenter
      BiDiMode = bdRightToLeft
      Caption = 'lbl_Steps'
      ParentBiDiMode = False
    end
  end
  object GroupBox3: TGroupBox
    Left = 440
    Top = 240
    Width = 257
    Height = 169
    Caption = 'interaction parameters'
    TabOrder = 6
    object Label1: TLabel
      Left = 8
      Top = 29
      Width = 76
      Height = 12
      Caption = 'angle threshold :'
    end
    object Lbl_B: TLabel
      Left = 90
      Top = 29
      Width = 15
      Height = 12
      Caption = '___'
    end
    object Label3: TLabel
      Left = 136
      Top = 29
      Width = 81
      Height = 12
      Caption = 'wiggle threshold :'
    end
    object Lbl_wiggle: TLabel
      Left = 226
      Top = 29
      Width = 15
      Height = 12
      Caption = '___'
    end
    object Label5: TLabel
      Left = 56
      Top = 92
      Width = 85
      Height = 12
      Caption = ': diffusion strength'
    end
    object Label6: TLabel
      Left = 56
      Top = 118
      Width = 70
      Height = 12
      Caption = ': noise strength'
    end
    object Label4: TLabel
      Left = 56
      Top = 144
      Width = 76
      Height = 12
      Caption = ': distance scaling'
    end
    object TrB_thresh: TScrollBar
      Left = 8
      Top = 48
      Width = 113
      Height = 17
      LargeChange = 5
      Max = 180
      PageSize = 0
      Position = 157
      TabOrder = 0
      OnChange = TrB_threshChange
    end
    object SB_wiggle: TScrollBar
      Left = 136
      Top = 48
      Width = 113
      Height = 17
      LargeChange = 5
      Max = 180
      PageSize = 0
      TabOrder = 1
      OnChange = SB_wiggleChange
    end
    object E_diffuse: TEdit
      Left = 8
      Top = 88
      Width = 41
      Height = 20
      TabOrder = 2
      Text = '0,04'
      OnChange = E_diffuseChange
    end
    object E_noise: TEdit
      Left = 8
      Top = 114
      Width = 41
      Height = 20
      TabOrder = 3
      Text = '4'
      OnChange = E_noiseChange
    end
    object E_dScale: TEdit
      Left = 8
      Top = 140
      Width = 41
      Height = 20
      TabOrder = 4
      Text = '0,1'
      OnChange = E_dScaleChange
    end
  end
  object Timer1: TTimer
    Interval = 1
    OnTimer = Timer1Timer
    Left = 704
    Top = 16
  end
end

(********************************************************************)
(*                                                                  *) 
(*                                                                  *)
(*                         Active Walker                            *)
(*                          Version 1.1                             *)
(*                                                                  *)
(*                                                                  *)
(*     Programmierer: Reinhard K�nig                      June 2006 *)
(*                    http://www.entwurfsforschung.de               *)
(*                                                                  *)
(*     Last Update: Jun-04, 2006                                    *)
(*                                                                  *)
(********************************************************************) 
{revision history:

1.0     [Jun-03, 2006]
        first release to the public
1.1     [Jun-04, 2006]
        multi-agents
        interface improvements
}

unit CellForm;

interface

uses
  Windows, Messages, SysUtils, Classes, Graphics, Controls, Forms,
  Dialogs, StdCtrls, cell_P, ExtCtrls, Math, agenten, calcer;

type
  TForm1 = class(TForm)
    ZeichenPanel   : TPanel;
    RadioGroup1    : TRadioGroup;
    rb_rulette     : TRadioButton;
    GroupBox1      : TGroupBox;
    B_setup        : TButton;
    B_stop         : TButton;
    B_oneStep      : TButton;
    Edit_anzAg     : TEdit;
    Lbl_TextAnzahl : TLabel;
    Edit_size      : TEdit;
    Label2         : TLabel;
    rb_hill        : TRadioButton;
    GroupBox2      : TGroupBox;
    lbl_Steps      : TLabel;
    Timer1         : TTimer;
    GroupBox3      : TGroupBox;
    TrB_thresh     : TScrollBar;
    Label1         : TLabel;
    Lbl_B          : TLabel;
    SB_wiggle      : TScrollBar;
    Label3         : TLabel;
    Lbl_wiggle     : TLabel;
    E_diffuse      : TEdit;
    Label5         : TLabel;
    E_noise        : TEdit;
    Label6         : TLabel;
    E_dScale       : TEdit;
    Label4         : TLabel;
    procedure E_dScaleChange  (Sender: TObject);
    procedure E_diffuseChange (Sender: TObject);
    procedure E_noiseChange   (Sender: TObject);
    procedure Edit_sizeChange (Sender: TObject);
    procedure SB_wiggleChange (Sender: TObject);
    procedure B_oneStepClick  (Sender: TObject);
    procedure TrB_threshChange(Sender: TObject);
    procedure B_stopClick     (Sender: TObject);
    procedure B_setupClick    (Sender: TObject);
    procedure Timer1Timer     (Sender: TObject);
    procedure FormDestroy     (Sender: TObject);
    procedure FormCreate      (Sender: TObject);
  private
    AgentList  : TList;
    cellList   : TCellList;
    limboWorld : TLimbo;
    procedure createPaintImg;
    procedure createRaster;
    procedure createAgents;
    procedure setupCells;
    procedure setupAgents;
    procedure calcAgents;
    procedure repaintAll;
    procedure checkArea   (I : Integer);
    procedure calculate;
    procedure settings;
    procedure deleter;
    procedure calcCellDist;
    procedure findMaxMin;
  public
end;

var
  Form1    : TForm1;
  paintImg : TImage;
  agentImg : TImage;

implementation

{$R *.dfm}

const
  AgSize = 2;                    //-- Agenten gr��e

var
  reih     : Integer;            //-- Zellen-Reihen gesamt
  spalt    : Integer;            //-- Zellen-Spalten gesamt
  steps    : Integer;
  cellScal : Integer;            //-- Zellen  gr��e
  halfScal : Integer;
  maxM     : Extended;           //-- maximal mark value
  minM     : Extended;           //-- minimal mark value

// ---------------------------------------------------------------------------//
// *** Initialisierung *********************************************************
procedure TForm1.FormCreate(Sender: TObject);
begin
  settings;
  Lbl_B.Caption := IntToStr(TrB_thresh.Position) + ' Grad';
  Lbl_wiggle.Caption := IntToStr(SB_wiggle.Position) + ' Grad';
end;

// *****************************************************************************
procedure TForm1.settings;
begin
  cellScal  := StrToInt(Edit_size.Text) ;
  halfScal  := round(cellScal/2);
  spalt     := round (ZeichenPanel.Width / cellScal);
  reih      := round (ZeichenPanel.Height / cellScal);
  AgentList := TList.Create;
  SetLength(cellList, spalt, reih);
  SetLength(limboWorld, spalt, reih);
  createPaintImg;
  CreateRaster;
  CreateAgents;
  ZeichenPanel.Enabled := true;
  steps := 0;
end;
// ---------------------------------------------------------------------------//
// ------------------------- Elemente erstellen ------------------------------//
// ---------------------------------------------------------------------------//

// *** Legt eine leere Zeichenfl�che �ber das Zeichenpanel *********************
procedure TForm1.createPaintImg;
begin
  paintImg        := TImage.Create(self);
  paintImg.Parent := ZeichenPanel;
  paintImg.top    := 0;
  paintImg.Left   := 0;
  paintImg.Height := ZeichenPanel.Height;
  paintImg.Width  := ZeichenPanel.Width;
  paintImg.Enabled:= False;                  // -- does not reakt on mouseEvents

  agentImg        := TImage.Create(self);
  agentImg.Parent := ZeichenPanel;
  agentImg.top    := 0;
  agentImg.Left   := 0;
  agentImg.Height := ZeichenPanel.Height;
  agentImg.Width  := ZeichenPanel.Width;
  agentImg.Transparent := true;
  agentImg.Enabled:= False;
end;

// *****************************************************************************
procedure TForm1.CreateAgents;
var
  I        : Integer;
  curAgent : TAgent;
begin
  for I := 1 to StrToInt(Edit_anzAg.Text) do
  begin
    curAgent := TAgent.Create;
    AgentList.Add (curAgent);
  end;
  setupAgents;
end;

// *** Agenten initialisieren **************************************************
procedure TForm1.setupAgents;
var
  curAgent : TAgent;
  I        : Integer;
begin
  Randomize();
  for I := 0 to AgentList.Count - 1 do
  begin
    curAgent := AgentList.Items [I];
    curAgent.onCell.X := random(reih);
    curAgent.onCell.Y := random(spalt);
    curAgent.PosX     := curAgent.onCell.X * cellScal + halfScal;
    curAgent.PosY     := curAgent.onCell.Y * cellScal + halfScal;
    curAgent.Size     := AgSize;
    curAgent.Heading  := random (360);
    curAgent.Paint   (agentImg.Canvas);
  end;
end;

// *** Zellen erstellen ********************************************************
procedure TForm1.CreateRaster;
var
  curCell : TCell;
  I       : Integer;
  K       : Integer;
begin
  for I := 0 to reih -1 do
  begin
    for K := 0 to spalt -1 do
    begin
      curCell := TCell.Create(halfScal + K * cellScal, halfScal + I * cellScal, halfScal, 0);
      cellList[K,I] := curCell;
    end;
  end;
  setupCells;
end;

// *** Zellen initialisieren ***************************************************
procedure TForm1.setupCells;
var
  curCell : TCell;
  I, K    : Integer;
begin
  Randomize();
  for I := 0 to reih -1 do
  begin
    for K := 0 to spalt -1 do
    begin
      curCell         := cellList[K,I];
      curCell.colr    := 255;
      curCell.maxM    := 1;
      curCell.mark    := 0;
      curCell.Paint(paintImg.Canvas);
    end;
  end;
end;

// ---------------------------------------------------------------------------//
// ---------------------------- Berechnungen ---------------------------------//
// ---------------------------------------------------------------------------//

// *** Rekursive Befehle ausf�hren ***
procedure TForm1.Timer1Timer(Sender: TObject);
begin
  calculate;
end;

// *****************************************************************************
procedure TForm1.calculate;
begin
  diffuse(StrToFloat(E_diffuse.Text), spalt, reih, limboWorld, cellList);     // -- diffuse procedure in calcer

  calcCellDist;

  findMaxMin;

  repaintAll;

  calcAgents; // -- ver�ndert die Position der Agenten

  steps := steps +1;
  lbl_Steps.Caption := intToStr (steps);
end;

// *****************************************************************************
procedure TForm1.calcCellDist;
var
  onCell   : TCell;
  curCell  : TCell;
  curAgent : TAgent;
  I, K, M  : Integer;
  tempPos  : TPoint;
  cellPos  : TPoint;
  halfSpalt : Real;
  dScale    : Real;
begin
  halfSpalt := spalt / 2;
  dScale    := StrToFloat(E_dScale.Text);
  for M := 0 to AgentList.Count - 1 do
  begin
    curAgent  := AgentList.Items [M];
    tempPos.X := curAgent.onCell.X;
    tempPos.Y := curAgent.onCell.Y;
    onCell    := cellList[tempPos.X, tempPos.Y];
    onCell.walked := true;
    for I := 0 to reih -1 do
    begin
      for K := 0 to spalt -1 do
      begin
        curCell   := cellList[K,I];
        cellPos.X := curCell.FPos.X;
        cellPos.Y := curCell.FPos.Y;
        // --- distance-torus measure --------
        If abs(tempPos.X - K) > halfSpalt Then
          If K < halfSpalt Then cellPos.X := (K + spalt) * cellScal + halfScal
                           Else cellPos.X := (K - spalt) * cellScal + halfScal;
        If abs(tempPos.Y - I) > halfSpalt Then
          If I < halfSpalt Then cellPos.Y := (I + spalt) * cellScal + halfScal
                           Else cellPos.Y := (I - spalt) * cellScal + halfScal;
        // -- calculate and sum the distances --
        curCell.Dist    := calcDistance(cellPos.X, cellPos.Y, onCell.FPos.X,onCell.FPos.Y);
        curCell.mark    := curCell.mark + sqrt(dScale *curCell.Dist);
      end;
    end;
  end;
end;

// *** find the max and min of the mark values *********************************
procedure TForm1.findMaxMin;
var
  curCell : TCell;
  I, K    : Integer;
begin
  maxM      := 0.1;
  minM      := 999999999999999999;
  for I := 0 to reih -1 do
  begin
    for K := 0 to spalt -1 do
    begin
      curCell   := cellList[K,I];
      If curCell.mark > maxM Then maxM := curCell.mark;
      If curCell.mark < minM Then minM := curCell.mark;
    end;
  end;
end;

// *****************************************************************************
procedure TForm1.repaintAll;
var
  curAgent : TAgent;
  curCell  : TCell;
  I, K     : Integer;
begin
  agentImg.Canvas.brush.Color := clWhite;
  agentImg.Canvas.pen.Color   := clWhite;
  agentImg.Canvas.Rectangle(0,0,ZeichenPanel.Height,ZeichenPanel.Width);
  for I := 0 to reih -1 do
  begin
    for K := 0 to spalt -1 do
    begin
      curCell := cellList[K,I];
      curCell.maxM := maxM;
      curCell.minM := minM;
      curCell.Paint (paintImg.Canvas);
    end;
  end;

  for I := 0 to AgentList.Count - 1 do
  begin
    curAgent := AgentList.Items [I];
    curAgent.Paint (agentImg.Canvas);
  end;
end;

// *****************************************************************************
// *** look at the cells in the neigbourhood defined by the horizon-parameter **
// *****************************************************************************
procedure TForm1.checkArea (I : Integer);
var
  curCell  : TCell;
  curAgent : TAgent;
  M        : Integer;
  Angle    : Array [0..1] of Real;
  horizon  : Integer;
  neib     : TPoint;
  comper   : Real;
  wList    : Array of Double;
  wSum     : Double;
  tmP      : TPoint;
  fromTo   : Array [0..1] of Integer;
  curNr    : Integer;
  noise    : Double;
  strN     : Real;
begin
  horizon := TrB_thresh.Position;
  curAgent := AgentList.Items [I];
  Angle[0] := curAgent.Heading - horizon - 22.5;     // -- minAngle
  Angle[1] := curAgent.Heading + horizon - 22.5;     // -- maxAngle
  angelBorder (Angle[0]);
  angelBorder (Angle[1]);
  //-- find the cells to look at
  SetLength(curAgent.lookToList, 0);

  for M := 0 to 1 do
  begin
    comper   := Angle[M];
    case round(comper) of           // find start and end field (cell)
      0..45:    fromTo[M] := 1;
      46..90:   fromTo[M] := 2;
      91..135:  fromTo[M] := 3;
      136..180: fromTo[M] := 4;
      181..225: fromTo[M] := 5;
      226..270: fromTo[M] := 6;
      271..315: fromTo[M] := 7;
      316..360: fromTo[M] := 8;
    end;
  end;

  curNr := fromTo[0] -1;
  repeat
  inc(curNr);
  If curNr > 8 Then curNr := 1;
    case curNr of                   // set the direction to the cell-positions
      1: begin neib.X := 1;  neib.Y := 1;  end;
      2: begin neib.X := 0;  neib.Y := 1;  end;
      3: begin neib.X := -1; neib.Y := 1;  end;
      4: begin neib.X := -1; neib.Y := 0;  end;
      5: begin neib.X := -1; neib.Y := -1; end;
      6: begin neib.X := 0;  neib.Y := -1; end;
      7: begin neib.X := 1;  neib.Y := -1; end;
      8: begin neib.X := 1;  neib.Y := 0;  end;
    end;
    SetLength(curAgent.lookToList, length(curAgent.lookToList) + 1);
    curAgent.lookToList[High(curAgent.lookToList)] := neib;
  until curNr = fromTo[1];

  SetLength(wList, length(curAgent.lookToList));
  wSum := 0;
  curAgent.sumChem := 0;
  strN := StrToFloat(E_noise.Text);
  For M := 0 To High(curAgent.lookToList) Do
  begin
    noise := strN*(random()-0.5);
    tmP.X := curAgent.onCell.X + curAgent.lookToList[M].X;
    tmP.Y := curAgent.onCell.Y + curAgent.lookToList[M].Y;
    torus (tmP.X, tmP.Y, spalt, reih);
    curCell := cellList[tmP.X, tmP.Y];
    curAgent.sumChem := curAgent.sumChem + curCell.mark + noise;
    wSum := wSum + curCell.mark + noise;
    wList[M] := curCell.mark + noise;
  end;

  SetLength(curAgent.weightList, 0);
  SetLength(curAgent.weightList, length(curAgent.lookToList));
  For M := 0 To High(curAgent.lookToList) Do
  begin
    // --- write in the agent's weight list ---
    curAgent.weightList[M] := wList[M]/wSum * 100;
  end;
end;

// *****************************************************************************
// *** Ver�ndert die Position der Agenten **************************************
// *****************************************************************************
procedure TForm1.calcAgents;
var
  curAgent : TAgent;
  I        : Integer;
  tempPos  : TPoint;
  horizon  : Integer;
  wiggle   : Integer;
  method   : Integer;
begin
  horizon := TrB_thresh.Position;
  wiggle  := SB_wiggle.Position;
  If rb_rulette.Checked = true Then begin method := 1; end
  else begin If rb_hill.Checked = true Then method := 2; end;
  for I := 0 to AgentList.Count - 1 do
  begin
    curAgent := AgentList.Items [I];
    checkArea (I);
    curAgent.ChangeHeading(horizon, 1, wiggle, method);                       // -- Richtungsspektrum und Distanz
    tempPos.X := curAgent.onCell.X + curAgent.stepX;
    tempPos.Y := curAgent.onCell.Y + curAgent.stepY;
    torus     (tempPos.X, tempPos.Y, spalt, reih);                                             // -- Torus --
    curAgent.onCell.X := tempPos.X;
    curAgent.onCell.Y := tempPos.Y;
    curAgent.PosX     := curAgent.onCell.X * cellScal + halfScal;             // -- Wenn Zelle frei, Agent bewegen ---
    curAgent.PosY     := curAgent.onCell.Y * cellScal + halfScal;
    end;
end;

// ---------------------------------------------------------------------------//
// ------------------------------- Schalter ----------------------------------//
// ---------------------------------------------------------------------------//
procedure TForm1.B_setupClick(Sender: TObject);
begin
  deleter;
  settings;
end;

procedure TForm1.B_stopClick(Sender: TObject);
begin
  Timer1.enabled := not(Timer1.enabled);
end;

procedure TForm1.TrB_threshChange(Sender: TObject);
begin
  Lbl_B.Caption := IntToStr(TrB_thresh.Position) + ' Grad';
end;

procedure TForm1.SB_wiggleChange(Sender: TObject);
begin
  Lbl_wiggle.Caption := IntToStr(SB_wiggle.Position) + ' Grad';
end;

procedure TForm1.B_oneStepClick(Sender: TObject);
begin
  calculate;
end;

procedure TForm1.Edit_sizeChange(Sender: TObject);
begin
  If StrToInt(Edit_size.Text) > 10 Then Edit_size.Text := '10';
  If StrToInt(Edit_size.Text) < 1  Then Edit_size.Text := '1';
end;

procedure TForm1.E_noiseChange(Sender: TObject);
begin
  If (E_noise.text = '') Then E_noise.text := '0';
end;

procedure TForm1.E_diffuseChange(Sender: TObject);
begin
  If (E_diffuse.text = '') Then E_diffuse.text := '0';
end;

procedure TForm1.E_dScaleChange(Sender: TObject);
begin
  If (E_dScale.text = '') Then E_dScale.text := '0';
end;

// *****************************************************************************
procedure TForm1.FormDestroy(Sender: TObject);
begin
  deleter;
  ZeichenPanel.Free;
end;

procedure TForm1.deleter;
begin
  steps := 0;
  AgentList.Free;
  paintImg.Free;
  agentImg.Free;
  SetLength(cellList, 0, 0);
  SetLength(limboWorld, 0, 0);
end;

end.

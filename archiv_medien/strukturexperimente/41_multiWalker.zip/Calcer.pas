unit Calcer;

interface

uses
  Math, SysUtils, cell_P;

type
  wigList   = Array of Real;
  TLimbo    = Array of Array of Extended;
  TCellList = Array of Array of TCell;

const                            //-- globale Konstanten
  DegToRad  = 3.141592654/180;
  RadToDeg  = 180/3.141592654;
  Pi        = 3.141592654;

function  IntToBin     (Int: Integer): String;
function  BinToInt     (Binary: String): Integer;
function  CalcDistance (pAX: Integer; pAY: Integer; pBX: Integer; pBY: Integer): Integer;
procedure torus        (var Xp: Integer; var Yp: Integer; spalt, reih: Integer);
function  rouletteWheel(weightList: wigList): Integer;
procedure angelBorder  (var angle : Integer); overload;
procedure angelBorder  (var angle : Real);    overload;
procedure checkNei     (K, I, spalt, reih: Integer; var limboWorld: TLimbo; var cellList: TCellList);
procedure diffuse      (dVal: Real; spalt, reih: Integer; var limboWorld: TLimbo; var cellList: TCellList);

implementation


// *** diffuse the mark-values *************************************************
procedure diffuse (dVal: Real; spalt, reih: Integer; var limboWorld: TLimbo; var cellList: TCellList);
var
  curCell  : TCell;
  I, K     : Integer;
begin
  for I := 0 to reih -1 do
  begin
    for K := 0 to spalt -1 do
    begin
      checkNei (K, I, spalt, reih, limboWorld, cellList);
    end;
  end;
  for I := 0 to reih -1 do
  begin
    for K := 0 to spalt -1 do
    begin
      curCell          := cellList[K,I];
      limboWorld[K, I] := (limboWorld[K, I]/ 8)* dVal;
      curCell.mark     := curCell.mark + limboWorld[K, I];
    end;
  end;
end;

// *** check the moore-neighbourhood *******************************************
procedure checkNei (K, I, spalt, reih: Integer; var limboWorld: TLimbo; var cellList: TCellList);
var
  u, v   : Integer;
  Xp, Yp : Integer;
begin
  // --- Summe berechnen ---
  limboWorld[K, I] := 0;
  for u := -1 to 1 do
  begin
    for v := -1 to 1 do
    begin
      Xp := K + v;
      Yp := I + u;
      torus(Xp, Yp, spalt, reih);  // -- Torus
      limboWorld[K, I] := limboWorld[K, I] + cellList[Xp, Yp].mark;
    end;
  end;
  limboWorld[K, I] := limboWorld[K, I] - cellList[K, I].mark;
end;

// *** roulette wheel selection ************************************************
function rouletteWheel(weightList: wigList): Integer;
var
  M      : Integer;
  rnd    : Extended;
  sum    : Extended;
begin
  Randomize;
  rnd := random (100);
  sum := 0;
  M := 0;
  repeat
    sum := sum + weightList[M];
    Result := M;
    M := M +1;
  until (sum >= rnd) Or (M > length(weightList)-1);
end;

// *** Entferung berechnen *****************************************************
function CalcDistance(pAX: Integer; pAY: Integer; pBX: Integer; pBY: Integer): Integer;
var
  temp : double;
begin
  temp := sqrt(Power((pAX - pBX), 2) + Power((pAY - pBY), 2));
  Result := Round(temp);
end;

// *** Integer To Binary *******************************************************
function IntToBin(Int: Integer): String;
var
  I : Integer;
begin
  Result := '';
  for I := 7 downto 0 do
    Result := Result + IntToStr((Int shr I) and 1);
end;

// *** Binary To Integer *******************************************************
function BinToInt(Binary: String): Integer;
var
  I : Integer;
begin
  Result := 0;
  for I := Length(Binary) downto 1 do
    Inc(Result, StrToInt(Binary[I]) * 1 shl (Length(Binary) - I));
end;

// *** Torusfunktion ***********************************************************
procedure torus (var Xp: Integer; var Yp: Integer; spalt, reih:Integer);
begin
  if Xp < 0     then begin
     Xp := spalt + Xp;
  end else
  if Xp > spalt-1  then begin
     Xp := 0 + (Xp - spalt) ;
  end;
  if Yp < 0     then begin
     Yp := reih + Yp;
  end else
  if Yp > reih-1  then begin
     Yp := 0 + (Yp - reih) ;
  end;
end;

// *** borders of the angle-value **********************************************
procedure angelBorder (var angle : Integer);
begin
  If angle < 0   Then angle := 360 + angle;
  If angle > 360 Then angle := angle -360;
end;

procedure angelBorder  (var angle : Real);
begin
  If angle < 0   Then angle := 360 + angle;
  If angle > 360 Then angle := angle -360;
end;

end.
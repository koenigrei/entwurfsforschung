(********************************************************************)
(*                                                                  *) 
(*                                                                  *)
(*                  Zentralit�t und zentrale Orte                   *)
(*                      Modell nach Christaller                     *)
(*                          Version 1.0                             *)
(*                                                                  *) 
(*     Programmierer: Reinhard K�nig                     June 2005  *)
(*                    http://www.entwurfsforschung.de/              *)
(*                                                                  *)
(*     Last Update: June-25, 2005                                   *)
(*                                                                  *) 
(********************************************************************) 
{revision history:

1.0     [June-25, 2005]
        first release to the public
}

unit facsSteer;

interface

uses
  Windows, Messages, SysUtils, Variants, Classes, Graphics, Controls, Forms, cell,
  Dialogs, ExtCtrls, Grids, agenten, Math, ConvUtils, StdCtrls, AppEvnts,    //ActnMan ,
  Menus;

type
  TMovePlate = class(TForm)
    ScrollBar1          : TScrollBar;
    ApplicationEvents1  : TApplicationEvents;
    Label1              : TLabel;
    Label2              : TLabel;
    Button_Delete       : TButton;
    Button2             : TButton;
    Label3              : TLabel;
    Label_Radius        : TLabel;
    CheckB_Zellen       : TCheckBox;
    Button_Create       : TButton;
    Label4: TLabel;
    LabelInterakt: TLabel;
    ScrollBar_DistGelb: TScrollBar;
    Label5: TLabel;
    Label_MinDist: TLabel;
    ScrollBar_MinDist: TScrollBar;
    Label6: TLabel;
    Label_Sichtfeld: TLabel;
    ScrollBar_DistBlau: TScrollBar;
    ButtonPause: TButton;
    ButtonCreateB: TButton;
    ButtonCreateY: TButton;
    Label7: TLabel;
    LabelDistRed: TLabel;
    ScrollBar_DistRot: TScrollBar;
    CB_showRed: TCheckBox;
    CB_showBlau: TCheckBox;
    CB_showGelb: TCheckBox;
    CB_Verbind: TCheckBox;
    Label8: TLabel;
    Lbl_BindGelb: TLabel;
    Label10: TLabel;
    Lbl_BindBlau: TLabel;
    Label12: TLabel;
    Lbl_BindRot: TLabel;
    SB_BindGelb: TScrollBar;
    SB_BindBlau: TScrollBar;
    SB_BindRot: TScrollBar;
    Label9: TLabel;
    Lbl_RepelDistGelb: TLabel;
    Label13: TLabel;
    Lbl_RepelDistBlau: TLabel;
    Label15: TLabel;
    Lbl_RepelDistRot: TLabel;
    SB_RepelDistGelb: TScrollBar;
    SB_RepelDistBlau: TScrollBar;
    SB_RepelDistRot: TScrollBar;
    GroupBox1: TGroupBox;
    ImagePaint: TImage;
    Edi_NrRed: TEdit;
    Edi_NrBlau: TEdit;
    Edi_NrGelb: TEdit;
    procedure SB_BindGelbChange(Sender: TObject);
    procedure SB_BindBlauChange(Sender: TObject);
    procedure SB_BindRotChange(Sender: TObject);
    procedure SB_RepelDistGelbChange(Sender: TObject);
    procedure SB_RepelDistBlauChange(Sender: TObject);
    procedure SB_RepelDistRotChange(Sender: TObject);
    procedure ScrollBar_DistRotChange(Sender: TObject);
    procedure ButtonCreateYClick(Sender: TObject);
    procedure ButtonCreateBClick(Sender: TObject);
    procedure ImagePaintClick(Sender: TObject);
    procedure ButtonPauseClick(Sender: TObject);
    procedure ScrollBar_DistBlauChange(Sender: TObject);
    procedure ScrollBar_MinDistChange(Sender: TObject);
    procedure ScrollBar_DistGelbChange(Sender: TObject);
    procedure Button_DeleteClick(Sender: TObject);
    procedure Button_CreateClick(Sender: TObject);
    procedure Button2MouseUp(Sender: TObject; Button: TMouseButton;
      Shift: TShiftState; X, Y: Integer);
    procedure FormDestroy(Sender: TObject);
    procedure ImagePaintMouseMove(Sender: TObject; Shift: TShiftState; X,
      Y: Integer);
    procedure ApplicationEvents1Idle(Sender: TObject; var Done: Boolean);
    procedure PaintBox1Paint(Sender: TObject);
    procedure ScrollBar1Change(Sender: TObject);
    procedure FormCreate(Sender: TObject);
  private
    { Private declarations }
    ShapesList: TList;
    CurrShape: TBaseShape;
    procedure CommonPaint (Canvas: TCanvas);
    procedure RegionPaint (Canvas: TCanvas; AShape: TAgent);
    procedure checkNeighbour (Canvas: TCanvas; xPos : Integer; yPos : Integer);
    procedure lookCell (Canvas: TCanvas);
    procedure cellStates (Canvas: TCanvas);
    procedure Verbinden();
    procedure Swarming();
//    procedure BewegVekt();
    procedure RectanglPaint (Canvas: TCanvas);
    procedure RectanglCreate (Canvas: TCanvas);
  public
    { Public declarations }
  end;

var
  MovePlate: TMovePlate;

implementation

{$R *.dfm}

const
    NUM_BALLS = 100;
    cellScal = 10;
var
  reih      : Integer;
  spalt     : Integer;
  Dir       : Integer = 1;
  //StepX     : Integer;
  //StepY     : Integer;
  LEFT_BORDER   : Integer;
  TOP_BORDER    : Integer;
  RIGHT_BORDER  : Integer;
  BOTTOM_BORDER : Integer;
  Mouse_Rad     : Integer;
  MouseX        : Integer;
  MouseY        : Integer;
  Backpuffer    : TBitmap;
  cellList      : Array of Array of TCell;
  limboWorld    : Array of Array of Integer;
  oldPos        : Array of Array of Integer;
  limboPos      : Array of Array of Double;
  Abstand       : Integer;
  MinAbstand    : Integer;
  Sichtfeld     : Integer;
  //test          : Integer;
  fertig        : Boolean;

function distance(pX1: Integer; pY1: Integer; pX2: Integer; pY2: Integer): Integer;
  var temp: double;
  begin
  temp := sqrt(Power((pX1 - pX2), 2) + Power((pY1 - pY2), 2));
  distance := Round(temp);
end;

procedure TMovePlate.FormCreate(Sender: TObject);
begin
  scaled := false;
  fertig := false;
  // --- deklarieren des Arrays f�r die 'Cellen' -------------------------------
  spalt := round (ImagePaint.Width / cellScal);
  reih  := round (ImagePaint.Height / cellScal);
  SetLength(cellList, reih, spalt);
  SetLength(limboWorld, reih, spalt);
  // --- initialization and creation of the list -------------------------------
  ShapesList                    := TList.Create;
  MovePlate.Color               := clBlack;
  MovePlate.Canvas.Pen.Color    := clred;
  MovePlate.Canvas.Brush.Color  := clred;
  LEFT_BORDER                   := ImagePaint.Left-5;
  TOP_BORDER                    := ImagePaint.Top-5;
  RIGHT_BORDER                  := ImagePaint.Width-5;
  BOTTOM_BORDER                 := ImagePaint.Height-5;
  // --- Slider & Label --------------------------------------------------------
  Mouse_Rad                     := ScrollBar1.Position;
  Label_Radius.Caption          := IntToStr(Mouse_Rad);
  LabelInterakt.Caption         := IntToStr(Abstand);
  MinAbstand                    := ScrollBar_MinDist.Position;
  Label_MinDist.Caption         := IntToStr(MinAbstand);
  Label_Sichtfeld.Caption       := IntToStr(Sichtfeld);
  LabelInterakt.Caption         := IntToStr(ScrollBar_DistGelb.Position);
  Label_Sichtfeld.Caption       := IntToStr(ScrollBar_DistBlau.Position);
  LabelDistRed.Caption          := IntToStr(ScrollBar_DistRot.Position);
  Lbl_RepelDistRot.Caption      := IntToStr(SB_RepelDistRot.Position);
  Lbl_RepelDistBlau.Caption     := IntToStr(SB_RepelDistBlau.Position);
  Lbl_RepelDistGelb.Caption     := IntToStr(SB_RepelDistGelb.Position);
  Lbl_BindRot.Caption           := IntToStr(SB_BindRot.Position);
  Lbl_BindBlau.Caption          := IntToStr(SB_BindBlau.Position);
  Lbl_BindGelb.Caption          := IntToStr(SB_BindGelb.Position);
  // --- Zwischenspeicher f�r die Bildaktualisierung ---------------------------
  Backpuffer        := TBitmap.create;
  Backpuffer.width  := ImagePaint.width;
  Backpuffer.height := ImagePaint.height;
  Backpuffer.canvas.brush.color := clgreen;
  Backpuffer.canvas.rectangle(10,10,Backpuffer.width,Backpuffer.height);
  RectanglCreate (Backpuffer.Canvas);
end;

// *********************************
// *** ------- Agenten --------- ***
//**********************************
// *** Zeichnet die Agenten ***
procedure TMovePlate.PaintBox1Paint(Sender: TObject);
begin
  MovePlate.Color := clBlack;
  MovePlate.canvas.brush.color := clgreen;
  MovePlate.canvas.pen.color := clgreen;
  MovePlate.canvas.pen.width := 2;
  MovePlate.canvas.rectangle(5,5,810,610);
  MovePlate.refresh;
  CommonPaint (Canvas);
end;

procedure TMovePlate.CommonPaint (Canvas: TCanvas);
var
  I     : Integer;
  AShape: TAgent;
begin
  // repaint each shape of the list
  for I := 0 to ShapesList.Count - 1 do
  begin
    AShape := ShapesList.Items [I];
    AShape.BindungSet := 0; // --- Anzahl Bindungen je Typ zur�cksetzen
    AShape.Paint (Canvas);
    If (AShape.State = 0)  And (CB_showRed.State = cbChecked) Then Begin
      Canvas.Pen.Color := clMaroon;
      RegionPaint (Canvas, AShape);
    end;
    If (AShape.State = 1)  And (CB_showBlau.State = cbChecked) Then Begin
      Canvas.Pen.Color := clNavy;
      RegionPaint (Canvas, AShape);
    end;
    If (AShape.State = 2)  And (CB_showGelb.State = cbChecked) Then Begin
      Canvas.Pen.Color := clOlive;
      RegionPaint (Canvas, AShape);
    end;
  end;
end;

procedure TMovePlate.RegionPaint (Canvas: TCanvas; AShape: TAgent);
var
  I    : Integer;
  tmpD : Integer;
begin
  Canvas.Brush.Style := bsclear;  //!!!(=bsClear, bsSolid, bsCross)
  Canvas.Pen.Style := psDot;      //!!!(=psSolid, psDash, psDot, psClear, psDashDot)
  For I := 0 to 1 Do
  Begin
    tmpD := I *  AShape.RepelDist;
    Canvas.Ellipse (AShape.PositionX - AShape.AnlDist + tmpD , AShape.FPositionY - AShape.AnlDist + tmpD,
                    AShape.PositionX + AShape.AnlDist - tmpD , AShape.FPositionY + AShape.AnlDist - tmpD);
  end;
end;

// *** Bewegungsvektor zeichnen ***
{procedure TMovePlate.BewegVekt();
var
  J      : Integer;
  AShape : TAgent;
  BShape : TAgent;
begin
  for J := 0 to ShapesList.Count - 1 do
  begin
    AShape := ShapesList.Items [J];
    Backpuffer.Canvas.Pen.Color := clLime;  // 898989;
    Backpuffer.Canvas.MoveTo(AShape.PositionX, AShape.PositionY); // --- Verbindungen mit oldPosition zeichnen
    Backpuffer.Canvas.LineTo((AShape.PositionX - 7*round(AShape.StepX)), (AShape.PositionY - 7*round(AShape.StepY)));
  end;
end;}

// *** Verbinde n�chste Nachbarn ***
procedure TMovePlate.Verbinden();
var
  J      : Integer;
  K      : Integer;
  AShape : TAgent;
  //BShape : TAgent;
begin
  for J := 0 to ShapesList.Count -1 do
  begin
    AShape := ShapesList.Items [J];
    Backpuffer.Canvas.Pen.Width := 1;
    K := 0;
    While  K < length(AShape.FBindListSelf) Do
    Begin
      //BShape := ShapesList.Items [AShape.BindListSelf[K]];
      Backpuffer.Canvas.Pen.Color := AShape.FillColor;//clMaroon;
      Backpuffer.Canvas.Pen.Style := psSolid;
      Backpuffer.Canvas.MoveTo(oldPos[J][0], oldPos[J][1]); // --- Verbindungen mit oldPosition zeichnen
      Backpuffer.Canvas.LineTo(oldPos[AShape.BindListSelf[K]][0], oldPos[AShape.BindListSelf[K]][1]);
      K := K + 1;
    end;
    K := 0;
    While  K < length(AShape.FBindListOther) Do
    Begin
      //BShape := ShapesList.Items [AShape.BindListOther[K]];
      Backpuffer.Canvas.Pen.Color := AShape.FillColor;//clMaroon;
      Backpuffer.Canvas.MoveTo(oldPos[J][0], oldPos[J][1]); // --- Verbindungen mit oldPosition zeichnen
      Backpuffer.Canvas.LineTo(oldPos[AShape.BindListOther[K]][0], oldPos[AShape.BindListOther[K]][1]);
      K := K + 1;
    end;
  end;
end;

// **** Schwarmverhalten ****
procedure TMovePlate.Swarming();
var
  J      : Integer;
  AShape : TAgent;
  XCell  : Integer;
  YCell  : Integer;
  //Cstatus: Integer;
begin
  SetLength(limboPos, ShapesList.Count, 2); //--- definiert die Gr��e der LimboPos
  SetLength(oldPos, ShapesList.Count, 2);   //--- definiert die Gr��e der oldPos
  for J := 0 to ShapesList.Count - 1 do
  begin
    AShape := ShapesList.Items [J];
    // --- Alte Positionen Speichern
    oldPos[J][0] := AShape.PositionX;
    oldPos[J][1] := AShape.PositionY;
    XCell := round((AShape.FPositionX - (cellScal / 2)) / (cellScal));
    YCell := round((AShape.FPositionY - (cellScal / 2)) / (cellScal));
    If not (((XCell < 0) or (XCell > spalt-1)) or ((YCell < 0) or (YCell > reih-1))) then
    begin
      //Cstatus:= cellList[YCell,XCell].State;
      // *** Lagert nur da an, wo zellen gleich gef�rbt
      //If (AShape.State = 0) OR ((AShape.State = 1) And (Cstatus <= 0)) OR
      //((AShape.State = 2) And (Cstatus >= 0))  Then begin
        AShape.NeigborCheck (ShapesList, J, ScrollBar_MinDist.Position, limboPos[J]);  // --- Berechnet die Nachbarn
      //end else begin
        //AShape.Connect := 0;
        //AShape.SetRndDir(1.1);
      //end;
    end;
  end;
end;

// *** Aktualisierungen je Durchlauf***
procedure TMovePlate.ApplicationEvents1Idle(Sender: TObject; var Done: Boolean);
var
  I         : Integer;
  //J         : Integer;
  AShape    : TAgent;
  distMouse : Integer;
  //Area      : Trect;
begin
  If fertig = false then done := false;
  If fertig = true  then begin done := true; exit; end;
  //If (CheckB_Verbind.State = cbChecked) then  //--- Swarming ...
    //lookCell (Backpuffer.Canvas);
    Swarming (); // --- Schwarmverhalten Subprozedur aufrufen
  //------------------------------------------//
  for I := 0 to ShapesList.Count - 1 do
  begin
    AShape := ShapesList.Items [I];
    {//--- LimboPos �bertragen f�r Swarming Bewegung ---
    If (CheckB_Verbind.State = cbChecked) then
    begin
      AShape.StepX := 1.0035 * (0.9 * AShape.StepX + 0.1 * limboPos[I][0]); // Mischverh�ltnis
      AShape.StepY := 1.0035 * (0.9 * AShape.StepY + 0.1 * limboPos[I][1]); // und Bescheunigungsfaktor
    end;}

    distMouse := distance (AShape.PositionX, AShape.PositionY, MouseX, MouseY);
    If (distMouse < Mouse_Rad) // --- MausInteraktion
    then begin
      AShape.FStepX := Dir * round ((AShape.PositionX - MouseX) * 0.1); //AShape.FStepX * -3;
      AShape.FStepY := Dir * round ((AShape.PositionY - MouseY) * 0.1); //AShape.FStepY * -3;
    end;

    // --- Randlos Torus--- // Rand nicht �berschreiten
    if AShape.PositionX < LEFT_BORDER  then
      AShape.PositionX := RIGHT_BORDER;
      //AShape.StepX := - AShape.StepX;
    if AShape.PositionX > RIGHT_BORDER then
      AShape.PositionX := LEFT_BORDER;
      //AShape.StepX := - AShape.StepX;
    if AShape.PositionY < TOP_BORDER then
      AShape.PositionY := BOTTOM_BORDER;
      //AShape.StepY := - AShape.StepY;
    if AShape.PositionY > BOTTOM_BORDER then
      AShape.PositionY := TOP_BORDER;
      //AShape.StepY := - AShape.StepY;
    // ++++ Position aktualisieren ++++
    AShape.PositionX := AShape.FPositionX + round(AShape.FStepX);
    AShape.PositionY := AShape.FPositionY + round(AShape.FStepY);
  end;

  // --- berechnen, zeichnen und verbinden ----
  If (CheckB_Zellen.State = cbChecked) then
  begin
    lookCell (Backpuffer.Canvas);
    cellStates (Backpuffer.Canvas);
  end;
  RectanglPaint (Backpuffer.Canvas);                   // --- L�scht Zeichung und Aktualisiert Zellen
  If (CB_Verbind.State = cbChecked) then  Verbinden(); // --- Verbindungslinie wenn angedockt
  CommonPaint (Backpuffer.Canvas);
  /// --- Bild aktualisieren ---
  //BitBlt(Backpuffer.Canvas.Handle, bildleft, bildtop, Bild.Width, Bild.Height, Bild.canvas.handle, 0, 0, SRCCOPY);//Bild auf Backpuffer kopieren
  ImagePaint.Invalidate;
  BitBlt(ImagePaint.Canvas.Handle, 0, 0, Backpuffer.Width, Backpuffer.Height, Backpuffer.canvas.handle, 0, 0, SRCCOPY);//Backpuffer auf das Formular kopieren
end;

procedure TMovePlate.ImagePaintMouseMove(Sender: TObject; Shift: TShiftState; X, Y: Integer);
begin
  MouseX := X;
  MouseY := Y;
end;


// *********************************
// *** ------- Zellen ---------- ***
//**********************************
// *** Erstellt das ZellenRaster ***
procedure TMovePlate.RectanglCreate (Canvas: TCanvas);
var
  I: Integer;
  K: Integer;
begin
  for I := 0 to reih -1 do
  begin
    for K := 0 to spalt -1 do
    begin
      cellList[I,K] := TCell.Create;
      cellList[I,K].PositionX := K * cellScal + round(cellScal / 2);
      cellList[I,K].PositionY := I * cellScal + round(cellScal / 2);
      cellList[I,K].Size := round (cellScal / 2)+1;
      //ARecht.FillColor :=  RGB (I*K mod 255, I, K);
      cellList[I,K].Paint(Canvas);
    end ;
  end;
end;

// *** Aktualisiert das ZellenRaster ***
procedure TMovePlate.RectanglPaint (Canvas: TCanvas);
var
  I    : Integer;
  K    : Integer;
  used : Integer;
begin
  //--- Backbuffer l�schen
  canvas.brush.color := clGreen;
  canvas.pen.color := clGreen;
  canvas.rectangle(10,10,Backpuffer.width,Backpuffer.height);
  for I := 0 to reih -1 do
  begin
    for K := 0 to spalt -1 do
    begin
      // --- Cellen anpassen ---
      cellList[I,K].FillColor := clBlack;     // --- Cellen l�schen
      cellList[I,K].State := limboWorld[I,K]; // --- limboWorld kopieren
      used := cellList[I,K].State;
      If used < -255 then used := -255;
      If used > 255 then used := 255;
      If  cellList[I,K].State < 0 then begin
        used:= used * -1;
        cellList[I,K].FillColor := RGB (0,0,used);
      end
      else If  cellList[I,K].State > 0 then begin
        cellList[I,K].FillColor := RGB (used,used,0);
      end;
      //case cellList[I,K].State of             // --- Farbe nach Status zuweisen
      //  0:  cellList[I,K].FillColor := RGB (125,165,255);
      // 10: cellList[I,K].FillColor := clBlue ;
      //end;
      //used := cellList[I,K].Passed;
      //cellList[I,K].FillColor := cellList[I,K].State;// RGB (used,used,used);
      // --- Neu zeichnen ---
      cellList[I,K].Paint(Canvas);
      limboWorld[I,K] := 0;     // --- limboWorld zur�cksetzen
      //cellList[I,K].State := 0; // --- Status l�schen
    end ;
  end;
end;

//*** Berechnet die Celle unter dem Agenten ***
procedure TMovePlate.lookCell (Canvas: TCanvas);
var
  I      : Integer;
  AShape : TAgent;
  XCell  : Integer;
  YCell  : Integer;
begin
  for I := 0 to ShapesList.Count - 1 do
  begin
    AShape := ShapesList.Items [I];
    XCell := round((AShape.FPositionX - (cellScal / 2)) / (cellScal));
    YCell := round((AShape.FPositionY - (cellScal / 2)) / (cellScal));
    If not (((XCell < 0) or (XCell > spalt-1)) or ((YCell < 0) or (YCell > reih-1))) then
    begin
      cellList[YCell,XCell].State := AShape.FState; //+ RGB (3,4,5);
    end;
  end;
end;

procedure TMovePlate.cellStates (Canvas: TCanvas);
var
  I: Integer;
  K: Integer;
begin
  for I := 1 to reih -2 do
  begin
    for K := 1 to spalt -2 do
    begin
      checkNeighbour (Backpuffer.Canvas, I, K);
    end ;
  end;
end;

procedure TMovePlate.checkNeighbour (Canvas: TCanvas; xPos : Integer; yPos : Integer);
var
  I: Integer;
  K: Integer;
  state : Integer;
begin
  state := 0;
  for I := xPos - 1 to xPos + 1 do
  begin
    for K := yPos - 1 to yPos + 1 do
    begin
      //If not ((I = xPos) and (K = yPos)) then
      If (cellList[I,K].State = 1) then state := state - 55;
      If (cellList[I,K].State = 2) then state := state + 50;
    end;
  end;
  limboWorld[xPos,yPos] := state;
end;

// ***************************
// ********* Buttons *********
// ***************************
//
// *** Repel - Attract - Button ***
procedure TMovePlate.Button2MouseUp(Sender: TObject; Button: TMouseButton;
  Shift: TShiftState; X, Y: Integer);
begin
  Dir := Dir * (-1);
end;

// *** einzelne Agenten erstellen ***
procedure TMovePlate.ImagePaintClick(Sender: TObject);
begin
  CurrShape := TAgent.Create;
  CurrShape.PositionX :=  MouseX;
  CurrShape.PositionY :=  MouseY;
  CurrShape.StepX := (random(3) - 1);
  CurrShape.StepY := (random(3) - 1);
  CurrShape.Size := 3;
  CurrShape.Connect := 0;
  CurrShape.State := 0;
  CurrShape.BindungMax:= SB_BindRot.Position;
  CurrShape.AnlDist   := ScrollBar_DistRot.Position;
  CurrShape.RepelDist := SB_RepelDistRot.Position;
  CurrShape.basicSettings;
  ShapesList.Add (CurrShape);
  CommonPaint (ImagePaint.Canvas);
  Label2.Caption := IntToStr(ShapesList.Count);
end;

// *** Initialisiert die Roten Agenten ***
procedure TMovePlate.Button_CreateClick(Sender: TObject);
var
  I: Integer;
begin
  for I := 1 to StrToInt(Edi_NrRed.Text) Do //NUM_BALLS do
  begin
    CurrShape := TAgent.Create;
    CurrShape.PositionX := random (760);
    CurrShape.PositionY := random (450);
    CurrShape.StepX := (random(3) - 1);
    CurrShape.StepY := (random(3) - 1);
    CurrShape.Size := 3;
    CurrShape.Connect := 0;
    CurrShape.State := 0;
    CurrShape.BindungMax:= SB_BindRot.Position;
    CurrShape.AnlDist   := ScrollBar_DistRot.Position;
    CurrShape.RepelDist := SB_RepelDistRot.Position;
    // ---  add to the list ---
    CurrShape.basicSettings;
    ShapesList.Add (CurrShape);
  end ;
  CommonPaint (ImagePaint.Canvas);
  Label2.Caption := IntToStr(ShapesList.Count);
end;

// *** Initialisiert die Blauen Agenten ***
procedure TMovePlate.ButtonCreateBClick(Sender: TObject);
var
  I: Integer;
begin
  for I := 1 to StrToInt(Edi_NrBlau.Text) do
  begin
    CurrShape := TAgent.Create;
    CurrShape.PositionX := random (760);
    CurrShape.PositionY := random (450);
    CurrShape.StepX := (random(3) - 1);
    CurrShape.StepY := (random(3) - 1);
    CurrShape.Size := 3;
    CurrShape.Connect := 0;
    CurrShape.State := 1;
    CurrShape.BindungMax:= SB_BindBlau.Position;
    CurrShape.AnlDist   := ScrollBar_DistBlau.Position;
    CurrShape.RepelDist := SB_RepelDistBlau.Position;
    CurrShape.basicSettings;
    ShapesList.Add (CurrShape);
  end ;
  CommonPaint (ImagePaint.Canvas);
  Label2.Caption := IntToStr(ShapesList.Count);
end;

// *** Initialisiert die Gelben Agenten ***
procedure TMovePlate.ButtonCreateYClick(Sender: TObject);
var
  I: Integer;
begin
  for I := 1 to StrToInt(Edi_NrGelb.Text) do
  begin
    CurrShape := TAgent.Create;
    CurrShape.PositionX := random (750);
    CurrShape.PositionY := random (450);
    CurrShape.StepX := (random(3) - 1);
    CurrShape.StepY := (random(3) - 1);
    CurrShape.Size := 3;
    CurrShape.Connect := 0;
    CurrShape.State := 2;
    CurrShape.BindungMax:= SB_BindGelb.Position;
    CurrShape.AnlDist   := ScrollBar_DistGelb.Position;
    CurrShape.RepelDist := SB_RepelDistGelb.Position;
    CurrShape.basicSettings;
    ShapesList.Add (CurrShape);
  end ;
  CommonPaint (ImagePaint.Canvas);
  Label2.Caption := IntToStr(ShapesList.Count);
end;

// *** Alle Zellen wieder schwarz ***
procedure TMovePlate.ButtonPauseClick(Sender: TObject);
//var
  //I: Integer;
  //K: Integer;
begin
  fertig := Not fertig; //true;
  If MovePlate.Color = clRed Then begin
    MovePlate.Color := clBlack;
    exit;
  end;
  MovePlate.Color := clRed;
  {for I := 0 to reih -1 do
  begin
    for K := 0 to spalt -1 do
    begin
        cellList[I,K].Passed := 0;
    end;
  end; }
end;

// *** Agenten l�schen ***
procedure TMovePlate.Button_DeleteClick(Sender: TObject);
begin
ShapesList.Count := ShapesList.Count - 100;
  Label2.Caption := IntToStr(ShapesList.Count);
end;

// ***************************
// ******* ScrollBars ********
// ***************************
//
// *** DistanzRot einstellen ***
procedure TMovePlate.ScrollBar_DistRotChange(Sender: TObject);
var
  J      : Integer;
  AShape : TAgent;
begin
  for J := 0 to ShapesList.Count - 1 do
  begin
    AShape := ShapesList.Items [J];
    If AShape.State = 0 then
    AShape.AnlDist := ScrollBar_DistRot.Position;
    AShape.Connect := 0;
    AShape.StepX := (random(3) - 1);
    AShape.StepY := (random(3) - 1);
  end;
    LabelDistRed.Caption := IntToStr(ScrollBar_DistRot.Position);
end;

// *** DistanzGelb einstellen ***
procedure TMovePlate.ScrollBar_DistGelbChange(Sender: TObject);
var
  J      : Integer;
  AShape : TAgent;
begin
  for J := 0 to ShapesList.Count - 1 do
  begin
    AShape := ShapesList.Items [J];
    If AShape.State = 2 then
    AShape.AnlDist := ScrollBar_DistGelb.Position;
    AShape.Connect := 0;
    AShape.StepX := (random(3) - 1);
    AShape.StepY := (random(3) - 1);
  end;
    LabelInterakt.Caption := IntToStr(ScrollBar_DistGelb.Position);
end;

// *** DistanzBlau einstellen ***
procedure TMovePlate.ScrollBar_DistBlauChange(Sender: TObject);
var
  J      : Integer;
  AShape : TAgent;
begin
  for J := 0 to ShapesList.Count - 1 do
  begin
    AShape := ShapesList.Items [J];
    If AShape.State = 1 then
    AShape.AnlDist := ScrollBar_DistBlau.Position;
    AShape.Connect := 0;
    AShape.StepX := (random(3) - 1);
    AShape.StepY := (random(3) - 1);
  end;
  Label_Sichtfeld.Caption := IntToStr(ScrollBar_DistBlau.Position);
end;

// *** Mindestabstand zwischen den Agenten ***
procedure TMovePlate.ScrollBar_MinDistChange(Sender: TObject);
begin
  MinAbstand                 := ScrollBar_MinDist.Position;
  Label_MinDist.Caption      := IntToStr(MinAbstand);
  ScrollBar_MinDist.Position := MinAbstand;
end;

// *** MausInteraktionsRadius ***
procedure TMovePlate.ScrollBar1Change(Sender: TObject);
begin
    Mouse_Rad            := ScrollBar1.Position;
    Label_Radius.Caption := IntToStr(Mouse_Rad);
end;

// *** Repel Abstand f�r Rote Punkte ***
procedure TMovePlate.SB_RepelDistRotChange(Sender: TObject);
var
  J      : Integer;
  AShape : TAgent;
begin
  Lbl_RepelDistRot.Caption := IntToStr(SB_RepelDistRot.Position);
  for J := 0 to ShapesList.Count - 1 do
  begin
    AShape := ShapesList.Items [J];
    If AShape.State = 0 then
    AShape.RepelDist := SB_RepelDistRot.Position;
  end;
end;

// *** Repel Abstand f�r Blaue Punkte ***
procedure TMovePlate.SB_RepelDistBlauChange(Sender: TObject);
var
  J      : Integer;
  AShape : TAgent;
begin
  Lbl_RepelDistBlau.Caption := IntToStr(SB_RepelDistBlau.Position);
  for J := 0 to ShapesList.Count - 1 do
  begin
    AShape := ShapesList.Items [J];
    If AShape.State = 1 then
    AShape.RepelDist := SB_RepelDistBlau.Position;
  end;
end;

// *** Repel Abstand f�r Gelbe Punkte ***
procedure TMovePlate.SB_RepelDistGelbChange(Sender: TObject);
var
  J      : Integer;
  AShape : TAgent;
begin
  Lbl_RepelDistGelb.Caption := IntToStr(SB_RepelDistGelb.Position);
  for J := 0 to ShapesList.Count - 1 do
  begin
    AShape := ShapesList.Items [J];
    If AShape.State = 2 then
    AShape.RepelDist := SB_RepelDistGelb.Position;
  end;
end;

procedure TMovePlate.SB_BindRotChange(Sender: TObject);
begin
  Lbl_BindRot.Caption := IntToStr(SB_BindRot.Position);
end;

procedure TMovePlate.SB_BindBlauChange(Sender: TObject);
begin
  Lbl_BindBlau.Caption := IntToStr(SB_BindBlau.Position);
end;

procedure TMovePlate.SB_BindGelbChange(Sender: TObject);
begin
  Lbl_BindGelb.Caption := IntToStr(SB_BindGelb.Position);
end;

// ******************************
// *** Array und Liste L�schen***
// ******************************
procedure TMovePlate.FormDestroy(Sender: TObject);
var
  I: Integer;
  J: Integer;
  K: Integer;
begin
  // --- delete each agent
  for I := ShapesList.Count - 1 downto 0 do
    TBaseShape (ShapesList [I]).Free;
  ShapesList.Free;
  // --- delete each cell
  for J := reih -1 downto 0 do
  begin
    for K := spalt -1 downto 0 do
    begin
      TBaseShape (cellList[J,K]).Free;
    end;
  end;
end;

end.

object MovePlate: TMovePlate
  Left = 0
  Top = 0
  Width = 800
  Height = 655
  Caption = 'MovePlate'
  Color = clSilver
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -10
  Font.Name = 'Tahoma'
  Font.Style = []
  OldCreateOrder = False
  OnCreate = FormCreate
  OnDestroy = FormDestroy
  PixelsPerInch = 96
  TextHeight = 12
  object Label1: TLabel
    Left = 6
    Top = 480
    Width = 106
    Height = 13
    Caption = 'Anzahl Knotenpunkte:'
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clWhite
    Font.Height = -11
    Font.Name = 'Tahoma'
    Font.Style = []
    ParentFont = False
  end
  object Label2: TLabel
    Left = 108
    Top = 480
    Width = 24
    Height = 13
    Caption = '0000'
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clWhite
    Font.Height = -11
    Font.Name = 'Tahoma'
    Font.Style = []
    ParentFont = False
  end
  object Label3: TLabel
    Left = 400
    Top = 485
    Width = 61
    Height = 13
    Caption = 'MausRadius:'
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clWhite
    Font.Height = -11
    Font.Name = 'Tahoma'
    Font.Style = []
    ParentFont = False
  end
  object Label_Radius: TLabel
    Left = 474
    Top = 485
    Width = 24
    Height = 13
    Caption = '____'
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clWhite
    Font.Height = -11
    Font.Name = 'Tahoma'
    Font.Style = []
    ParentFont = False
  end
  object Label4: TLabel
    Left = 25
    Top = 593
    Width = 90
    Height = 13
    Caption = 'Anlager Dist. Gelb:'
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clWhite
    Font.Height = -11
    Font.Name = 'Tahoma'
    Font.Style = []
    ParentFont = False
  end
  object LabelInterakt: TLabel
    Left = 122
    Top = 593
    Width = 24
    Height = 13
    Caption = '____'
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clWhite
    Font.Height = -11
    Font.Name = 'Tahoma'
    Font.Style = []
    ParentFont = False
  end
  object Label5: TLabel
    Left = 381
    Top = 504
    Width = 80
    Height = 13
    Caption = 'Mindestabstand:'
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clWhite
    Font.Height = -11
    Font.Name = 'Tahoma'
    Font.Style = []
    ParentFont = False
  end
  object Label_MinDist: TLabel
    Left = 474
    Top = 504
    Width = 24
    Height = 13
    Caption = '____'
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clWhite
    Font.Height = -11
    Font.Name = 'Tahoma'
    Font.Style = []
    ParentFont = False
  end
  object Label6: TLabel
    Left = 26
    Top = 575
    Width = 89
    Height = 13
    Caption = 'Anlager Dist. Blau:'
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clWhite
    Font.Height = -11
    Font.Name = 'Tahoma'
    Font.Style = []
    ParentFont = False
  end
  object Label_Sichtfeld: TLabel
    Left = 122
    Top = 575
    Width = 24
    Height = 13
    Caption = '____'
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clWhite
    Font.Height = -11
    Font.Name = 'Tahoma'
    Font.Style = []
    ParentFont = False
  end
  object Label7: TLabel
    Left = 29
    Top = 557
    Width = 86
    Height = 13
    Caption = 'Anlager Dist. Rot:'
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clWhite
    Font.Height = -11
    Font.Name = 'Tahoma'
    Font.Style = []
    ParentFont = False
  end
  object LabelDistRed: TLabel
    Left = 122
    Top = 557
    Width = 24
    Height = 13
    Caption = '____'
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clWhite
    Font.Height = -11
    Font.Name = 'Tahoma'
    Font.Style = []
    ParentFont = False
  end
  object Label8: TLabel
    Left = 603
    Top = 593
    Width = 78
    Height = 13
    Caption = 'Bindungen Gelb:'
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clWhite
    Font.Height = -11
    Font.Name = 'Tahoma'
    Font.Style = []
    ParentFont = False
  end
  object Lbl_BindGelb: TLabel
    Left = 688
    Top = 593
    Width = 24
    Height = 13
    Caption = '____'
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clWhite
    Font.Height = -11
    Font.Name = 'Tahoma'
    Font.Style = []
    ParentFont = False
  end
  object Label10: TLabel
    Left = 604
    Top = 575
    Width = 77
    Height = 13
    Caption = 'Bindungen Blau:'
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clWhite
    Font.Height = -11
    Font.Name = 'Tahoma'
    Font.Style = []
    ParentFont = False
  end
  object Lbl_BindBlau: TLabel
    Left = 688
    Top = 575
    Width = 24
    Height = 13
    Caption = '____'
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clWhite
    Font.Height = -11
    Font.Name = 'Tahoma'
    Font.Style = []
    ParentFont = False
  end
  object Label12: TLabel
    Left = 607
    Top = 557
    Width = 74
    Height = 13
    Caption = 'Bindungen Rot:'
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clWhite
    Font.Height = -11
    Font.Name = 'Tahoma'
    Font.Style = []
    ParentFont = False
  end
  object Lbl_BindRot: TLabel
    Left = 688
    Top = 557
    Width = 24
    Height = 13
    Caption = '____'
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clWhite
    Font.Height = -11
    Font.Name = 'Tahoma'
    Font.Style = []
    ParentFont = False
  end
  object Label9: TLabel
    Left = 365
    Top = 593
    Width = 77
    Height = 13
    Caption = 'RepelDist. Gelb:'
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clWhite
    Font.Height = -11
    Font.Name = 'Tahoma'
    Font.Style = []
    ParentFont = False
  end
  object Lbl_RepelDistGelb: TLabel
    Left = 450
    Top = 593
    Width = 24
    Height = 13
    Caption = '____'
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clWhite
    Font.Height = -11
    Font.Name = 'Tahoma'
    Font.Style = []
    ParentFont = False
  end
  object Label13: TLabel
    Left = 366
    Top = 575
    Width = 76
    Height = 13
    Caption = 'RepelDist. Blau:'
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clWhite
    Font.Height = -11
    Font.Name = 'Tahoma'
    Font.Style = []
    ParentFont = False
  end
  object Lbl_RepelDistBlau: TLabel
    Left = 450
    Top = 575
    Width = 24
    Height = 13
    Caption = '____'
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clWhite
    Font.Height = -11
    Font.Name = 'Tahoma'
    Font.Style = []
    ParentFont = False
  end
  object Label15: TLabel
    Left = 369
    Top = 557
    Width = 73
    Height = 13
    Caption = 'RepelDist. Rot:'
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clWhite
    Font.Height = -11
    Font.Name = 'Tahoma'
    Font.Style = []
    ParentFont = False
  end
  object Lbl_RepelDistRot: TLabel
    Left = 450
    Top = 557
    Width = 24
    Height = 13
    Caption = '____'
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clWhite
    Font.Height = -11
    Font.Name = 'Tahoma'
    Font.Style = []
    ParentFont = False
  end
  object ScrollBar1: TScrollBar
    Left = 504
    Top = 481
    Width = 97
    Height = 15
    Max = 200
    PageSize = 0
    TabOrder = 0
    OnChange = ScrollBar1Change
  end
  object Button_Delete: TButton
    Left = 718
    Top = 528
    Width = 68
    Height = 16
    Caption = 'Delete 100 Pts'
    TabOrder = 1
    OnClick = Button_DeleteClick
  end
  object Button2: TButton
    Left = 718
    Top = 505
    Width = 67
    Height = 16
    Caption = 'Attract/Repel'
    TabOrder = 2
    OnMouseUp = Button2MouseUp
  end
  object CheckB_Zellen: TCheckBox
    Left = 6
    Top = 504
    Width = 97
    Height = 13
    Caption = 'Zellen markieren'
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clWhite
    Font.Height = -11
    Font.Name = 'Tahoma'
    Font.Style = []
    ParentFont = False
    TabOrder = 3
  end
  object Button_Create: TButton
    Left = 152
    Top = 481
    Width = 68
    Height = 16
    Caption = 'Create Reds'
    TabOrder = 4
    OnClick = Button_CreateClick
  end
  object ScrollBar_DistGelb: TScrollBar
    Left = 152
    Top = 589
    Width = 97
    Height = 15
    LargeChange = 5
    Max = 120
    Min = 5
    PageSize = 0
    Position = 14
    TabOrder = 5
    OnChange = ScrollBar_DistGelbChange
  end
  object ScrollBar_MinDist: TScrollBar
    Left = 504
    Top = 505
    Width = 97
    Height = 15
    Max = 50
    Min = 1
    PageSize = 0
    Position = 5
    TabOrder = 6
    OnChange = ScrollBar_MinDistChange
  end
  object ScrollBar_DistBlau: TScrollBar
    Left = 152
    Top = 571
    Width = 97
    Height = 15
    LargeChange = 5
    Max = 120
    Min = 5
    PageSize = 0
    Position = 30
    TabOrder = 7
    OnChange = ScrollBar_DistBlauChange
  end
  object ButtonPause: TButton
    Left = 718
    Top = 479
    Width = 68
    Height = 18
    Caption = 'Pause'
    TabOrder = 8
    OnClick = ButtonPauseClick
  end
  object ButtonCreateB: TButton
    Left = 152
    Top = 512
    Width = 68
    Height = 15
    Caption = 'Create Blues'
    TabOrder = 9
    OnClick = ButtonCreateBClick
  end
  object ButtonCreateY: TButton
    Left = 152
    Top = 529
    Width = 68
    Height = 15
    Caption = 'Create Yellows'
    TabOrder = 10
    OnClick = ButtonCreateYClick
  end
  object ScrollBar_DistRot: TScrollBar
    Left = 152
    Top = 553
    Width = 97
    Height = 15
    LargeChange = 5
    Max = 200
    Min = 5
    PageSize = 0
    Position = 75
    TabOrder = 11
    OnChange = ScrollBar_DistRotChange
  end
  object CB_showRed: TCheckBox
    Left = 262
    Top = 555
    Width = 49
    Height = 13
    Caption = 'show'
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clWhite
    Font.Height = -11
    Font.Name = 'Tahoma'
    Font.Style = []
    ParentFont = False
    TabOrder = 12
  end
  object CB_showBlau: TCheckBox
    Left = 262
    Top = 573
    Width = 49
    Height = 13
    Caption = 'show'
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clWhite
    Font.Height = -11
    Font.Name = 'Tahoma'
    Font.Style = []
    ParentFont = False
    TabOrder = 13
  end
  object CB_showGelb: TCheckBox
    Left = 262
    Top = 591
    Width = 49
    Height = 13
    Caption = 'show'
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clWhite
    Font.Height = -11
    Font.Name = 'Tahoma'
    Font.Style = []
    ParentFont = False
    TabOrder = 14
  end
  object CB_Verbind: TCheckBox
    Left = 6
    Top = 522
    Width = 97
    Height = 13
    Caption = 'Verbindungslinien'
    Checked = True
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clWhite
    Font.Height = -11
    Font.Name = 'Tahoma'
    Font.Style = []
    ParentFont = False
    State = cbChecked
    TabOrder = 15
  end
  object SB_BindGelb: TScrollBar
    Left = 718
    Top = 589
    Width = 67
    Height = 15
    Max = 10
    Min = 1
    PageSize = 2
    Position = 6
    TabOrder = 16
    OnChange = SB_BindGelbChange
  end
  object SB_BindBlau: TScrollBar
    Left = 718
    Top = 571
    Width = 67
    Height = 15
    Max = 10
    Min = 1
    PageSize = 2
    Position = 6
    TabOrder = 17
    OnChange = SB_BindBlauChange
  end
  object SB_BindRot: TScrollBar
    Left = 718
    Top = 553
    Width = 67
    Height = 15
    Max = 10
    Min = 1
    PageSize = 2
    Position = 6
    TabOrder = 18
    OnChange = SB_BindRotChange
  end
  object SB_RepelDistGelb: TScrollBar
    Left = 478
    Top = 589
    Width = 79
    Height = 15
    Max = 30
    Min = 1
    PageSize = 8
    Position = 6
    TabOrder = 19
    OnChange = SB_RepelDistGelbChange
  end
  object SB_RepelDistBlau: TScrollBar
    Left = 478
    Top = 571
    Width = 79
    Height = 15
    Max = 30
    Min = 1
    PageSize = 8
    Position = 10
    TabOrder = 20
    OnChange = SB_RepelDistBlauChange
  end
  object SB_RepelDistRot: TScrollBar
    Left = 478
    Top = 553
    Width = 79
    Height = 15
    Max = 30
    Min = 1
    PageSize = 8
    Position = 10
    TabOrder = 21
    OnChange = SB_RepelDistRotChange
  end
  object GroupBox1: TGroupBox
    Left = 6
    Top = 0
    Width = 779
    Height = 469
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clWindowText
    Font.Height = -11
    Font.Name = 'Tahoma'
    Font.Style = []
    ParentFont = False
    TabOrder = 22
    object ImagePaint: TImage
      Left = 8
      Top = 11
      Width = 769
      Height = 456
      OnClick = ImagePaintClick
      OnMouseMove = ImagePaintMouseMove
    end
  end
  object Edi_NrRed: TEdit
    Left = 224
    Top = 477
    Width = 25
    Height = 20
    TabOrder = 23
    Text = '50'
  end
  object Edi_NrBlau: TEdit
    Left = 224
    Top = 507
    Width = 25
    Height = 20
    TabOrder = 24
    Text = '90'
  end
  object Edi_NrGelb: TEdit
    Left = 224
    Top = 524
    Width = 25
    Height = 20
    TabOrder = 25
    Text = '90'
  end
  object ApplicationEvents1: TApplicationEvents
    OnIdle = ApplicationEvents1Idle
    Left = 120
    Top = 72
  end
end

unit agenten;

interface

uses
  Windows, Graphics;

type
  TBaseShape = class
  private
  public
    FPositionX: Integer;
    FPositionY: Integer;
    FSize: Integer;
    FStepX : Double;
    FStepY : Double;
    FFillColor : Integer;
    FState: Integer;
    procedure Paint (Canvas: TCanvas); virtual;
    procedure SetPositionX(const Value: Integer);
    procedure SetPositionY(const Value: Integer);
    procedure SetStepX(const Value: Double);
    procedure SetStepY(const Value: Double);
    procedure SetSize(const Value: Integer);
    procedure SetFillColor(const Value: Integer);
    procedure SetState(const Value: Integer);
  published
    property PositionX: Integer read FPositionX write SetPositionX;
    property PositionY: Integer read FPositionY write SetPositionY;
    property StepX: Double read FStepX write SetStepX;
    property StepY: Double read FStepY write SetStepY;
    property Size: Integer read FSize write SetSize;
    property FillColor: Integer read FFillColor write SetFillColor;
    property State: Integer read FState write SetState;
  end;

type
  TAgent = class (TBaseShape)
    procedure Paint (Canvas: TCanvas); override;
  end;

  TCell = class (TBaseShape)
    procedure Paint (Canvas: TCanvas); override;
  end;

implementation

procedure TBaseShape.Paint (Canvas: TCanvas);
begin
  // set the attributes
  Canvas.Pen.Width := 1;
end;

procedure TBaseShape.SetStepX(const Value: Double);
begin
  FStepX := Value;
end;

procedure TBaseShape.SetStepY(const Value: Double);
begin
  FStepY := Value;
end;

procedure TBaseShape.SetPositionX(const Value: Integer);
begin
  FPositionX := Value;
end;

procedure TBaseShape.SetPositionY(const Value: Integer);
begin
  FPositionY := Value;
end;

procedure TBaseShape.SetSize(const Value: Integer);
begin
  FSize := Value;
end;

procedure TBaseShape.SetFillColor(const Value: Integer);
begin
  FFillColor := Value;
end;

procedure TBaseShape.SetState(const Value: Integer);
begin
  FState := Value;
end;

procedure TAgent.Paint(Canvas: TCanvas);
begin
  inherited Paint (Canvas);
  Canvas.Pen.Color := clGreen;
  Canvas.Brush.Color := FFillColor;
  Canvas.Ellipse (FPositionX - FSize , FPositionY - (FSize), FPositionX + (FSize), FPositionY + (FSize));
end;

procedure TCell.Paint(Canvas: TCanvas);
begin
  inherited Paint (Canvas);
  Canvas.Pen.Color := clGreen;
  Canvas.Brush.Color := FFillColor;
  Canvas.Rectangle (FPositionX - FSize , FPositionY - (FSize), FPositionX + (FSize), FPositionY + (FSize));
end;

end.

unit facsSteer;

interface

uses
  Windows, Messages, SysUtils, Variants, Classes, Graphics, Controls, Forms,
  Dialogs, ExtCtrls, Grids, agenten, Math, ConvUtils, StdCtrls, ActnMan , AppEvnts;

type
  TMovePlate = class(TForm)
    ScrollBar1: TScrollBar;
    ApplicationEvents1: TApplicationEvents;
    ImagePaint: TImage;
    Label1: TLabel;
    Label2: TLabel;
    Button_Delete: TButton;
    Button2: TButton;
    Label3: TLabel;
    Label_Radius: TLabel;
    CheckB_Zellen: TCheckBox;
    CheckB_Verbind: TCheckBox;
    Button_Create: TButton;
    procedure Button_DeleteClick(Sender: TObject);
    procedure Button_CreateClick(Sender: TObject);
    procedure Button2MouseUp(Sender: TObject; Button: TMouseButton;
      Shift: TShiftState; X, Y: Integer);
    procedure FormDestroy(Sender: TObject);
    procedure ImagePaintMouseMove(Sender: TObject; Shift: TShiftState; X,
      Y: Integer);
    procedure ApplicationEvents1Idle(Sender: TObject; var Done: Boolean);
    procedure PaintBox1Paint(Sender: TObject);
    procedure ScrollBar1Change(Sender: TObject);
    procedure FormCreate(Sender: TObject);

  private
    { Private declarations }
    ShapesList: TList;
    CurrShape: TBaseShape;
    procedure CommonPaint (Canvas: TCanvas);
    procedure checkNeighbour (Canvas: TCanvas; xPos : Integer; yPos : Integer);
    procedure lookCell (Canvas: TCanvas);
    procedure cellStates (Canvas: TCanvas);
    procedure RectanglPaint (Canvas: TCanvas);
    procedure RectanglCreate (Canvas: TCanvas);
    procedure Connect (Canvas: TCanvas);
  public
    { Public declarations }
  end;

var
  MovePlate: TMovePlate;

implementation

{$R *.dfm}

const
    NUM_BALLS = 500;
    cellScal = 10;
var
  reih : Integer;
  spalt : Integer;
  Dir : integer = 1;
  StepX : integer;
  StepY : integer;
  LEFT_BORDER : integer;
  TOP_BORDER : integer;
  RIGHT_BORDER : integer;
  BOTTOM_BORDER : integer;
  Mouse_Rad : integer;
  MouseX : Integer;
  MouseY : Integer;
  Backpuffer: TBitmap;
  cellList : Array of Array of TCell;
  limboWorld: Array of Array of Integer;
  XCell : Integer;
  YCell : Integer;

function distance(pX1: Integer; pY1: Integer; pX2: Integer; pY2: Integer): integer;
  var temp: double;
  begin
  temp := sqrt(Power((pX1 - pX2), 2) + Power((pY1 - pY2), 2));
  distance := Round(temp);
end;

procedure TMovePlate.FormCreate(Sender: TObject);
begin
  // --- deklarieren des Arrays f�r die 'Cellen' ---
  spalt := round (ImagePaint.Width / cellScal);
  reih := round (ImagePaint.Height / cellScal);
  SetLength(cellList, reih, spalt);
  SetLength(limboWorld, reih, spalt);
  // --- initialization and creation of the list ---
  ShapesList := TList.Create;
  MovePlate.Color := clBlack;
  MovePlate.Canvas.Pen.Color := clred;
  MovePlate.Canvas.Brush.Color := clred;
  LEFT_BORDER := ImagePaint.Left-5;
  TOP_BORDER := ImagePaint.Top-5;
  RIGHT_BORDER := ImagePaint.Width-5;
  BOTTOM_BORDER := ImagePaint.Height-5;
  Mouse_Rad := 50;
  Label_Radius.Caption := IntToStr(Mouse_Rad);
  ScrollBar1.Position := Mouse_Rad;
  // --- Zwischenspeicher f�r die Bildaktualisierung ---
  Backpuffer:= TBitmap.create;
  Backpuffer.width := ImagePaint.width;
  Backpuffer.height:= ImagePaint.height;
  Backpuffer.canvas.brush.color := clgreen;
  Backpuffer.canvas.rectangle(0,0,Backpuffer.width,Backpuffer.height);
  // --- zellenraster initialisieren ---
  RectanglCreate (ImagePaint.Canvas);
end;

// *** Erstellt das ZellenRaster ***
procedure TMovePlate.RectanglCreate (Canvas: TCanvas);
var
  I: Integer;
  K: Integer;
begin
  for I := 0 to reih -1 do
  begin
    for K := 0 to spalt -1 do
    begin
      cellList[I,K] := TCell.Create;
      cellList[I,K].PositionX := K * cellScal + round(cellScal / 2);
      cellList[I,K].PositionY := I * cellScal + round(cellScal / 2);
      cellList[I,K].Size := round (cellScal / 2)+1;
      //ARecht.FillColor :=  RGB (I*K mod 255, I, K);
      cellList[I,K].Paint(Canvas);
    end ;
  end;
end;

// *** Aktualisiert das ZellenRaster ***
procedure TMovePlate.RectanglPaint (Canvas: TCanvas);
var
  I: Integer;
  K: Integer;
begin
  //--- Backbuffer l�schen
  canvas.brush.color := clblack;
  canvas.pen.color := clGreen;
  canvas.rectangle(0,0,Backpuffer.width,Backpuffer.height);
  for I := 0 to reih -1 do
  begin
    for K := 0 to spalt -1 do
    begin
      // --- Cellen anpassen ---
      cellList[I,K].FillColor := clBlack;     // --- Cellen l�schen
      cellList[I,K].State := limboWorld[I,K]; // --- limboWorld kopieren
      case cellList[I,K].State of             // --- Farbe nach Status zuweisen
        1:  cellList[I,K].FillColor := RGB (125,165,255);
        10: cellList[I,K].FillColor := clBlue ;
      end;
      // --- Neu zeichnen ---
      cellList[I,K].Paint(Canvas);
      limboWorld[I,K] := 0;     // --- limboWorld zur�cksetzen
      cellList[I,K].State := 0; // --- Status l�schen
    end ;
  end;
end;

//*** Berechnet die Celle unter dem Agenten ***
procedure TMovePlate.lookCell (Canvas: TCanvas);
var
  I : Integer;
  AShape : TAgent;
begin
  for I := 0 to ShapesList.Count - 1 do
  begin
    AShape := ShapesList.Items [I];
    XCell := round((AShape.FPositionX - (cellScal / 2)) / (cellScal));
    YCell := round((AShape.FPositionY - (cellScal / 2)) / (cellScal));
    If not (((XCell < 0) or (XCell > spalt-1)) or ((YCell < 0) or (YCell > reih-1))) then
    begin
      cellList[YCell,XCell].State := 10; //cellList[YCell,XCell].FFillColor + RGB (3,4,5);
    end;
  end;
end;

procedure TMovePlate.cellStates (Canvas: TCanvas);
var
  I: Integer;
  K: Integer;
begin
  for I := 1 to reih -2 do
  begin
    for K := 1 to spalt -2 do
    begin
      checkNeighbour (Backpuffer.Canvas, I, K);
    end ;
  end;
end;

procedure TMovePlate.checkNeighbour (Canvas: TCanvas; xPos : Integer; yPos : Integer);
var
  I: Integer;
  K: Integer;
  state : Integer;
begin
  state := 0;
  for I := xPos - 1 to xPos + 1 do
  begin
    for K := yPos - 1 to yPos + 1 do
    begin
      //If not ((I = xPos) and (K = yPos)) then
      If (cellList[I,K].State = 10) then
        state := state + 1;
    end;
  end;

  If (cellList[xPos,yPos].State = 10)
    then begin
      limboWorld[xPos,yPos] := 10;
      state := state - 1;
    end
    else begin
      If (state > 0)then
      begin
        limboWorld[xPos,yPos] := 1;
      end;
    end;
end;

// *** Zeichnet die Agenten ***
procedure TMovePlate.PaintBox1Paint(Sender: TObject);
begin
  CommonPaint (Canvas);
end;

procedure TMovePlate.CommonPaint (Canvas: TCanvas);
var
  I: Integer;
  AShape: TAgent;
begin
  // repaint each shape of the list
  for I := 0 to ShapesList.Count - 1 do
  begin
    AShape := ShapesList.Items [I];
    AShape.Paint (Canvas);
  end;
end;

// *** zeichnet die Verbindungslinien***
procedure TMovePlate.Connect (Canvas: TCanvas);
var
  I: Integer;
  K: Integer;
  AShape: TAgent;
  BShape: TAgent;
  distNode : integer;
begin
  for I := 0 to ShapesList.Count - 1 do
  begin
    AShape := ShapesList.Items [I];
    for K := I+1 to ShapesList.Count - 1 do
    begin
      BShape := ShapesList.Items [K];
      distNode := distance (AShape.PositionX, AShape.PositionY, BShape.PositionX, BShape.PositionY);
      if distNode < 40 then
      begin
        Canvas.Pen.Color := RGB (70,70,70);//898989;
        Canvas.MoveTo(AShape.PositionX, AShape.PositionY);
        Canvas.LineTo(BShape.PositionX, BShape.PositionY);
      end;
    end;
  end;
end;

// *** Aktualisierungen je Durchlauf***
procedure TMovePlate.ApplicationEvents1Idle(Sender: TObject; var Done: Boolean);
var
  I: Integer;
  AShape: TAgent;
  distMouse : integer;
  Area: Trect;
begin
  done := false;
  // new position for each shape of the list
  for I := 0 to ShapesList.Count - 1 do
  begin
    AShape := ShapesList.Items [I];
    distMouse := distance (AShape.PositionX, AShape.PositionY, MouseX, MouseY);
    if (distMouse < Mouse_Rad)
      then begin
        AShape.FStepX := Dir * round ((AShape.PositionX - MouseX) * 0.1); //AShape.FStepX * -3;
        AShape.FStepY := Dir * round ((AShape.PositionY - MouseY) * 0.1); //AShape.FStepY * -3;
      end
      else begin
        // --- BewegungsVektor ver�ndern
        AShape.StepX := AShape.FStepX + (random(3) - 1) * 0.11;
        AShape.StepY := AShape.FStepY + (random(3) - 1) * 0.11;
      end;
    // --- Rand nicht �berschreiten
    if AShape.PositionX < TOP_BORDER then
      AShape.StepX := - AShape.StepX;
    if AShape.PositionX > RIGHT_BORDER then
      AShape.StepX := - AShape.StepX;
    if AShape.PositionY < TOP_BORDER then
      AShape.StepY := - AShape.StepY;
    if AShape.PositionY > BOTTOM_BORDER then
      AShape.StepY := - AShape.StepY;
    AShape.PositionX := AShape.FPositionX + round(AShape.FStepX);
    AShape.PositionY := AShape.FPositionY + round(AShape.FStepY);
  end;
  // --- berechnen, zeichnen und verbinden
  If (CheckB_Zellen.State = cbChecked) then
  begin
    lookCell (Backpuffer.Canvas);
    cellStates (Backpuffer.Canvas);
  end;
  RectanglPaint (Backpuffer.Canvas);
  If (CheckB_Verbind.State = cbChecked) then
    Connect (Backpuffer.Canvas);

  CommonPaint (Backpuffer.Canvas);
  /// --- Bild aktualisieren ---
  //BitBlt(Backpuffer.Canvas.Handle, bildleft, bildtop, Bild.Width, Bild.Height, Bild.canvas.handle, 0, 0, SRCCOPY);//Bild auf Backpuffer kopieren
  ImagePaint.Invalidate;
  BitBlt(ImagePaint.Canvas.Handle, 0, 0, Backpuffer.Width, Backpuffer.Height, Backpuffer.canvas.handle, 0, 0, SRCCOPY);//Backpuffer auf das Formular kopieren
end;

procedure TMovePlate.ImagePaintMouseMove(Sender: TObject; Shift: TShiftState; X,
  Y: Integer);
begin
  MouseX := X;
  MouseY := Y;
end;

procedure TMovePlate.ScrollBar1Change(Sender: TObject);
begin
    Mouse_Rad := ScrollBar1.Position;
    Label_Radius.Caption := IntToStr(Mouse_Rad);
end;

procedure TMovePlate.Button2MouseUp(Sender: TObject; Button: TMouseButton;
  Shift: TShiftState; X, Y: Integer);
begin
  Dir := Dir * (-1);
end;

// *** Array und Liste L�schen***
procedure TMovePlate.FormDestroy(Sender: TObject);
var
  I: Integer;
  J: Integer;
  K: Integer;
begin
  // --- delete each agent
  for I := ShapesList.Count - 1 downto 0 do
    TBaseShape (ShapesList [I]).Free;
  ShapesList.Free;
  // --- delete each cell
  for J := reih -1 downto 0 do
  begin
    for K := spalt -1 downto 0 do
    begin
      TBaseShape (cellList[J,K]).Free;
    end;
  end;
end;

// *** Initialisiert die Agenten ***
procedure TMovePlate.Button_CreateClick(Sender: TObject);
var
  I: Integer;
begin
  // set the style and colors
  for I := 1 to NUM_BALLS do
  begin
    CurrShape := TAgent.Create;
    CurrShape.PositionX := random (800);
    CurrShape.PositionY := 250 + random (50);
    CurrShape.StepX := (random(3) - 1);
    CurrShape.StepY := (random(3) - 1);
    CurrShape.Size := 3;
    CurrShape.FillColor := clRed;
    // add to the list
    ShapesList.Add (CurrShape);
  end ;
  CommonPaint (ImagePaint.Canvas);
  Label2.Caption := IntToStr(ShapesList.Count);
end;

// *** Agenten l�schen ***
procedure TMovePlate.Button_DeleteClick(Sender: TObject);
begin
ShapesList.Count := ShapesList.Count - 100;
  Label2.Caption := IntToStr(ShapesList.Count);
end;

end.

program FACS;

uses
  Forms,
  facsSteer in 'facsSteer.pas' {MovePlate},
  agenten in 'agenten.pas';

{$R *.res}

begin
  Application.Initialize;
  Application.CreateForm(TMovePlate, MovePlate);
  Application.Run;
end.

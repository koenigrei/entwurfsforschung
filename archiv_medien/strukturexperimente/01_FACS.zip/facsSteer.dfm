object MovePlate: TMovePlate
  Left = 0
  Top = 0
  Width = 840
  Height = 768
  Caption = 'MovePlate'
  Color = clSilver
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -13
  Font.Name = 'Tahoma'
  Font.Style = []
  OldCreateOrder = False
  OnCreate = FormCreate
  OnDestroy = FormDestroy
  PixelsPerInch = 120
  TextHeight = 16
  object ImagePaint: TImage
    Left = 10
    Top = 10
    Width = 800
    Height = 600
    OnMouseMove = ImagePaintMouseMove
  end
  object Label1: TLabel
    Left = 8
    Top = 624
    Width = 124
    Height = 16
    Caption = 'Anzahl Knotenpunkte:'
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clWhite
    Font.Height = -13
    Font.Name = 'Tahoma'
    Font.Style = []
    ParentFont = False
  end
  object Label2: TLabel
    Left = 144
    Top = 624
    Width = 28
    Height = 16
    Caption = '0000'
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clWhite
    Font.Height = -13
    Font.Name = 'Tahoma'
    Font.Style = []
    ParentFont = False
  end
  object Label3: TLabel
    Left = 560
    Top = 630
    Width = 73
    Height = 16
    Caption = 'MausRadius:'
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clWhite
    Font.Height = -13
    Font.Name = 'Tahoma'
    Font.Style = []
    ParentFont = False
  end
  object Label_Radius: TLabel
    Left = 640
    Top = 630
    Width = 28
    Height = 16
    Caption = '____'
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clWhite
    Font.Height = -13
    Font.Name = 'Tahoma'
    Font.Style = []
    ParentFont = False
  end
  object ScrollBar1: TScrollBar
    Left = 672
    Top = 625
    Width = 129
    Height = 20
    Max = 200
    Min = 5
    PageSize = 0
    Position = 50
    TabOrder = 0
    OnChange = ScrollBar1Change
  end
  object Button_Delete: TButton
    Left = 288
    Top = 625
    Width = 91
    Height = 20
    Caption = 'Delete 100 Pts'
    TabOrder = 1
    OnClick = Button_DeleteClick
  end
  object Button2: TButton
    Left = 672
    Top = 657
    Width = 89
    Height = 20
    Caption = 'Attract/Repel'
    TabOrder = 2
    OnMouseUp = Button2MouseUp
  end
  object CheckB_Zellen: TCheckBox
    Left = 8
    Top = 656
    Width = 129
    Height = 17
    Caption = 'Zellen markieren'
    Checked = True
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clWhite
    Font.Height = -13
    Font.Name = 'Tahoma'
    Font.Style = []
    ParentFont = False
    State = cbChecked
    TabOrder = 3
  end
  object CheckB_Verbind: TCheckBox
    Left = 8
    Top = 688
    Width = 129
    Height = 17
    Caption = 'Verbindungslinien'
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clWhite
    Font.Height = -13
    Font.Name = 'Tahoma'
    Font.Style = []
    ParentFont = False
    TabOrder = 4
  end
  object Button_Create: TButton
    Left = 192
    Top = 625
    Width = 91
    Height = 20
    Caption = 'Create Pts'
    TabOrder = 5
    OnClick = Button_CreateClick
  end
  object ApplicationEvents1: TApplicationEvents
    OnIdle = ApplicationEvents1Idle
    Left = 120
    Top = 72
  end
end

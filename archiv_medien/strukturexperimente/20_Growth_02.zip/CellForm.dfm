object Form1: TForm1
  Left = 0
  Top = 0
  Width = 608
  Height = 458
  Caption = 'growth with moore neighborhood'
  Color = clBtnFace
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -10
  Font.Name = 'Tahoma'
  Font.Style = []
  OldCreateOrder = False
  OnCreate = FormCreate
  OnDestroy = FormDestroy
  PixelsPerInch = 96
  TextHeight = 12
  object lbl_Steps: TLabel
    Left = 462
    Top = 48
    Width = 39
    Height = 12
    Alignment = taRightJustify
    Caption = 'lbl_Steps'
  end
  object lbl_timesteps: TLabel
    Left = 512
    Top = 48
    Width = 47
    Height = 12
    Caption = ': timesteps'
  end
  object Label2: TLabel
    Left = 512
    Top = 80
    Width = 55
    Height = 12
    Caption = ': alpha scale'
  end
  object ZeichenPanel: TPanel
    Left = 8
    Top = 9
    Width = 404
    Height = 404
    BorderStyle = bsSingle
    DockSite = True
    TabOrder = 0
  end
  object B_setup: TButton
    Left = 428
    Top = 8
    Width = 75
    Height = 25
    Caption = 'new setup'
    TabOrder = 1
    OnClick = B_setupClick
  end
  object Edit_alpha: TEdit
    Left = 460
    Top = 72
    Width = 41
    Height = 20
    TabOrder = 2
    Text = '1,9'
    OnChange = Edit_alphaChange
  end
  object B_start: TButton
    Left = 514
    Top = 8
    Width = 75
    Height = 25
    Caption = 're-start'
    TabOrder = 3
    OnClick = B_startClick
  end
  object Timer1: TTimer
    Interval = 500
    OnTimer = Timer1Timer
    Left = 560
    Top = 384
  end
end

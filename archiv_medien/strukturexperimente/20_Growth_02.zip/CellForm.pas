(********************************************************************)
(*                                                                  *) 
(*                                                                  *)
(*                       Zellul�rer Automat                         *)
(*                          Version 1.0                             *)
(*       Model for spatial averaging with Moore Neighborhood        *)
(*                                                                  *) 
(*     Programmierer: Reinhard K�nig                  December 2005 *)
(*                    http://www.entwurfsforschung.de/              *)
(*                                                                  *)
(*     Last Update: Dec-13, 2005                                    *)
(*                                                                  *)
(********************************************************************) 
{revision history:

1.0     [Nov-17, 2005]
        first release to the public
        growth and spatial redistribution through increasing returns to scale.
}

unit CellForm;

interface

uses
  Windows, Messages, SysUtils, Variants, Classes, Graphics, Controls, Forms,
  Dialogs, StdCtrls, Cell_P, node, ExtCtrls, ButtonGroup, ComCtrls, Math, ToolWin,
  ImgList;

type
  TForm1 = class(TForm)
    ZeichenPanel  : TPanel;
    Timer1        : TTimer;
    lbl_Steps     : TLabel;
    B_setup       : TButton;
    lbl_timesteps : TLabel;
    Label2        : TLabel;
    Edit_alpha    : TEdit;
    B_start       : TButton;
    procedure B_startClick(Sender: TObject);
    procedure Edit_alphaChange(Sender: TObject);
    procedure B_setupClick(Sender: TObject);
    procedure Timer1Timer(Sender: TObject);
    procedure FormDestroy(Sender: TObject);
    procedure FormCreate(Sender: TObject);
  private
    cellList     : Array of Array of TCell;
    limboWorld   : Array of Array of Real;
    function  CalcDistance(pAX: Integer; pAY: Integer; pBX: Integer; pBY: Integer): Integer;
    procedure RasterCreate;
    procedure setup;
    procedure createPaintImg;
    procedure checkNei (K, I: Integer);
  public

  end;

var
  Form1: TForm1;
  paintImg : TImage;
  steps: Integer;

implementation

{$R *.dfm}

const                      //-- globale Konstanten
  cellScal  = 20;          //-- Zellen gr��e

var                        //-- globale Variablen
  reih        : Integer;   //-- Zellen-Reihen gesamt
  spalt       : Integer;   //-- Zellen-Spalten gesamt

// ---------------------------------------------------------------------------//
// *** Initialisierung ***
procedure TForm1.FormCreate(Sender: TObject);
begin
  spalt          := round (ZeichenPanel.Width / cellScal);
  reih           := round (ZeichenPanel.Height / cellScal);
  SetLength(cellList, spalt, reih);
  SetLength(limboWorld, spalt, reih);
  createPaintImg;
  RasterCreate;
  ZeichenPanel.DoubleBuffered := True;       //-- Verhindert Flackern der Zellen
  steps := 0;
end;

// ---------------------------------------------------------------------------//
// ---------------------------------------------------------------------------//
// *** Erstellt das Raster ***
procedure TForm1.RasterCreate;
var
  curCell : TCell;
  size    : Integer;
  I       : Integer;
  K       : Integer;
begin
  size := round(cellScal/2);
  Randomize();
  for I := 0 to reih -1 do
  begin
    for K := 0 to spalt -1 do
    begin
      curCell := TCell.Create(size + K * cellScal, size + I * cellScal, size, 0);
      cellList[K,I] := curCell;
      curCell.SetState(random()); //(random(200));
      curCell.colr := round (255 * curCell.state); //-- Farbe in Abh. des H�chstwerts
      curCell.Paint(paintImg.Canvas);
    end;
  end;
end;

procedure TForm1.setup;
var
  curCell : TCell;
  I       : Integer;
  K       : Integer;
begin
  Randomize();
  for I := 0 to reih -1 do
  begin
    for K := 0 to spalt -1 do
    begin
      curCell := cellList[K,I];
      curCell.SetState(random()); //(random(200));
      curCell.colr := round (255 * curCell.state); //-- Farbe in Abh. des H�chstwerts
      curCell.Paint(paintImg.Canvas);
    end;
  end;
end;

// *** Legt eine leere Zeichenfl�che �ber das Zeichenpanel ***
procedure TForm1.createPaintImg;
begin
  paintImg := TImage.Create(self);
  paintImg.Parent  := ZeichenPanel;
  paintImg.top        := 0;
  paintImg.Left       := 0;
  paintImg.Height     := ZeichenPanel.Height;
  paintImg.Width      := ZeichenPanel.Width;
end;

procedure TForm1.checkNei (K, I: Integer);
var
  u  : Integer;
  v  : Integer;
  Xp : Integer;
  Yp : Integer;
begin
  // --- Summe berechnen ---
  for u := -1 to 1 do
  begin
    for v := -1 to 1 do
    begin
      Xp := K + v;
      Yp := I + u;
      // -- Torus --
      if Xp < 0       then Xp := reih-1;
      if Xp > spalt-1 then Xp := 0;
      if Yp < 0       then Yp := spalt-1;
      if Yp > reih-1  then Yp := 0;
      limboWorld[K, I] := limboWorld[K, I] + cellList[Xp, Yp].state;
    end;
  end;
end;

procedure TForm1.Timer1Timer(Sender: TObject);
var
  curCell : TCell;
  I       : Integer;
  K       : Integer;
  Pt      : Integer;
  Pges    : Real;
  maxP    : Real;
  alpha   : real;
  mK      : Array [0..1] of Integer;
begin
  Pges := 0;
  maxP := 0;
  for I := 0 to reih -1 do
  begin
    for K := 0 to spalt -1 do
    begin
      limboWorld[K, I] := 0;
      checkNei(K, I);        // -- Nachbarschaftswerte in limboWorld zusammenz�hlen
      Pges := Pges + limboWorld[K, I];
    end;
  end;
  Pges := Pges / (reih * spalt);

  for I := 0 to reih -1 do
  begin
    for K := 0 to spalt -1 do
    begin
      curCell := cellList[K, I];
      curCell.maxP := false;

      //-- Growth - function
      alpha := StrToFloat(Edit_alpha.Text);
      curCell.State := Power((limboWorld[K, I] / 9), alpha);

      //-- Maximalwert und zugeh�rige Zelle ermitteln --
      if abs(curCell.State) > abs(maxP) then begin
        maxP := curCell.State;
        mK[0] := K;
        mK[1] := I;
      end;
    end;
  end;
  
  If maxP = 0 then begin  // -- Stop wenn alles 0
    Timer1.enabled := false;
    exit;
  end;
  cellList[mk[0], mk[1]].maxP := true; // -- Zelle mit Maximalwert markieren

  for I := 0 to reih -1 do   //-- Schleife kann gespart werden! nur wegen maximalWert Markierung notwendig
  begin
    for K := 0 to spalt -1 do
    begin
      curCell := cellList[K, I];
      // --- Farbe bestimmen und zeichen ---
      curCell.colr := round ((255 / maxP) * curCell.state); //-- Farbe in Abh. des H�chstwerts
      curCell.Paint(paintImg.Canvas);
    end;
  end;
  steps := steps +1;
  lbl_Steps.Caption := intToStr (steps);
end;

function TForm1.CalcDistance(pAX: Integer; pAY: Integer; pBX: Integer; pBY: Integer): Integer;
var
  temp : double;
begin
  temp := sqrt(Power((pAX - pBX), 2) + Power((pAY - pBY), 2));
  Result := Round(temp);
end;

procedure TForm1.FormDestroy(Sender: TObject);
begin
  paintImg.Free;
  ZeichenPanel.Free;
end;

procedure TForm1.B_setupClick(Sender: TObject);
begin
  setup;
  steps := 0;
end;

procedure TForm1.Edit_alphaChange(Sender: TObject);
begin
  Timer1.enabled := false;
end;

procedure TForm1.B_startClick(Sender: TObject);
begin
  Timer1.enabled := true;
end;

end.

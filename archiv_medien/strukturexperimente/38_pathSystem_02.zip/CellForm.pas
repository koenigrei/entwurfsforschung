(********************************************************************)
(*                                                                  *) 
(*                                                                  *)
(*                         Path System 02                              *)
(*                          Version 1.0                             *)
(*                                                                  *)
(*                                                                  *)
(*     Programmierer: Reinhard K�nig                     April 2006 *)
(*                    http://www.entwurfsforschung.de               *)
(*                                                                  *)
(*     Last Update: Apr-16, 2006                                    *)
(*                                                                  *)
(********************************************************************) 
{revision history:

1.0     [Apr-16, 2006]
        first release to the public
}

unit CellForm;

interface

uses
  Windows, Messages, SysUtils, Variants, Classes, Graphics, Controls, Forms,
  Dialogs, StdCtrls, cell_P, ExtCtrls, ButtonGroup, ComCtrls, Math, ToolWin,
  ImgList, Epina.SDL.rchart, agenten, CategoryButtons;

type
  TForm1 = class(TForm)
    ZeichenPanel   : TPanel;
    Timer1         : TTimer;
    RChart1        : TRChart;
    Lbl_B          : TLabel;
    Label1         : TLabel;
    TrB_thresh     : TScrollBar;
    Lbl_wiggle     : TLabel;
    Label3         : TLabel;
    SB_wiggle      : TScrollBar;
    RadioGroup1    : TRadioGroup;
    rb_rulette     : TRadioButton;
    GroupBox1      : TGroupBox;
    B_setup        : TButton;
    B_stop         : TButton;
    B_oneStep      : TButton;
    CB_mCent       : TCheckBox;
    Edit_anzAg     : TEdit;
    Lbl_TextAnzahl : TLabel;
    Edit_size      : TEdit;
    Label2         : TLabel;
    rb_hill        : TRadioButton;
    GroupBox2      : TGroupBox;
    lbl_Steps      : TLabel;
    CB_diffuse     : TCheckBox;
    Lbl_strenght   : TLabel;
    Label5         : TLabel;
    SB_strenght    : TScrollBar;
    Lbl_evapo      : TLabel;
    Label6         : TLabel;
    SB_evapo       : TScrollBar;
    Lbl_sniff      : TLabel;
    Label7         : TLabel;
    SB_sniff       : TScrollBar;
    Lbl_visible    : TLabel;
    Label8         : TLabel;
    SB_visible     : TScrollBar;
    procedure SB_visibleChange     (Sender: TObject);
    procedure SB_sniffChange       (Sender: TObject);
    procedure SB_evapoChange       (Sender: TObject);
    procedure SB_strenghtChange    (Sender: TObject);
    procedure ZeichenPanelMouseUp  (Sender: TObject; Button: TMouseButton;
                                    Shift: TShiftState; X, Y: Integer);
    procedure ZeichenPanelMouseMove(Sender: TObject; Shift: TShiftState; X, Y: Integer);
    procedure ZeichenPanelMouseDown(Sender: TObject; Button: TMouseButton;
                                    Shift: TShiftState; X, Y: Integer);
    procedure Edit_sizeChange  (Sender: TObject);
    procedure SB_wiggleChange  (Sender: TObject);
    procedure B_oneStepClick   (Sender: TObject);
    procedure TrB_threshChange (Sender: TObject);
    procedure B_stopClick      (Sender: TObject);
    procedure B_setupClick     (Sender: TObject);
    procedure Timer1Timer      (Sender: TObject);
    procedure FormDestroy      (Sender: TObject);
    procedure FormCreate       (Sender: TObject);
  private
    AgentList    : TList;
    cellList     : Array of Array of TCell;
    limboWorld   : Array of Array of Extended;
    function  CalcDistance  (pAX: Integer; pAY: Integer; pBX: Integer; pBY: Integer): Integer;
    procedure torus         (var Xp: Integer; var Yp: Integer);
    procedure createPaintImg;
    procedure createRaster;
    procedure createAgents;
    procedure SetupCells    (market: Array of TPoint);
    procedure SetupAgents   (market: Array of TPoint);
    procedure calcAgents;
    procedure repaintAll;
    procedure checkArea     (I : Integer);
    procedure angelBorder   (var angle : Real);
    procedure calculate;
    procedure settings;
    procedure deleter;
    procedure markCell      (X, Y: Integer);
    procedure plot          (value1: Integer);
    procedure resetGraph;
    procedure checkNei      (K, I: Integer);
    procedure diffuse;
    procedure oneCentre;
    procedure multiCentre   (market: Array of TPoint);
    procedure SetupSource;
  public
end;

var
  Form1    : TForm1;
  paintImg : TImage;
  agentImg : TImage;

implementation

{$R *.dfm}

const                          //-- globale Konstanten
  Pi     = 3.141592654;
  AgSize = 2;                  //-- Agenten gr��e
  //
var                            //-- globale Variablen
  reih     : Integer;          //-- Zellen-Reihen gesamt
  spalt    : Integer;          //-- Zellen-Spalten gesamt
  steps    : Integer;
  Xmax     : Integer;
  Ymax     : Integer;
  cellSum  : Integer;
  OldY1    : Double;           //-- Speichert die Position t-1 f�r Graphen
  //OldY2    : Double;         //-- Speichert die Position t-1 f�r Graphen
  cellScal : Integer;          //-- Zellen  gr��e
  halfScal : Integer;
  rDown    : Boolean;
  lDown    : Boolean;

// ---------------------------------------------------------------------------//
// *** Initialisierung *********************************************************
procedure TForm1.FormCreate(Sender: TObject);
begin
  settings;
  Lbl_B.Caption        := IntToStr(TrB_thresh.Position) + ' Grad';
  Lbl_wiggle.Caption   := IntToStr(SB_wiggle.Position)  + ' Grad';
  Lbl_strenght.Caption := IntToStr(SB_strenght.Position);
  Lbl_evapo.Caption    := FloatToStr(SB_evapo.Position/100);
  Lbl_sniff.Caption    := FloatToStr(SB_sniff.Position);
  Lbl_visible.Caption  := FloatToStr(SB_visible.Position);
end;

// *** Settings ****************************************************************
procedure TForm1.settings;
var
  I : Integer;
  market  : Array [0..9] of TPoint;
begin
  cellScal  := StrToInt(Edit_size.Text) ;
  halfScal  := round(cellScal/2);
  spalt     := round (ZeichenPanel.Width / cellScal);
  reih      := round (ZeichenPanel.Height / cellScal);
  Xmax      := (spalt) * cellScal;
  Ymax      := (reih ) * cellScal;
  for I := 0 to 9 do
  begin
    market[I].X := random(spalt);
    market[I].Y := random(reih);
  end;
  AgentList := TList.Create;
  SetLength(cellList, spalt, reih);
  SetLength(limboWorld, spalt, reih);
  createPaintImg;
  CreateRaster;
  SetupCells(market);
  SetupSource;
  CreateAgents;
  SetupAgents(market);
  ZeichenPanel.Enabled := true;
  ZeichenPanel.DoubleBuffered := True;       //-- Verhindert Flackern der Zellen
  steps := 0;
  rDown := false;
  lDown := false;
  resetGraph;                                //-- Diagramm initialisieren
end;
// ---------------------------------------------------------------------------//
// ------------------------- Elemente erstellen ------------------------------//
// ---------------------------------------------------------------------------//

// *** Legt eine leere Zeichenfl�che �ber das Zeichenpanel *********************
procedure TForm1.createPaintImg;
begin
  paintImg        := TImage.Create(self);
  paintImg.Parent := ZeichenPanel;
  paintImg.top    := 0;
  paintImg.Left   := 0;
  paintImg.Height := ZeichenPanel.Height;
  paintImg.Width  := ZeichenPanel.Width;
  paintImg.Enabled:= False;               // -- does not reakt on mouseEvents

  agentImg        := TImage.Create(self);
  agentImg.Parent := ZeichenPanel;
  agentImg.top    := 0;
  agentImg.Left   := 0;
  agentImg.Height := ZeichenPanel.Height;
  agentImg.Width  := ZeichenPanel.Width;
  agentImg.Transparent := true;
  agentImg.Enabled:= False;
end;

// *** Agenten erstellen *******************************************************
procedure TForm1.CreateAgents;
var
  I        : Integer;
  curAgent : TAgent;
begin
  for I := 1 to StrToInt(Edit_anzAg.Text) do //   StrToInt(Edi_NrRed.Text) Do
  begin
    curAgent := TAgent.Create;
    AgentList.Add (curAgent);     // ---  add to the list
  end;
end;

// *** Agenten initialisieren **************************************************
procedure TForm1.SetupAgents(market: Array of TPoint);
var
  curAgent : TAgent;
  I , M    : Integer;
  val      : Integer;
begin
  Randomize();
  If CB_mCent.Checked = true Then val := 1 Else val := 0;
  for I := 0 to AgentList.Count - 1 do
  begin
    M := round(I mod 10);//random(10);
    curAgent := AgentList.Items [I];
    curAgent.Home.X   := market[M].X;
    curAgent.Home.Y   := market[M].Y;
    curAgent.onCell.X := market[M].X; //random (spalt);
    curAgent.onCell.Y := market[M].Y; // random (reih);
    curAgent.PosX     := curAgent.onCell.X * cellScal + halfScal;
    curAgent.PosY     := curAgent.onCell.Y * cellScal + halfScal;
    curAgent.Size     := AgSize;
    curAgent.State    := val;
    curAgent.Stopped  := false;
    curAgent.Seeking  := true;
    curAgent.Heading  := random (360);
    curAgent.centr.X  := round(spalt/2);
    curAgent.centr.Y  := round(reih/2);
    curAgent.Paint   (agentImg.Canvas);

  end;
end;

// *** Zellen erstellen ********************************************************
procedure TForm1.CreateRaster;
var
  curCell : TCell;
  I       : Integer;
  K       : Integer;
begin
  for I := 0 to reih -1 do
  begin
    for K := 0 to spalt -1 do
    begin
      curCell := TCell.Create(halfScal + K * cellScal, halfScal + I * cellScal, halfScal, 0);
      cellList[K,I] := curCell;
    end;
  end;
end;

procedure TForm1.SetupSource;
var
  K, I, U, V : Integer;
begin
  K := round(spalt/2);
  I := round(reih/2);
  For U := -2 to 2 do
  begin
    For V := -2 to 2 do
    begin
      cellList[K+V ,I+U].source := true;
      cellList[K+V ,I+U].mark   := 10;
    end;
  end;
end;

// *** Zellen initialisieren ***************************************************
procedure TForm1.SetupCells(market: Array of TPoint);
begin
  OldY1   := 0;                          // -- Ausgangswert t=0 f�r Graphen
  cellSum := spalt * reih;
  Randomize();
  {If CB_mCent.State = cbUnchecked then   // -- calculate the distance to one or multi center
  begin
    oneCentre;
  end else begin}
    multiCentre(market);
  //end;
end;

// *** setup cells with several centres across the field ***********************
procedure TForm1.multiCentre (market: Array of TPoint);
var
  curCell : TCell;
  I, K, M : Integer;
begin
  for I := 0 to reih -1 do
  begin
    for K := 0 to spalt -1 do
    begin
      curCell         := cellList[K,I];
      curCell.besetzt := false;
      curCell.colr    := 255;
      curCell.mark    := 1;
      curCell.oldMark := 100;
      curCell.cent    := false;
      curCell.source  := false;
      curCell.Dist    := 10000;
      curCell.indM    := 0;
      for M := 0 to 9 do
      begin
        curCell.distM[M] := calcDistance(K, I, market[M].X, market[M].Y);// -- distance to center for every cell
        If curCell.distM[M] < curCell.Dist then
        begin
          curCell.Dist := curCell.distM[M];
          curCell.indM := M;
          curCell.mark := 10;
        end;
      end;
      curCell.Paint(paintImg.Canvas, 0);
    end;
  end;
  // -- mark the centerCells --
  for I := 0 to 9 do
  begin
    cellList[market[I].X,market[I].Y].cent := true;
    cellList[market[I].X,market[I].Y].Paint(paintImg.Canvas, 0);
  end;
end;

// *** setup cells with one centre in the middle *******************************
procedure TForm1.oneCentre;
var
  curCell : TCell;
  I, K    : Integer;
begin
  Randomize();
  // -- calculate the distance to the center --
  for I := 0 to reih -1 do
  begin
    for K := 0 to spalt -1 do
    begin
      curCell         := cellList[K,I];
      curCell.besetzt := false;
      curCell.colr    := 255;
      curCell.mark    := 1;
      curCell.oldMark := 100;
      curCell.Dist    := calcDistance(curCell.FPos.X,curCell.FPos.Y, // -- distance to center for every cell
                                      cellList[round(spalt/2),round(reih/2)].Fpos.X,
                                      cellList[round(spalt/2),round(reih/2)].Fpos.Y);
      curCell.Paint(paintImg.Canvas, 0);
    end;
  end;
  cellList[round(spalt/2),round(reih/2)].cent := true;
  cellList[round(spalt/2),round(reih/2)].Paint(paintImg.Canvas, 0);
end;

// ###########################################################################//
// ---------------------------- Berechnungen ---------------------------------//
// ###########################################################################//

// *** TIMER - Rekursive Befehle ausf�hren *************************************
procedure TForm1.Timer1Timer(Sender: TObject);
begin
  calculate;
end;

// *** the main procedures *****************************************************
procedure TForm1.calculate;
begin
  repaintAll;

  calcAgents; // -- ver�ndert die Position der Agenten

  If CB_diffuse.Checked = true Then diffuse;

  steps := steps +1;
  lbl_Steps.Caption := intToStr (steps);
end;

// *** diffuse the mark-values *************************************************
procedure TForm1.diffuse;
var
  curCell  : TCell;
  I, K     : Integer;
  evapo    : Real;
begin
  for I := 0 to reih -1 do
  begin
    for K := 0 to spalt -1 do
    begin
      checkNei (K, I);
    end;
  end;
  evapo := 1 - StrToFloat(Lbl_evapo.Caption);
  for I := 0 to reih -1 do
  begin
    for K := 0 to spalt -1 do
    begin
      curCell := cellList[K,I];
      curCell.mark := round(limboWorld[K, I]/8);
      curCell.mark := round(curCell.mark *evapo);
      If curCell.mark < 1 Then curCell.mark := 1;
    end;
  end;
end;

// *** check the moore-neighbourhood *******************************************
procedure TForm1.checkNei (K, I: Integer);
var
  u, v   : Integer;
  Xp, Yp : Integer;
begin
  // --- Summe berechnen ---
  limboWorld[K, I] := 0;
  for u := -1 to 1 do
  begin
    for v := -1 to 1 do
    begin
      Xp := K + v;
      Yp := I + u;
      torus(Xp, Yp);  // -- Torus
      limboWorld[K, I] := limboWorld[K, I] + cellList[Xp, Yp].mark;
    end;
  end;
  limboWorld[K, I] := limboWorld[K, I] - cellList[K, I].mark;
end;

// *** plot value **************************************************************
procedure TForm1.plot(value1: Integer);
begin
  if steps mod 999 = 0 then begin                      // -- Plotten bis maximum
    resetGraph;
  end;
  If (value1+50) > RChart1.Scale1Y.RangeHigh Then RChart1.Scale1Y.RangeHigh := value1 + 100;
  RChart1.ActiveLayer:= 1;
  RChart1.DataColor := clRed;
  RChart1.Line(Steps-1, OldY1, Steps, value1);
  OldY1 := value1;
end;

// *** reset the plot-graph ****************************************************
procedure TForm1.resetGraph;
begin
  RChart1.ClearGraf;
  RChart1.MoveTo (0,0);
  RChart1.Scale1Y.RangeLow  := 0;
  RChart1.Scale1Y.RangeHigh := 100;
  RChart1.Scale1X.RangeLow  := steps;
  RChart1.Scale1X.RangeHigh := steps + 1000;
end;

// *** paint the cells and agents **********************************************
procedure TForm1.repaintAll;
var
  curAgent : TAgent;
  curCell  : TCell;
  I, K     : Integer;
  sumM     : Integer;
  evapo    : Integer;
  visiTh   : Integer;
begin
  agentImg.Canvas.brush.Color := clWhite;
  agentImg.Canvas.pen.Color   := clWhite;
  agentImg.Canvas.Rectangle(0,0,ZeichenPanel.Height,ZeichenPanel.Width);
  sumM  := 0;
  evapo := round(StrToFloat(Lbl_evapo.Caption)*10);
  visiTh:= StrToInt(Lbl_visible.Caption);
  // --- repaint the cells ---
  for I := 0 to reih -1 do
  begin
    for K := 0 to spalt -1 do
    begin
      curCell := cellList[K,I];
      If curCell.mark > (evapo+2) Then begin
        If CB_diffuse.Checked = false Then curCell.mark := curCell.mark - evapo;
        If curCell.mark > visiTh Then inc(sumM);
        //If curCell.mark > 255 Then  curCell.mark := 255;
      end;
      curCell.Paint (paintImg.Canvas, visiTh);
    end;
  end;
  plot(sumM);
  // --- repaint the agents ---
  for I := 0 to AgentList.Count - 1 do
  begin
    curAgent := AgentList.Items [I];
    curAgent.Paint (agentImg.Canvas);
  end;
end;

// *****************************************************************************
// *** look at the cells in the neigbourhood defined by the horizon-parameter **
// *****************************************************************************
procedure TForm1.checkArea (I : Integer);
var
  curCell  : TCell;
  curAgent : TAgent;
  M        : Integer;
  Angle    : Array [0..1] of Real;
  horizon  : Integer;
  neib     : TPoint;
  comper   : Real;
  wList    : Array of Integer;
  wSum     : Integer;
  tmP      : TPoint;
  fromTo   : Array [0..1] of Integer;
  curNr    : Integer;
begin
  horizon := TrB_thresh.Position;
  curAgent := AgentList.Items [I];
  Angle[0] := curAgent.Heading - horizon - 22.5;     // -- minAngle
  Angle[1] := curAgent.Heading + horizon - 22.5;     // -- maxAngle
  angelBorder (Angle[0]);
  angelBorder (Angle[1]);
  //-- find the cells to look at
  SetLength(curAgent.lookToList, 0);

  for M := 0 to 1 do
  begin
    comper   := Angle[M];
    case round(comper) of           // find start and end cell in the (cell)field
      0..45:    fromTo[M] := 1;
      46..90:   fromTo[M] := 2;
      91..135:  fromTo[M] := 3;
      136..180: fromTo[M] := 4;
      181..225: fromTo[M] := 5;
      226..270: fromTo[M] := 6;
      271..315: fromTo[M] := 7;
      316..360: fromTo[M] := 8;
    end;
  end;

  curNr := fromTo[0] -1;
  repeat
  inc(curNr);
  If curNr > 8 Then curNr := 1;
    case curNr of                   // set the direction to the cell-positions
      1: begin neib.X := 1;  neib.Y := 1;  end;
      2: begin neib.X := 0;  neib.Y := 1;  end;
      3: begin neib.X := -1; neib.Y := 1;  end;
      4: begin neib.X := -1; neib.Y := 0;  end;
      5: begin neib.X := -1; neib.Y := -1; end;
      6: begin neib.X := 0;  neib.Y := -1; end;
      7: begin neib.X := 1;  neib.Y := -1; end;
      8: begin neib.X := 1;  neib.Y := 0;  end;
    end;
    SetLength(curAgent.lookToList, length(curAgent.lookToList) + 1);
    curAgent.lookToList[High(curAgent.lookToList)] := neib;
  until curNr = fromTo[1];

  SetLength(wList, length(curAgent.lookToList));
  wSum := 0;
  curAgent.sumChem := 0;
  For M := 0 To High(curAgent.lookToList) Do
  begin
    tmP.X := curAgent.onCell.X + curAgent.lookToList[M].X;
    tmP.Y := curAgent.onCell.Y + curAgent.lookToList[M].Y;
    torus (tmP.X, tmP.Y);
    curCell := cellList[tmP.X, tmP.Y];
    curAgent.sumChem := curAgent.sumChem + curCell.mark;
    wSum := wSum + curCell.mark;
    wList[M] := curCell.mark;
  end;

  SetLength(curAgent.weightList, 0);
  SetLength(curAgent.weightList, length(curAgent.lookToList));
  For M := 0 To High(curAgent.lookToList) Do
  begin
    If wSum > 0 Then begin
      curAgent.weightList[M] := wList[M]/wSum * 100;
    end else begin
      curAgent.weightList[M] := 0;
    end;
  end;
end;

// *****************************************************************************
// *** Ver�ndert die Position der Agenten **************************************
// *****************************************************************************
procedure TForm1.calcAgents;
var
  curCell  : TCell;
  curAgent : TAgent;
  I        : Integer;
  tempPos  : TPoint;
  horizon  : Integer;
  wiggle   : Integer;
  method   : Integer;
  markStr  : Integer;
  sniffTh  : Integer;
begin
  markStr := StrToInt(Lbl_strenght.Caption);
  sniffTh := StrToInt(Lbl_sniff.Caption);
  horizon := TrB_thresh.Position;
  wiggle  := SB_wiggle.Position;
  method  := 0;
  If rb_rulette.Checked = true Then begin method := 1; end
  else begin If rb_hill.Checked = true Then method := 2; end;
  for I := 0 to AgentList.Count - 1 do
  begin
    curAgent := AgentList.Items [I];
    checkArea (I);
    curAgent.ChangeHeading(horizon, 1, wiggle, method, sniffTh);              // -- Richtungsspektrum und Distanz
    tempPos.X := curAgent.onCell.X + curAgent.stepX;
    tempPos.Y := curAgent.onCell.Y + curAgent.stepY;
    torus (tempPos.X, tempPos.Y);                                             // -- Torus --
    curCell := cellList[tempPos.X, tempPos.Y];
    If curAgent.Seeking = false Then
    begin
      cellList[curAgent.onCell.X, curAgent.onCell.Y].mark := markStr + cellList[curAgent.onCell.X, curAgent.onCell.Y].mark;
    end else begin
      //cellList[curAgent.onCell.X, curAgent.onCell.Y].mark := round(markStr/10) + cellList[curAgent.onCell.X, curAgent.onCell.Y].mark;
    end;
    curAgent.onCell.X := tempPos.X;
    curAgent.onCell.Y := tempPos.Y;
    curAgent.PosX     := curAgent.onCell.X * cellScal + halfScal;             // -- Wenn Zelle frei, Agent bewegen ---
    curAgent.PosY     := curAgent.onCell.Y * cellScal + halfScal;
    curCell.State     := curAgent.State;
    curCell.AgNr      := I;                                                   // -- Agenten index in Zelle speichern
    If curCell.source = true Then curAgent.Seeking := false;
  end;
end;

// ---------------------------------------------------------------------------//
// -------------------------- Funktionen -------------------------------------//
// ---------------------------------------------------------------------------//
// *** Torusfunktion ***********************************************************
procedure TForm1.torus (var Xp: Integer; var Yp: Integer);
begin
  if Xp < 0     then begin
     Xp := spalt + Xp;
  end else
  if Xp > spalt-1  then begin
     Xp := 0 + (Xp - spalt) ;
  end;
  if Yp < 0     then begin
     Yp := reih + Yp;
  end else
  if Yp > reih-1  then begin
     Yp := 0 + (Yp - reih) ;
  end;
end;

// *** borders of the angle-value **********************************************
procedure TForm1.angelBorder (var angle : Real);
begin
  If angle < 0   Then angle := 360 + angle;
  If angle > 360 Then angle := angle -360;
end;

// *** Entferung berechnen *****************************************************
function TForm1.CalcDistance(pAX: Integer; pAY: Integer; pBX: Integer; pBY: Integer): Integer;
var
  temp : double;
begin
  temp := sqrt(Power((pAX - pBX), 2) + Power((pAY - pBY), 2));
  Result := Round(temp);
end;

// ---------------------------------------------------------------------------//
// ------------------------------- Schalter ----------------------------------//
// ---------------------------------------------------------------------------//
// *** buttons sliders and edit-fields *****************************************
procedure TForm1.B_setupClick(Sender: TObject);
begin
  deleter;
  settings;
end;

// *****************************************************************************
procedure TForm1.B_stopClick(Sender: TObject);
begin
  Timer1.enabled := not(Timer1.enabled);
end;

// *****************************************************************************
procedure TForm1.TrB_threshChange(Sender: TObject);
begin
  Lbl_B.Caption := IntToStr(TrB_thresh.Position) + ' Grad';
end;

// *****************************************************************************
procedure TForm1.SB_wiggleChange(Sender: TObject);
begin
  Lbl_wiggle.Caption := IntToStr(SB_wiggle.Position) + ' Grad';
end;

// *****************************************************************************
procedure TForm1.SB_strenghtChange(Sender: TObject);
begin
  Lbl_strenght.Caption := IntToStr(SB_strenght.Position);
end;

// *****************************************************************************
procedure TForm1.SB_evapoChange(Sender: TObject);
begin
  Lbl_evapo.Caption := FloatToStr(SB_evapo.Position/100);
end;

// *****************************************************************************
procedure TForm1.SB_sniffChange(Sender: TObject);
begin
  Lbl_sniff.Caption := FloatToStr(SB_sniff.Position);
end;

// *****************************************************************************
procedure TForm1.SB_visibleChange(Sender: TObject);
begin
  Lbl_visible.Caption := FloatToStr(SB_visible.Position);
end;

// *****************************************************************************
procedure TForm1.B_oneStepClick(Sender: TObject);
begin
  calculate;
end;

// *****************************************************************************
procedure TForm1.Edit_sizeChange(Sender: TObject);
begin
  If StrToInt(Edit_size.Text) > 10 Then Edit_size.Text := '10';
  If StrToInt(Edit_size.Text) < 1  Then Edit_size.Text := '1' ;
end;

// *****************************************************************************
// *** the mouse interactions **************************************************
// *****************************************************************************
procedure TForm1.ZeichenPanelMouseDown(Sender: TObject; Button: TMouseButton;
  Shift: TShiftState; X, Y: Integer);
begin
   If Button = mbRight then  rDown := true;
   If Button = mbLeft  then  lDown := true;
end;
// *****************************************************************************
procedure TForm1.ZeichenPanelMouseMove(Sender: TObject; Shift: TShiftState; X, Y: Integer);
begin
  If (rDown = true) or (lDown = true) Then
  begin
    markCell (X, Y);
  end;
end;
// *****************************************************************************
procedure TForm1.ZeichenPanelMouseUp(Sender: TObject; Button: TMouseButton;
  Shift: TShiftState; X, Y: Integer);
begin
  rDown := false;
  lDown := false;
end;
// *****************************************************************************
procedure TForm1.markCell (X, Y: Integer);
var
  curCell : TCell;
  cPos    : TPoint;
begin
  cPos.X  := round(X / cellScal);
  cPos.Y  := round(Y / cellScal);
  curCell := cellList[cPos.X, cPos.Y];
  If (lDown = true) Then
  begin
    curCell.mark := 255;
  end else
  If (rDown = true) Then
  begin
    curCell.mark := 1;
    curCell.Paint (paintImg.Canvas, 0);
  end;
end;
// *****************************************************************************
// *****************************************************************************
procedure TForm1.FormDestroy(Sender: TObject);
begin
  deleter;
  ZeichenPanel.Free;
end;

// *****************************************************************************
procedure TForm1.deleter;
begin
  steps := 0;
  AgentList.Free;
  paintImg.Free;
  agentImg.Free;
  SetLength(cellList, 0, 0);
  SetLength(limboWorld, 0, 0);
end;

end.

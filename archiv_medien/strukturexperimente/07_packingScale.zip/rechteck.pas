unit rechteck;

interface

uses
  Windows, Graphics;

type
  TBaseRecht = class
  private
    procedure SetBottom(const Value: Integer);
    procedure SetLeft(const Value: Integer);
    procedure SetRight(const Value: Integer);
    procedure SetTop(const Value: Integer);
    procedure SetPositionX(const Value: Integer);
    procedure SetPositionY(const Value: Integer);
    procedure SetFillColor(const Value: Integer);
    procedure Setcx(const Value: Integer);
    procedure Setcy(const Value: Integer);
  protected
    FRect: TRect;
    FSize: TSize;
  public
    FPositionX: Integer;
    FPositionY: Integer;
    FFillColor: Integer;
    FPassed   : Integer;
    rA        : TRect;
    procedure Paint (Canvas: TCanvas);
  published
    property PositionX: Integer read FPositionX write SetPositionX;
    property PositionY: Integer read FPositionY write SetPositionY;
    property FillColor: Integer read FFillColor write SetFillColor;
    property Left     : Integer write SetLeft;
    property Right    : Integer write SetRight;
    property Top      : Integer write SetTop;
    property Bottom   : Integer write SetBottom;
    property Rect     : TRect   read FRect;
    property cx       : Integer write Setcx;
    property cy       : Integer write Setcy;
    property Size     : TSize read FSize;
  end;

//------------------------------------------------------------------------------
implementation

procedure TBaseRecht.Setcx(const Value: Integer);
begin
  fSize.cx    := Value;
  //fRect.Left  := PositionX - Value;
  //fRect.Right := PositionX + Value;
end;

procedure TBaseRecht.Setcy(const Value: Integer);
begin
  fSize.cy     := Value;
  //fRect.Top    := PositionY - Value;
  //fRect.Bottom := PositionY + Value;
end;

procedure TBaseRecht.SetBottom(const Value: Integer);
begin
  fRect.Bottom := Value;
end;

procedure TBaseRecht.SetLeft(const Value: Integer);
begin
  fRect.Left := Value;
end;

procedure TBaseRecht.SetRight(const Value: Integer);
begin
  fRect.Right := Value;
end;

procedure TBaseRecht.SetTop(const Value: Integer);
begin
  fRect.Top := Value;
end;

procedure TBaseRecht.Paint (Canvas: TCanvas);
begin
  Canvas.Pen.Width := 1;
  Canvas.Pen.Color := clGreen;
  Canvas.Brush.Color := FFillColor;
  Canvas.Rectangle (rect.left , rect.top, rect.right, rect.bottom);
end;

procedure TBaseRecht.SetPositionX(const Value: Integer);
begin
  FPositionX := Value;
end;

procedure TBaseRecht.SetPositionY(const Value: Integer);
begin
  FPositionY := Value;
end;

procedure TBaseRecht.SetFillColor(const Value: Integer);
begin
  FFillColor := Value;
end;

end.

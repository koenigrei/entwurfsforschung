{*******************************************************************************
*********** Programm zur Berechnung dichter Packungen   ************************
*********** mittels evolution�rer Strategie             ************************
*********** Version 1.01                                 ************************
*********** von Reinhard K�nig                          ************************
********************************************************************************
N�chste Entwicklungsschritte:
    |System bleibt oft in lokalem Optimum h�ngen
    |=> Mehrere L�sungspfade verfolgen; Auswahl nach Fitness.
  + Verbessert auf 4 L�sungspfade
  - Feature f�r feste Raumabmessungen.
  - System folgt topologischer Vorgabe... -> Grundrissanforderung
    (dazu zus�tzlich Genetischer Algorithmus)
  - Ausgabef�nktion der Ergebnisse (bzw. Kombination mehrerer vershc. L�sungen)
    1. Als Vektordaten -> CAD
    2. Die Daten zur Kombination versch. L�sungen. (Gencode bzw. Phenotype Eigenschaften)
********************************************************************************
*******************************************************************************}

unit main;

interface

uses
  Windows, Messages, SysUtils, Variants, Classes, Graphics, Controls, Forms,
  Dialogs, ExtCtrls, StdCtrls, rechteck, VarCmplx, Math, SortThds, AppEvnts;

type
    ValueType = Longint; // --- Type used in the arrays at Selectionsort.
    IndexType = Longint; // --- Type used to index arrays at Selectionsort.
  TForm1 = class(TForm)
    ImagePaint          : TImage;
    Button_createRecht  : TButton;
    Button_delete       : TButton;
    Label_Mutate        : TLabel;
    Label_Ready         : TLabel;
    Label4              : TLabel;
    Label_Variation     : TLabel;
    Label1              : TLabel;
    Label_Numbers       : TLabel;
    Label_area          : TLabel;
    Label2              : TLabel;
    Label3              : TLabel;
    Label5              : TLabel;
    Label_Size          : TLabel;
    ScrollBar_Size      : TScrollBar;
    ScrollBar_Numbers   : TScrollBar;
    ScrollBar_Mutate    : TScrollBar;
    ScrollBar_Variantion: TScrollBar;
    ApplicationEvents1  : TApplicationEvents;
    Label6: TLabel;
    Label_gesArea: TLabel;
    Label8: TLabel;
    Label_gesRecht: TLabel;
    procedure ScrollBar_SizeChange(Sender: TObject);
    procedure ScrollBar_VariantionChange(Sender: TObject);
    procedure ApplicationEvents1Idle(Sender: TObject; var Done: Boolean);
    procedure ScrollBar_MutateChange(Sender: TObject);
    procedure ScrollBar_NumbersChange(Sender: TObject);
    procedure Button_deleteClick(Sender: TObject);
    procedure Button_createRechtClick(Sender: TObject);
    procedure FormCreate(Sender: TObject);
  private
    { Private declarations }
    ShapesList: Array of TList;
    LapsList  : Array of TList;
    Backpuffer: TBitmap;
    procedure Selectionsort(var List : array of ValueType; var listInd : array of Integer;
                            min, max : IndexType);
    procedure RechtPaint(Canvas: TCanvas; ind : Integer);
    procedure sumAreas(var area : Array of Integer);
    procedure schneideRecht;
    procedure overlap;
    procedure optimize (var area : Array of Integer; const area_ind : Array of Integer);
    procedure deleteAll;
  public
    { Public declarations }
  end;

var
  Form1: TForm1;

implementation

{$R *.dfm}
var
  nrPop         : Integer;

//--- Form initialisieren-------------------------------------------------------
procedure TForm1.FormCreate(Sender: TObject);
var K : Integer;
begin
  scaled                := false;
  nrPop                 := 16;
  SetLength(ShapesList, nrPop);
  SetLength(LapsList, nrPop);
  For K := 0 to nrPop-1 Do
  begin
    ShapesList[K]         := TList.Create;
    LapsList[K]           := TList.Create;
  end;
  Form1.color             := clBlack;
  Label_Numbers.Caption   := IntToStr(ScrollBar_Numbers.Position);
  Label_area.Caption      := '0';
  Label_Mutate.Caption    := IntToStr(ScrollBar_Mutate.Position);
  Label_Variation.Caption := IntToStr(ScrollBar_Variantion.Position);
  Label_Size.Caption      := IntToStr(ScrollBar_Size.Position);
  Label_gesArea.Caption   := IntToStr(ImagePaint.Width * ImagePaint.Height);
  Label_gesRecht.Caption  := IntToStr(round (ScrollBar_Numbers.Position * Power((ScrollBar_Size.Position * 2), 2)));
  //--- Zwischenspeicher f�r die Bildaktualisierung -----------------
  Backpuffer              := TBitmap.create;
  Backpuffer.width        := ImagePaint.width;
  Backpuffer.height       := ImagePaint.height;
  Backpuffer.canvas.brush.color := clblack;
  Backpuffer.canvas.rectangle(0,0,Backpuffer.width,Backpuffer.height);
end;

//--- Button Rechtecke erstellen -----------------------------------------------
procedure TForm1.Button_createRechtClick(Sender: TObject);
var
  rechtA : TBaseRecht;
  I,K    : Integer;
  numbers: Integer;
begin
  Label_Ready.Caption    := 'Optimierung l�uft ...';
  Label_Ready.Font.Color := clRed;
  deleteAll;
  numbers := ScrollBar_Numbers.Position;
  For K:= 0 to nrPop-1 Do
  begin
    For I:= 1 to numbers Do
    begin
      rechtA           := TBaseRecht.Create;
      rechtA.cx        := ScrollBar_Size.Position;
      rechtA.cy        := ScrollBar_Size.Position;
      rechtA.PositionX := rechtA.Size.cx + random(ImagePaint.Width - 2 * rechtA.Size.cx);
      rechtA.PositionY := rechtA.Size.cy + random(ImagePaint.Height -2 * rechtA.Size.cy);
      rechtA.Left      := rechtA.PositionX - rechtA.Size.cx;
      rechtA.Right     := rechtA.PositionX + rechtA.Size.cx;
      rechtA.Top       := rechtA.PositionY - rechtA.Size.cy;
      rechtA.Bottom    := rechtA.PositionY + rechtA.Size.cy;
      ShapesList[K].Add (rechtA); //--- neues Rechtecke zur Liste hinzuf�gen ---
    end;
  end;
  overlap                         //--- �berlapungs-Optimierung starten --------
end;

// --- Wiederholt die Optimierung, bis die �berlagerungsfl�chen < 100 ----------
procedure TForm1.ApplicationEvents1Idle(Sender: TObject; var Done: Boolean);
begin
  done := false;
  If StrToInt(Label_area.Caption) <= 100 Then begin done := true;
  end else begin
    overlap;
  end;
end;

//--- �berlagerungen berechnen -------------------------------------------------
procedure TForm1.overlap;
var
  I,K      : Integer;
  area     : Array of Integer;
  area_ind : Array of Integer;
  sortArea : Array of Integer;
begin
  SetLength(area, nrPop);
  SetLength(area_ind, nrPop);
  For K:= 0 to nrPop-1 Do
  begin
    For I := LapsList[K].Count - 1 downto 0 do
    begin
      TBaseRecht (LapsList[K][I]).Free;
    end;
  end;
  For K:= 0 to nrPop-1 Do begin
    LapsList[K] := TList.Create;
  end;
  schneideRecht;                             //-- Auf �berlappung pr�fen
  sumAreas (area);                           //-- �berlagerungsfl�chen addieren
  Selectionsort(area, area_ind, 0, nrPop-1); //-- Nach Liste mit der kleinsten �berlagerungsfl�che sortieren
  RechtPaint(Backpuffer.Canvas, area_ind[0]);//-- Version mit den geringsten �berlappungen zeichnen
  Label_area.Caption := IntToStr(area[0]);
  //---------------------------------------------
  If area[0] > 100 then begin                //-- Rekursiver Aufruf -> ApplicationEvents1
    optimize (area, area_ind);               //-- L�sung optimieren -> �berlagerungsfl�chen minimieren
  end else begin //------------------------------
    Label_Ready.Caption := 'Programm bereit';
    Label_Ready.Font.Color := clWhite;
  end;
end;

//--- Variiert die Version mit den geringsten �berlappungen --------------------
procedure TForm1.optimize (var area : Array of Integer; const area_ind : Array of Integer);
var
  I,K,J      : Integer; //-- Laufvariablen
  ind        : Array [0..3] of Integer;
  counter    : Integer;
  Xpos, YPos : Integer;
  rechtA     : TBaseRecht;
  rechtB     : TBaseRecht;
  tempRecht  : TBaseRecht;
  tempList   : Array of Tlist;
  mutRat     : Integer; //-- Wahrscheinlichkeit f�r Mutation - zuf�llige Positionsver�nderung
  varSteps   : Integer; //-- Variationsm�glichkeiten der Position pro Generation
  scalStep   : Integer; //-- Ver�nderungsspektrum der Scalierung - Abh. von varSteps
  IR         : Integer; //-- Fl�cheninhalt
begin
  For J := 0 to 3 do begin
    ind[J]   := area_ind[J]; //-- Die besten vier Varianten erzeugen Variationen von sich selbst.
  end;
  SetLength(tempList, nrPop);
  For J := 0 to nrPop-1 do begin //--- Tempor�re Kopie der Rechtecke -----------
  tempList[J]:= TList.Create;
    For I := 0 To ShapesList[J].Count - 1 do begin
      tempRecht := TBaseRecht.Create;
      rechtB    := ShapesList[J].Items[I];
      tempRecht.PositionX := rechtB.PositionX;
      tempRecht.PositionY := rechtB.PositionY;
      tempRecht.cx        := rechtB.Size.cx;
      tempRecht.cy        := rechtB.Size.cy;
      tempRecht.Left      := rechtB.Rect.Left;
      tempRecht.Right     := rechtB.Rect.Right;
      tempRecht.Top       := rechtB.Rect.Top;
      tempRecht.Bottom    := rechtB.Rect.Bottom;
      tempList[J].Add(tempRecht);
    end;
  end;
  mutRat     := ScrollBar_Mutate.Position;
  varSteps   := ScrollBar_Variantion.Position;
  scalStep   := round(varSteps / 1);
  For K:= 0 to nrPop-1 Do
  begin
    counter := Ceil(K/4 - 0.9); //-- Vier Varianten der vier besten Versionen
    If Not (K = ind[counter]) then
    For I := 0 To ShapesList[ind[counter]].Count - 1 do
    begin
      rechtA    := ShapesList[ind[counter]].Items[I];
      tempRecht := tempList[K].Items[I];
      Xpos   := rechtA.PositionX;
      YPos   := rechtA.PositionY;
      IR     := round(Power((ScrollBar_Size.Position * 2), 2));//-- Gibt die zu erhaltende Fl�che vor.
      // --- Variation der Position --------------------------------------------
      If mutRat > random(100) then //--- Mutation ---
      begin
        Xpos   := random(ImagePaint.Width);
        YPos   := random(ImagePaint.Height);
      end
      else begin
        Xpos := Xpos + (random(varSteps*2+1)-(varSteps));
        YPos := YPos + (random(varSteps*2+1)-(varSteps));
      end;
      // --- Variation der Abmessung H�he/Breite -------------------------------
      tempRecht.cx := rechtA.Size.cx + (random(scalStep * 2 + 1) - (scalStep));
      If tempRecht.Size.cx < 10 then tempRecht.cx := 10;          //-- Minimale Scalierung X
      If tempRecht.Size.cx > round(ImagePaint.width/2 -5) then //-- Maximale Scalierung X
        tempRecht.cx := round(ImagePaint.width/2 -5);
      tempRecht.cy := round((IR /(tempRecht.Size.cx*2))/2); //-- zweite Seite in Abh. der Fl�che erstellen
      If tempRecht.Size.cy < 10 then begin               //-- Minimale Scalierung Y
        tempRecht.cy := 10;
        tempRecht.cx := round(IR / tempRecht.Size.cy);
      end;
      If tempRecht.Size.cy > round(ImagePaint.height/2 -5) then begin //-- Minimale Scalierung Y
        tempRecht.cy := round(ImagePaint.height/2 -5);
        tempRecht.cx := round(IR / tempRecht.Size.cy);
      end;
      // --- Kntrolle, ob innerhalb des Zeichenbereichs ------------------------
      If xPos < tempRecht.Size.cx Then xPos := tempRecht.Size.cx;
      If xPos > ImagePaint.Width - tempRecht.Size.cx Then xPos := ImagePaint.Width - tempRecht.Size.cx;
      If yPos < tempRecht.Size.cy Then yPos := tempRecht.Size.cy;
      If yPos > ImagePaint.Height - tempRecht.Size.cy Then yPos := ImagePaint.Height - tempRecht.Size.cy;
      // --- Koordinaten �bertragen ---
      tempRecht.PositionX := Xpos;
      tempRecht.PositionY := YPos;
      tempRecht.Left      := tempRecht.PositionX - tempRecht.Size.cx;
      tempRecht.Right     := tempRecht.PositionX + tempRecht.Size.cx;
      tempRecht.Top       := tempRecht.PositionY - tempRecht.Size.cy;
      tempRecht.Bottom    := tempRecht.PositionY + tempRecht.Size.cy;
    end;
  end;
  For J := 0 to nrPop-1 do begin //--- Tempor�re Kopien �bertragen und l�schen ----------------
    counter := Ceil(J/4 - 0.9); //-- Vier Varianten der vier besten Versionen - diese nicht �berschreiben
    If (Not (J = ind[0]) And Not (J = ind[1]) And Not (J = ind[2]) And Not (J = ind[3]))then
    For I := 0 To tempList[J].Count - 1 do begin
      rechtB    := ShapesList[J].Items[I];
      tempRecht := tempList[J].Items[I];
      rechtB.PositionX := tempRecht.PositionX;
      rechtB.PositionY := tempRecht.PositionY;
      rechtB.cx        := tempRecht.Size.cx;
      rechtB.cy        := tempRecht.Size.cy;
      rechtB.Left      := tempRecht.Rect.Left;
      rechtB.Right     := tempRecht.Rect.Right;
      rechtB.Top       := tempRecht.Rect.Top;
      rechtB.Bottom    := tempRecht.Rect.Bottom;
      TBaseRecht (tempList[J][I]).Free;
    end;
    tempList[J].Free;
  end;
end;

//--- Rechtecke zeichnen -------------------------------------------------------
procedure TForm1.RechtPaint(Canvas: TCanvas; ind : Integer);
var
  I,K    : Integer;
  rechtA : TBaseRecht;
begin
  //--- Backpuffer l�schen ------------------------------------------
  Backpuffer.canvas.brush.color := clBlack;
  Backpuffer.canvas.pen.color := clgreen;
  Backpuffer.canvas.rectangle(0,0,Backpuffer.width,Backpuffer.height);
  //--- Rechtecke der Liste zeichnen --------------------------------
  For I := 0 To ShapesList[ind].Count - 1 do
  begin
    rechtA := ShapesList[ind].Items[I];
    rechtA.FillColor := clRed;
    rechtA.Paint(Canvas);
  end;
  //--- �berlagerungsfl�chen aus Liste zeichnen ---------------------
  For I := 0 To LapsList[ind].Count - 1 do
  begin
    rechtA := LapsList[ind].Items[I];
    rechtA.FillColor := clBlue;
    rechtA.Paint(Canvas);
  end;
  ImagePaint.Canvas.Draw (0, 0, Backpuffer); //-- Backpuffer auf Zeichenfl�che kopieren
end;

//--- Berechnet und addiert die �berlagerungsfl�chen ---------------------------
procedure TForm1.sumAreas (var area : Array of Integer);
var
  I,K    : Integer;
  rechtA : TBaseRecht;
  siteA  : Integer;
  siteB  : Integer;
begin
  For K:= 0 to nrPop-1 Do
  begin
    area[K] := 0;
    For I := 0 To LapsList[K].Count - 1 do
    begin
      rechtA  := LapsList[K].Items[I];
      siteA   := rechtA.Rect.Bottom - rechtA.Rect.Top;  //-- H�he
      siteB   := rechtA.Rect.Right - rechtA.Rect.Left;  //-- Breite
      area[K] := area[K] + siteA * siteB;
      end;
  end;
end;

//--- Berechnet die �berlagerungen der Rechtecke -------------------------------
procedure TForm1.schneideRecht;
var
  I, K, L : Integer;
  rechtA  : TBaseRecht; //-- Container f�r Rechtecke
  rechtB  : TBaseRecht;
  rechtLap: TBaseRecht;
  lapR    : TRect;
  isLap   : Boolean;
begin
  For K := 0 to nrPop-1 Do
  begin
    For I := 0 To ShapesList[K].Count - 1 do
    begin
      rechtA := ShapesList[K].Items[I];
      For L := I+1 To ShapesList[K].Count - 1 do //-- Werden auf �berlagerung gepr�ft
      begin
        rechtB := ShapesList[K].Items[L];        //-- Vergleichs-Clipping-Rechteck --
        isLap := intersectRect(lapR, rechtA.Rect, rechtB.Rect);
        If isLap = true then
        begin
          rechtLap        := TBaseRecht.Create;
          rechtLap.Left   := lapR.Left;
          rechtLap.Top    := lapR.Top;
          rechtLap.Right  := lapR.Right;
          rechtLap.Bottom := lapR.Bottom;
          LapsList[K].Add (rechtLap); //--- In Liste der �berlappenden Fl�chen eintragen
        end;
      end;
    end;
  end;
end;

//--- Sortier Algorithmus ------------------------------------------------------
procedure TForm1.Selectionsort(var List : array of ValueType; var listInd : array of Integer;
                               min, max : IndexType);
var
  i, j, best_j : IndexType;
  best_value   : ValueType;
begin
  for i := min to max -1  do
  begin
    best_value := List[i];
    best_j := i;
    for j := i + 1 to max do
    begin
      if (List[j] < best_value) Then
      begin
        best_value := List[j];
        best_j := j;
        listInd[I] := j;
        listInd[I+1] := i;
      end;
    end;    // for j := i + 1 to max do
    List[best_j]:= List[i];
    List[i]     := best_value;
  end;        // for i := min to max - 1 do
end;

// --- Anzahl der Rechtecke pro klick einstellen -------------------------------
procedure TForm1.ScrollBar_NumbersChange(Sender: TObject);
begin
  Label_Numbers.Caption := IntToStr(ScrollBar_Numbers.Position);
  Label_gesRecht.Caption  := IntToStr(round (ScrollBar_Numbers.Position * Power((ScrollBar_Size.Position * 2), 2)));
end;

// --- Mutationsrate einstellen ------------------------------------------------
procedure TForm1.ScrollBar_MutateChange(Sender: TObject);
begin
  Label_Mutate.Caption  := IntToStr(ScrollBar_Mutate.Position);
end;

// --- Variations-Schrittweite einstellen --------------------------------------
procedure TForm1.ScrollBar_VariantionChange(Sender: TObject);
begin
   Label_Variation.Caption := IntToStr(ScrollBar_Variantion.Position);
end;

// --- Rechteckgr��e einstellen => zu erhaltende Fl�che ------------------------
procedure TForm1.ScrollBar_SizeChange(Sender: TObject);
begin
  Label_Size.Caption := IntToStr(ScrollBar_Size.Position);
  Label_gesRecht.Caption  := IntToStr(round (ScrollBar_Numbers.Position * Power((ScrollBar_Size.Position * 2), 2)));
end;

// --- Button delete -----------------------------------------------------------
procedure TForm1.Button_deleteClick(Sender: TObject);
begin
  Label_Ready.Caption := 'Programm bereit';
  Label_Ready.Font.Color := clWhite;
  deleteAll;
end;

// --- Rechtecke l�schen -------------------------------------------------------
procedure TForm1.deleteAll;
var I,K : Integer;
begin
  For K := 0 to nrPop-1 Do //--- Rechtecke l�schen ---
  begin
    For I := ShapesList[K].Count - 1 downto 0 do
    begin
      TBaseRecht (ShapesList[K][I]).Free;
    end;
    ShapesList[K]:= TList.Create;
  end;
  For K := 0 to nrPop-1 Do //--- �berlagerungsfl�chen l�schen ---
  begin
    for I := LapsList[K].Count - 1 downto 0 do
    begin
      TBaseRecht (LapsList[K][I]).Free;
    end;
    LapsList[K] := TList.Create;
  end;
  Label_area.Caption := '0';
  Backpuffer.canvas.brush.color := clblack;
  Backpuffer.canvas.rectangle(0,0,Backpuffer.width,Backpuffer.height);
  ImagePaint.Canvas.Draw (0, 0, Backpuffer); //-- Backpuffer auf Zeichenfl�che kopieren
end;

end.

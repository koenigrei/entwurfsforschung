object Form1: TForm1
  Left = 0
  Top = 0
  Width = 800
  Height = 459
  Caption = 'Pcking 1.01'
  Color = clActiveCaption
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -10
  Font.Name = 'Tahoma'
  Font.Style = []
  OldCreateOrder = False
  OnCreate = FormCreate
  PixelsPerInch = 96
  TextHeight = 12
  object ImagePaint: TImage
    Left = 12
    Top = 12
    Width = 580
    Height = 400
  end
  object Label1: TLabel
    Left = 608
    Top = 78
    Width = 100
    Height = 13
    Caption = 'Rechtecke per Click: '
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clWhite
    Font.Height = -11
    Font.Name = 'Tahoma'
    Font.Style = []
    ParentFont = False
  end
  object Label_Numbers: TLabel
    Left = 707
    Top = 78
    Width = 18
    Height = 13
    Caption = '___'
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clWhite
    Font.Height = -11
    Font.Name = 'Tahoma'
    Font.Style = []
    ParentFont = False
  end
  object Label_area: TLabel
    Left = 610
    Top = 328
    Width = 102
    Height = 13
    Caption = '_________________'
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clRed
    Font.Height = -11
    Font.Name = 'Tahoma'
    Font.Style = []
    ParentFont = False
  end
  object Label2: TLabel
    Left = 608
    Top = 308
    Width = 126
    Height = 13
    Caption = 'min. '#220'berlagerungsfl'#228'che:'
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clWhite
    Font.Height = -11
    Font.Name = 'Tahoma'
    Font.Style = []
    ParentFont = False
  end
  object Label3: TLabel
    Left = 608
    Top = 277
    Width = 71
    Height = 13
    Caption = 'Mutationsrate:'
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clWhite
    Font.Height = -11
    Font.Name = 'Tahoma'
    Font.Style = []
    ParentFont = False
  end
  object Label_Mutate: TLabel
    Left = 707
    Top = 277
    Width = 18
    Height = 13
    Caption = '___'
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clWhite
    Font.Height = -11
    Font.Name = 'Tahoma'
    Font.Style = []
    ParentFont = False
  end
  object Label_Ready: TLabel
    Left = 610
    Top = 352
    Width = 97
    Height = 13
    Caption = 'Programm bereit'
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clWhite
    Font.Height = -11
    Font.Name = 'Tahoma'
    Font.Style = [fsBold]
    ParentFont = False
  end
  object Label4: TLabel
    Left = 608
    Top = 227
    Width = 77
    Height = 13
    Caption = 'Variationsweite:'
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clWhite
    Font.Height = -11
    Font.Name = 'Tahoma'
    Font.Style = []
    ParentFont = False
  end
  object Label_Variation: TLabel
    Left = 707
    Top = 227
    Width = 18
    Height = 13
    Caption = '___'
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clWhite
    Font.Height = -11
    Font.Name = 'Tahoma'
    Font.Style = []
    ParentFont = False
  end
  object Label5: TLabel
    Left = 608
    Top = 141
    Width = 76
    Height = 13
    Caption = 'Rechteckgr'#246#223'e:'
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clWhite
    Font.Height = -11
    Font.Name = 'Tahoma'
    Font.Style = []
    ParentFont = False
  end
  object Label_Size: TLabel
    Left = 715
    Top = 141
    Width = 18
    Height = 13
    Caption = '___'
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clWhite
    Font.Height = -11
    Font.Name = 'Tahoma'
    Font.Style = []
    ParentFont = False
  end
  object Label6: TLabel
    Left = 608
    Top = 159
    Width = 77
    Height = 13
    Caption = 'Feldfl'#228'che ges.:'
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clWhite
    Font.Height = -11
    Font.Name = 'Tahoma'
    Font.Style = []
    ParentFont = False
  end
  object Label_gesArea: TLabel
    Left = 715
    Top = 159
    Width = 18
    Height = 13
    Caption = '___'
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clWhite
    Font.Height = -11
    Font.Name = 'Tahoma'
    Font.Style = []
    ParentFont = False
  end
  object Label8: TLabel
    Left = 608
    Top = 177
    Width = 101
    Height = 13
    Caption = 'Rechteckfl'#228'che ges.:'
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clWhite
    Font.Height = -11
    Font.Name = 'Tahoma'
    Font.Style = []
    ParentFont = False
  end
  object Label_gesRecht: TLabel
    Left = 715
    Top = 177
    Width = 18
    Height = 13
    Caption = '___'
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clWhite
    Font.Height = -11
    Font.Name = 'Tahoma'
    Font.Style = []
    ParentFont = False
  end
  object Button_createRecht: TButton
    Left = 608
    Top = 12
    Width = 121
    Height = 21
    Caption = 'Rechtecke erstellen'
    TabOrder = 0
    OnClick = Button_createRechtClick
  end
  object Button_delete: TButton
    Left = 608
    Top = 384
    Width = 121
    Height = 25
    Caption = 'Rechtecke l'#246'schen'
    TabOrder = 1
    OnClick = Button_deleteClick
  end
  object ScrollBar_Numbers: TScrollBar
    Left = 608
    Top = 60
    Width = 121
    Height = 16
    LargeChange = 5
    Min = 1
    PageSize = 3
    Position = 15
    TabOrder = 2
    OnChange = ScrollBar_NumbersChange
  end
  object ScrollBar_Mutate: TScrollBar
    Left = 608
    Top = 256
    Width = 121
    Height = 16
    LargeChange = 5
    Max = 50
    PageSize = 3
    Position = 1
    TabOrder = 3
    OnChange = ScrollBar_MutateChange
  end
  object ScrollBar_Variantion: TScrollBar
    Tag = 2
    Left = 608
    Top = 207
    Width = 121
    Height = 16
    LargeChange = 5
    Min = 1
    PageSize = 3
    Position = 1
    TabOrder = 4
    OnChange = ScrollBar_VariantionChange
  end
  object ScrollBar_Size: TScrollBar
    Left = 608
    Top = 118
    Width = 121
    Height = 16
    LargeChange = 5
    PageSize = 3
    Position = 61
    TabOrder = 5
    OnChange = ScrollBar_SizeChange
  end
  object ApplicationEvents1: TApplicationEvents
    OnIdle = ApplicationEvents1Idle
    Left = 64
    Top = 64
  end
end

unit facsSteer;

interface

uses
  Windows, Messages, SysUtils, Variants, Classes, Graphics, Controls, Forms, cell,
  Dialogs, ExtCtrls, Grids, agenten, Math, ConvUtils, StdCtrls, AppEvnts,    //ActnMan ,
  Menus;

type
  TMovePlate = class(TForm)
    ScrollBar1          : TScrollBar;
    ApplicationEvents1  : TApplicationEvents;
    Label1              : TLabel;
    Label2              : TLabel;
    Button2             : TButton;
    Label3              : TLabel;
    Label_Radius        : TLabel;
    CB_moveMarkt: TCheckBox;
    ButtonPause: TButton;
    CB_Distanz: TCheckBox;
    GroupBox1: TGroupBox;
    ImagePaint: TImage;
    GroupBox2: TGroupBox;
    Label11: TLabel;
    Lbl_AnbauErtr: TLabel;
    SB_AnbauErtr: TScrollBar;
    Label8: TLabel;
    Lbl_ErzeugKost: TLabel;
    SB_ErzeugKost: TScrollBar;
    Label6: TLabel;
    Lbl_MarktPr: TLabel;
    SB_MarktPr: TScrollBar;
    Label14: TLabel;
    Lbl_TranspKost: TLabel;
    SB_TranspKost: TScrollBar;
    GroupBox3: TGroupBox;
    Label4: TLabel;
    Lbl_AnbauErtr2: TLabel;
    Label9: TLabel;
    Lbl_ErzeugKost2: TLabel;
    Label12: TLabel;
    Lbl_MarktPr2: TLabel;
    Label15: TLabel;
    Lbl_TranspKost2: TLabel;
    SB_AnbauErtr2: TScrollBar;
    SB_ErzeugKost2: TScrollBar;
    SB_MarktPr2: TScrollBar;
    SB_TranspKost2: TScrollBar;
    GroupBox4: TGroupBox;
    Label17: TLabel;
    Lbl_AnbauErtr3: TLabel;
    Label19: TLabel;
    Lbl_ErzeugKost3: TLabel;
    Label21: TLabel;
    Lbl_MarktPr3: TLabel;
    Label23: TLabel;
    Lbl_TranspKost3: TLabel;
    SB_AnbauErtr3: TScrollBar;
    SB_ErzeugKost3: TScrollBar;
    SB_MarktPr3: TScrollBar;
    SB_TranspKost3: TScrollBar;
    GroupBox5: TGroupBox;
    Label5: TLabel;
    Label7: TLabel;
    Label10: TLabel;
    CB_Lagerente: TCheckBox;
    B_delMarkt: TButton;
    procedure B_delMarktClick(Sender: TObject);
    procedure SB_TranspKost3Change(Sender: TObject);
    procedure SB_MarktPr3Change(Sender: TObject);
    procedure SB_TranspKost2Change(Sender: TObject);
    procedure SB_MarktPr2Change(Sender: TObject);
    procedure SB_ErzeugKost3Change(Sender: TObject);
    procedure SB_ErzeugKost2Change(Sender: TObject);
    procedure SB_AnbauErtr3Change(Sender: TObject);
    procedure SB_AnbauErtr2Change(Sender: TObject);
    procedure SB_TranspKostChange(Sender: TObject);
    procedure SB_MarktPrChange(Sender: TObject);
    procedure SB_ErzeugKostChange(Sender: TObject);
    procedure SB_AnbauErtrChange(Sender: TObject);
    procedure ImagePaintClick(Sender: TObject);
    procedure ButtonPauseClick(Sender: TObject);
    procedure Button_DeleteClick(Sender: TObject);
    procedure Button2MouseUp(Sender: TObject; Button: TMouseButton;
      Shift: TShiftState; X, Y: Integer);
    procedure FormDestroy(Sender: TObject);
    procedure ImagePaintMouseMove(Sender: TObject; Shift: TShiftState; X,
      Y: Integer);
    procedure ApplicationEvents1Idle(Sender: TObject; var Done: Boolean);
    procedure PaintBox1Paint(Sender: TObject);
    procedure ScrollBar1Change(Sender: TObject);
    procedure FormCreate(Sender: TObject);
  private
    { Private declarations }
    ShapesList: TList;
    CurrShape: TBaseShape;
    procedure CommonPaint (Canvas: TCanvas);
    procedure RegionPaint (Canvas: TCanvas; AShape: TAgent);
    procedure checkNeighbour (Canvas: TCanvas; xPos : Integer; yPos : Integer);
    procedure lookCell (Canvas: TCanvas);
    procedure cellStates (Canvas: TCanvas);
    procedure Verbinden();
    procedure Swarming();
    procedure BewegVekt();
    procedure RectanglPaint  (Canvas: TCanvas);
    procedure RectanglCreate (Canvas: TCanvas);
    procedure SetzeErtrag    (const J : Integer);
    procedure SetzeErzeugKost(const J : Integer);
    procedure SetzeMarktPr   (const J : Integer);
    procedure SetzeTranspKost(const J : Integer);
  public
    { Public declarations }
  end;

var
  MovePlate: TMovePlate;

implementation

{$R *.dfm}

const
    NUM_BALLS = 100;
    cellScal  = 6;
    NumProd   = 3;
var
  reih      : Integer;
  spalt     : Integer;
  Dir       : Integer = 1;
  StepX     : Integer;
  StepY     : Integer;
  LEFT_BORDER   : Integer;
  TOP_BORDER    : Integer;
  RIGHT_BORDER  : Integer;
  BOTTOM_BORDER : Integer;
  Mouse_Rad     : Integer;
  MouseX        : Integer;
  MouseY        : Integer;
  Backpuffer    : TBitmap;
  cellList      : Array of Array of TCell;
  limboWorld    : Array of Array of Integer;
  oldPos        : Array of Array of Integer;
  limboPos      : Array of Array of Double;
  Abstand       : Integer;
  Sichtfeld     : Integer;
  test          : Integer;
  fertig        : Boolean;

function distance(pX1: Integer; pY1: Integer; pX2: Integer; pY2: Integer): Integer;
  var temp: double;
  begin
  temp := sqrt(Power((pX1 - pX2), 2) + Power((pY1 - pY2), 2));
  distance := Round(temp);
end;

procedure TMovePlate.FormCreate(Sender: TObject);
begin
  scaled := false;
  fertig := false;
  // --- deklarieren des Arrays f�r die 'Cellen' -------------------------------
  spalt := round (ImagePaint.Width / cellScal);
  reih  := round (ImagePaint.Height / cellScal);
  SetLength(cellList, reih, spalt);
  SetLength(limboWorld, reih, spalt);
  // --- initialization and creation of the list -------------------------------
  ShapesList                    := TList.Create;
  MovePlate.Color               := clBlack;
  MovePlate.Canvas.Pen.Color    := clred;
  MovePlate.Canvas.Brush.Color  := clred;
  LEFT_BORDER                   := ImagePaint.Left-5;
  TOP_BORDER                    := ImagePaint.Top-5;
  RIGHT_BORDER                  := ImagePaint.Width-5;
  BOTTOM_BORDER                 := ImagePaint.Height-5;
  // --- Slider & Label --------------------------------------------------------
  Mouse_Rad                     := ScrollBar1.Position;
  Label_Radius.Caption          := IntToStr(Mouse_Rad);
  Lbl_AnbauErtr.Caption         := IntToStr(SB_AnbauErtr.Position);
  Lbl_ErzeugKost.Caption        := IntToStr(SB_ErzeugKost.Position);
  Lbl_MarktPr.Caption           := IntToStr(SB_MarktPr.Position);
  Lbl_TranspKost.Caption        := IntToStr(SB_TranspKost.Position);
  //---
  Lbl_AnbauErtr2.Caption         := IntToStr(SB_AnbauErtr2.Position);
  Lbl_ErzeugKost2.Caption        := IntToStr(SB_ErzeugKost2.Position);
  Lbl_MarktPr2.Caption           := IntToStr(SB_MarktPr2.Position);
  Lbl_TranspKost2.Caption        := IntToStr(SB_TranspKost2.Position);
  //---
  Lbl_AnbauErtr3.Caption         := IntToStr(SB_AnbauErtr3.Position);
  Lbl_ErzeugKost3.Caption        := IntToStr(SB_ErzeugKost3.Position);
  Lbl_MarktPr3.Caption           := IntToStr(SB_MarktPr3.Position);
  Lbl_TranspKost3.Caption        := IntToStr(SB_TranspKost3.Position);
  // --- Zwischenspeicher f�r die Bildaktualisierung ---------------------------
  Backpuffer                    := TBitmap.create;
  Backpuffer.width              := ImagePaint.width;
  Backpuffer.height             := ImagePaint.height;
  Backpuffer.canvas.brush.color := clgreen;
  Backpuffer.canvas.rectangle   (10,10,Backpuffer.width,Backpuffer.height);
  RectanglCreate (Backpuffer.Canvas);
end;

// *********************************
// *** ------- Agenten --------- ***
//**********************************
// *** Zeichnet die Agenten ***
procedure TMovePlate.PaintBox1Paint(Sender: TObject);
begin
  MovePlate.Color := clBlack;
  MovePlate.canvas.brush.color := clgreen;
  MovePlate.canvas.pen.color := clgreen;
  MovePlate.canvas.pen.width := 2;
  MovePlate.canvas.rectangle(5,5,810,610);
  MovePlate.refresh;
  CommonPaint (Canvas);
end;

procedure TMovePlate.CommonPaint (Canvas: TCanvas);
var
  I     : Integer;
  AShape: TAgent;
begin
  // repaint each shape of the list
  for I := 0 to ShapesList.Count - 1 do
  begin
    AShape := ShapesList.Items [I];
    AShape.BindungSet := 0; // --- Anzahl Bindungen je Typ zur�cksetzen
    AShape.Paint (Canvas);
    {If (AShape.State = 0)  And (CB_showRed.State = cbChecked) Then Begin
      Canvas.Pen.Color := clMaroon;
      RegionPaint (Canvas, AShape);
    end;
    If (AShape.State = 1)  And (CB_showBlau.State = cbChecked) Then Begin
      Canvas.Pen.Color := clNavy;
      RegionPaint (Canvas, AShape);
    end;
    If (AShape.State = 2)  And (CB_showGelb.State = cbChecked) Then Begin
      Canvas.Pen.Color := clOlive;
      RegionPaint (Canvas, AShape);
    end; }
  end;
end;

procedure TMovePlate.RegionPaint (Canvas: TCanvas; AShape: TAgent);
var
  I    : Integer;
  tmpD : Integer;
begin
  Canvas.Brush.Style := bsclear;  //!!!(=bsClear, bsSolid, bsCross)
  Canvas.Pen.Style := psDot;      //!!!(=psSolid, psDash, psDot, psClear, psDashDot)
  For I := 0 to 1 Do
  Begin
    tmpD := I *  AShape.RepelDist;
    Canvas.Ellipse (AShape.PositionX - AShape.AnlDist + tmpD , AShape.FPositionY - AShape.AnlDist + tmpD,
                    AShape.PositionX + AShape.AnlDist - tmpD , AShape.FPositionY + AShape.AnlDist - tmpD);
  end;
end;

// *** Bewegungsvektor zeichnen ***
procedure TMovePlate.BewegVekt();
var
  J      : Integer;
  AShape : TAgent;
  BShape : TAgent;
begin
  for J := 0 to ShapesList.Count - 1 do
  begin
    AShape := ShapesList.Items [J];
    Backpuffer.Canvas.Pen.Color := clLime;  // 898989;
    Backpuffer.Canvas.MoveTo(AShape.PositionX, AShape.PositionY); // --- Verbindungen mit oldPosition zeichnen
    Backpuffer.Canvas.LineTo((AShape.PositionX - 7*round(AShape.StepX)), (AShape.PositionY - 7*round(AShape.StepY)));
  end;
end;

// *** Verbinde n�chste Nachbarn ***
procedure TMovePlate.Verbinden();
var
  J      : Integer;
  K      : Integer;
  AShape : TAgent;
  BShape : TAgent;
begin
  for J := 0 to ShapesList.Count -1 do
  begin
    AShape := ShapesList.Items [J];
    Backpuffer.Canvas.Pen.Width := 1;
    K := 0;
    While  K < length(AShape.FBindListSelf) Do
    Begin
      BShape := ShapesList.Items [AShape.BindListSelf[K]];
      Backpuffer.Canvas.Pen.Color := AShape.FillColor;//clMaroon;
      Backpuffer.Canvas.Pen.Style := psSolid;
      Backpuffer.Canvas.MoveTo(oldPos[J][0], oldPos[J][1]); // --- Verbindungen mit oldPosition zeichnen
      Backpuffer.Canvas.LineTo(oldPos[AShape.BindListSelf[K]][0], oldPos[AShape.BindListSelf[K]][1]);
      K := K + 1;
    end;
    K := 0;
    While  K < length(AShape.FBindListOther) Do
    Begin
      BShape := ShapesList.Items [AShape.BindListOther[K]];
      Backpuffer.Canvas.Pen.Color := AShape.FillColor;//clMaroon;
      Backpuffer.Canvas.MoveTo(oldPos[J][0], oldPos[J][1]); // --- Verbindungen mit oldPosition zeichnen
      Backpuffer.Canvas.LineTo(oldPos[AShape.BindListOther[K]][0], oldPos[AShape.BindListOther[K]][1]);
      K := K + 1;
    end;
  end;
end;

// **** Schwarmverhalten ****
procedure TMovePlate.Swarming();
var
  J      : Integer;
  AShape : TAgent;
  XCell  : Integer;
  YCell  : Integer;
  Cstatus: Integer;
begin
  SetLength(limboPos, ShapesList.Count, 2); //--- definiert die Gr��e der LimboPos
  SetLength(oldPos, ShapesList.Count, 2);   //--- definiert die Gr��e der oldPos
  for J := 0 to ShapesList.Count - 1 do
  begin
    AShape := ShapesList.Items [J];
    // --- Alte Positionen Speichern
    oldPos[J][0] := AShape.PositionX;
    oldPos[J][1] := AShape.PositionY;
    XCell := round((AShape.FPositionX - (cellScal / 2)) / (cellScal));
    YCell := round((AShape.FPositionY - (cellScal / 2)) / (cellScal));
    If not (((XCell < 0) or (XCell > spalt-1)) or ((YCell < 0) or (YCell > reih-1))) then
    begin
      Cstatus:= cellList[YCell,XCell].State;
      //AShape.NeigborCheck (ShapesList, J, ScrollBar_MinDist.Position, limboPos[J]);  // --- Berechnet die Nachbarn
    end;
  end;
end;

// *** Aktualisierungen je Durchlauf***
procedure TMovePlate.ApplicationEvents1Idle(Sender: TObject; var Done: Boolean);
var
  I         : Integer;
  J         : Integer;
  AShape    : TAgent;
  distMouse : Integer;
  Area      : Trect;
begin
  If fertig = false then done := false;
  If fertig = true  then begin done := true; exit; end;
  //Swarming (); // --- Schwarmverhalten Subprozedur aufrufen
  //------------------------------------------//
  If (CB_moveMarkt.State = cbChecked) Then Begin
  for I := 0 to ShapesList.Count - 1 do
  begin
    AShape := ShapesList.Items [I];
    distMouse := distance (AShape.PositionX, AShape.PositionY, MouseX, MouseY);
    If (distMouse < Mouse_Rad) // --- MausInteraktion
    then begin
      AShape.FStepX := Dir * round ((AShape.PositionX - MouseX) * 0.1); //AShape.FStepX * -3;
      AShape.FStepY := Dir * round ((AShape.PositionY - MouseY) * 0.1); //AShape.FStepY * -3;
    end;
    AShape.SetRndDir (1.0001);
    // --- Randlos Torus--- // Rand nicht �berschreiten
    if AShape.PositionX < LEFT_BORDER  then
      AShape.PositionX := RIGHT_BORDER;
    if AShape.PositionX > RIGHT_BORDER then
      AShape.PositionX := LEFT_BORDER;
    if AShape.PositionY < TOP_BORDER then
      AShape.PositionY := BOTTOM_BORDER;
    if AShape.PositionY > BOTTOM_BORDER then
      AShape.PositionY := TOP_BORDER;
    // ++++ Position aktualisieren ++++
    AShape.PositionX := AShape.FPositionX + round(AShape.FStepX);
    AShape.PositionY := AShape.FPositionY + round(AShape.FStepY);
  end;
  end;

  // --- berechnen, zeichnen und verbinden ----
  RectanglPaint (Backpuffer.Canvas);                   // --- L�scht Zeichung und Aktualisiert Zellen
  CommonPaint (Backpuffer.Canvas);
  /// --- Bild aktualisieren ---
  //BitBlt(Backpuffer.Canvas.Handle, bildleft, bildtop, Bild.Width, Bild.Height, Bild.canvas.handle, 0, 0, SRCCOPY);//Bild auf Backpuffer kopieren
  ImagePaint.Invalidate;
  BitBlt(ImagePaint.Canvas.Handle, 0, 0, Backpuffer.Width, Backpuffer.Height, Backpuffer.canvas.handle, 0, 0, SRCCOPY);//Backpuffer auf das Formular kopieren
end;

procedure TMovePlate.ImagePaintMouseMove(Sender: TObject; Shift: TShiftState; X, Y: Integer);
begin
  MouseX := X;
  MouseY := Y;
end;


// *********************************
// *** ------- Zellen ---------- ***
//**********************************
// *** Erstellt das ZellenRaster ***
procedure TMovePlate.RectanglCreate (Canvas: TCanvas);
var
  I: Integer;
  K: Integer;
  J: Integer;
begin
  for I := 0 to reih -1 do
  begin
    for K := 0 to spalt -1 do
    begin
      cellList[I,K] := TCell.Create;
      //--- Variablen in Abh. der Produkte dimensionieren ---
      SetLength(cellList[I,K].FLagerente,  NumProd);
      SetLength(cellList[I,K].FErtrag,     NumProd);
      SetLength(cellList[I,K].FErzeugKost, NumProd);
      SetLength(cellList[I,K].FTranspKost, NumProd);
      SetLength(cellList[I,K].FMarktPreis, NumProd);
      cellList[I,K].PositionX := K * cellScal + round(cellScal / 2);
      cellList[I,K].PositionY := I * cellScal + round(cellScal / 2);
      cellList[I,K].Size := round (cellScal / 2)+1;
      //ARecht.FillColor :=  RGB (I*K mod 255, I, K);
      cellList[I,K].Paint(Canvas);
    end ;
  end;
  //--- Werte in Veariablen schreiben ---
  for J := 0 to NumProd -1 do
  begin
    SetzeErtrag    (J);
    SetzeErzeugKost(J);
    SetzeMarktPr   (J);
    SetzeTranspKost(J);
  end;
end;

// *** Aktualisiert das ZellenRaster ***
procedure TMovePlate.RectanglPaint (Canvas: TCanvas);
var
  I    : Integer;
  K    : Integer;
  used : Integer;
  dist : Integer;
begin
  //--- Backbuffer l�schen
  canvas.brush.color := clGreen;
  canvas.pen.color := clGreen;
  canvas.rectangle(10,10,Backpuffer.width,Backpuffer.height);
  for I := 0 to reih -1 do
  begin
    for K := 0 to spalt -1 do
    begin
      // --- Cellen anpassen ---
      cellList[I,K].FillColor := clBlack;     // --- Cellen l�schen
      cellList[I,K].NextMarkt(ShapesList);
      cellList[I,K].CalcLagerR;
      used := cellList[I,K].State;
      If (CB_Lagerente.State = cbChecked) Then Begin  // --- Wenn Schalter "Lagerente anzeigen" ein
        dist := round(cellList[I,K].Lagerente[used]);//Distance;       //dist := 255 - round (cellList[I,K].Distance /2);
        If dist > 255 then dist := 255;
        dist := dist - cellList[I,K].Distance;
        If dist < 0 then dist := 0;
        cellList[I,K].FillColor := RGB (dist,dist,dist);
      end
      else If (CB_Distanz.State = cbChecked) Then Begin  // --- Wenn Schalter "Distanzen anzeigen" ein
        dist := 255 - round (cellList[I,K].Distance /2);
        If dist < 0 then dist := 0;
        cellList[I,K].FillColor := RGB (dist,dist,dist);
      end
      else begin              // --- Wenn Schalter aus -> Th�nen Reinge zeichnen    //If used < 99 then
        dist := round (cellList[I,K].Lagerente[used] / 1);
        If dist < 0 then dist := 0;
        If dist > 255 then dist := 255;
        case used of
          0: cellList[I,K].FillColor := RGB (dist,dist,0);
          1: cellList[I,K].FillColor := RGB (10,dist,10);
          2: cellList[I,K].FillColor := RGB (dist,dist,dist);
        end;
      end;
      cellList[I,K].Paint(Canvas);
      //If  cellList[I,K].State < 0 then begin
      //  used:= used * -1;
    end ;
  end;
end;

//*** Berechnet die Celle unter dem Agenten ***
procedure TMovePlate.lookCell (Canvas: TCanvas);
var
  I      : Integer;
  AShape : TAgent;
  XCell  : Integer;
  YCell  : Integer;
begin
  for I := 0 to ShapesList.Count - 1 do
  begin
    AShape := ShapesList.Items [I];
    XCell := round((AShape.FPositionX - (cellScal / 2)) / (cellScal));
    YCell := round((AShape.FPositionY - (cellScal / 2)) / (cellScal));
    If not (((XCell < 0) or (XCell > spalt-1)) or ((YCell < 0) or (YCell > reih-1))) then
    begin
      cellList[YCell,XCell].State := AShape.FState +1; //+ RGB (3,4,5);
    end;
  end;
end;

procedure TMovePlate.cellStates (Canvas: TCanvas);
var
  I: Integer;
  K: Integer;
begin
  for I := 1 to reih -2 do
  begin
    for K := 1 to spalt -2 do
    begin
      checkNeighbour (Backpuffer.Canvas, I, K);
    end ;
  end;
end;

procedure TMovePlate.checkNeighbour (Canvas: TCanvas; xPos : Integer; yPos : Integer);
var
  I: Integer;
  K: Integer;
  state : Integer;
begin
  state := 0;
  for I := xPos - 1 to xPos + 1 do
  begin
    for K := yPos - 1 to yPos + 1 do
    begin
      //If not ((I = xPos) and (K = yPos)) then
      If (cellList[I,K].State = 1) then state := state - 55;
      If (cellList[I,K].State = 2) then state := state + 50;
    end;
  end;
  limboWorld[xPos,yPos] := state;
end;

// ***************************
// ********* Buttons *********
// ***************************
//
// *** Repel - Attract - Button ***
procedure TMovePlate.Button2MouseUp(Sender: TObject; Button: TMouseButton;
  Shift: TShiftState; X, Y: Integer);
begin
  Dir := Dir * (-1);
end;

// *** einzelne Agenten erstellen ***
procedure TMovePlate.ImagePaintClick(Sender: TObject);
begin
  CurrShape := TAgent.Create;
  CurrShape.PositionX :=  MouseX;
  CurrShape.PositionY :=  MouseY;
  CurrShape.StepX := (random(3) - 1);
  CurrShape.StepY := (random(3) - 1);
  CurrShape.Size := 3;
  CurrShape.Connect := 0;
  CurrShape.State := 0;
  //CurrShape.BindungMax:= SB_BindRot.Position;
  //CurrShape.AnlDist   := ScrollBar_DistRot.Position;
  //CurrShape.RepelDist := SB_RepelDistRot.Position;
  CurrShape.basicSettings;
  ShapesList.Add (CurrShape);
  CommonPaint (ImagePaint.Canvas);
  Label2.Caption := IntToStr(ShapesList.Count);
  //lookCell (Backpuffer.Canvas);
  //cellStates (Backpuffer.Canvas);
end;


procedure TMovePlate.B_delMarktClick(Sender: TObject);
begin
  // --- delete each market
  ShapesList.Count := 0;
end;

// *** Alle Zellen wieder schwarz ***
procedure TMovePlate.ButtonPauseClick(Sender: TObject);
begin
  fertig := Not fertig; //true;
  If MovePlate.Color = clRed Then begin
    MovePlate.Color := clBlack;
    exit;
  end;
  MovePlate.Color := clRed;
end;

// *** Agenten l�schen ***
procedure TMovePlate.Button_DeleteClick(Sender: TObject);
begin
ShapesList.Count := ShapesList.Count - 100;
  Label2.Caption := IntToStr(ShapesList.Count);
end;

// ***************************
// ******* ScrollBars ********
// ***************************

// *** MausInteraktionsRadius ***
procedure TMovePlate.ScrollBar1Change(Sender: TObject);
begin
    Mouse_Rad            := ScrollBar1.Position;
    Label_Radius.Caption := IntToStr(Mouse_Rad);
end;

// *** ***
procedure TMovePlate.SB_AnbauErtrChange(Sender: TObject);
begin
  Lbl_AnbauErtr.Caption := IntToStr(SB_AnbauErtr.Position);
  SetzeErtrag (0);
end;

procedure TMovePlate.SB_AnbauErtr2Change(Sender: TObject);
begin
  Lbl_AnbauErtr2.Caption := IntToStr(SB_AnbauErtr2.Position);
  SetzeErtrag (1);
end;

procedure TMovePlate.SB_AnbauErtr3Change(Sender: TObject);
begin
  Lbl_AnbauErtr3.Caption := IntToStr(SB_AnbauErtr3.Position);
  SetzeErtrag (2);
end;

procedure TMovePlate.SetzeErtrag(const J : Integer);
var
  I : Integer;
  K : Integer;
begin
  for I := 0 to reih -1 do
  begin
    for K := 0 to spalt -1 do
    begin
      case J of
        0: cellList[I,K].Ertrag[J] := SB_AnbauErtr.Position;
        1: cellList[I,K].Ertrag[J] := SB_AnbauErtr2.Position;
        2: cellList[I,K].Ertrag[J] := SB_AnbauErtr3.Position;
      end;
    end;
  end;
end;

// ***  ***
procedure TMovePlate.SB_ErzeugKostChange(Sender: TObject);
begin
  Lbl_ErzeugKost.Caption := IntToStr(SB_ErzeugKost.Position);
  SetzeErzeugKost (0);
end;

procedure TMovePlate.SB_ErzeugKost2Change(Sender: TObject);
begin
  Lbl_ErzeugKost2.Caption := IntToStr(SB_ErzeugKost2.Position);
  SetzeErzeugKost (1);
end;

procedure TMovePlate.SB_ErzeugKost3Change(Sender: TObject);
begin
  Lbl_ErzeugKost3.Caption := IntToStr(SB_ErzeugKost3.Position);
  SetzeErzeugKost (2);
end;

procedure TMovePlate.SetzeErzeugKost(const J : Integer);
var
  I : Integer;
  K : Integer;
begin
  for I := 0 to reih -1 do
  begin
    for K := 0 to spalt -1 do
    begin
      case J of
        0: cellList[I,K].ErzeugKost[J] := SB_ErzeugKost.Position;
        1: cellList[I,K].ErzeugKost[J] := SB_ErzeugKost2.Position;
        2: cellList[I,K].ErzeugKost[J] := SB_ErzeugKost3.Position;
      end;
    end;
  end;
end;

// *** ***
procedure TMovePlate.SB_MarktPrChange(Sender: TObject);
begin
  Lbl_MarktPr.Caption := IntToStr(SB_MarktPr.Position);
  SetzeMarktPr(0);
end;

procedure TMovePlate.SB_MarktPr2Change(Sender: TObject);
begin
  Lbl_MarktPr2.Caption := IntToStr(SB_MarktPr2.Position);
  SetzeMarktPr(1);
end;

procedure TMovePlate.SB_MarktPr3Change(Sender: TObject);
begin
  Lbl_MarktPr3.Caption := IntToStr(SB_MarktPr3.Position);
  SetzeMarktPr(2);
end;

procedure TMovePlate.SetzeMarktPr(const J : Integer);
var
  I : Integer;
  K : Integer;
begin
  for I := 0 to reih -1 do
  begin
    for K := 0 to spalt -1 do
    begin
      case J of
        0: cellList[I,K].MarktPreis[J] := SB_MarktPr.Position;
        1: cellList[I,K].MarktPreis[J] := SB_MarktPr2.Position;
        2: cellList[I,K].MarktPreis[J] := SB_MarktPr3.Position;
      end;
    end;
  end;
end;

procedure TMovePlate.SB_TranspKostChange(Sender: TObject);
begin
  Lbl_TranspKost.Caption := IntToStr(SB_TranspKost.Position);
  SetzeTranspKost(0);
end;

procedure TMovePlate.SB_TranspKost2Change(Sender: TObject);
begin
  Lbl_TranspKost2.Caption := IntToStr(SB_TranspKost2.Position);
  SetzeTranspKost(1);
end;

procedure TMovePlate.SB_TranspKost3Change(Sender: TObject);
begin
  Lbl_TranspKost3.Caption := IntToStr(SB_TranspKost3.Position);
  SetzeTranspKost(2);
end;

procedure TMovePlate.SetzeTranspKost(const J : Integer);
var
  I : Integer;
  K : Integer;
begin
  for I := 0 to reih -1 do
  begin
    for K := 0 to spalt -1 do
    begin
      case J of
        0: cellList[I,K].TranspKost[J] := SB_TranspKost.Position;
        1: cellList[I,K].TranspKost[J] := SB_TranspKost2.Position;
        2: cellList[I,K].TranspKost[J] := SB_TranspKost3.Position;
      end;
    end;
  end;
end;

// ******************************
// *** Array und Liste L�schen***
// ******************************
procedure TMovePlate.FormDestroy(Sender: TObject);
var
  I: Integer;
  J: Integer;
  K: Integer;
begin
  // --- delete each agent
  for I := ShapesList.Count - 1 downto 0 do
    TBaseShape (ShapesList [I]).Free;
  ShapesList.Free;
  // --- delete each cell
  for J := reih -1 downto 0 do
  begin
    for K := spalt -1 downto 0 do
    begin
      TBaseShape (cellList[J,K]).Free;
    end;
  end;
end;

end.

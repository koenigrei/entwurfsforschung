object MovePlate: TMovePlate
  Left = 0
  Top = 0
  Width = 800
  Height = 905
  Caption = 'MovePlate'
  Color = clSilver
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -10
  Font.Name = 'Tahoma'
  Font.Style = []
  OldCreateOrder = False
  OnCreate = FormCreate
  OnDestroy = FormDestroy
  PixelsPerInch = 96
  TextHeight = 12
  object Label1: TLabel
    Left = 6
    Top = 474
    Width = 72
    Height = 13
    Caption = 'Anzahl M'#228'rkte:'
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clWhite
    Font.Height = -11
    Font.Name = 'Tahoma'
    Font.Style = []
    ParentFont = False
  end
  object Label2: TLabel
    Left = 84
    Top = 474
    Width = 24
    Height = 13
    Caption = '0000'
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clWhite
    Font.Height = -11
    Font.Name = 'Tahoma'
    Font.Style = []
    ParentFont = False
  end
  object Label3: TLabel
    Left = 630
    Top = 485
    Width = 61
    Height = 13
    Caption = 'MausRadius:'
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clWhite
    Font.Height = -11
    Font.Name = 'Tahoma'
    Font.Style = []
    ParentFont = False
  end
  object Label_Radius: TLabel
    Left = 702
    Top = 485
    Width = 24
    Height = 13
    Caption = '____'
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clWhite
    Font.Height = -11
    Font.Name = 'Tahoma'
    Font.Style = []
    ParentFont = False
  end
  object ScrollBar1: TScrollBar
    Left = 630
    Top = 505
    Width = 97
    Height = 15
    Max = 200
    PageSize = 0
    Position = 60
    TabOrder = 0
    OnChange = ScrollBar1Change
  end
  object Button2: TButton
    Left = 630
    Top = 527
    Width = 67
    Height = 18
    Caption = 'Attract/Repel'
    TabOrder = 1
    OnMouseUp = Button2MouseUp
  end
  object CB_moveMarkt: TCheckBox
    Left = 6
    Top = 492
    Width = 97
    Height = 13
    Caption = 'M'#228'rkte bewegen'
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clWhite
    Font.Height = -11
    Font.Name = 'Tahoma'
    Font.Style = []
    ParentFont = False
    TabOrder = 2
  end
  object ButtonPause: TButton
    Left = 736
    Top = 505
    Width = 50
    Height = 15
    Caption = 'Pause'
    TabOrder = 3
    OnClick = ButtonPauseClick
  end
  object CB_Distanz: TCheckBox
    Left = 6
    Top = 510
    Width = 103
    Height = 13
    Caption = 'Distanzen anzeigen'
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clWhite
    Font.Height = -11
    Font.Name = 'Tahoma'
    Font.Style = []
    ParentFont = False
    TabOrder = 4
  end
  object GroupBox1: TGroupBox
    Left = 6
    Top = 0
    Width = 779
    Height = 469
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clWindowText
    Font.Height = -11
    Font.Name = 'Tahoma'
    Font.Style = []
    ParentFont = False
    TabOrder = 5
    object ImagePaint: TImage
      Left = 2
      Top = 10
      Width = 775
      Height = 455
      OnClick = ImagePaintClick
      OnMouseMove = ImagePaintMouseMove
    end
  end
  object GroupBox2: TGroupBox
    Left = 6
    Top = 552
    Width = 251
    Height = 91
    Caption = 'Produkt A - Gelb'
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clWindow
    Font.Height = -11
    Font.Name = 'Tahoma'
    Font.Style = []
    ParentFont = False
    TabOrder = 6
    object Label11: TLabel
      Left = 37
      Top = 19
      Width = 65
      Height = 13
      Caption = 'Anbauertrag:'
      Font.Charset = DEFAULT_CHARSET
      Font.Color = clWhite
      Font.Height = -11
      Font.Name = 'Tahoma'
      Font.Style = []
      ParentFont = False
    end
    object Lbl_AnbauErtr: TLabel
      Left = 112
      Top = 19
      Width = 24
      Height = 13
      Caption = '____'
      Font.Charset = DEFAULT_CHARSET
      Font.Color = clWhite
      Font.Height = -11
      Font.Name = 'Tahoma'
      Font.Style = []
      ParentFont = False
    end
    object Label8: TLabel
      Left = 10
      Top = 37
      Width = 92
      Height = 13
      Caption = 'Erzeugungskosten:'
      Font.Charset = DEFAULT_CHARSET
      Font.Color = clWhite
      Font.Height = -11
      Font.Name = 'Tahoma'
      Font.Style = []
      ParentFont = False
    end
    object Lbl_ErzeugKost: TLabel
      Left = 112
      Top = 37
      Width = 24
      Height = 13
      Caption = '____'
      Font.Charset = DEFAULT_CHARSET
      Font.Color = clWhite
      Font.Height = -11
      Font.Name = 'Tahoma'
      Font.Style = []
      ParentFont = False
    end
    object Label6: TLabel
      Left = 48
      Top = 55
      Width = 54
      Height = 13
      Caption = 'Marktpreis:'
      Font.Charset = DEFAULT_CHARSET
      Font.Color = clWhite
      Font.Height = -11
      Font.Name = 'Tahoma'
      Font.Style = []
      ParentFont = False
    end
    object Lbl_MarktPr: TLabel
      Left = 112
      Top = 55
      Width = 24
      Height = 13
      Caption = '____'
      Font.Charset = DEFAULT_CHARSET
      Font.Color = clWhite
      Font.Height = -11
      Font.Name = 'Tahoma'
      Font.Style = []
      ParentFont = False
    end
    object Label14: TLabel
      Left = 19
      Top = 73
      Width = 83
      Height = 13
      Caption = 'Transportkosten:'
      Font.Charset = DEFAULT_CHARSET
      Font.Color = clWhite
      Font.Height = -11
      Font.Name = 'Tahoma'
      Font.Style = []
      ParentFont = False
    end
    object Lbl_TranspKost: TLabel
      Left = 112
      Top = 73
      Width = 24
      Height = 13
      Caption = '____'
      Font.Charset = DEFAULT_CHARSET
      Font.Color = clWhite
      Font.Height = -11
      Font.Name = 'Tahoma'
      Font.Style = []
      ParentFont = False
    end
    object SB_AnbauErtr: TScrollBar
      Left = 148
      Top = 16
      Width = 97
      Height = 15
      LargeChange = 10
      Max = 10000
      Min = 1
      PageSize = 8
      Position = 2500
      TabOrder = 0
      OnChange = SB_AnbauErtrChange
    end
    object SB_ErzeugKost: TScrollBar
      Left = 148
      Top = 34
      Width = 97
      Height = 15
      LargeChange = 10
      Max = 1000
      Min = 1
      PageSize = 8
      Position = 10
      TabOrder = 1
      OnChange = SB_ErzeugKostChange
    end
    object SB_MarktPr: TScrollBar
      Left = 148
      Top = 52
      Width = 97
      Height = 15
      LargeChange = 10
      Max = 1000
      Min = 1
      PageSize = 8
      Position = 400
      TabOrder = 2
      OnChange = SB_MarktPrChange
    end
    object SB_TranspKost: TScrollBar
      Left = 148
      Top = 70
      Width = 97
      Height = 15
      LargeChange = 10
      Max = 50
      Min = 1
      PageSize = 8
      Position = 5
      TabOrder = 3
      OnChange = SB_TranspKostChange
    end
  end
  object GroupBox3: TGroupBox
    Left = 272
    Top = 552
    Width = 257
    Height = 91
    Caption = 'Produkt B - Gr'#252'n'
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clWindow
    Font.Height = -11
    Font.Name = 'Tahoma'
    Font.Style = []
    ParentFont = False
    TabOrder = 7
    object Label4: TLabel
      Left = 37
      Top = 19
      Width = 65
      Height = 13
      Caption = 'Anbauertrag:'
      Font.Charset = DEFAULT_CHARSET
      Font.Color = clWhite
      Font.Height = -11
      Font.Name = 'Tahoma'
      Font.Style = []
      ParentFont = False
    end
    object Lbl_AnbauErtr2: TLabel
      Left = 112
      Top = 19
      Width = 24
      Height = 13
      Caption = '____'
      Font.Charset = DEFAULT_CHARSET
      Font.Color = clWhite
      Font.Height = -11
      Font.Name = 'Tahoma'
      Font.Style = []
      ParentFont = False
    end
    object Label9: TLabel
      Left = 10
      Top = 37
      Width = 92
      Height = 13
      Caption = 'Erzeugungskosten:'
      Font.Charset = DEFAULT_CHARSET
      Font.Color = clWhite
      Font.Height = -11
      Font.Name = 'Tahoma'
      Font.Style = []
      ParentFont = False
    end
    object Lbl_ErzeugKost2: TLabel
      Left = 112
      Top = 37
      Width = 24
      Height = 13
      Caption = '____'
      Font.Charset = DEFAULT_CHARSET
      Font.Color = clWhite
      Font.Height = -11
      Font.Name = 'Tahoma'
      Font.Style = []
      ParentFont = False
    end
    object Label12: TLabel
      Left = 48
      Top = 55
      Width = 54
      Height = 13
      Caption = 'Marktpreis:'
      Font.Charset = DEFAULT_CHARSET
      Font.Color = clWhite
      Font.Height = -11
      Font.Name = 'Tahoma'
      Font.Style = []
      ParentFont = False
    end
    object Lbl_MarktPr2: TLabel
      Left = 112
      Top = 55
      Width = 24
      Height = 13
      Caption = '____'
      Font.Charset = DEFAULT_CHARSET
      Font.Color = clWhite
      Font.Height = -11
      Font.Name = 'Tahoma'
      Font.Style = []
      ParentFont = False
    end
    object Label15: TLabel
      Left = 19
      Top = 73
      Width = 83
      Height = 13
      Caption = 'Transportkosten:'
      Font.Charset = DEFAULT_CHARSET
      Font.Color = clWhite
      Font.Height = -11
      Font.Name = 'Tahoma'
      Font.Style = []
      ParentFont = False
    end
    object Lbl_TranspKost2: TLabel
      Left = 112
      Top = 73
      Width = 24
      Height = 13
      Caption = '____'
      Font.Charset = DEFAULT_CHARSET
      Font.Color = clWhite
      Font.Height = -11
      Font.Name = 'Tahoma'
      Font.Style = []
      ParentFont = False
    end
    object SB_AnbauErtr2: TScrollBar
      Left = 148
      Top = 16
      Width = 97
      Height = 15
      LargeChange = 10
      Max = 10000
      Min = 1
      PageSize = 8
      Position = 500
      TabOrder = 0
      OnChange = SB_AnbauErtr2Change
    end
    object SB_ErzeugKost2: TScrollBar
      Left = 148
      Top = 34
      Width = 97
      Height = 15
      LargeChange = 10
      Max = 1000
      Min = 1
      PageSize = 8
      Position = 1
      TabOrder = 1
      OnChange = SB_ErzeugKost2Change
    end
    object SB_MarktPr2: TScrollBar
      Left = 148
      Top = 52
      Width = 97
      Height = 15
      LargeChange = 10
      Max = 1000
      Min = 1
      PageSize = 8
      Position = 900
      TabOrder = 2
      OnChange = SB_MarktPr2Change
    end
    object SB_TranspKost2: TScrollBar
      Left = 148
      Top = 70
      Width = 97
      Height = 15
      LargeChange = 10
      Max = 50
      Min = 1
      PageSize = 8
      Position = 6
      TabOrder = 3
      OnChange = SB_TranspKost2Change
    end
  end
  object GroupBox4: TGroupBox
    Left = 536
    Top = 552
    Width = 253
    Height = 91
    Caption = 'Produkt C - Weiss'
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clWindow
    Font.Height = -11
    Font.Name = 'Tahoma'
    Font.Style = []
    ParentFont = False
    TabOrder = 8
    object Label17: TLabel
      Left = 37
      Top = 19
      Width = 65
      Height = 13
      Caption = 'Anbauertrag:'
      Font.Charset = DEFAULT_CHARSET
      Font.Color = clWhite
      Font.Height = -11
      Font.Name = 'Tahoma'
      Font.Style = []
      ParentFont = False
    end
    object Lbl_AnbauErtr3: TLabel
      Left = 112
      Top = 19
      Width = 24
      Height = 13
      Caption = '____'
      Font.Charset = DEFAULT_CHARSET
      Font.Color = clWhite
      Font.Height = -11
      Font.Name = 'Tahoma'
      Font.Style = []
      ParentFont = False
    end
    object Label19: TLabel
      Left = 10
      Top = 37
      Width = 92
      Height = 13
      Caption = 'Erzeugungskosten:'
      Font.Charset = DEFAULT_CHARSET
      Font.Color = clWhite
      Font.Height = -11
      Font.Name = 'Tahoma'
      Font.Style = []
      ParentFont = False
    end
    object Lbl_ErzeugKost3: TLabel
      Left = 112
      Top = 37
      Width = 24
      Height = 13
      Caption = '____'
      Font.Charset = DEFAULT_CHARSET
      Font.Color = clWhite
      Font.Height = -11
      Font.Name = 'Tahoma'
      Font.Style = []
      ParentFont = False
    end
    object Label21: TLabel
      Left = 48
      Top = 55
      Width = 54
      Height = 13
      Caption = 'Marktpreis:'
      Font.Charset = DEFAULT_CHARSET
      Font.Color = clWhite
      Font.Height = -11
      Font.Name = 'Tahoma'
      Font.Style = []
      ParentFont = False
    end
    object Lbl_MarktPr3: TLabel
      Left = 112
      Top = 55
      Width = 24
      Height = 13
      Caption = '____'
      Font.Charset = DEFAULT_CHARSET
      Font.Color = clWhite
      Font.Height = -11
      Font.Name = 'Tahoma'
      Font.Style = []
      ParentFont = False
    end
    object Label23: TLabel
      Left = 19
      Top = 73
      Width = 83
      Height = 13
      Caption = 'Transportkosten:'
      Font.Charset = DEFAULT_CHARSET
      Font.Color = clWhite
      Font.Height = -11
      Font.Name = 'Tahoma'
      Font.Style = []
      ParentFont = False
    end
    object Lbl_TranspKost3: TLabel
      Left = 112
      Top = 73
      Width = 24
      Height = 13
      Caption = '____'
      Font.Charset = DEFAULT_CHARSET
      Font.Color = clWhite
      Font.Height = -11
      Font.Name = 'Tahoma'
      Font.Style = []
      ParentFont = False
    end
    object SB_AnbauErtr3: TScrollBar
      Left = 148
      Top = 16
      Width = 97
      Height = 15
      LargeChange = 10
      Max = 10000
      Min = 1
      PageSize = 8
      Position = 2000
      TabOrder = 0
      OnChange = SB_AnbauErtr3Change
    end
    object SB_ErzeugKost3: TScrollBar
      Left = 148
      Top = 34
      Width = 97
      Height = 15
      LargeChange = 10
      Max = 1000
      Min = 1
      PageSize = 8
      Position = 6
      TabOrder = 1
      OnChange = SB_ErzeugKost3Change
    end
    object SB_MarktPr3: TScrollBar
      Left = 148
      Top = 52
      Width = 97
      Height = 15
      LargeChange = 10
      Max = 1000
      Min = 1
      PageSize = 8
      Position = 400
      TabOrder = 2
      OnChange = SB_MarktPr3Change
    end
    object SB_TranspKost3: TScrollBar
      Left = 148
      Top = 70
      Width = 97
      Height = 15
      LargeChange = 10
      Max = 50
      Min = 1
      PageSize = 8
      Position = 3
      TabOrder = 3
      OnChange = SB_TranspKost3Change
    end
  end
  object GroupBox5: TGroupBox
    Left = 150
    Top = 474
    Width = 469
    Height = 67
    Caption = 'Bedienung:'
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clWindow
    Font.Height = -11
    Font.Name = 'Tahoma'
    Font.Style = []
    ParentFont = False
    TabOrder = 9
    object Label5: TLabel
      Left = 6
      Top = 18
      Width = 294
      Height = 13
      Caption = 'Markt erstellen: Linke Maustaste innerhalb der Zeichenfl'#228'che.'
    end
    object Label7: TLabel
      Left = 6
      Top = 33
      Width = 370
      Height = 13
      Caption = 
        'Mausinteraktion (rechts) funktioniert nur wenn '#39'M'#228'rkte bewegen'#39' ' +
        'aktiviert ist.'
    end
    object Label10: TLabel
      Left = 6
      Top = 48
      Width = 456
      Height = 13
      Caption = 
        #39'Distanzen / Lagerente anzeigen'#39' wechselt die Darstellung: Th'#252'ne' +
        'nringe, Lagerente, Distanzen.'
    end
  end
  object CB_Lagerente: TCheckBox
    Left = 6
    Top = 528
    Width = 103
    Height = 13
    Caption = 'Lagerente anzeigen'
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clWhite
    Font.Height = -11
    Font.Name = 'Tahoma'
    Font.Style = []
    ParentFont = False
    TabOrder = 10
  end
  object B_delMarkt: TButton
    Left = 704
    Top = 527
    Width = 81
    Height = 18
    Caption = 'M'#228'rkte l'#246'schen'
    TabOrder = 11
    OnClick = B_delMarktClick
  end
  object ApplicationEvents1: TApplicationEvents
    OnIdle = ApplicationEvents1Idle
    Left = 120
    Top = 72
  end
end

program thuenen2;

uses
  Forms,
  facsSteer in 'facsSteer.pas' {MovePlate},
  cell in 'cell.pas',
  agenten in 'agenten.pas';

{$R *.res}

begin
  Application.Initialize;
  Application.CreateForm(TMovePlate, MovePlate);
  Application.Run;
end.

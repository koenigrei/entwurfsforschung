program A_Stern;

uses
  Forms,
  facsSteer in 'facsSteer.pas' {MovePlate},
  cell in 'cell.pas';

{$R *.res}

begin
  Application.Initialize;
  Application.CreateForm(TMovePlate, MovePlate);
  Application.Run;
end.

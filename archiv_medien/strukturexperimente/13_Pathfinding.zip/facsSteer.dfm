object MovePlate: TMovePlate
  Left = 0
  Top = 0
  Width = 800
  Height = 600
  Caption = 'A-Stern Pathfinding'
  Color = clSilver
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -10
  Font.Name = 'Tahoma'
  Font.Style = []
  OldCreateOrder = False
  OnCreate = FormCreate
  OnDestroy = FormDestroy
  PixelsPerInch = 96
  TextHeight = 12
  object Panel1: TPanel
    Left = 6
    Top = 6
    Width = 763
    Height = 463
    Caption = 'Panel1'
    Color = clSilver
    DockSite = True
    TabOrder = 0
    object ImagePaint: TImage
      Left = 2
      Top = 2
      Width = 758
      Height = 458
      OnMouseDown = ImagePaintMouseDown
      OnMouseMove = ImagePaintMouseMove
      OnMouseUp = ImagePaintMouseUp
    end
  end
  object Panel2: TPanel
    Left = 6
    Top = 470
    Width = 763
    Height = 91
    Caption = 'Panel2'
    Color = clBlack
    DockSite = True
    TabOrder = 1
    object B_Path: TButton
      Left = 30
      Top = 18
      Width = 73
      Height = 67
      Caption = 'find Path'
      TabOrder = 0
      OnClick = B_PathClick
    end
    object GroupBox1: TGroupBox
      Left = 108
      Top = 12
      Width = 259
      Height = 73
      Caption = 'Bedienung:'
      Font.Charset = DEFAULT_CHARSET
      Font.Color = clWindow
      Font.Height = -11
      Font.Name = 'Tahoma'
      Font.Style = []
      ParentFont = False
      TabOrder = 1
      object Label1: TLabel
        Left = 74
        Top = 12
        Width = 186
        Height = 13
        Align = alCustom
        Caption = 'linke Maustaste : Startpunkt versetzen'
        Layout = tlCenter
      end
      object Label2: TLabel
        Left = 66
        Top = 24
        Width = 188
        Height = 13
        Align = alCustom
        Caption = 'rechte Maustaste : Zielpunkt versetzen'
        Layout = tlCenter
      end
      object Label3: TLabel
        Left = 60
        Top = 42
        Width = 172
        Height = 13
        Align = alCustom
        Caption = 'mittlere Maustaste : Wand zeichnen'
        Layout = tlCenter
      end
      object Label4: TLabel
        Left = 29
        Top = 54
        Width = 202
        Height = 13
        Align = alCustom
        Caption = 'mittlere Maustaste + Shift : Wand l'#246'schen'
        Layout = tlCenter
      end
    end
  end
  object Timer1: TTimer
    Interval = 1
    OnTimer = Timer1Timer
    Left = 192
    Top = 72
  end
end

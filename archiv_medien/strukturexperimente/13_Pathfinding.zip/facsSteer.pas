(********************************************************************)
(*                                                                  *) 
(*                                                                  *)
(*                         Pathfinding                              *)
(*                     mit A-Stern Algorithmus                      *)
(*                          Version 1.0                             *)
(*                                                                  *) 
(*     Programmierer: Reinhard K�nig                     July 2005  *)
(*                    http://www.entwurfsforschung.de/              *)
(*                                                                  *)
(*     Last Update: July-16, 2005                                   *)
(*                                                                  *) 
(********************************************************************) 
{revision history:

1.0     [July-16, 2005]
        first release to the public

        [July-17, 2005]
        W�nde werden nicht diagonal geschnitten 
}

unit facsSteer;

interface

uses
  Windows, Messages, SysUtils, Variants, Classes, Graphics, Controls, Forms, cell,
  Dialogs, ExtCtrls, ConvUtils, StdCtrls, AppEvnts, Types, Menus;

type
  TMovePlate = class(TForm)
    Panel1: TPanel;
    ImagePaint: TImage;
    Panel2: TPanel;
    B_Path: TButton;
    Timer1: TTimer;
    GroupBox1: TGroupBox;
    Label1: TLabel;
    Label2: TLabel;
    Label3: TLabel;
    Label4: TLabel;
    procedure Timer1Timer(Sender: TObject);
    procedure ImagePaintMouseMove(Sender: TObject; Shift: TShiftState; X,
      Y: Integer);
    procedure ImagePaintMouseDown(Sender: TObject; Button: TMouseButton;
      Shift: TShiftState; X, Y: Integer);
    procedure ImagePaintMouseUp(Sender: TObject; Button: TMouseButton;
      Shift: TShiftState; X, Y: Integer);
    procedure B_PathClick(Sender: TObject);
    procedure FormDestroy(Sender: TObject);
    procedure FormCreate(Sender: TObject);
  private
    { Private declarations }
    openList  : TList;
    closedList: TList;
    cellList  : Array of Array of TCell;
    procedure updateScreen (Canvas: TCanvas);
    procedure RectanglPaint  (Canvas: TCanvas);
    procedure RectanglCreate (Canvas: TCanvas);
    procedure deleteZells;
    procedure deletePath;
    procedure findPath;
    procedure checkNeighbour (xPos : Integer; yPos : Integer);
    procedure calcF          (vorg: TCell; me: TCell);
  public
    { Public declarations }
  end;

var
  MovePlate: TMovePlate;

implementation

{$R *.dfm}

const
  cellScal  = 14;

var
  reih      : Integer;
  spalt     : Integer;
  LEFT_BORDER   : Integer;
  TOP_BORDER    : Integer;
  RIGHT_BORDER  : Integer;
  BOTTOM_BORDER : Integer;
  MouseX        : Integer;
  MouseY        : Integer;
  Backpuffer    : TBitmap;
  startCell     : TCell;
  zielCell      : TCell;
  MDown         : Boolean;
  SDown         : Boolean;
  foundPath     : Boolean;
  cutWall       : Boolean;

// TList sort routine : compare customers by name
// --------------------------------------------------------------------------
// The returned integer has the following value :
//
//   > 0 : (positive) Item1 is less than Item2
//     0 : Item1 is equal to Item2
//   < 0 : (negative) Item1 is greater than Item2
function compareByF(Item1 : Pointer; Item2 : Pointer) : Integer;
var
  customer1, customer2 : TCell;
begin
  // We start by viewing the object pointers as TCell objects
  customer1 := TCell(Item1);
  customer2 := TCell(Item2);
  // Now compare by F - complete Kosts
  if   customer1.F < customer2.F
    then Result := 1
  else if customer1.F = customer2.F
    then Result := 0
  else   Result := -1;
end;

procedure TMovePlate.FormCreate(Sender: TObject);
begin
  // --- deklarieren des Arrays f�r die 'Cellen' -------------------------------
  spalt := round (ImagePaint.Width / cellScal);
  reih  := round (ImagePaint.Height / cellScal);
  SetLength(cellList, reih, spalt);
  // --- initialization and creation of the list -------------------------------
  openList                      := TList.Create;
  closedList                    := TList.Create;
  MovePlate.Color               := clBlack;
  MovePlate.Panel2.Color        := clInfoText;
  MovePlate.Canvas.Pen.Color    := clred;
  MovePlate.Canvas.Brush.Color  := clred;
  LEFT_BORDER                   := ImagePaint.Left-5;
  TOP_BORDER                    := ImagePaint.Top-5;
  RIGHT_BORDER                  := ImagePaint.Width-5;
  BOTTOM_BORDER                 := ImagePaint.Height-5;
  // --- Slider & Label --------------------------------------------------------

  // --- Zwischenspeicher f�r die Bildaktualisierung ---------------------------
  Backpuffer                    := TBitmap.create;
  Backpuffer.width              := ImagePaint.width;
  Backpuffer.height             := ImagePaint.height;
  Backpuffer.canvas.brush.color := clgreen;
  Backpuffer.canvas.rectangle   (10,10,Backpuffer.width,Backpuffer.height);
  RectanglCreate (Backpuffer.Canvas);
  Timer1.Enabled := false;
  SDown := false;
end;

// *** Aktualisierungen je Durchlauf***
procedure TMovePlate.updateScreen (Canvas: TCanvas);
begin
  // --- berechnen, zeichnen und verbinden ----
  RectanglPaint (Backpuffer.Canvas);  // --- L�scht Zeichung und Aktualisiert Zellen

  /// --- Bild aktualisieren ---
  //BitBlt(Backpuffer.Canvas.Handle, bildleft, bildtop, Bild.Width, Bild.Height, Bild.canvas.handle, 0, 0, SRCCOPY);//Bild auf Backpuffer kopieren
  ImagePaint.Invalidate;
  BitBlt(ImagePaint.Canvas.Handle, 0, 0, Backpuffer.Width, Backpuffer.Height, Backpuffer.canvas.handle, 0, 0, SRCCOPY);//Backpuffer auf das Formular kopieren
end;


// *********************************
// *** ------- Zellen ---------- ***
//**********************************
// *** Erstellt das ZellenRaster ***
procedure TMovePlate.RectanglCreate (Canvas: TCanvas);
var
  I    : Integer;
  K    : Integer;
begin
  for I := 0 to reih -1 do
  begin
    for K := 0 to spalt -1 do
    begin
      cellList[I,K] := TCell.Create;
      //--- Variablen in Abh. der Produkte dimensionieren ---
      cellList[I,K].PositionX := K * cellScal + round(cellScal / 2);
      cellList[I,K].PositionY := I * cellScal + round(cellScal / 2);
      cellList[I,K].FReihPosY := I;
      cellList[I,K].FSpaltPosX:= K;
      cellList[I,K].Size := round (cellScal / 2)+1;
      cellList[I,K].F:= 0;
      cellList[I,K].G:= 0;
      cellList[I,K].H:= 0;
      cellList[I,K].closed:= false;
      cellList[I,K].State:= 0;
      cellList[I,K].Paint(Canvas);
    end ;
  end;
  // --- Start- und Zielpunkte festlegen ---
  startCell := cellList[20,5];
  startCell.FillColor := clGreen;
  startCell.state := 1;
  zielCell := cellList[20,50];
  zielCell.FillColor := clRed;
  zielCell.state := 1;
  // --- Wand ---
  for I := 0 to 20 Do begin
    cellList[(10 + I),30].State:= 999;
    cellList[(10 + I),30].FillColor:= clBlue;
  end;
  updateScreen (Canvas);
end;

// *** Aktualisiert das ZellenRaster ***
procedure TMovePlate.RectanglPaint (Canvas: TCanvas);
var
  I    : Integer;
  K    : Integer;
//  used : Integer;
begin
  //--- Backbuffer l�schen
  canvas.brush.color := clGreen;
  canvas.pen.color := clGreen;
  canvas.rectangle(10,10,Backpuffer.width,Backpuffer.height);
  for I := 0 to reih -1 do
  begin
    for K := 0 to spalt -1 do
    begin
//      used := cellList[I,K].F;
      cellList[I,K].Paint(Canvas);
    end ;
  end;
end;

// *** Zellen l�schen ***
procedure TMovePlate.deleteZells;
var
  I : Integer;
  K : Integer;
begin
  for I := reih -1 downto 0 do
  begin
    for K := spalt -1 downto 0 do
    begin
      TBaseCell (cellList[I,K]).Free;
    end;
  end;
end;

procedure TMovePlate.checkNeighbour (xPos: Integer; yPos: Integer);
var
  I       : Integer;
  K       : Integer;
  U       : Integer;
  state   : Integer;
  altG    : Integer;
  altH    : Integer;
  altF    : Integer;
  inOpen  : Boolean;

begin
  state := 0;
  for I := xPos - 1 to xPos + 1 do
  begin
    for K := yPos - 1 to yPos + 1 do
    begin
      // --- nicht untersucht werden W�nde und closed Nodes
      If ((I >= 0) and (K >= 0) and (I < reih) and (K < spalt)) then // --- Randbedingungen
      If ((cellList[I,K].State < 999) and (cellList[I,K].Closed = false)) then
      begin
        inOpen := false;
        for U := 0 To openList.count -1 do  // --- pr�ft, ob Knoten bereits in openList
        begin
          If (openList.Items[U] = cellList[I,K]) then begin
            inOpen := true;
          end;
        end;
        If inOpen = false then
        begin
          calcF (cellList[xPos,YPos], cellList[I,K]);
          If (cutWall = false) then begin //--- pr�fe, ob diagonal �ber Wand ---
            cellList[I,K].Vorg := cellList[xPos,YPos];
            openList.Add(cellList[I,K]);
            If (cellList[I,K] = zielCell) Then begin
              foundPath := true; // Ziel erreicht
            end;
          end;
        end else begin
          //pr�fe, ob G g�nstiger => ver�ndere Vorg
          altG := cellList[I,K].G; // G-Wert vor der neuBerechnung
          altH := cellList[I,K].H;
          altF := cellList[I,K].F;
          calcF (cellList[xPos,YPos], cellList[I,K]);
          If (altG < cellList[I,K].G) or (cutWall = true) Then begin
            cellList[I,K].G := altG;
            cellList[I,K].H := altH;
            cellList[I,K].F := altF;
          end else begin
            cellList[I,K].Vorg := cellList[xPos,YPos];
          end;
        end;
      end;
    end;
  end;
end;

procedure TMovePlate.calcF (vorg: TCell; me: TCell);
var
  distX    : Integer;
  distY    : Integer;
  I        : Integer;
  K        : Integer;
  U        : Integer;
begin
  // ----- Berechne G -----
  distX := abs(vorg.FSpaltPosX - me.FSpaltPosX);
  distY := abs(vorg.FReihPosY  - me.FReihPosY);
  If ((distX = 1) and (distY = 1)) then begin
    me.G := vorg.G + 14;
    // --- pr�fe, ob Wand diagonl geschnitten wird ----
    cutWall := false;
    For U:= 0 to 3 Do begin
      K := me.FSpaltPosX;
      I := me.FReihPosY;
      case U of
        0: I := I+1;
        1: K := K+1;
        2: I := I-1;
        3: K := K-1;
      end;
      If (( I >= 0) and (K >= 0) and (I < reih) and (K < spalt)) then // --- Randbedingungen
      begin
        If (cellList[I,K].State = 999) then begin
          cutWall := true;  // --- Wand wird diagonal geschnitten!
        end;
      end;
    end;
    // -------------------------------------------------
  end else
  begin
    me.G := vorg.G + 10;
    cutWall := false;
  end;
  // ----- Berechne H -----
  distX := abs(zielCell.FSpaltPosX - me.FSpaltPosX);
  distY := abs(zielCell.FReihPosY  - me.FReihPosY);
  me.H := distX * 10 + distY * 10;
  // ----- Berechne F -----
  me.F := me.G + me.H;
end;

// ***************************
// ********* Buttons *********
// ***************************

// *** path find ***
procedure TMovePlate.B_PathClick(Sender: TObject);
begin
  findPath;
end;

procedure TMovePlate.findPath;
var
  explNode : TCell;
begin
  foundPath := false;
  deletePath;
  openList.Add(startCell);
  // --- Wdh. bis openList.count = 0 oder foundPath = true
  While ((openList.count > 0) And (foundPath = false)) Do
  begin
    explNode := openList.Items[openList.count -1];
    explNode.closed := true;
    checkNeighbour (explNode.FReihPosY, explNode.FSpaltPosX);
    openList.Sort(compareByF);
    openList.Remove(explNode);
  end;
  zielCell.FillColor := clRed;
  // --- zeichen den Pfad ---
  If foundPath = true Then begin
    repeat
      explNode.FillColor := clLime;
      explNode := explNode.Vorg;
    Until (explNode = startCell);
  end;
  updateScreen (Canvas);
end;

// *** Pfade l�schen ***
procedure TMovePlate.deletePath;
var
  I : Integer;
  K : Integer;
begin
  openList.Free;
  openList := TList.Create;
  zielCell.FillColor := clRed;
  for I := reih -1 downto 0 do
  begin
    for K := spalt -1 downto 0 do
    begin
      cellList[I,K].F:= 0;
      cellList[I,K].G:= 0;
      cellList[I,K].H:= 0;
      cellList[I,K].closed:= false;
      If cellList[I,K].state = 0 then cellList[I,K].FillColor := clBlack;
    end;
  end;
end;

// ***************************
// ******* ScrollBars ********
// ***************************

// -----------------------------------------------------------------------------

// ******************************
// *** Array und Liste L�schen***
// ******************************
procedure TMovePlate.FormDestroy(Sender: TObject);
begin
  // --- delete each cell
  deleteZells;
end;

// -----------------------------------------------------------------------------
//                         Maus Interaktion
// -----------------------------------------------------------------------------

procedure TMovePlate.ImagePaintMouseUp(Sender: TObject; Button: TMouseButton;
  Shift: TShiftState; X, Y: Integer);
var
  XCell  : Integer;
  YCell  : Integer;
begin
  XCell := round((X - (cellScal / 2)) / (cellScal));
  YCell := round((Y - (cellScal / 2)) / (cellScal));
  If button = mbRight then
  Begin
    If Not (zielCell = nil) then zielCell.FillColor := clBlack;
    zielCell := cellList[YCell,XCell];
    cellList[YCell,XCell].FillColor := clRed;
    cellList[YCell,XCell].state := 1;
  end else
  If button = mbLeft then
  Begin
    If Not (startCell = nil) then startCell.FillColor := clBlack;
    startCell := cellList[YCell,XCell];
    cellList[YCell,XCell].FillColor := clGreen;
    cellList[YCell,XCell].state := 1;
  end;
  MDown := false;
  Timer1.Enabled := false;
  findPath;
  updateScreen (Canvas);
end;

procedure TMovePlate.ImagePaintMouseDown(Sender: TObject; Button: TMouseButton;
  Shift: TShiftState; X, Y: Integer);
begin
  Timer1.Enabled := true;
  If button = mbMiddle then  MDown := true;
  if ssShift in Shift  then begin SDown := true
  end else SDown := false;
  updateScreen (Canvas);
end;

procedure TMovePlate.ImagePaintMouseMove(Sender: TObject; Shift: TShiftState; X,
  Y: Integer);
begin
  MouseX := X;
  MouseY := Y;
end;

procedure TMovePlate.Timer1Timer(Sender: TObject);
var
  XCell  : Integer;
  YCell  : Integer;
begin
  XCell := round((MouseX - (cellScal / 2)) / (cellScal));
  YCell := round((MouseY - (cellScal / 2)) / (cellScal));
  If MDown = true then
  Begin
    If SDown = false then begin
      cellList[YCell,XCell].FillColor := clBlue;
      cellList[YCell,XCell].State := 999;
    end else begin
      cellList[YCell,XCell].FillColor := clBlack;
      cellList[YCell,XCell].State := 0;
    end;
  end;
  updateScreen (Canvas);
end;

end.

unit cell;

interface

uses
  Windows, Graphics, Classes, Math;

type
  TNachbar = record
  NPos  : TPoint;
  NDist : Integer;
  end;

type
  TBaseCell = class
  private
  public
    F  : Integer;
    G  : Integer;
    H  : Integer;
    Vorg : Pointer;
    closed : Boolean;
    {BewerbList : TList;
    NRent      : Array of Integer;
    AkzeptList : TList;
    ARent      : Array of Integer;
    DistMarkt  : Array of Double; }
    //--------------------------------------------------------------------------
    FPositionX: Integer;
    FPositionY: Integer;
    FReihPosY : Integer;
    FSpaltPosX: Integer;
    FSize     : Integer;
    FStepX    : Double;
    FStepY    : Double;
    FFillColor: Integer;
    FState    : Integer; //--- Speichert den Produktindex der h�chsten Lagerente
    FPassed   : Integer;

    FDistance : Integer;
    FMaxRente : Integer;           //--- Maximalwert aus dem Lagerenten-Array
    FLagerente: Array of Integer;  //--- Lagerenten der versch Funktionen
    //--------------------------------------------------------------------------
    FErtrag    : Array of Integer; //--- Werden in jeder Zelle gespeichert, um
    FErzeugKost: Array of Integer; //--- die Werte sp�ter von der Bodenqualit�t
    FTranspKost: Array of Integer; //--- und anderen lokalen Bedingungen abh�ngig zu machen
    FMarktPreis: Array of Integer;
    //--------------------------------------------------------------------------
    procedure SetLagerente  (Index: Integer; Value: Integer);
    function  GetLagerente  (Index: Integer): Integer;
    property  Lagerente     [Index: Integer]: Integer read GetLagerente write SetLagerente;
    procedure SetErtrag     (Index: Integer; Value: Integer);
    function  GetErtrag     (Index: Integer): Integer;
    property  Ertrag        [Index: Integer]: Integer read GetErtrag write SetErtrag;
    procedure SetErzeugKost (Index: Integer; Value: Integer);
    function  GetErzeugKost (Index: Integer): Integer;
    property  ErzeugKost    [Index: Integer]: Integer read GetErzeugKost write SetErzeugKost;
    procedure SetTranspKost (Index: Integer; Value: Integer);
    function  GetTranspKost (Index: Integer): Integer;
    property  TranspKost    [Index: Integer]: Integer read GetTranspKost write SetTranspKost;
    procedure SetMarktPreis (Index: Integer; Value: Integer);
    function  GetMarktPreis (Index: Integer): Integer;
    property  MarktPreis    [Index: Integer]: Integer read GetMarktPreis write SetMarktPreis;
    procedure Paint         (Canvas: TCanvas); virtual;
    procedure SetPositionX  (const Value: Integer);
    procedure SetPositionY  (const Value: Integer);
    procedure SetReihPosY   (const Value: Integer);
    procedure SetSpaltPosX  (const Value: Integer);
    procedure SetStepX      (const Value: Double);
    procedure SetStepY      (const Value: Double);
    procedure SetSize       (const Value: Integer);
    procedure SetFillColor  (const Value: Integer);
    procedure SetState      (const Value: Integer);
    procedure SetPassed     (const Value: Integer);
    procedure SetDistance   (const Value: Integer);
    procedure SetMaxRente   (const Value: Integer);
    function  CalcDistance  (pX, pY: Integer): Integer;
  published
    //procedure calcF         (vorg: Pointer; ziel: Pointer);
    property PositionX: Integer read FPositionX write SetPositionX;
    property PositionY: Integer read FPositionY write SetPositionY;
    property ReihPosY : Integer read FReihPosY  write SetReihPosY;
    property SpaltPosX: Integer read FSpaltPosX write SetSpaltPosX;
    property StepX    : Double  read FStepX     write SetStepX;
    property StepY    : Double  read FStepY     write SetStepY;
    property Size     : Integer read FSize      write SetSize;
    property FillColor: Integer read FFillColor write SetFillColor;
    property State    : Integer read FState     write SetState;
    property Passed   : Integer read FPassed    write SetPassed;
    property Distance : Integer read FDistance  write SetDistance;
    property MaxRente : Integer read FMaxRente  write SetMaxRente;
  end;

type
  TCell = class (TBaseCell)
    procedure Paint (Canvas: TCanvas); override;
  end;

// ---------------------------------------------------------------------------//
implementation

function TBaseCell.CalcDistance(pX: Integer; pY: Integer): Integer;
  var temp: double;
  begin
  temp := sqrt(Power((pX - FPositionX), 2) + Power((pY - FPositionY), 2));
  Result := Round(temp);
end;

//------------------------------------------------------------------------------
procedure TBaseCell.SetMarktPreis (Index: Integer; Value: Integer);
begin
  FMarktPreis[Index] := Value;
end;

function TBaseCell.GetMarktPreis (Index: Integer): Integer;
begin
  Result := FMarktPreis[index];
end;
//------------------------------------------------------------------------------
procedure TBaseCell.SetTranspKost (Index: Integer; Value: Integer);
begin
  FTranspKost[Index] := Value;
end;

function TBaseCell.GetTranspKost (Index: Integer): Integer;
begin
  Result := FTranspKost[index];
end;
//------------------------------------------------------------------------------
procedure TBaseCell.SetErzeugKost (Index: Integer; Value: Integer);
begin
  FErzeugKost[Index] := Value;
end;

function TBaseCell.GetErzeugKost (Index: Integer): Integer;
begin
  Result := FErzeugKost[index];
end;
//------------------------------------------------------------------------------
procedure TBaseCell.SetErtrag (Index: Integer; Value: Integer);
begin
  FErtrag[Index] := Value;
end;

function TBaseCell.GetErtrag (Index: Integer): Integer;
begin
  Result := FErtrag[index];
end;
//------------------------------------------------------------------------------
procedure TBaseCell.SetLagerente (Index: Integer; Value: Integer);
begin
  FLagerente[Index] := Value;
end;

function TBaseCell.GetLagerente (Index: Integer): Integer;
begin
  Result := FLagerente[index];
end;
//------------------------------------------------------------------------------

procedure TBaseCell.SetMaxRente(const Value: Integer);
begin
  FMaxRente := Value;
end;

procedure TBaseCell.SetDistance(const Value: Integer);
begin
  FDistance := Value;
end;

procedure TBaseCell.Paint (Canvas: TCanvas);
begin
  Canvas.Pen.Width := 1;
end;

procedure TBaseCell.SetStepX(const Value: Double);
begin
  FStepX := Value;
end;

procedure TBaseCell.SetPassed(const Value: Integer);
begin
  FPassed := Value;
end;

procedure TBaseCell.SetStepY(const Value: Double);
begin
  FStepY := Value;
end;

procedure TBaseCell.SetPositionX(const Value: Integer);
begin
  FPositionX := Value;
end;

procedure TBaseCell.SetPositionY(const Value: Integer);
begin
  FPositionY := Value;
end;

procedure TBaseCell.SetReihPosY(const Value: Integer);
begin
  FReihPosY := Value;
end;

procedure TBaseCell.SetSpaltPosX(const Value: Integer);
begin
  FSpaltPosX := Value;
end;

procedure TBaseCell.SetSize(const Value: Integer);
begin
  FSize := Value;
end;

procedure TBaseCell.SetFillColor(const Value: Integer);
begin
  FFillColor := Value;
end;

procedure TBaseCell.SetState(const Value: Integer);
begin
  FState := Value;
end;

procedure TCell.Paint(Canvas: TCanvas);
begin
  inherited Paint (Canvas);
  Canvas.Pen.Color := clBlack;       //FFillColor; //
  Canvas.Brush.Color := FFillColor;
  Canvas.Rectangle (FPositionX - FSize , FPositionY - (FSize), FPositionX + (FSize), FPositionY + (FSize));
end;

end.

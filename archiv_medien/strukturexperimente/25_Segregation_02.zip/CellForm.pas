(********************************************************************)
(*                                                                  *) 
(*                                                                  *)
(*                       Segregation by Move                        *)
(*                          Version 1.0                             *)
(*                                                                  *)
(*                                                                  *)
(*     Programmierer: Reinhard K�nig                  December 2005 *)
(*                    http://www.entwurfsforschung.de               *)
(*                                                                  *)
(*     Last Update: Dec-19, 2005                                    *)
(*                                                                  *)
(********************************************************************) 
{revision history:

1.0     [Dec-19, 2005]
        first release to the public
        zu verbessern ist die changeHeadin prozedur bei den agenten
}

unit CellForm;

interface

uses
  Windows, Messages, SysUtils, Variants, Classes, Graphics, Controls, Forms,
  Dialogs, StdCtrls, cell_P, ExtCtrls, ButtonGroup, ComCtrls, Math, ToolWin,
  ImgList, Epina.SDL.rchart, agenten;

type
  TForm1 = class(TForm)
    ZeichenPanel   : TPanel;
    Timer1         : TTimer;
    lbl_Steps      : TLabel;
    B_setup        : TButton;
    lbl_timesteps  : TLabel;
    Lbl_TextSwelle : TLabel;
    Edit_thresh    : TEdit;
    B_stop         : TButton;
    RChart1        : TRChart;
    Lbl_TextAnzahl : TLabel;
    Edit_anzAg     : TEdit;
    procedure B_stopClick   (Sender: TObject);
    procedure B_setupClick  (Sender: TObject);
    procedure Timer1Timer   (Sender: TObject);
    procedure FormDestroy   (Sender: TObject);
    procedure FormCreate    (Sender: TObject);
  private
    AgentList    : TList;
    cellList     : Array of Array of TCell;
    limboWorld   : Array of Array of Extended;
    function  CalcDistance  (pAX: Integer; pAY: Integer; pBX: Integer; pBY: Integer): Integer;
    function  rndN          (lower: Integer; upper: Integer):Integer;
    procedure checkNei      (K, I: Integer);
    procedure torus         (var Xp: Integer; var Yp: Integer);
    procedure createPaintImg;
    procedure createRaster;
    procedure createAgents;
    procedure setupCells;
    procedure setupAgents;
    procedure calcAgents;
    procedure calcCells;
  public
end;

var
  Form1    : TForm1;
  paintImg : TImage;

implementation

{$R *.dfm}

const                            //-- globale Konstanten
  cellScal = 10;                  //-- Zellen  gr��e
  AgSize   = 4;                  //-- Agenten gr��e
  halfScal = round(cellScal/2);
var                              //-- globale Variablen
  reih    : Integer;             //-- Zellen-Reihen gesamt
  spalt   : Integer;             //-- Zellen-Spalten gesamt
  steps   : Integer;
  Xmax    : Integer;
  Ymax    : Integer;
  cellSum : Integer;
  OldY1   : Double;              //-- Speichert die Position t-1 f�r Graphen
  OldY2   : Double;              //-- Speichert die Position t-1 f�r Graphen
  happy   : Integer;             // -- z�hlt die angelagerten Agenten
  unhappy : Integer;             // -- z�hlt die noch freien Agenten

// ---------------------------------------------------------------------------//
// *** Initialisierung ***
procedure TForm1.FormCreate(Sender: TObject);
begin
  spalt     := round (ZeichenPanel.Width / cellScal);
  reih      := round (ZeichenPanel.Height / cellScal);
  Xmax      := (spalt) * cellScal;
  Ymax      := (reih ) * cellScal;
  AgentList := TList.Create;
  SetLength(cellList, spalt, reih);
  SetLength(limboWorld, spalt, reih);
  createPaintImg;
  CreateRaster;
  CreateAgents;
  ZeichenPanel.DoubleBuffered := True;       //-- Verhindert Flackern der Zellen
  steps := 0;

  // -- Diagramm initialisieren --
  RChart1.Scale1X.RangeLow  := 0;     { range of chart area }
  RChart1.Scale1X.RangeHigh := 100;   //-- Maximale Reichweite = 1000 bei Testversion!!!
  RChart1.Scale1Y.RangeLow  := 0;
  RChart1.Scale1Y.RangeHigh := StrToInt(Edit_anzAg.Text);
  RChart1.ShowGraf;
end;

// ---------------------------------------------------------------------------//
// ------------------------- Elemente erstellen ------------------------------//
// ---------------------------------------------------------------------------//

// *** Legt eine leere Zeichenfl�che �ber das Zeichenpanel ***
procedure TForm1.createPaintImg;
begin
  paintImg        := TImage.Create(self);
  paintImg.Parent := ZeichenPanel;
  paintImg.top    := 0;
  paintImg.Left   := 0;
  paintImg.Height := ZeichenPanel.Height;
  paintImg.Width  := ZeichenPanel.Width;
end;

procedure TForm1.CreateAgents;
var
  I        : Integer;
  curAgent : TAgent;
begin
  for I := 1 to StrToInt(Edit_anzAg.Text) do //   StrToInt(Edi_NrRed.Text) Do
  begin
    curAgent := TAgent.Create;
    AgentList.Add (curAgent);     // ---  add to the list
  end;
  setupAgents;
end;

// *** Agenten initialisieren ***
procedure TForm1.setupAgents;
var
  curAgent : TAgent;
  I        : Integer;
begin
  Randomize();
  for I := 0 to AgentList.Count - 1 do
  begin
    curAgent := AgentList.Items [I];
    curAgent.PosX    := random (spalt)* cellScal + halfScal;
    curAgent.PosY    := random (reih) * cellScal + halfScal;
    curAgent.Size    := AgSize;
    curAgent.State   := random(2);
    curAgent.Stopped := false;
    curAgent.Paint   (paintImg.Canvas);
  end;
end;

// *** Zellen erstellen ***
procedure TForm1.CreateRaster;
var
  curCell : TCell;
  I       : Integer;
  K       : Integer;
  upperB  : Integer;
  lowerB  : Integer;
begin
  for I := 0 to reih -1 do
  begin
    for K := 0 to spalt -1 do
    begin
      curCell := TCell.Create(halfScal + K * cellScal, halfScal + I * cellScal, halfScal, 0);
      cellList[K,I] := curCell;
    end;
  end;
  setupCells;
end;

// *** Zellen initialisieren ***
procedure TForm1.setupCells;
var
  curCell : TCell;
  I       : Integer;
  K       : Integer;
begin
  OldY1   := 0; // -- Ausgangswert t=0 f�r Graphen
  cellSum := spalt * reih;
  Randomize();
  for I := 0 to reih -1 do
  begin
    for K := 0 to spalt -1 do
    begin
      curCell         := cellList[K,I];
      curCell.besetzt := false;
      curCell.colr    := 125;
      curCell.Paint(paintImg.Canvas);
    end;
  end;
  RChart1.ClearGraf;      { initialize chart }
  RChart1.MoveTo (0,0);
end;

// ---------------------------------------------------------------------------//
// ---------------------------- Berechnungen ---------------------------------//
// ---------------------------------------------------------------------------//

// *** Rekursive Befehle ausf�hren ***
procedure TForm1.Timer1Timer(Sender: TObject);
begin

  calcAgents; // -- ver�ndert die Position der Agenten

  calcCells;  // -- berechnet die Zellennachbarschaften

  steps := steps +1;
  lbl_Steps.Caption := intToStr (steps);

  //--- Ausgabe in Graph ---
  if steps < RChart1.Scale1X.RangeHigh then begin // -- Plotten bis
    RChart1.ActiveLayer:= 1;
    RChart1.DataColor := clRed;
    RChart1.Line(steps-1, OldY1, steps, happy);
    OldY1 := happy;
    RChart1.ActiveLayer:= 3;
    RChart1.DataColor := clGreen;
    RChart1.Line(steps-1, OldY2, steps, unhappy);
    OldY2:=unhappy;
  end;
end;

// *** Ver�ndert die Position der Agenten ***
procedure TForm1.calcAgents;
var
  curCell     : TCell;
  curAgent    : TAgent;
  I           : Integer;
  agCount     : Integer;
  agAltReih   : Integer;
  agAltSpalt  : Integer;
  tempPos     : TPoint;
begin
  agCount := 0;
  happy   := 0;
  unhappy := 0;
  for I := 0 to AgentList.Count - 1 do
  begin
    curAgent := AgentList.Items [I];
    agAltSpalt := round((curAgent.PosX - halfScal) / cellScal);
    agAltReih  := round((curAgent.PosY - halfScal) / cellScal);
    If curAgent.Stopped = false then          // -- Wenn Agent noch nicht angelagert,
    begin                                     // -- zuf�llig weiterbewegen
      agCount := agCount +1;
      unhappy := unhappy +1;

      repeat
        curAgent.ChangeHeading(180, 10);      // -- Richtungsspektrum und Distanz
        tempPos.X := agAltSpalt + curAgent.stepX;
        tempPos.Y := agAltReih  + curAgent.stepY;

        torus (tempPos.X, tempPos.Y);         // -- Torus --

        curCell := cellList[tempPos.X, tempPos.Y];
      until curCell.besetzt = false;                  // -- wiederholen, bis freie Zelle gefunden

      cellList[agAltSpalt, agAltReih].besetzt := false;         // -- alte Zelle wieder leer
      cellList[agAltSpalt, agAltReih].Paint (paintImg.Canvas);  // -- und neu zeichnen
      curAgent.PosX   := tempPos.X * cellScal + halfScal;       // -- Wenn Zelle frei, Agent bewegen ---
      curAgent.PosY   := tempPos.Y * cellScal + halfScal;
      curCell.Besetzt := true;                        // -- Zelle unter Agent als besetzt markieren.
      curCell.State   := curAgent.State;
      curCell.AgNr    := I;                           // -- Agenten index in Zelle speichern

    end else begin                                    // -- Wenn Agent bereits angehalten
      cellList[agAltSpalt, agAltReih].AgNr    := I;   // -- Agenten index in Zelle speichern
      cellList[agAltSpalt, agAltReih].State   := curAgent.State;
      cellList[agAltSpalt, agAltReih].besetzt := true;
      happy := happy +1;
    end;
    curAgent.Paint (paintImg.Canvas);
  end;
  // -- Wenn alle Agenten angelagert sind, anhalten
  If agCount = 0 then Timer1.enabled := false;
end;

// *** Berechnet die Zellen ***
procedure TForm1.calcCells;
var
  curCell     : TCell;
  curAgent    : TAgent;
  I, K        : Integer;
  thresh      : Real;
  nSum        : Integer;
  similar     : Double;
begin
  thresh := StrToInt(Edit_thresh.Text);
  for I := 0 to reih -1 do
  begin
    for K := 0 to spalt -1 do
    begin
      curCell := cellList[K,I];

      If curCell.besetzt = true Then
      begin
        checkNei(K, I);                             // -- Vergleicht die Agenten in der Moore Nachbarschaft
        nSum := curCell.neighSimi + curCell.neighDiff;

        If nSum > 0 then begin
          similar := (curCell.neighSimi/nSum) * 100;
        end else begin
          similar := 0
        end;

        curAgent := AgentList.Items [curCell.AgNr]; // -- Agenten �ber Zelle ermitteln
        If (similar > thresh) then                  // -- Wenn Anzahl Summe > Threshold
        begin
          curAgent.stopped := true;                 // -- Agent anhalten
        end else begin
          curAgent.stopped := false;                // -- Agent weiterlaufen
        end;
      end;
    end;
  end;
end;

// --- Moorsche Nachbarschaft, mit den Abstand 1 �berpr�fen
procedure TForm1.checkNei (K, I: Integer);
var
  u  : Integer;
  v  : Integer;
  Xp : Integer;
  Yp : Integer;
begin
  cellList[K,I].neighSimi := 0;
  cellList[K,I].neighDiff := 0;
  // --- Summe berechnen ---
  for v := -1 to 1 do
  begin
    for u := -1 to 1 do
    begin
      Xp := K + u;
      Yp := I + v;

      torus(Xp, Yp); // -- Torus --

      If (cellList[Xp, Yp].besetzt = true) then
      begin
        If (cellList[Xp, Yp].state = cellList[K, I].state) then begin
          cellList[K,I].neighSimi := cellList[K,I].neighSimi +1;   // -- z�hlt Zellen mit gleichem Status
        end else begin
          cellList[K,I].neighDiff := cellList[K,I].neighDiff +1;   // -- z�hlt Zellen mit anderem Status
        end;
      end;

    end;
  end;
  cellList[K,I].neighSimi := cellList[K,I].neighSimi -1;           // -- zieht sich selbst wieder ab
end;

// ---------------------------------------------------------------------------//
// -------------------------- Funktionen -------------------------------------//
// ---------------------------------------------------------------------------//
// *** Torusfunktion ***
procedure TForm1.torus (var Xp: Integer; var Yp: Integer);
begin
  if Xp < 0     then begin
     Xp := spalt + Xp;
  end else
  if Xp > spalt-1  then begin
     Xp := 0 + (Xp - spalt) ;
  end;
  if Yp < 0     then begin
     Yp := reih + Yp;
  end else
  if Yp > reih-1  then begin
     Yp := 0 + (Yp - reih) ;
  end;
end;

// *** Entferung berechnen ***
function TForm1.CalcDistance(pAX: Integer; pAY: Integer; pBX: Integer; pBY: Integer): Integer;
var
  temp : double;
begin
  temp := sqrt(Power((pAX - pBX), 2) + Power((pAY - pBY), 2));
  Result := Round(temp);
end;

// *** Zufallszahl innerhalb eines Bereichs berechnen ***
function TForm1.rndN(lower : Integer; upper : Integer):Integer;
begin
  Result := round ((upper - lower + 1) * Random() + lower);
end;

// ---------------------------------------------------------------------------//
// ------------------------------- Schalter ----------------------------------//
// ---------------------------------------------------------------------------//
procedure TForm1.B_setupClick(Sender: TObject);
begin
  steps := 0;
  AgentList.Destroy;
  AgentList := TList.Create;
  RChart1.Scale1Y.RangeHigh := StrToInt(Edit_anzAg.Text);
  setupCells;
  createAgents;
  Timer1.enabled := true;
end;

procedure TForm1.B_stopClick(Sender: TObject);
begin
  Timer1.enabled := not(Timer1.enabled);
end;

procedure TForm1.FormDestroy(Sender: TObject);
begin
  paintImg.Free;
  ZeichenPanel.Free;
  AgentList.Destroy;
end;

end.

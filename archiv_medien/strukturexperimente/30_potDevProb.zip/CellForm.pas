(********************************************************************)
(*                                                                  *)
(*                                                                  *)
(*                       2D Cellular Automata                       *)
(*               Potential Development and Probability              *)
(*                          Version 1.0                             *)
(*                                                                  *)
(*                                                                  *)
(*     Programmierer: Reinhard K�nig                   January 2006 *)
(*                    http://www.entwurfsforschung.de               *)
(*                                                                  *)
(*     Last Update: Jan-24, 2006                                    *)
(*                                                                  *)
(********************************************************************) 
{revision history:

1.0     [Jan-24, 2006]
        first release to the public
}

unit CellForm;

interface

uses
  Windows, Messages, SysUtils, Variants, Classes, Graphics, Controls, Forms,
  Dialogs, StdCtrls, cell_P, ExtCtrls, ButtonGroup, ComCtrls, Math, ToolWin,
  ImgList, Epina.SDL.rchart;

type
  TForm1 = class(TForm)
    ZeichenPanel   : TPanel;
    Timer1         : TTimer;
    lbl_Steps      : TLabel;
    B_setup        : TButton;
    lbl_timesteps  : TLabel;
    B_stop         : TButton;
    RChart1        : TRChart;
    E_probab       : TEdit;
    Lbl_Prob       : TLabel;
    Cb_rnd         : TCheckBox;
    Lbl_death      : TLabel;
    E_death        : TEdit;
    Lbl_statProb   : TLabel;
    E_Noise        : TEdit;
    Cb_aging       : TCheckBox;
    procedure E_probabChange(Sender: TObject);
    procedure B_stopClick   (Sender: TObject);
    procedure B_setupClick  (Sender: TObject);
    procedure Timer1Timer   (Sender: TObject);
    procedure FormDestroy   (Sender: TObject);
    procedure FormCreate    (Sender: TObject);
  private
    AgentList  : TList;
    cellList   : Array of Array of TCell;
    limboWorld : Array of Array of Extended;
    function  CalcDistance  (pAX: Integer; pAY: Integer; pBX: Integer; pBY: Integer): Integer;
    function  rndN          (lower: Integer; upper: Integer):Integer;
    procedure checkNei      (K, I: Integer; var sumState : Integer);
    procedure checkPot      (K, I: Integer);
    procedure createPaintImg;
    procedure createRaster;
    procedure setupCells;
    procedure plot          (stateSum: Integer);
    procedure ageCheck;
  public
end;

var
  Form1    : TForm1;
  paintImg : TImage;

implementation

{$R *.dfm}

const                            //-- globale Konstanten
  cellScal = 4;                  //-- Zellen  gr��e
  AgSize   = 1;                  //-- Agenten gr��e
  halfScal = round(cellScal/2);
var                              //-- globale Variablen
  reih    : Integer;             //-- Zellen-Reihen gesamt
  spalt   : Integer;             //-- Zellen-Spalten gesamt
  steps   : Integer;
  Xmax    : Integer;
  Ymax    : Integer;
  cellSum : Integer;
  OldY1   : Integer;              //-- Speichert die Position t-1 f�r Graphen
  OldY2   : Integer;              //-- Speichert die Position t-1 f�r Graphen
  OldY3   : Integer;

// ---------------------------------------------------------------------------//
// *** Initialisierung ***
procedure TForm1.FormCreate(Sender: TObject);
begin
  spalt     := round (ZeichenPanel.Width / cellScal);
  reih      := round (ZeichenPanel.Height / cellScal);
  Xmax      := (spalt) * cellScal;
  Ymax      := (reih ) * cellScal;
  AgentList := TList.Create;
  SetLength(cellList, spalt, reih);
  SetLength(limboWorld, spalt, reih);
  createPaintImg;
  CreateRaster;
  ZeichenPanel.DoubleBuffered := True;       //-- Verhindert Flackern der Zellen
  steps := 0;

  // -- Diagramm initialisieren --
  RChart1.Scale1X.RangeLow  := 0;     { range of chart area }
  RChart1.Scale1X.RangeHigh := 50;  //-- Maximale Reichweite = 1000 bei Testversion!!!
  RChart1.Scale1Y.RangeLow  := 0;   //0.45;
  RChart1.Scale1Y.RangeHigh := spalt * reih + 100; //0.55;
  RChart1.ShowGraf;
end;

// ---------------------------------------------------------------------------//
// ------------------------- Elemente erstellen ------------------------------//
// ---------------------------------------------------------------------------//

// *** Legt eine leere Zeichenfl�che �ber das Zeichenpanel ***
procedure TForm1.createPaintImg;
begin
  paintImg        := TImage.Create(self);
  paintImg.Parent := ZeichenPanel;
  paintImg.top    := 0;
  paintImg.Left   := 0;
  paintImg.Height := ZeichenPanel.Height;
  paintImg.Width  := ZeichenPanel.Width;
end;

// *** Zellen erstellen ***
procedure TForm1.CreateRaster;
var
  curCell : TCell;
  I       : Integer;
  K       : Integer;
  upperB  : Integer;
  lowerB  : Integer;
begin
  for I := 0 to reih -1 do
  begin
    for K := 0 to spalt -1 do
    begin
      curCell := TCell.Create(halfScal + K * cellScal, halfScal + I * cellScal, halfScal, 0);
      cellList[K,I] := curCell;
    end;
  end;
  setupCells;
end;

// *** Zellen initialisieren ***
procedure TForm1.setupCells;
var
  curCell : TCell;
  I       : Integer;
  K       : Integer;
begin
  OldY1   := 0; // -- Ausgangswert t=0 f�r Graphen
  OldY2   := 0;
  OldY3   := 0;
  cellSum := spalt * reih;
  Randomize();
  for I := 0 to reih -1 do
  begin
    for K := 0 to spalt -1 do
    begin
      curCell          := cellList[K,I];
      curCell.State    := 0;               // -- set D(0) = 0;
      curCell.Pot      := 0;               // -- set P(0) = 0;
      limboWorld[K, I] := 0;
      curCell.probab   := 0.5;//StrToInt(E_probab.Text)/100;
      curCell.colr     := curCell.State * 255;
      curCell.birth    := 0;
      curCell.off      := false;
      curCell.Paint(paintImg.Canvas);
    end;
  end;
  if Cb_rnd.state = cbChecked Then  // -- random distribution of initial seed-cells
  begin
    for K := 0 to 10 do
    begin
      curCell := cellList[random(reih),random(spalt)];
      curCell.Pot := 1;   
      curCell.Paint(paintImg.Canvas);
    end;
  end;
  curCell := cellList[round(spalt/2),round(reih/2)];
  curCell.Pot := 1;                                  //  -- one seed
  curCell.colr  := curCell.State * 255;
  curCell.Paint(paintImg.Canvas);
  RChart1.ClearGraf;                                 // -- initialize chart 
  RChart1.MoveTo (0,0);
  RChart1.Scale1X.RangeHigh := StrToInt(E_death.Text);
end;

// ---------------------------------------------------------------------------//
// ---------------------------- Calculations ---------------------------------//
// ---------------------------------------------------------------------------//
// *** check age or the developed cell ***
procedure TForm1.ageCheck;
var
  curCell : TCell;
  K, I    : Integer;
  probab  : Real;
  death   : Integer;
begin
  death  := StrToInt(E_death.Text);
  probab := StrToInt(E_probab.Text)/100;
  for I  := 0 to reih -1 do
  begin
    for K := 0 to spalt -1 do
    begin
      curCell := cellList[K,I];
      If Cb_aging.State = cbChecked Then
      begin
        curCell.age := (steps - curCell.birth);    // -- increase age every step
        If curCell.age > death Then begin          // -- Cell dies on overaging
          curCell.age    := 0;
          curCell.pot    := 0;
          curCell.state  := 0;
          curCell.probab := probab;
        end;
      end;
    end;
  end;
end;

// --- Check Moore-Neigborhood for state and potential ---
procedure TForm1.checkNei (K, I: Integer; var sumState : Integer);
var
  u,v      : Integer;
  Xp, Yp   : Integer;
begin
  // --- Summe berechnen ---
  for v := -1 to 1 do
  begin
    for u := -1 to 1 do
    begin
      Xp := K + u;
      Yp := I + v;
      // -- Torus --
      if Xp < 0       then Xp := spalt-1;
      if Xp > spalt-1 then Xp := 0;
      if Yp < 0       then Yp := reih-1;
      if Yp > reih-1  then Yp := 0;
      sumState := sumState + cellList[Xp, Yp].State;  // -- count the states of the neighbours
    end;
  end;
  sumState := sumState - cellList[K, I].State;        // -- subtract the self-state of the cell
end;

// *****************************************************************************
// *** Rekursive Befehle ausf�hren ***
procedure TForm1.Timer1Timer(Sender: TObject);
var
  curCell  : TCell;
  K, I     : Integer;
  probab   : Real;
  stateSum : Integer;
  sumState : Integer;
  thresh   : Real;
  noise    : Integer;
  colM     : Integer;
begin
  Randomize;
  thresh   := StrToInt(E_probab.Text)/100;
  noise    := StrToInt(E_Noise.Text)*10;
  stateSum := 0;                             // -- sum all states
  probab   := 0.5;//StrToInt(E_probab.Text)/100;
  SetRoundMode (rmTruncate);
  colM     := round(255 / StrToInt(E_death.Text));
  ageCheck;                          // -- check age or the developed cell

  // -- Zellenstatus ver�ndern ---
  for I := 0 to reih -1 do
  begin
    for K := 0 to spalt -1 do
    begin
      curCell := cellList[K,I];
      If (curCell.State = 0) then
      begin
        If (curCell.Pot > thresh) then // and (random() < curCell.Probab) then
        begin
          // -- Wenn Zelle "geboren" wird
          curCell.birth := steps;                 // -- save the birthtime of development
          curCell.age   := 0;
          curCell.state := 1;
        end else begin
          curCell.birth := steps;                 // -- save the birthtime of undevelopment
          curCell.age   := 0;
        end;
      end;
      If curCell.state > 0 Then stateSum := stateSum + 1;         // -- count cells
      curCell.colr  := curCell.State * (255 - colM*curCell.age );//- colM*curCell.age);
      //curCell.colr  := round(curCell.Pot *4* 255 );
      curCell.Paint (paintImg.Canvas);
    end;
  end;

  // --- potential and state check  ---
  for I := 0 to reih -1 do
  begin
    for K := 0 to spalt -1 do
    begin
      limboWorld[K,I] := 0;
      curCell := cellList[K,I];
      sumState := 0;                           // -- sum of the neighborhood states
      checkNei(K, I, sumState);                // -- Z�hlt die Agenten in der Moore Nachbarschaft
      If (sumState >= 1) and (curCell.Pot = 0) then
      begin
        checkPot(K, I);                        // -- set limboWorld in checkPot
      end;
    end;
  end;

  // --- set potential value t+1---
  for I := 0 to reih -1 do
  begin
    for K := 0 to spalt -1 do
    begin
      curCell  := cellList[K,I];
      If (limboWorld[K,I] > 0) then  //and (curCell.off = false) then  // -- just if the cell got some neighbors
      begin
        curCell.Pot := limboWorld[K,I] + (random(noise)/1000);
      end;
      If curCell.Pot > 1 then curCell.Pot := 1;
      If curCell.State = 1 then curCell.Pot := 0;
    end;
  end;

  steps := steps +1;                              // -- increase steps
  lbl_Steps.Caption := intToStr (steps);
  plot(stateSum);             // -- plot the number of cells
  If steps = StrToInt(E_death.Text) Then begin                       // -- stop condition
    Timer1.enabled := false;                      // -- stop automata
  end;
end;

// --- Check Moore-Neigborhood for state and potential ---
procedure TForm1.checkPot (K, I: Integer);
var
  curCell  : TCell;
  u,v      : Integer;
  Xp, Yp   : Integer;
begin
  // --- Summe berechnen ---
  for v := -1 to 1 do
  begin
    for u := -1 to 1 do
    begin
      Xp := K + u;
      Yp := I + v;
      // -- Torus --
      if Xp < 0       then Xp := spalt-1;
      if Xp > spalt-1 then Xp := 0;
      if Yp < 0       then Yp := reih-1;
      if Yp > reih-1  then Yp := 0;
      If Not ((Xp = K) and (Yp = I)) Then begin
        limboWorld[K,I] := limboWorld[K,I] + (cellList[Xp, Yp].Pot/9);
      end;
    end;
  end;
end;

// ---------------------------------------------------------------------------//
//*** Ausgabe in Graph ***
procedure TForm1.plot(stateSum: Integer);
begin

  if steps < 300 then begin                        // -- bis Maximalwert Plotten
    RChart1.ActiveLayer:= 1;
    RChart1.DataColor := clRed;
    RChart1.Line(steps-1, OldY1, steps, stateSum);
    OldY1 := stateSum;
  end;
end;

// ---------------------------------------------------------------------------//
// -------------------------- Funktionen -------------------------------------//
// ---------------------------------------------------------------------------//
// *** Entferung berechnen ***
function TForm1.CalcDistance(pAX: Integer; pAY: Integer; pBX: Integer; pBY: Integer): Integer;
var
  temp : double;
begin
  temp := sqrt(Power((pAX - pBX), 2) + Power((pAY - pBY), 2));
  Result := Round(temp);
end;

// *** Zufallszahl innerhalb eines Bereichs berechnen ***
function TForm1.rndN(lower : Integer; upper : Integer):Integer;
begin
  Result := round ((upper - lower + 1) * Random() + lower);
end;

// ---------------------------------------------------------------------------//
// ------------------------------- Schalter ----------------------------------//
// ---------------------------------------------------------------------------//
procedure TForm1.B_setupClick(Sender: TObject);
begin
  steps := 0;
  setupCells;
  Timer1.enabled := true;

end;

procedure TForm1.B_stopClick(Sender: TObject);
begin
  Timer1.enabled := not(Timer1.enabled);
end;

procedure TForm1.FormDestroy(Sender: TObject);
begin
  paintImg.Free;
  ZeichenPanel.Free;
  AgentList.Destroy;
end;

procedure TForm1.E_probabChange(Sender: TObject);
begin
    E_Noise.Text := IntToStr(StrToInt(E_probab.Text) + 7);
end;

end.

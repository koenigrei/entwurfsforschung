unit main;

interface

uses
  Windows, Messages, SysUtils, Variants, Classes, Graphics, Controls, Forms,
  Dialogs, ExtCtrls, StdCtrls, rechteck, VarCmplx, Math;

type
  TForm1 = class(TForm)
    ImagePaint: TImage;
    Button_createRecht: TButton;
    Button_delete: TButton;
    Button_Overlap: TButton;
    ScrollBar_Numbers: TScrollBar;
    Label1: TLabel;
    Label_Numbers: TLabel;
    Label_area: TLabel;
    Label2: TLabel;
    procedure ScrollBar_NumbersChange(Sender: TObject);
    procedure Button_OverlapClick(Sender: TObject);
    procedure Button_deleteClick(Sender: TObject);
    procedure Button_createRechtClick(Sender: TObject);
    procedure FormCreate(Sender: TObject);
  private
    { Private declarations }
    ShapesList: TList;
    LapsList  : TList;
    //CurrShape : TBaseRecht;
    procedure RechtPaint(Canvas: TCanvas);
    procedure sumAreas;
    procedure schneideRecht;
  public
    { Public declarations }
  end;

var
  Form1: TForm1;

implementation

{$R *.dfm}
var
  Backpuffer    : TBitmap;
  numbers       : Integer;
  lap           : TRect;

//--- Form initialisieren-------------------------------------------------------
procedure TForm1.FormCreate(Sender: TObject);
begin
  Form1.color           := clBlack;
  ShapesList            := TList.Create;
  LapsList              := TList.Create;
  Label_Numbers.Caption := IntToStr(ScrollBar_Numbers.Position);
  numbers               := ScrollBar_Numbers.Position;
  Label_area.Caption    := '0';
  //--- Zwischenspeicher f�r die Bildaktualisierung -----------------
  Backpuffer            := TBitmap.create;
  Backpuffer.width      := ImagePaint.width;
  Backpuffer.height     := ImagePaint.height;
  Backpuffer.canvas.brush.color := clblack;
  Backpuffer.canvas.rectangle(0,0,Backpuffer.width,Backpuffer.height);
end;

//--- Button Rechtecke erstellen -----------------------------------------------
procedure TForm1.Button_createRechtClick(Sender: TObject);
var
  rechtA : TBaseRecht;
  I      : Integer;
begin
  for I:= 1 to numbers Do
  begin
    rechtA := TBaseRecht.Create;
    rechtA.PositionX := random(ImagePaint.Width);
    rechtA.PositionY := random(ImagePaint.Height); //round(ImagePaint.Height /2); random(50)
    rechtA.SetKoordinates(rechtA.PositionX - 10 - random(50), rechtA.PositionY - 10 - random(50),
                          rechtA.PositionX + 10 + random(50), rechtA.PositionY + 10 + random(50));
    rechtA.FillColor := clRed;
    ShapesList.Add (rechtA);                 //-- neues Rechtecke zur Liste hinzuf�gen
  end;
  RechtPaint(Backpuffer.Canvas);             //-- Rechtecke zeichnen
end;

//--- Button �berlagerungen berechnen ------------------------------------------
procedure TForm1.Button_OverlapClick(Sender: TObject);
var I : Integer;
begin
  for I := LapsList.Count - 1 downto 0 do
  begin
    TBaseRecht (LapsList [I]).Free;
  end;
  LapsList    := TList.Create;

  schneideRecht;                              //-- Auf �berlappung pr�fen
  RechtPaint(Backpuffer.Canvas);             //-- Rechtecke zeichnen
  sumAreas;                                  //-- �berlagerungsfl�chen addieren
end;

//--- Rechtecke zeichnen -------------------------------------------------------
procedure TForm1.RechtPaint(Canvas: TCanvas);
var
  I      : Integer;
  rechtA : TBaseRecht;
begin
  //--- Backpuffer l�schen ------------------------------------------
  Backpuffer.canvas.brush.color := clblack;
  Backpuffer.canvas.pen.color := clgreen;
  Backpuffer.canvas.rectangle(0,0,Backpuffer.width,Backpuffer.height);
  //--- Rechtecke der Liste zeichnen --------------------------------
  For I := 0 To ShapesList.Count - 1 do
  begin
    rechtA := ShapesList.Items[I];
    rechtA.FillColor := clRed;
    rechtA.Paint(Canvas);
  end;
  //--- �berlagerungsfl�chen aus Liste zeichnen ----------------------
  For I := 0 To LapsList.Count - 1 do
  begin
    rechtA := LapsList.Items[I];
    rechtA.FillColor := clBlue;
    rechtA.Paint(Canvas);
  end;
  ImagePaint.Canvas.Draw (0, 0, Backpuffer); //-- Backpuffer auf Zeichenfl�che kopieren
end;

//--- Berechnet und addiert die �berlagerungsfl�chen ---------------------------
procedure TForm1.sumAreas;
var
  I      : Integer;
  rechtA : TBaseRecht;
  siteA  : Integer;
  siteB  : Integer;
  area   : LongInt;
begin
  area := 0;
  For I := 0 To LapsList.Count - 1 do
  begin
    rechtA := LapsList.Items[I];
    siteA:= rechtA.Points[3,1] - rechtA.Points[0,1];
    siteB:= rechtA.Points[1,0] - rechtA.Points[0,0];
    area := area + siteA * siteB;
  end;
  Label_area.Caption := IntToStr(area);
end;

//--- Berechnet die �berlagerungen der Rechtecke -------------------------------
procedure TForm1.schneideRecht;
var
  I, K   : Integer;
  rechtA : TBaseRecht; //-- Container f�r Rechtecke
  rechtB : TBaseRecht;
  rechtLap : TBaseRecht;
  rA     : TRect;
  rB     : TRect;
  lapR   : TRect;
  isLap  : Boolean;
begin
  For I := 0 To ShapesList.Count - 1 do
  begin
    rechtA := ShapesList.Items[I];
    rA := Rect (rechtA.Points[0,0], rechtA.Points[0,1], rechtA.Points[2,0], rechtA.Points[2,1]);
    For K := I+1 To ShapesList.Count - 1 do //-- Werden auf �berlagerung gepr�ft
    begin
      rechtB := ShapesList.Items[K];        //-- Vergleichs-Clipping-Rechteck --
      rB := Rect (rechtB.Points[0,0], rechtB.Points[0,1], rechtB.Points[2,0], rechtB.Points[2,1]);
      isLap := intersectRect(lapR, rA, rB);
      If isLap = true then
      begin
        rechtLap := TBaseRecht.Create;
        rechtLap.SetKoordinates(lapR.Left, lapR.Top, lapR.Right, lapR.Bottom);
        LapsList.Add (rechtLap); //--- In Liste der �berlappenden Fl�chen eintragen
      end;
    end;
  end;
end;

// --- Anzahl der Rechtecke pro klick einstellen -------------------------------
procedure TForm1.ScrollBar_NumbersChange(Sender: TObject);
begin
  Label_Numbers.Caption := IntToStr(ScrollBar_Numbers.Position);
  numbers := ScrollBar_Numbers.Position;
end;

// --- Rechtecke l�schen -------------------------------------------------------
procedure TForm1.Button_deleteClick(Sender: TObject);
var I : Integer;
begin

  for I := ShapesList.Count - 1 downto 0 do
  begin
    TBaseRecht (ShapesList [I]).Free;
  end;

  for I := LapsList.Count - 1 downto 0 do
  begin
    TBaseRecht (LapsList [I]).Free;
  end;
  ShapesList  := TList.Create;
  LapsList    := TList.Create;
  Label_area.Caption := '0';
  Backpuffer.canvas.brush.color := clblack;
  Backpuffer.canvas.rectangle(0,0,Backpuffer.width,Backpuffer.height);
  ImagePaint.Canvas.Draw (0, 0, Backpuffer); //-- Backpuffer auf Zeichenfl�che kopieren
end;

end.

program segregation01;

uses
  Forms,
  Cell in 'Cell.pas',
  Node in 'Node.pas',
  CellForm in 'CellForm.pas' {Form1},
  cell_P in 'cell_P.pas',
  agenten in 'agenten.pas';

{$R *.res}

begin
  Application.Initialize;
  Application.CreateForm(TForm1, Form1);
  Application.Run;
end.

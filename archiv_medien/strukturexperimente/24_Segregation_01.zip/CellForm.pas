(********************************************************************)
(*                                                                  *) 
(*                                                                  *)
(*                        Segregation Model                         *)
(*                          Version 1.0                             *)
(*                                                                  *)
(*                                                                  *)
(*     Programmierer: Reinhard K�nig                  December 2005 *)
(*                    http://www.entwurfsforschung.de               *)
(*                                                                  *)
(*     Last Update: Dec-18, 2005                                    *)
(*                                                                  *)
(********************************************************************) 
{revision history:

1.0     [Dec-18, 2005]
        first release to the public
}

unit CellForm;

interface

uses
  Windows, Messages, SysUtils, Variants, Classes, Graphics, Controls, Forms,
  Dialogs, StdCtrls, cell_P, ExtCtrls, ButtonGroup, ComCtrls, Math, ToolWin,
  ImgList, Epina.SDL.rchart, agenten;

type
  TForm1 = class(TForm)
    ZeichenPanel   : TPanel;
    Timer1         : TTimer;
    lbl_Steps      : TLabel;
    B_setup        : TButton;
    lbl_timesteps  : TLabel;
    Lbl_TextSwelle : TLabel;
    Edit_thresh    : TEdit;
    B_stop         : TButton;
    RChart1        : TRChart;
    cb_leerZell    : TCheckBox;
    B_disturb      : TButton;
    Edit_disturb   : TEdit;
    Lbl_disturb    : TLabel;
    procedure B_disturbClick(Sender: TObject);
    procedure B_stopClick   (Sender: TObject);
    procedure B_setupClick  (Sender: TObject);
    procedure Timer1Timer   (Sender: TObject);
    procedure FormDestroy   (Sender: TObject);
    procedure FormCreate    (Sender: TObject);
  private
    AgentList    : TList;
    cellList     : Array of Array of TCell;
    limboWorld   : Array of Array of Extended;
    function  CalcDistance  (pAX: Integer; pAY: Integer; pBX: Integer; pBY: Integer): Integer;
    function  rndN          (lower: Integer; upper: Integer):Integer;
    procedure checkNei      (K, I: Integer);
    procedure createPaintImg;
    procedure createRaster;
//    procedure createAgents;
    procedure setupCells;
//    procedure setupAgents;
  public
end;

var
  Form1    : TForm1;
  paintImg : TImage;

implementation

{$R *.dfm}

const                            //-- globale Konstanten
  cellScal = 4;                  //-- Zellen  gr��e
  AgSize   = 1;                  //-- Agenten gr��e
  halfScal = round(cellScal/2);
var                              //-- globale Variablen
  reih    : Integer;             //-- Zellen-Reihen gesamt
  spalt   : Integer;             //-- Zellen-Spalten gesamt
  steps   : Integer;
  Xmax    : Integer;
  Ymax    : Integer;
  cellSum : Integer;
  OldY1   : Double;              //-- Speichert die Position t-1 f�r Graphen
  OldY2   : Double;              //-- Speichert die Position t-1 f�r Graphen

// ---------------------------------------------------------------------------//
// *** Initialisierung ***
procedure TForm1.FormCreate(Sender: TObject);
begin
  spalt     := round (ZeichenPanel.Width / cellScal);
  reih      := round (ZeichenPanel.Height / cellScal);
  Xmax      := (spalt) * cellScal;
  Ymax      := (reih ) * cellScal;
  AgentList := TList.Create;
  SetLength(cellList, spalt, reih);
  SetLength(limboWorld, spalt, reih);
  createPaintImg;
  CreateRaster;
  //CreateAgents;
  ZeichenPanel.DoubleBuffered := True;       //-- Verhindert Flackern der Zellen
  steps := 0;

  // -- Diagramm initialisieren --
  RChart1.Scale1X.RangeLow  := 0;     { range of chart area }
  RChart1.Scale1X.RangeHigh := 30;  //-- Maximale Reichweite = 1000 bei Testversion!!!
  RChart1.Scale1Y.RangeLow  := 0; //0.45;
  RChart1.Scale1Y.RangeHigh := 0.6; //0.55;
  RChart1.ShowGraf;
end;

// ---------------------------------------------------------------------------//
// ------------------------- Elemente erstellen ------------------------------//
// ---------------------------------------------------------------------------//

// *** Legt eine leere Zeichenfl�che �ber das Zeichenpanel ***
procedure TForm1.createPaintImg;
begin
  paintImg        := TImage.Create(self);
  paintImg.Parent := ZeichenPanel;
  paintImg.top    := 0;
  paintImg.Left   := 0;
  paintImg.Height := ZeichenPanel.Height;
  paintImg.Width  := ZeichenPanel.Width;
end;

{procedure TForm1.CreateAgents;
var
  I        : Integer;
  curAgent : TAgent;
begin
  for I := 1 to StrToInt(Edit_anzAg.Text) do //   StrToInt(Edi_NrRed.Text) Do
  begin
    curAgent := TAgent.Create;
    AgentList.Add (curAgent);     // ---  add to the list
  end;
  setupAgents;
end;  }

// *** Agenten initialisieren ***
{procedure TForm1.setupAgents;
var
  curAgent : TAgent;
  I        : Integer;
begin
  Randomize();
  for I := 0 to AgentList.Count - 1 do
  begin
    curAgent := AgentList.Items [I];
    curAgent.PosX    := random (spalt)* cellScal + halfScal;
    curAgent.PosY    := random (reih) * cellScal + halfScal;
    curAgent.Heading := (random(8) * 45);
    curAgent.Size    := AgSize;
    curAgent.State   := 1;
    curAgent.Paint (paintImg.Canvas);
  end;
end; }

// *** Zellen erstellen ***
procedure TForm1.CreateRaster;
var
  curCell : TCell;
  I       : Integer;
  K       : Integer;
  upperB  : Integer;
  lowerB  : Integer;
begin
  for I := 0 to reih -1 do
  begin
    for K := 0 to spalt -1 do
    begin
      curCell := TCell.Create(halfScal + K * cellScal, halfScal + I * cellScal, halfScal, 0);
      cellList[K,I] := curCell;
    end;
  end;
  setupCells;
end;

// *** Zellen initialisieren ***
procedure TForm1.setupCells;
var
  curCell : TCell;
  I       : Integer;
  K       : Integer;
begin
  OldY1   := 0; // -- Ausgangswert t=0 f�r Graphen
  cellSum := spalt * reih;
  Randomize();
  for I := 0 to reih -1 do
  begin
    for K := 0 to spalt -1 do
    begin
      curCell := cellList[K,I];

      If (cb_leerZell.State = cbChecked) then begin  // --- mit leeren Zellen
        curCell.State := random(3);
        If curCell.State < 2 then begin
          OldY1 := OldY1 + curCell.State;
          curCell.colr  := curCell.State * 255;
        end else begin
          curCell.colr  := 125;
          cellSum := cellSum -1;
        end;
        
      end else begin                                 // --- ohne leeren Zellen
        curCell.State := random(2);
        OldY1 := OldY1 + curCell.State;
        curCell.colr  := curCell.State * 255;
      end;
      curCell.Paint(paintImg.Canvas);
    end;
  end;
  OldY1 := OldY1 / cellSum;
  RChart1.ClearGraf;      { initialize chart }
  RChart1.MoveTo (0,0);
end;

// ---------------------------------------------------------------------------//
// ---------------------------- Berechnungen ---------------------------------//
// ---------------------------------------------------------------------------//
// --- Moorsche Nachbarschaft, mit den Abstand 1 �berpr�fen
procedure TForm1.checkNei (K, I: Integer);
var
  u  : Integer;
  v  : Integer;
  Xp : Integer;
  Yp : Integer;
begin
  // --- Summe berechnen ---
  for v := -1 to 1 do
  begin
    for u := -1 to 1 do
    begin
      Xp := K + u;
      Yp := I + v;
      // -- Torus --
      if Xp < 0       then Xp := spalt-1;
      if Xp > spalt-1 then Xp := 0;
      if Yp < 0       then Yp := reih-1;
      if Yp > reih-1  then Yp := 0;
      If (cb_leerZell.State = cbChecked) then                // -- System mit leeren Zellen
      begin                                                  // -- Z�hlt schwarze und wei�e Zellen getrennt
        If cellList[Xp, Yp].state = 0 then cellList[K,I].neighWhite := cellList[K,I].neighWhite + 1;
        If cellList[Xp, Yp].state = 1 then cellList[K,I].neighBlack := cellList[K,I].neighBlack + 1;
      end else begin                                         // -- System ohne leeren Zellen
        cellList[K,I].neighSum := cellList[K,I].neighSum + cellList[Xp, Yp].state;
      end;
    end;
  end;
  cellList[K,I].neighSum := cellList[K,I].neighSum - cellList[K, I].state;  //-- eigenen Wert wieder abziehen
end;

// *** Rekursive Befehle ausf�hren ***
procedure TForm1.Timer1Timer(Sender: TObject);
var
  curCell : TCell;
  curAgent: TAgent;
  I       : Integer;
  K       : Integer;
  M       : Integer;
  agCount : Integer;
  agReih  : Integer;
  agSpalt : Integer;
  fin     : Boolean;
  thresh  : Real;
  stateSum    : Double;
  stateSumOld : Double;
  dStateChg   : Double;
begin
  fin := true;
  stateSum := 0;
  thresh := StrToInt(Edit_thresh.Text);
  // --- Zellennachbarschaft �berpr�fen ---
  for I := 0 to reih -1 do
  begin
    for K := 0 to spalt -1 do
    begin
      cellList[K,I].neighSum   := 0;
      cellList[K,I].neighWhite := 0;
      cellList[K,I].neighBlack := 0;
      If cellList[K,I].State < 2 then begin
        checkNei(K, I);           // -- Z�hlt die Agenten in der Moore Nachbarschaft
      end;
    end;
  end;

  // -- Zellenstatus ver�ndern ---
  for I := 0 to reih -1 do
  begin
    for K := 0 to spalt -1 do
    begin
      curCell := cellList[K,I];

      If (cb_leerZell.State = cbChecked) then begin                   // -- System mit leeren Zellen
        If curCell.state < 2then begin                                // -- Nicht die leeren Zellen berechnen
          If (curCell.neighBlack > curCell.neighWhite) then           // -- Wenn Anzahl Schwarz > Wei�
          begin
            curCell.State := 1;
          end else if (curCell.neighWhite > curCell.neighBlack) then  // -- Wenn Anzahl Wei� < Schwarz
          begin
            curCell.State := 0;
          end;
          stateSum := stateSum + curCell.State;
          curCell.colr  := curCell.State * 255;
          curCell.Paint (paintImg.Canvas);
        end;

      end else begin                                   // -- System ohne leeren Zellen
        If (curCell.neighSum > thresh) then            // -- Wenn Anzahl Summe > Threshold
        begin
          curCell.State := 1;
        end else if (curCell.neighSum < thresh) then   // -- Wenn Anzahl Summe < Threshold
        begin
          curCell.State := 0;
        end;
        stateSum := stateSum + curCell.State;
        curCell.colr  := curCell.State * 255;
        curCell.Paint (paintImg.Canvas);
      end;
      
    end;
  end;
  stateSum := stateSum / cellSum;                // -- globaler Durchschnittswert des Zellenstatus
  dStateChg := abs(stateSum - OldY1)*100;        // -- Ver�nderungsrate (der Meinungen)

  steps := steps +1;
  lbl_Steps.Caption := intToStr (steps);
  //--- Ausgabe in Graph ---
  if steps < 32 then begin // -- Maximalwert Plotten
    RChart1.ActiveLayer:= 1;
    RChart1.DataColor := clRed;
    RChart1.Line(steps-1, OldY1, steps, stateSum);
    OldY1 := stateSum;
    RChart1.ActiveLayer:= 3;
    RChart1.DataColor := clGreen;
    RChart1.Line(steps-1, OldY2, steps, dStateChg);
    OldY2:=dStateChg;
  end;
  stateSumOld := stateSum;
end;

// ---------------------------------------------------------------------------//
// -------------------------- Funktionen -------------------------------------//
// ---------------------------------------------------------------------------//
// *** Entferung berechnen ***
function TForm1.CalcDistance(pAX: Integer; pAY: Integer; pBX: Integer; pBY: Integer): Integer;
var
  temp : double;
begin
  temp := sqrt(Power((pAX - pBX), 2) + Power((pAY - pBY), 2));
  Result := Round(temp);
end;

// *** Zufallszahl innerhalb eines Bereichs berechnen ***
function TForm1.rndN(lower : Integer; upper : Integer):Integer;
begin
  Result := round ((upper - lower + 1) * Random() + lower);
end;

// ---------------------------------------------------------------------------//
// ------------------------------- Schalter ----------------------------------//
// ---------------------------------------------------------------------------//
procedure TForm1.B_setupClick(Sender: TObject);
begin
  steps := 0;
  //AgentList.Destroy;
  //AgentList := TList.Create;
  //RChart1.Scale1Y.RangeHigh := StrToInt(Edit_anzAg.Text)+50;
  setupCells;
  //Timer1.enabled := true;
  //createAgents;
end;

procedure TForm1.B_stopClick(Sender: TObject);
begin
  Timer1.enabled := not(Timer1.enabled);
end;

procedure TForm1.FormDestroy(Sender: TObject);
begin
  paintImg.Free;
  ZeichenPanel.Free;
  AgentList.Destroy;
end;

// *** F�gt eine einmaliges St�rung ein ***
procedure TForm1.B_disturbClick(Sender: TObject);
var
  curCell : TCell;
  I       : Integer;
  K       : Integer;
  disturb : Real;
begin
  steps   := 0;
  OldY1   := 0;                              // -- Ausgangswert t=0 f�r Graphen
  disturb := StrToFloat(Edit_disturb.Text);  // -- St�rke der St�rung
  Randomize();
  for I := 0 to reih -1 do
  begin
    for K := 0 to spalt -1 do
    begin
      curCell := cellList[K,I];

      If (cb_leerZell.State = cbChecked) then begin  // --- mit leeren Zellen
        If curCell.State < 2 then begin
          If (random < disturb) then curCell.State := random(2);
          OldY1 := OldY1 + curCell.State;
          curCell.colr  := curCell.State * 255;
        end;

      end else begin                                 // --- ohne leeren Zellen
        If (random < disturb) then curCell.State := random(2);
        OldY1 := OldY1 + curCell.State;
        curCell.colr  := curCell.State * 255;
      end;
      curCell.Paint(paintImg.Canvas);
    end;
  end;
  OldY1 := OldY1 / cellSum;
  RChart1.ClearGraf;      { initialize chart }
  RChart1.MoveTo (0,0);
end;

end.

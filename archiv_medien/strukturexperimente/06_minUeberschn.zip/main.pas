unit main;

interface

uses
  Windows, Messages, SysUtils, Variants, Classes, Graphics, Controls, Forms,
  Dialogs, ExtCtrls, StdCtrls, rechteck, VarCmplx, Math, SortThds, AppEvnts;

type
    ValueType = Longint; // Type used in the arrays.
    IndexType = Longint; // Type used to index arrays.
  TForm1 = class(TForm)
    ImagePaint          : TImage;
    Button_createRecht  : TButton;
    Button_delete       : TButton;
    Label_Mutate        : TLabel;
    Label_Ready         : TLabel;
    Label4              : TLabel;
    Label_Variation     : TLabel;
    Label1              : TLabel;
    Label_Numbers       : TLabel;
    Label_area          : TLabel;
    Label2              : TLabel;
    Label3              : TLabel;
    Label5              : TLabel;
    Label_Size          : TLabel;
    ScrollBar_Size      : TScrollBar;
    ScrollBar_Numbers   : TScrollBar;
    ScrollBar_Mutate    : TScrollBar;
    ScrollBar_Variantion: TScrollBar;
    ApplicationEvents1  : TApplicationEvents;
    procedure ScrollBar_SizeChange(Sender: TObject);
    procedure ScrollBar_VariantionChange(Sender: TObject);
    procedure ApplicationEvents1Idle(Sender: TObject; var Done: Boolean);
    procedure ScrollBar_MutateChange(Sender: TObject);
    procedure ScrollBar_NumbersChange(Sender: TObject);
    procedure Button_deleteClick(Sender: TObject);
    procedure Button_createRechtClick(Sender: TObject);
    procedure FormCreate(Sender: TObject);
  private
    { Private declarations }
    ShapesList: Array of TList;
    LapsList  : Array of TList;
    procedure Selectionsort(var List : array of ValueType; var listInd : array of Integer;
                            min, max : IndexType);
    procedure RechtPaint(Canvas: TCanvas; ind : Integer);
    procedure sumAreas(var area : Array of Integer);
    procedure schneideRecht;
    procedure overlap;
    procedure optimize (var area : Array of Integer; const area_ind : Array of Integer);
    procedure deleteAll;
  public
    { Public declarations }
  end;

var
  Form1: TForm1;

implementation

{$R *.dfm}
var
  Backpuffer    : TBitmap;
  nrPop         : Integer;

//--- Form initialisieren-------------------------------------------------------
procedure TForm1.FormCreate(Sender: TObject);
var K : Integer;
begin
  nrPop                 := 10;
  SetLength(ShapesList, nrPop);
  SetLength(LapsList, nrPop);
  For K := 0 to nrPop-1 Do
  begin
    ShapesList[K]         := TList.Create;
    LapsList[K]           := TList.Create;
  end;
  Form1.color             := clBlack;
  Label_Numbers.Caption   := IntToStr(ScrollBar_Numbers.Position);
  Label_area.Caption      := '0';
  Label_Mutate.Caption    := IntToStr(ScrollBar_Mutate.Position);
  Label_Variation.Caption := IntToStr(ScrollBar_Variantion.Position);
  Label_Size.Caption      := IntToStr(ScrollBar_Size.Position);
  //--- Zwischenspeicher f�r die Bildaktualisierung -----------------
  Backpuffer              := TBitmap.create;
  Backpuffer.width        := ImagePaint.width;
  Backpuffer.height       := ImagePaint.height;
  Backpuffer.canvas.brush.color := clblack;
  Backpuffer.canvas.rectangle(0,0,Backpuffer.width,Backpuffer.height);
end;

//--- Button Rechtecke erstellen -----------------------------------------------
procedure TForm1.Button_createRechtClick(Sender: TObject);
var
  rechtA : TBaseRecht;
  I,K    : Integer;
  Size   : Integer;
  numbers: Integer;
begin
  Label_Ready.Caption    := 'Optimierung l�uft ...';
  Label_Ready.Font.Color := clRed;
  deleteAll;
  numbers := ScrollBar_Numbers.Position;
  Size    := ScrollBar_Size.Position;
  For K:= 0 to nrPop-1 Do
  begin
    For I:= 1 to numbers Do
    begin
      rechtA := TBaseRecht.Create;
      rechtA.PositionX := Size + random(ImagePaint.Width - 2*Size) ;
      rechtA.PositionY := Size + random(ImagePaint.Height -2*Size);
      rechtA.Left   := rechtA.PositionX - Size;
      rechtA.Top    := rechtA.PositionY - Size;
      rechtA.Right  := rechtA.PositionX + Size;
      rechtA.Bottom := rechtA.PositionY + Size;
      ShapesList[K].Add (rechtA);   //--- neues Rechtecke zur Liste hinzuf�gen -
    end;
  end;
  overlap                           //--- �berlapungs-Optimierung starten ------
end;


procedure TForm1.ApplicationEvents1Idle(Sender: TObject; var Done: Boolean);
begin
  done := false;
  If StrToInt(Label_area.Caption) <= 100 Then begin done := true;
  end else begin
    overlap;
  end;
end;

//--- �berlagerungen berechnen -------------------------------------------------
procedure TForm1.overlap;
var
  I,K      : Integer;
  area     : Array of Integer;
  area_ind : Array of Integer;
  sortArea : Array of Integer;
begin
  SetLength(area, nrPop);
  SetLength(area_ind, nrPop);
  For K:= 0 to nrPop-1 Do
  begin
    For I := LapsList[K].Count - 1 downto 0 do
    begin
      TBaseRecht (LapsList[K][I]).Free;
    end;
  end;
  For K:= 0 to nrPop-1 Do begin
    LapsList[K] := TList.Create;
  end;
  schneideRecht;                             //-- Auf �berlappung pr�fen
  sumAreas (area);                           //-- �berlagerungsfl�chen addieren
  Selectionsort(area, area_ind, 0, nrPop-1); //-- Nach Liste mit der kleinsten �berlagerungsfl�che sortieren
  RechtPaint(Backpuffer.Canvas, area_ind[0]);//-- Version mit den geringsten �berlappungen zeichnen
  Label_area.Caption := IntToStr(area[0]);
  //-----------------------------------
  If area[0] > 100 then begin                //-- Rekursiver Aufruf - !!!Achtung vor Endlosschleife!!!
    optimize (area, area_ind);               //-- L�sung optimieren -> �berlagerungsfl�chen minimieren
  end else begin
    Label_Ready.Caption := 'Programm bereit';
    Label_Ready.Font.Color := clWhite;
  end;
end;

//--- Variiert die Version mit den geringsten �berlappungen --------------------
procedure TForm1.optimize (var area : Array of Integer; const area_ind : Array of Integer);
var
  I,K        : Integer;
  ind        : Integer;
  Xpos, YPos : Integer;
  rechtA     : TBaseRecht;
  rechtB     : TBaseRecht;
  baseList   : Tlist;
  mutRat     : Integer;
  varSteps   : Integer;
  Size       : Integer;
begin
  ind        := area_ind[0];
  mutRat     := ScrollBar_Mutate.Position;
  varSteps   := ScrollBar_Variantion.Position;
  Size       := ScrollBar_Size.Position;
  For K:= 0 to nrPop-1 Do
  begin
    If Not (K = ind) then
    For I := 0 To ShapesList[ind].Count - 1 do
    begin
      rechtA := ShapesList[ind].Items[I];
      rechtB := ShapesList[K].Items[I];
      Xpos   := rechtA.PositionX;
      YPos   := rechtA.PositionY;
      If mutRat > random(100) then //--- Mutation ---
      begin
        Xpos   := random(ImagePaint.Width);
        YPos   := random(ImagePaint.Height);
      end
      else begin
        Xpos := Xpos + (random(varSteps*2+1)-(varSteps));
        YPos := YPos + (random(varSteps*2+1)-(varSteps));
      end;
      If xPos < Size Then xPos := Size;
      If xPos > ImagePaint.Width - Size Then xPos := ImagePaint.Width - Size;
      If yPos < Size Then yPos := Size;
      If yPos > ImagePaint.Height - Size Then yPos := ImagePaint.Height - Size;
      rechtB.PositionX := Xpos;    //--- Koordinaten �bertragen ---
      rechtB.PositionY := YPos;
      rechtB.Left   := rechtB.PositionX - Size;
      rechtB.Top    := rechtB.PositionY - Size;
      rechtB.Right  := rechtB.PositionX + Size;
      rechtB.Bottom := rechtB.PositionY + Size;
    end;
  end;
end;

//--- Sortier Algorithmus ------------------------------------------------------
procedure TForm1.Selectionsort(var List : array of ValueType; var listInd : array of Integer;
                               min, max : IndexType);
var
    i, j, best_j : IndexType;
    best_value   : ValueType;
begin
    for i := min to max -1  do
    begin
        best_value := List[i];
        best_j := i;
        for j := i + 1 to max do
        begin
            if (List[j] < best_value) Then
            begin
                best_value := List[j];
                best_j := j;
                listInd[I] := j;
                listInd[I+1] := i;
            end;
        end;    // for j := i + 1 to max do
        List[best_j]:= List[i];
        List[i]     := best_value;
    end;        // for i := min to max - 1 do
end;

//--- Rechtecke zeichnen -------------------------------------------------------
procedure TForm1.RechtPaint(Canvas: TCanvas; ind : Integer);
var
  I,K    : Integer;
  rechtA : TBaseRecht;
begin
  //--- Backpuffer l�schen ------------------------------------------
  Backpuffer.canvas.brush.color := clblack;
  Backpuffer.canvas.pen.color := clgreen;
  Backpuffer.canvas.rectangle(0,0,Backpuffer.width,Backpuffer.height);
  //--- Rechtecke der Liste zeichnen --------------------------------
  For I := 0 To ShapesList[ind].Count - 1 do
  begin
    rechtA := ShapesList[ind].Items[I];
    rechtA.FillColor := clRed;
    rechtA.Paint(Canvas);
  end;
  //--- �berlagerungsfl�chen aus Liste zeichnen ---------------------
  For I := 0 To LapsList[ind].Count - 1 do
  begin
    rechtA := LapsList[ind].Items[I];
    rechtA.FillColor := clBlue;
    rechtA.Paint(Canvas);
  end;
  ImagePaint.Canvas.Draw (0, 0, Backpuffer); //-- Backpuffer auf Zeichenfl�che kopieren
end;

//--- Berechnet und addiert die �berlagerungsfl�chen ---------------------------
procedure TForm1.sumAreas (var area : Array of Integer);
var
  I,K    : Integer;
  rechtA : TBaseRecht;
  siteA  : Integer;
  siteB  : Integer;
begin
  For K:= 0 to nrPop-1 Do
  begin
    area[K] := 0;
    For I := 0 To LapsList[K].Count - 1 do
    begin
      rechtA := LapsList[K].Items[I];
      siteA:= rechtA.Rect.Bottom - rechtA.Rect.Top;
      siteB:= rechtA.Rect.Right - rechtA.Rect.Left;
      area[K] := area[K] + siteA * siteB;
      end;
  end;
end;

//--- Berechnet die �berlagerungen der Rechtecke -------------------------------
procedure TForm1.schneideRecht;
var
  I, K, L : Integer;
  rechtA  : TBaseRecht; //-- Container f�r Rechtecke
  rechtB  : TBaseRecht;
  rechtLap: TBaseRecht;
  lapR    : TRect;
  isLap   : Boolean;
begin
  For K := 0 to nrPop-1 Do
  begin
    For I := 0 To ShapesList[K].Count - 1 do
    begin
      rechtA := ShapesList[K].Items[I];
      For L := I+1 To ShapesList[K].Count - 1 do //-- Werden auf �berlagerung gepr�ft
      begin
        rechtB := ShapesList[K].Items[L];        //-- Vergleichs-Clipping-Rechteck --
        isLap := intersectRect(lapR, rechtA.Rect, rechtB.Rect);
        If isLap = true then
        begin
          rechtLap := TBaseRecht.Create;
          rechtLap.Left   := lapR.Left;
          rechtLap.Top    := lapR.Top;
          rechtLap.Right  := lapR.Right;
          rechtLap.Bottom := lapR.Bottom;
          LapsList[K].Add (rechtLap); //--- In Liste der �berlappenden Fl�chen eintragen
        end;
      end;
    end;
  end;
end;

// --- Anzahl der Rechtecke pro klick einstellen -------------------------------
procedure TForm1.ScrollBar_NumbersChange(Sender: TObject);
begin
  Label_Numbers.Caption := IntToStr(ScrollBar_Numbers.Position);
end;

// --- Button delete -----------------------------------------------------------
procedure TForm1.Button_deleteClick(Sender: TObject);
begin
  deleteAll;
end;

// --- Rechtecke l�schen -------------------------------------------------------
procedure TForm1.deleteAll;
var I,K : Integer;
begin
  For K := 0 to nrPop-1 Do
  begin
    For I := ShapesList[K].Count - 1 downto 0 do
    begin
      TBaseRecht (ShapesList[K][I]).Free;
    end;
    ShapesList[K]:= TList.Create;
  end;

  For K := 0 to nrPop-1 Do
  begin
    for I := LapsList[K].Count - 1 downto 0 do
    begin
      TBaseRecht (LapsList[K][I]).Free;
    end;
    LapsList[K] := TList.Create;
  end;
  Label_area.Caption := '0';
  Backpuffer.canvas.brush.color := clblack;
  Backpuffer.canvas.rectangle(0,0,Backpuffer.width,Backpuffer.height);
  ImagePaint.Canvas.Draw (0, 0, Backpuffer); //-- Backpuffer auf Zeichenfl�che kopieren
end;

procedure TForm1.ScrollBar_MutateChange(Sender: TObject);
begin
  Label_Mutate.Caption  := IntToStr(ScrollBar_Mutate.Position);
end;

procedure TForm1.ScrollBar_VariantionChange(Sender: TObject);
begin
   Label_Variation.Caption := IntToStr(ScrollBar_Variantion.Position);
end;

procedure TForm1.ScrollBar_SizeChange(Sender: TObject);
begin
  Label_Size.Caption := IntToStr(ScrollBar_Size.Position);
end;

end.

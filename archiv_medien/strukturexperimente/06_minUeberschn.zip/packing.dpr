program packing;

{%File 'ModelSupport\main\main.txvpck'}
{%File 'ModelSupport\default.txvpck'}
{%File 'ModelSupport\Unit1\Unit1.txvpck'}
{%File 'ModelSupport\rechtecke\rechtecke.txvpck'}
{%File 'ModelSupport\cell\cell.txvpck'}
{%File 'ModelSupport\rech\rech.txvpck'}
{%File 'ModelSupport\rechteck\rechteck.txvpck'}

uses
  Forms,
  main in 'main.pas' {Form1},
  rechteck in 'rechteck.pas';

{$R *.res}

begin
  Application.Initialize;
  Application.CreateForm(TForm1, Form1);
  Application.Run;
end.

unit rechteck;

interface

uses
  Windows, Graphics;

type
  TBaseRecht = class
  private
    FPoints  : Array [0..3] of Array [0..1] of Integer;
    procedure SetPoints  (Index: Integer; IndK: Integer; Value: Integer);
    function  GetPoints  (Index: Integer; IndK: Integer): Integer;
    procedure SetBottom(const Value: Integer);
    procedure SetLeft(const Value: Integer);
    procedure SetRight(const Value: Integer);
    procedure SetTop(const Value: Integer);
    procedure SetPositionX(const Value: Integer);
    procedure SetPositionY(const Value: Integer);
    //procedure SetStepX(const Value: Double);
    //procedure SetStepY(const Value: Double);
    procedure SetSize(const Value: Integer);
    procedure SetFillColor(const Value: Integer);
    //procedure SetKoordinates(X1: Integer; Y1: Integer; X2: Integer; Y2: Integer);
  protected
    FRect: TRect;
  public
    FPositionX: Integer;
    FPositionY: Integer;
    FSize     : Integer;
    //FStepX    : Double;
    //FStepY    : Double;
    FFillColor: Integer;
    //FState    : Integer;
    FPassed   : Integer;
    rA        : TRect;
    procedure Paint (Canvas: TCanvas); //virtual;
    property  Points [Index: Integer; IndK: Integer]: Integer read GetPoints write SetPoints;
  published
    property PositionX: Integer read FPositionX write SetPositionX;
    property PositionY: Integer read FPositionY write SetPositionY;
    //property StepX    : Double  read FStepX     write SetStepX;
    //property StepY    : Double  read FStepY     write SetStepY;
    property Size     : Integer read FSize      write SetSize;
    property FillColor: Integer read FFillColor write SetFillColor;
    property Left     : Integer write SetLeft;
    property Right    : Integer write SetRight;
    property Top      : Integer write SetTop;
    property Bottom   : Integer write SetBottom;
    property Rect     : TRect   read FRect;
  end;

//------------------------------------------------------------------------------
implementation

procedure TBaseRecht.SetBottom(const Value: Integer);
begin
  fRect.Bottom := Value;
end;

procedure TBaseRecht.SetLeft(const Value: Integer);
begin
  fRect.Left := Value;
end;

procedure TBaseRecht.SetRight(const Value: Integer);
begin
  fRect.Right := Value;
end;

procedure TBaseRecht.SetTop(const Value: Integer);
begin
  fRect.Top := Value;
end;

{procedure TBaseRecht.SetKoordinates(X1: Integer; Y1: Integer; X2: Integer; Y2: Integer);
begin
  Points[0,0] := X1; // P0----- 4 Punkte des Rechtecks: ------------------------
  Points[0,1] := Y1; //
                     //             0----1
  Points[1,0] := X2; // P1          |    |
  Points[1,1] := Y1; //             |    |
                     //             |    |
  Points[2,0] := X2; // P2          3----2
  Points[2,1] := Y2; //
                     //
  Points[3,0] := X1; // P3
  Points[3,1] := Y2; // --------------------------------------------------------
end; }

procedure TBaseRecht.SetPoints (Index: Integer; IndK: Integer; Value: Integer);
begin
  FPoints[Index][IndK] := Value;
end;

function  TBaseRecht.GetPoints  (Index: Integer; IndK: Integer): Integer;
begin
  Result := FPoints[Index][IndK];
end;

procedure TBaseRecht.Paint (Canvas: TCanvas);
begin
  //inherited Paint (Canvas);
  Canvas.Pen.Width := 1;
  Canvas.Pen.Color := clGreen;
  Canvas.Brush.Color := FFillColor;
  Canvas.Rectangle (rect.left , rect.top, rect.right, rect.bottom);
end;

{procedure TBaseRecht.SetStepX(const Value: Double);
begin
  FStepX := Value;
end;

procedure TBaseRecht.SetStepY(const Value: Double);
begin
  FStepY := Value;
end;}

procedure TBaseRecht.SetPositionX(const Value: Integer);
begin
  FPositionX := Value;
end;

procedure TBaseRecht.SetPositionY(const Value: Integer);
begin
  FPositionY := Value;
end;

procedure TBaseRecht.SetSize(const Value: Integer);
begin
  FSize := Value;
end;

procedure TBaseRecht.SetFillColor(const Value: Integer);
begin
  FFillColor := Value;
end;

end.

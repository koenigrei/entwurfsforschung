object Form1: TForm1
  Left = 0
  Top = 0
  Width = 644
  Height = 514
  Caption = 'Form1'
  Color = clActiveCaption
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -13
  Font.Name = 'Tahoma'
  Font.Style = []
  OldCreateOrder = False
  OnCreate = FormCreate
  PixelsPerInch = 120
  TextHeight = 16
  object ImagePaint: TImage
    Left = 32
    Top = 32
    Width = 409
    Height = 393
  end
  object Label1: TLabel
    Left = 464
    Top = 88
    Width = 113
    Height = 16
    Caption = 'generate per Click: '
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clWhite
    Font.Height = -13
    Font.Name = 'Tahoma'
    Font.Style = []
    ParentFont = False
  end
  object Label_Numbers: TLabel
    Left = 579
    Top = 88
    Width = 21
    Height = 16
    Caption = '___'
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clWhite
    Font.Height = -13
    Font.Name = 'Tahoma'
    Font.Style = []
    ParentFont = False
  end
  object Label_area: TLabel
    Left = 467
    Top = 312
    Width = 119
    Height = 16
    Caption = '_________________'
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clRed
    Font.Height = -13
    Font.Name = 'Tahoma'
    Font.Style = []
    ParentFont = False
  end
  object Label2: TLabel
    Left = 464
    Top = 296
    Width = 151
    Height = 16
    Caption = 'min. '#220'berlagerungsfl'#228'che:'
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clWhite
    Font.Height = -13
    Font.Name = 'Tahoma'
    Font.Style = []
    ParentFont = False
  end
  object Label3: TLabel
    Left = 464
    Top = 252
    Width = 83
    Height = 16
    Caption = 'Mutationsrate:'
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clWhite
    Font.Height = -13
    Font.Name = 'Tahoma'
    Font.Style = []
    ParentFont = False
  end
  object Label_Mutate: TLabel
    Left = 563
    Top = 252
    Width = 21
    Height = 16
    Caption = '___'
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clWhite
    Font.Height = -13
    Font.Name = 'Tahoma'
    Font.Style = []
    ParentFont = False
  end
  object Label_Ready: TLabel
    Left = 467
    Top = 352
    Width = 109
    Height = 16
    Caption = 'Programm bereit'
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clWhite
    Font.Height = -13
    Font.Name = 'Tahoma'
    Font.Style = [fsBold]
    ParentFont = False
  end
  object Label4: TLabel
    Left = 464
    Top = 196
    Width = 93
    Height = 16
    Caption = 'Variationsweite:'
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clWhite
    Font.Height = -13
    Font.Name = 'Tahoma'
    Font.Style = []
    ParentFont = False
  end
  object Label_Variation: TLabel
    Left = 563
    Top = 196
    Width = 21
    Height = 16
    Caption = '___'
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clWhite
    Font.Height = -13
    Font.Name = 'Tahoma'
    Font.Style = []
    ParentFont = False
  end
  object Label5: TLabel
    Left = 464
    Top = 140
    Width = 89
    Height = 16
    Caption = 'Rechteckgr'#246#223'e:'
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clWhite
    Font.Height = -13
    Font.Name = 'Tahoma'
    Font.Style = []
    ParentFont = False
  end
  object Label_Size: TLabel
    Left = 563
    Top = 140
    Width = 21
    Height = 16
    Caption = '___'
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clWhite
    Font.Height = -13
    Font.Name = 'Tahoma'
    Font.Style = []
    ParentFont = False
  end
  object Button_createRecht: TButton
    Left = 464
    Top = 32
    Width = 137
    Height = 25
    Caption = 'Rechtecke erstellen'
    TabOrder = 0
    OnClick = Button_createRechtClick
  end
  object Button_delete: TButton
    Left = 464
    Top = 400
    Width = 137
    Height = 25
    Caption = 'Rechtecke l'#246'schen'
    TabOrder = 1
    OnClick = Button_deleteClick
  end
  object ScrollBar_Numbers: TScrollBar
    Left = 464
    Top = 64
    Width = 137
    Height = 16
    LargeChange = 5
    Min = 1
    PageSize = 3
    Position = 20
    TabOrder = 2
    OnChange = ScrollBar_NumbersChange
  end
  object ScrollBar_Mutate: TScrollBar
    Left = 464
    Top = 232
    Width = 137
    Height = 16
    LargeChange = 5
    Max = 50
    PageSize = 3
    Position = 1
    TabOrder = 3
    OnChange = ScrollBar_MutateChange
  end
  object ScrollBar_Variantion: TScrollBar
    Tag = 2
    Left = 464
    Top = 176
    Width = 137
    Height = 16
    LargeChange = 5
    Min = 1
    PageSize = 3
    Position = 10
    TabOrder = 4
    OnChange = ScrollBar_VariantionChange
  end
  object ScrollBar_Size: TScrollBar
    Left = 464
    Top = 120
    Width = 137
    Height = 16
    LargeChange = 5
    PageSize = 3
    Position = 30
    TabOrder = 5
    OnChange = ScrollBar_SizeChange
  end
  object ApplicationEvents1: TApplicationEvents
    OnIdle = ApplicationEvents1Idle
    Left = 48
    Top = 48
  end
end

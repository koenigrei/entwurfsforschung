(********************************************************************)
(*                                                                  *) 
(*                                                                  *)
(*                       Zellul�rer Automat                         *)
(*                          Version 1.0                             *)
(*                      Vicsek-Szalay Model                         *)
(*                                                                  *)
(*                                                                  *)
(*     Programmierer: Reinhard K�nig                  December 2005 *)
(*                    http://www.entwurfsforschung.de/              *)
(*                                                                  *)
(*     Last Update: Dec-14, 2005                                    *)
(*                                                                  *)
(********************************************************************) 
{revision history:

1.0     [Dec-14, 2005]
        first release to the public

}

unit CellForm;

interface

uses
  Windows, Messages, SysUtils, Variants, Classes, Graphics, Controls, Forms,
  Dialogs, StdCtrls, Cell_P, node, ExtCtrls, ButtonGroup, ComCtrls, Math, ToolWin,
  ImgList, Epina.SDL.rchart;

type
  TForm1 = class(TForm)
    ZeichenPanel : TPanel;
    Timer1       : TTimer;
    lbl_Steps    : TLabel;
    B_setup      : TButton;
    lbl_timesteps: TLabel;
    Label2       : TLabel;
    Edit_thresh  : TEdit;
    B_start      : TButton;
    B_stop       : TButton;
    RChart1      : TRChart;
    B_go         : TButton;
    procedure B_goClick(Sender: TObject);
    procedure B_stopClick(Sender: TObject);
    procedure B_startClick(Sender: TObject);
    procedure B_setupClick(Sender: TObject);
    procedure Timer1Timer(Sender: TObject);
    procedure FormDestroy(Sender: TObject);
    procedure FormCreate(Sender: TObject);
  private
    cellList     : Array of Array of TCell;
    limboWorld   : Array of Array of Extended;
    function  CalcDistance(pAX: Integer; pAY: Integer; pBX: Integer; pBY: Integer): Integer;
    procedure RasterCreate;
    procedure setup;
    procedure createPaintImg;
    procedure checkNei (K, I: Integer);
    function rndN(lower : Integer; upper : Integer):Integer;
  public

  end;

var
  Form1: TForm1;
  paintImg : TImage;
  steps: Integer;

implementation

{$R *.dfm}

const                      //-- globale Konstanten
  cellScal  = 3;          //-- Zellen gr��e

var                        //-- globale Variablen
  reih  : Integer;   //-- Zellen-Reihen gesamt
  spalt : Integer;   //-- Zellen-Spalten gesamt

// ---------------------------------------------------------------------------//
// *** Initialisierung ***
procedure TForm1.FormCreate(Sender: TObject);
begin
  spalt := round (ZeichenPanel.Width / cellScal);
  reih  := round (ZeichenPanel.Height / cellScal);
  SetLength(cellList, spalt, reih);
  SetLength(limboWorld, spalt, reih);
  createPaintImg;
  RasterCreate;
  ZeichenPanel.DoubleBuffered := True;       //-- Verhindert Flackern der Zellen
  steps := 0;
end;

// ---------------------------------------------------------------------------//
// ---------------------------------------------------------------------------//
// *** Erstellt das Raster ***

function TForm1.rndN(lower : Integer; upper : Integer):Integer;
begin
  Result := round ((upper - lower + 1) * Random() + lower);
end;

procedure TForm1.RasterCreate;
var
  curCell : TCell;
  size    : Integer;
  I       : Integer;
  K       : Integer;
  upperB  : Integer;
  lowerB  : Integer;
begin
  size := round(cellScal/2);
  Randomize();
  for I := 0 to reih -1 do
  begin
    for K := 0 to spalt -1 do
    begin
      curCell := TCell.Create(size + K * cellScal, size + I * cellScal, size, 0);
      cellList[K,I] := curCell;
      curCell.SetState((random(2)*2)-1);      // -- nur -1 und 1
      //curCell.SetState((random() -0.5) *2); // -- zwischen -1 und 1
      curCell.colr := 0; //alle Zellen schwarz
      curCell.Paint(paintImg.Canvas);
    end;
  end;

  // -- Diagramm initialisieren --
  RChart1.Scale1X.RangeLow := 0;                { range of chart area }
  RChart1.Scale1X.RangeHigh := 1000;  //-- Maximale Reichweite bei Testversion!!!
  RChart1.Scale1Y.RangeLow := -8;
  RChart1.Scale1Y.RangeHigh := 8;
  RChart1.ClearGraf;                          { initialize chart }
  RChart1.MoveTo (0,0);                { initial cursor position }
end;

procedure TForm1.setup;
var
  curCell : TCell;
  I       : Integer;
  K       : Integer;
begin
  Randomize();
  for I := 0 to reih -1 do
  begin
    for K := 0 to spalt -1 do
    begin
      curCell := cellList[K,I];
      curCell.SetState((random(2)*2)-1);
      //curCell.SetState((random() -0.5) *2); // -- zwischen -1 und 1
      curCell.colr := 0; //round ((255 / 2) * (1 + curCell.state)); //-- Farbe in Abh. des H�chstwerts
      curCell.Paint(paintImg.Canvas);
    end;
  end;
  RChart1.ClearGraf;                          { initialize chart }
  RChart1.MoveTo (0,0);
end;

// *** Legt eine leere Zeichenfl�che �ber das Zeichenpanel ***
procedure TForm1.createPaintImg;
begin
  paintImg := TImage.Create(self);
  paintImg.Parent  := ZeichenPanel;
  //paintImg.Enabled := False;       //-- PaintImg reagiert nicht auf Mausereignisse
  //paintImg.Transparent:= true;    //-- und ist transparent
  paintImg.top        := 0;
  paintImg.Left       := 0;
  paintImg.Height     := ZeichenPanel.Height;
  paintImg.Width      := ZeichenPanel.Width;
end;

procedure TForm1.checkNei (K, I: Integer);
var
  u  : Integer;
  v  : Integer;
  Xp : Integer;
  Yp : Integer;
  neighb : Array [0..4] of TPoint;
begin
  neighb[0].X := 0; //-- center
  neighb[0].Y := 0;
  neighb[1].X := -1; //-- left
  neighb[1].Y := 0;
  neighb[2].X := 1; //-- right
  neighb[2].Y := 0;
  neighb[3].X := 0; //-- upper
  neighb[3].Y := 1;
  neighb[4].X := 0; //-- lower
  neighb[4].Y := -1;
  // --- Summe berechnen ---
  for u := 0 to 4 do
  begin
    Xp := K + neighb[u].X;
    Yp := I + neighb[u].Y;
    // -- Torus --
    if Xp < 0       then Xp := reih-1;
    if Xp > spalt-1 then Xp := 0;
    if Yp < 0       then Yp := spalt-1;
    if Yp > reih-1  then Yp := 0;
    limboWorld[K, I] := limboWorld[K, I] + cellList[Xp, Yp].state;
  end;
end;

procedure TForm1.Timer1Timer(Sender: TObject);
var
  curCell : TCell;
  I       : Integer;
  K       : Integer;
  Pges    : Extended;
  Pavg    : Extended;
  maxP    : Extended;
  mK      : Array [0..1] of Integer;
  alpha   : real;
  Schwelle: real;
begin
  maxP := 0;
  Pges := 0;
  Schwelle := StrToFloat(Edit_thresh.Text); //4.5;
  for I := 0 to reih -1 do
  begin
    for K := 0 to spalt -1 do
    begin
      limboWorld[K, I] := 0; // -- LimboWorld l�schen
      checkNei(K, I);        // -- Nachbarschaftswerte in limboWorld zusammenz�hlen
      Pges := Pges + limboWorld[K, I];
    end;
  end;
  Pavg := Pges / (reih * spalt);
  //Pavg := (random(3)-1);
  for I := 0 to reih -1 do
  begin
    for K := 0 to spalt -1 do
    begin
      curCell := cellList[K, I];
      curCell.maxP := false;

      //-- Growth - function
      curCell.State := (limboWorld[K, I] / 5)+((random(2)*2)-1);

      //-- Maximalwert und zugeh�rige Zelle ermitteln --
      if abs(curCell.State) > abs(maxP) then begin
        maxP := curCell.State;
        //mK[0] := K;
        //mK[1] := I;
      end;
    end;
  end;
  If maxP = 0 then begin  // -- Stop wenn alles 0
    Timer1.enabled := false;
    exit;
  end;
  //cellList[mk[0], mk[1]].maxP := true; // -- Zelle mit Maximalwert markieren

  for I := 0 to reih -1 do   //-- Schleife kann gespart werden! nur wegen maximalWert Markierung notwendig
  begin
    for K := 0 to spalt -1 do
    begin
      curCell := cellList[K, I];
      // --- Farbe bestimmen und zeichen ---
      If (abs(curCell.state) > Schwelle) and (curCell.colr = 0)  then
        curCell.colr := 255;
      curCell.Paint(paintImg.Canvas);
    end;
  end;
  steps := steps +1;
  lbl_Steps.Caption := intToStr (steps);

  if steps < 1000 then begin // -- Maximalwert Plotten
    //RChart1.Scale1Y.RangeHigh := maxP;
    RChart1.DataColor := clRed;
    RChart1.DrawTo (steps, maxP);
    //RChart1.DataColor := clBlack;
    //RChart1.DrawTo (steps, Pavg*10);
    RChart1.ShowGraf;                   { show the chart on screen }
  end;
end;

function TForm1.CalcDistance(pAX: Integer; pAY: Integer; pBX: Integer; pBY: Integer): Integer;
var
  temp : double;
begin
  temp := sqrt(Power((pAX - pBX), 2) + Power((pAY - pBY), 2));
  Result := Round(temp);
end;

procedure TForm1.FormDestroy(Sender: TObject);
begin
  paintImg.Free;
  ZeichenPanel.Free;
end;

procedure TForm1.B_setupClick(Sender: TObject);
begin
  setup;
  steps := 0;
end;

procedure TForm1.B_startClick(Sender: TObject);
begin
  Timer1.enabled := true;
end;

procedure TForm1.B_stopClick(Sender: TObject);
begin
  Timer1.enabled := false;
end;

procedure TForm1.B_goClick(Sender: TObject);
begin
  Timer1.enabled := true;
end;

end.

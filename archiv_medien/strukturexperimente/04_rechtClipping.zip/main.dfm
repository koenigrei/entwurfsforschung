object Form1: TForm1
  Left = 0
  Top = 0
  Width = 626
  Height = 513
  Caption = 'Form1'
  Color = clActiveCaption
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -13
  Font.Name = 'Tahoma'
  Font.Style = []
  OldCreateOrder = False
  OnCreate = FormCreate
  PixelsPerInch = 120
  TextHeight = 16
  object ImagePaint: TImage
    Left = 32
    Top = 32
    Width = 410
    Height = 394
  end
  object Label1: TLabel
    Left = 464
    Top = 88
    Width = 113
    Height = 16
    Caption = 'generate per Click: '
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clWhite
    Font.Height = -13
    Font.Name = 'Tahoma'
    Font.Style = []
    ParentFont = False
  end
  object Label_Numbers: TLabel
    Left = 579
    Top = 88
    Width = 25
    Height = 16
    Caption = '___'
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clWhite
    Font.Height = -13
    Font.Name = 'Tahoma'
    Font.Style = []
    ParentFont = False
  end
  object Label_area: TLabel
    Left = 467
    Top = 160
    Width = 119
    Height = 16
    Caption = '_________________'
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clWhite
    Font.Height = -13
    Font.Name = 'Tahoma'
    Font.Style = []
    ParentFont = False
  end
  object Label2: TLabel
    Left = 464
    Top = 144
    Width = 122
    Height = 16
    Caption = #220'berlagerungsfl'#228'che:'
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clWhite
    Font.Height = -13
    Font.Name = 'Tahoma'
    Font.Style = []
    ParentFont = False
  end
  object Button_createRecht: TButton
    Left = 464
    Top = 32
    Width = 137
    Height = 25
    Caption = 'Rechtecke erstellen'
    TabOrder = 0
    OnClick = Button_createRechtClick
  end
  object Button_delete: TButton
    Left = 464
    Top = 208
    Width = 137
    Height = 25
    Caption = 'Rechtecke l'#246'schen'
    TabOrder = 1
    OnClick = Button_deleteClick
  end
  object Button_Overlap: TButton
    Left = 464
    Top = 112
    Width = 137
    Height = 25
    Caption = #220'berlagerungsfl'#228'chen'
    TabOrder = 2
    OnClick = Button_OverlapClick
  end
  object ScrollBar_Numbers: TScrollBar
    Left = 464
    Top = 64
    Width = 137
    Height = 16
    Max = 50
    Min = 1
    PageSize = 3
    Position = 10
    TabOrder = 3
    OnChange = ScrollBar_NumbersChange
  end
end

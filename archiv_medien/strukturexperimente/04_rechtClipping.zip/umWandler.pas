unit umWandler;

interface

uses
  Windows, Messages, SysUtils, Variants, Classes, Graphics, Controls, Forms,
  Dialogs, ExtCtrls, StdCtrls, rechteck, VarCmplx, Math;

implementation

function IntToBin(iSrc: Byte): String;
{ Umwandlung Byte in String mit Bin�rwert }
var
  i : Integer;
begin
  Result := '';
  For i := 1 to 4 do begin
    Result := IntToStr(iSrc AND 1) + Result;
    iSrc := iSrc shr 1;
  end;
end;

function BinToInt(const Value: string): Integer;  
var  
  i: Integer;
  Digit: Char;
begin  
  Result := 0;
  for i := 1 to Length(Value) do  
  begin  
    Digit := Value[i];  
    case Digit of  
      '0'..'1': Result := (Result shl 1) or (Ord(Digit) - Ord('0'));  
      ' ': ;  
    else  
      if Digit <> ThousandSeparator then  
        raise EConvertError.Create('keine Bin�rzahl');  
    end;  
  end;  
end;

{function IntToBin(Value: LongInt;
                  Digits: Integer): String;
var
 i: Integer;
begin
 Result:='';
 for i:=Digits downto 0 do
  if Value and (1 shl i)<>0 then
   Result:=Result + '1'
  else
   Result:=Result + '0';
end; }

{function BinToInt(Value: String): LongInt;
var i: Integer;
begin
 Result:=0;
//remove leading zeros
 while Copy(Value,1,1)='0' do
  Value:=Copy(Value,2,Length(Value)-1);
//do the conversion
 for i:=Length(Value) downto 1 do
  if Copy(Value,i,1)='1' then
   Result:=Result+(1 shl (i-1));
end;  }

{function IntToBin(int: integer): string;
begin
  Result := DezToX(int,2);
end; }

{function DezToX(dez, bas: Cardinal): String;
const  
zahlen: array[0..15] of Char =  
  ('0', '1', '2', '3', '4', '5', '6', '7',  
   '8', '9', 'A', 'B', 'C', 'D', 'E', 'F');  
begin  
if dez <> 0 then  
  Result := DezToX(dez div bas, bas) + zahlen[dez mod bas]  
else  
  Result := '';  
end;}

{function IntToBin(iSrc: Byte): String;
//--- Umwandlung Byte in String mit Bin�rwert 
var  
  i : Integer;  
begin  
  Result := '';  
  For i := 1 to 8 do begin
    //Result := IntToStr(iSrc AND 1) + Result;
    iSrc := iSrc shr 1;  
  end;  
end;}

{function BitVergleich(sMask: String; iSrc: Byte): Boolean;
//--- Vergleicht Bin�r mit Maske. Alles ausser '0' und '1' sind Joker
var  
  i : Integer;  
  sSrc : String[8];  
begin  
  sSrc := IntToBin(iSrc);
  While Length(sMask) < 8 do sMask := '*' + sMask; // Maske auf 8 Zeichen erweitern  
  Result := true;  
  For i := 1 to 8 do begin  
    IF (sMask[i] in ['0','1']) AND (sSrc[i] <> sMask[i]) then Result := false;  
  end;  
end;}

{function IntToBin(int: integer): string;
begin
  Result := DezToX(int,2);
end; }

{function BinToSingle(const s: String): Single;
type  
  PSingle = ^Single;  
begin  
  Result := PSingle(PChar(s))^;  
end;}

{function BaseToBase(Value: string; StartBase, EndBase: Byte): string;
const Digits = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ';   
var i: Integer; dec, j: Int64;  
begin  
  j:=1;  
  dec:=0;  
  for i:=Length(Value) downto 1 do begin  
    dec:=dec + (Pos(Value[i], Digits)-1) * j;  
    j:=j*StartBase;  
  end;  
  Result:='';  
  repeat  
    Result:=Digits[dec mod EndBase+1] + Result;  
    dec:=dec div EndBase;  
  until dec=0;  
end;  }

{function completeString (value: String): String;
begin
  while (length(value) < 4) do
  begin
    value := '0' + value;
  end;
  Result := value;
end; }

end.

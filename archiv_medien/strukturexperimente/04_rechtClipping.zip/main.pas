unit main;

interface

uses
  Windows, Messages, SysUtils, Variants, Classes, Graphics, Controls, Forms,
  Dialogs, ExtCtrls, StdCtrls, rechteck, VarCmplx, Math;

type
  TForm1 = class(TForm)
    ImagePaint: TImage;
    Button_createRecht: TButton;
    Button_delete: TButton;
    Button_Overlap: TButton;
    ScrollBar_Numbers: TScrollBar;
    Label1: TLabel;
    Label_Numbers: TLabel;
    Label_area: TLabel;
    Label2: TLabel;
    procedure ScrollBar_NumbersChange(Sender: TObject);
    procedure Button_OverlapClick(Sender: TObject);
    procedure Button_deleteClick(Sender: TObject);
    procedure Button_createRechtClick(Sender: TObject);
    procedure FormCreate(Sender: TObject);
  private
    { Private declarations }
    ShapesList: TList;
    LapsList  : TList;
    //CurrShape : TBaseRecht;
    procedure RechtPaint(Canvas: TCanvas);
    procedure checkOverlap;
    procedure sumAreas;
    procedure Schnittpunkt (a1X: Integer; a1Y: Integer; a2X: Integer; a2Y: Integer;
                            b1X: Integer; b1Y: Integer; b2X: Integer; b2Y: Integer;
                             var xStelle:Integer; var yStelle: Integer);
  public
    { Public declarations }
  end;

var
  Form1: TForm1;

implementation

{$R *.dfm}
var
  Backpuffer    : TBitmap;
  numbers       : Integer;

//--- Form initialisieren-------------------------------------------------------
procedure TForm1.FormCreate(Sender: TObject);
begin
  Form1.color           := clBlack;
  ShapesList            := TList.Create;
  LapsList              := TList.Create;
  Label_Numbers.Caption := IntToStr(ScrollBar_Numbers.Position);
  numbers               := ScrollBar_Numbers.Position;
  Label_area.Caption    := '0';
  //--- Zwischenspeicher f�r die Bildaktualisierung -----------------
  Backpuffer            := TBitmap.create;
  Backpuffer.width      := ImagePaint.width;
  Backpuffer.height     := ImagePaint.height;
  Backpuffer.canvas.brush.color := clblack;
  Backpuffer.canvas.rectangle(0,0,Backpuffer.width,Backpuffer.height);
end;

//--- Button Rechtecke erstellen -----------------------------------------------
procedure TForm1.Button_createRechtClick(Sender: TObject);
var
  rechtA : TBaseRecht;
  I      : Integer;
begin
  for I:= 1 to numbers Do
  begin
    rechtA := TBaseRecht.Create;
    rechtA.PositionX := random(ImagePaint.Width);
    rechtA.PositionY := random(ImagePaint.Height); //round(ImagePaint.Height /2); random(50)
    rechtA.SetKoordinates(rechtA.PositionX - 10 - random(50), rechtA.PositionY - 10 - random(50),
                          rechtA.PositionX + 10 + random(50), rechtA.PositionY + 10 + random(50));
    rechtA.FillColor := clRed;
    ShapesList.Add (rechtA);                 //-- neues Rechtecke zur Liste hinzuf�gen
  end;
  RechtPaint(Backpuffer.Canvas);             //-- Rechtecke zeichnen
end;

//--- Button �berlagerungen berechnen ------------------------------------------
procedure TForm1.Button_OverlapClick(Sender: TObject);
var I : Integer;
begin
  for I := LapsList.Count - 1 downto 0 do
  begin
    TBaseRecht (LapsList [I]).Free;
  end;
  LapsList    := TList.Create;

  checkOverlap;                              //-- Auf �berlappung pr�fen
  RechtPaint(Backpuffer.Canvas);             //-- Rechtecke zeichnen
  sumAreas;                                  //-- �berlagerungsfl�chen addieren
end;

//--- Rechtecke zeichnen -------------------------------------------------------
procedure TForm1.RechtPaint(Canvas: TCanvas);
var
  I      : Integer;
  rechtA : TBaseRecht;
begin
  //--- Backpuffer l�schen ------------------------------------------
  Backpuffer.canvas.brush.color := clblack;
  Backpuffer.canvas.pen.color := clgreen;
  Backpuffer.canvas.rectangle(0,0,Backpuffer.width,Backpuffer.height);
  //--- Rechtecke der Liste zeichnen --------------------------------
  For I := 0 To ShapesList.Count - 1 do
  begin
    rechtA := ShapesList.Items[I];
    rechtA.FillColor := clRed;
    rechtA.Paint(Canvas);
  end;
  //--- �berlagerungsfl�chen aus Liste zeichnen ----------------------
  For I := 0 To LapsList.Count - 1 do
  begin
    rechtA := LapsList.Items[I];
    rechtA.FillColor := clBlue;
    rechtA.Paint(Canvas);
  end;
  ImagePaint.Canvas.Draw (0, 0, Backpuffer); //-- Backpuffer auf Zeichenfl�che kopieren
end;

//--- Berechnet und addiert die �berlagerungsfl�chen ---------------------------
procedure TForm1.sumAreas;
var
  I      : Integer;
  rechtA : TBaseRecht;
  siteA  : Integer;
  siteB  : Integer;
  area   : LongInt;
begin
  area := 0;
  For I := 0 To LapsList.Count - 1 do
  begin
    rechtA := LapsList.Items[I];
    siteA:= rechtA.Points[3,1] - rechtA.Points[0,1];
    siteB:= rechtA.Points[1,0] - rechtA.Points[0,0];
    area := area + siteA * siteB;
  end;
  Label_area.Caption := IntToStr(area);
end;

//--- Datenumwandlung ----------------------------------------------------------
function IntToBin(iSrc: Byte): String;
{ Umwandlung Byte in String mit Bin�rwert }
var
  i : Integer;
begin
  Result := '';
  For i := 1 to 4 do begin
    Result := IntToStr(iSrc AND 1) + Result;
    iSrc := iSrc shr 1;
  end;
end;

function BinToInt(const Value: string): Integer;  
var  
  i: Integer;
  Digit: Char;
begin  
  Result := 0;
  for i := 1 to Length(Value) do  
  begin  
    Digit := Value[i];  
    case Digit of  
      '0'..'1': Result := (Result shl 1) or (Ord(Digit) - Ord('0'));  
      ' ': ;  
    else  
      if Digit <> ThousandSeparator then  
        raise EConvertError.Create('keine Bin�rzahl');  
    end;  
  end;  
end;

//****************** Sutherland-Hodgman-Algorithmus ****************************
//---Erl�uterung siehe z.B.: ---------------------------------------------------
//---http://www.informatik.fh-muenchen.de/~schieder/graphik-01-02/slide0087.html
//------------------------------------------------------------------------------
procedure TForm1.checkOverlap;
var
  I,K,U,V,J,N: Integer;    //-- Laufvariablen
  xmax       : Integer;    //-- Werte des Ursprungs-Rechtecks
  xmin       : Integer;    //     ""
  ymax       : Integer;    //     ""
  ymin       : Integer;    //     ""
  ptX        : Integer;    //-- aktuelle Vergleichspunkte
  ptY        : Integer;    //     ""
  rechtA     : TBaseRecht; //-- Container f�r Rechtecke
  rechtB     : TBaseRecht; //     ""
  rechtLap   : TBaseRecht; //     ""
  p0C        : Integer;    //-- Integer-Wert des bin�ren 'clipCode'
  p1C        : Integer;    //     ""
  p2C        : Integer;    //     ""
  p3C        : Integer;    //     ""
  idx        : Integer;    //-- Indexwert
  NrPt       : Integer;    //     ""
  lapped     : Boolean;    //-- Pr�fwerte
  test       : String;     //     ""
  lapKoord   : Array [0..3] of Array [0..1] of Integer; // -- Koordinaten des neuen Rechtecks
  tempKoord  : Array [0..3] of Array [0..1] of Integer; // -- Zwischenspeicher zum Sortieren
  clipCode   : Array [0..3] of String;                  // -- BitCode der Punkt-Lage
  SchnittAchs: Array of Array of Integer;               // -- Zur definition der Schnittachse
begin
  If ShapesList.Count > 1 then
  For I := 0 To ShapesList.Count - 1 do
  begin
    rechtA := ShapesList.Items[I];          //-- Basis-Rechteck ----------------
    xmax := rechtA.Points[1,0];
    xmin := rechtA.Points[0,0];
    ymax := rechtA.Points[3,1];
    ymin := rechtA.Points[0,1];
    For K := I+1 To ShapesList.Count - 1 do //-- Werden auf �berlagerung gepr�ft
    begin
      rechtB := ShapesList.Items[K];        //-- Vergleichs-Clipping-Rechteck --
      //--- Vorarbeit: Umfeld der CA in Gebiete aufteilen,              --------
      //---            dabei jedem Gebiet einen bin�ren Code zuordnen:  --------
      lapped := false;
      For U:=0 to 3 do
      begin
        ptX := rechtB.Points[U,0];
        ptY := rechtB.Points[U,1];
        clipCode[U] := '0000';
        If ptY > ymax then   //--- bit 1 y > ymax
          clipCode[U][1] := '1';
        If ptY < ymin then   //--- bit 2 y < ymin
          clipCode[U][2] := '1';
        If ptX > xmax then   //--- bit 3 x > xmax
          clipCode[U][3] := '1';
        If ptX < xmin then   //--- bit 4 x < xmin
          clipCode[U][4] := '1';
      end;
      //--- Pr�fen, ob sich die Rechtecke �berlagern ---------------------------
      For U := 0 to 3 do
      begin
        p0C := BinToInt(clipCode[U]);
        V   := (U+1) mod 4; //---Laufvariable + 1 und bei U=3 => 0; schlie�t Kreis
        p1C := BinToInt(clipCode[V]);
        If (p0C = 0) OR ((p0C OR p1C) = 3) OR ((p0C OR p1C) = 12) then lapped := true;
      end;
      //----- Fall 0): Rechtecke �berlager die Vergleichsfl�che komplett -------
      p0C := BinToInt(clipCode[0]); p1C := BinToInt(clipCode[1]);
      p2C := BinToInt(clipCode[2]); p3C := BinToInt(clipCode[3]);
      If (p0C Or p1C Or p2C Or p3C) = 15 then
      begin
        For U := 0 to 3 do begin
          For J := 0 to 1 do begin
            lapKoord[U,J] := rechtA.Points[U,J]; //--- Koordinaten kopieren ----
          end;
        end;
        //--- Erstellen des �berlappungs-Rechtecks -----------------------------
        rechtLap := TBaseRecht.Create;
        rechtLap.SetKoordinates(lapKoord[0,0], lapKoord[0,1], lapKoord[2,0], lapKoord[2,1]);
        LapsList.Add (rechtLap); //--- In Liste der �berlappenden Fl�chen eintragen
      end;
      //-- �berpr�fen des clipCodes  (Cohen-Sutherland-Algorithmus)
      //-- a) beide Endpunkte haben Code 0000 (= innerhalb Fenster)
      //      Code 1 OR Code 2 = 0  Zeichne Linie
      //-- b) beide Endpunkte sind au�en: Oberhalb, unterhalb, links oder rechts vom inneren Fenster
      //      Code 1 AND Code 2  0  Zeichne Linie nicht
      //-- c) Fenster und Linie schneiden sich
      //      Wenn (Code 1 AND Code 2 = 0) und (Code 1 OR Code 2 NOT 0) ist  Schneide Linie mit Fenster
      NrPt := 0;
      If lapped = true then
      For U := 0 to 3 do
      begin
        p0C := BinToInt(clipCode[U]);
        V   := (U+1) mod 4; //---Laufvariable + 1 und bei U=3 => 0; schlie�t Kreis
        p1C := BinToInt(clipCode[V]);
      //----- Pr�fen der F�lle: ------------------------------------------------
      //----- Fall a) ----------------------------------------------------------
        If (p0C OR p1C) = 0 then //--beide Punkte bei Cliping-Rechteck: rechtLap
        begin                    //--ersten Punkte in rechtLap aufnehmen -------
          lapKoord[NrPt,0] := rechtB.Points[U,0];
          lapKoord[NrPt,1] := rechtB.Points[U,1];
          NrPt := NrPt + 1;
        end
      //----- Fall b) ----------------------------------------------------------
        Else If (NOT ((p0C AND p1C) = 0)) then //-- beide Punkte au�erhalb -----
        begin                     //--- Eckpunkt des Basis-Rechtecks zu lapRechteck
          If clipCode[V] = '0101' then begin      //--- links oben -------------
            lapKoord[NrPt,0] := rechtA.Points[0,0];
            lapKoord[NrPt,1] := rechtA.Points[0,1];
            NrPt := NrPt + 1;
          end
          else If clipCode[V] = '0110' then begin //--- rechts oben ------------
            lapKoord[NrPt,0] := rechtA.Points[1,0];
            lapKoord[NrPt,1] := rechtA.Points[1,1];
            NrPt := NrPt + 1;
          end
          else If clipCode[V] = '1010' then begin //--- rechts unten -----------
            lapKoord[NrPt,0] := rechtA.Points[2,0];
            lapKoord[NrPt,1] := rechtA.Points[2,1];
            NrPt := NrPt + 1;
          end
          else If clipCode[V] = '1001' then begin //--- links unten ------------
            lapKoord[NrPt,0] := rechtA.Points[3,0];
            lapKoord[NrPt,1] := rechtA.Points[3,1];
            NrPt := NrPt + 1;
          end;
        end
      //----- Fall c) ----------------------------------------------------------
      //-- Linie schneidet Fenster - Schnittpunk ist Punkt von rechtLap --------
        Else If ((p0C AND p1C) = 0) and (NOT ((p0C OR p1C) = 0)) then
        begin
          SetLength(SchnittAchs, 0);
          test:= IntToBin(p0C OR p1C); //--- Mit welcher Achse geschnitten -----
          If p0C = 0 then              //--- Addiere Anfangspunkt innerhalb ----
          begin
            lapKoord[NrPt,0] := rechtB.Points[U,0];
            lapKoord[NrPt,1] := rechtB.Points[U,1];
            NrPt := NrPt + 1;
          end;
          If test[1] = '1' then        //--- Schnittpunkt auf unterer Kante-----
          begin
            SetLength(SchnittAchs, length(SchnittAchs) + 2);
            idx := High(SchnittAchs);
            SetLength(SchnittAchs[idx-1], 2);
            SetLength(SchnittAchs[idx], 2);
            SchnittAchs[idx-1,0] := rechtA.Points[2,0];
            SchnittAchs[idx-1,1] := rechtA.Points[2,1];
            SchnittAchs[idx,0]   := rechtA.Points[3,0];
            SchnittAchs[idx,1]   := rechtA.Points[3,1];
          end;
          If test[2] = '1' then       //--- Schnittpunkt auf oberer Kante ------
          begin
            SetLength(SchnittAchs, length(SchnittAchs) + 2);
            idx := High(SchnittAchs);
            SetLength(SchnittAchs[idx-1], 2);
            SetLength(SchnittAchs[idx], 2);
            SchnittAchs[idx-1,0] := rechtA.Points[0,0];
            SchnittAchs[idx-1,1] := rechtA.Points[0,1];
            SchnittAchs[idx,0]   := rechtA.Points[1,0];
            SchnittAchs[idx,1]   := rechtA.Points[1,1];
          end;
          If test[3] = '1' then       //--- Schnittpunkt auf rechter Kante -----
          begin
            SetLength(SchnittAchs, length(SchnittAchs) + 2);
            idx := High(SchnittAchs);
            SetLength(SchnittAchs[idx-1], 2);
            SetLength(SchnittAchs[idx], 2);
            SchnittAchs[idx-1,0] := rechtA.Points[1,0];
            SchnittAchs[idx-1,1] := rechtA.Points[1,1];
            SchnittAchs[idx,0]   := rechtA.Points[2,0];
            SchnittAchs[idx,1]   := rechtA.Points[2,1];
          end;
          If test[4] = '1' then       //--- Schnittpunkt auf linker Kante ------
          begin
            SetLength(SchnittAchs, length(SchnittAchs) + 2);
            idx := High(SchnittAchs);
            SetLength(SchnittAchs[idx-1], 2);
            SetLength(SchnittAchs[idx], 2);
            SchnittAchs[idx-1,0] := rechtA.Points[3,0];
            SchnittAchs[idx-1,1] := rechtA.Points[3,1];
            SchnittAchs[idx,0]   := rechtA.Points[0,0];
            SchnittAchs[idx,1]   := rechtA.Points[0,1];
          end;
          //--- Schnittpunkte berechnen, falls gefunden ------------------------
          J := 0;
          If length(SchnittAchs) > 0 then
          While J < length(SchnittAchs) do
          begin
            Schnittpunkt(SchnittAchs[J,0], SchnittAchs[J,1], SchnittAchs[J+1,0], SchnittAchs[J+1,1],
                         rechtB.Points[U,0], rechtB.Points[U,1], rechtB.Points[V,0], rechtB.Points[V,1],
                         lapKoord[NrPt,0], lapKoord[NrPt,1]);
            NrPt := NrPt + 1;
            J := J + 2;
          end;
        end;
      end;

      //--- neues Rechteck zeichenen--------------------------------------------
      If (lapped = true) then
      begin
      //--- Koordinaten sortieren ----------------------------------------------
        For U := 0 to 3 do begin
          For J := 0 to 1 do begin
            tempKoord[U,J] := lapKoord[U,J]; //--- Koordinaten kopieren --------
          end;
        end;
        For N := 0 to 3 do begin  //--- Sortieren in Uhrzeigersinn -------------
            If ((lapKoord[N,0] <= tempKoord[0,0]) AND (lapKoord[N,1] <= tempKoord[0,1])) then
            begin
              tempKoord[0,0] := lapKoord[N,0];
              tempKoord[0,1] := lapKoord[N,1];
            end;
            If ((lapKoord[N,0] >= tempKoord[1,0]) AND (lapKoord[N,1] <= tempKoord[1,1])) then
            begin
              tempKoord[1,0] := lapKoord[N,0];
              tempKoord[1,1] := lapKoord[N,1];
            end;
            If ((lapKoord[N,0] >= tempKoord[2,0]) AND (lapKoord[N,1] >= tempKoord[2,1])) then
            begin
              tempKoord[2,0] := lapKoord[N,0];
              tempKoord[2,1] := lapKoord[N,1];
            end;
            If ((lapKoord[N,0] <= tempKoord[3,0]) AND (lapKoord[N,1] >= tempKoord[3,1])) then
            begin
              tempKoord[3,0] := lapKoord[N,0];
              tempKoord[3,1] := lapKoord[N,1];
            end;
        end;
        For U := 0 to 3 do begin
          For J := 0 to 1 do begin
            lapKoord[U,J] := tempKoord[U,J]; //--- Koordinaten zur�ck kopieren -
          end;
        end;

        //--- Erstellen des �berlappungs-Rechtecks -----------------------------
        rechtLap := TBaseRecht.Create;
        rechtLap.SetKoordinates(lapKoord[0,0], lapKoord[0,1], lapKoord[2,0], lapKoord[2,1]);
        LapsList.Add (rechtLap); //--- In Liste der �berlappenden Fl�chen eintragen
      end;
    //--- ende der Rechteck-vergleichs-Schleifen: ------------------------------
    end;
  end;
end;

//------------------------------------------------------------------------------
// --- Schnittpunktberechnung f�r rechte Winkel --------------------------------
procedure TForm1.Schnittpunkt (a1X: Integer; a1Y: Integer; a2X: Integer; a2Y: Integer;
                               b1X: Integer; b1Y: Integer; b2X: Integer; b2Y: Integer;
                               var xStelle:Integer; var yStelle: Integer);
var
  m : Double;
  m2: Double;
begin
  If (a2x-a1x) = 0 then //--- vertikale Gerade
  begin
    xstelle := a1X;
    ystelle := b1y;
    exit;
  end;

  If (b2x-b1x) = 0 then
  begin
    xstelle := b1X;
    ystelle := a1y;
    exit;
  end;
end; //-------------------------------------------------------------------------

// --- Anzahl der Rechtecke pro klick einstellen -------------------------------
procedure TForm1.ScrollBar_NumbersChange(Sender: TObject);
begin
  Label_Numbers.Caption := IntToStr(ScrollBar_Numbers.Position);
  numbers := ScrollBar_Numbers.Position;
end;

// --- Rechtecke l�schen -------------------------------------------------------
procedure TForm1.Button_deleteClick(Sender: TObject);
var I : Integer;
begin

  for I := ShapesList.Count - 1 downto 0 do
  begin
    TBaseRecht (ShapesList [I]).Free;
  end;

  for I := LapsList.Count - 1 downto 0 do
  begin
    TBaseRecht (LapsList [I]).Free;
  end;
  ShapesList  := TList.Create;
  LapsList    := TList.Create;
  Label_area.Caption := '0';
  Backpuffer.canvas.brush.color := clblack;
  Backpuffer.canvas.rectangle(0,0,Backpuffer.width,Backpuffer.height);
  ImagePaint.Canvas.Draw (0, 0, Backpuffer); //-- Backpuffer auf Zeichenfl�che kopieren
end;

end.

unit rechteck;

interface

uses
  Windows, Graphics;

type
  TBaseRecht = class
  private
    FPoints  : Array [0..3] of Array [0..1] of Integer;
    procedure SetPoints  (Index: Integer; IndK: Integer; Value: Integer);
    function  GetPoints  (Index: Integer; IndK: Integer): Integer;
  public
    FPositionX: Integer;
    FPositionY: Integer;
    FSize     : Integer;
    FStepX    : Double;
    FStepY    : Double;
    FFillColor: Integer;
    FState    : Integer;
    FPassed   : Integer;
    procedure Paint (Canvas: TCanvas); //virtual;
    procedure SetPositionX(const Value: Integer);
    procedure SetPositionY(const Value: Integer);
    procedure SetStepX(const Value: Double);
    procedure SetStepY(const Value: Double);
    procedure SetSize(const Value: Integer);
    procedure SetFillColor(const Value: Integer);
    procedure SetKoordinates(X1: Integer; Y1: Integer; X2: Integer; Y2: Integer);
    property  Points [Index: Integer; IndK: Integer]: Integer read GetPoints write SetPoints;
  published
    property PositionX: Integer read FPositionX write SetPositionX;
    property PositionY: Integer read FPositionY write SetPositionY;
    property StepX    : Double  read FStepX     write SetStepX;
    property StepY    : Double  read FStepY     write SetStepY;
    property Size     : Integer read FSize      write SetSize;
    property FillColor: Integer read FFillColor write SetFillColor;
  end;

{type
  TCell = class (TBaseCell)
    procedure Paint (Canvas: TCanvas); override;
  end;  }
  
//------------------------------------------------------------------------------
implementation

procedure TBaseRecht.SetKoordinates(X1: Integer; Y1: Integer; X2: Integer; Y2: Integer);
begin
  Points[0,0] := X1; // P0----- 4 Punkte des Rechtecks: ------------------------
  Points[0,1] := Y1; //
                     //             0----1
  Points[1,0] := X2; // P1          |    |
  Points[1,1] := Y1; //             |    |
                     //             |    |
  Points[2,0] := X2; // P2          3----2
  Points[2,1] := Y2; //
                     //
  Points[3,0] := X1; // P3
  Points[3,1] := Y2; // --------------------------------------------------------
end;

procedure TBaseRecht.SetPoints (Index: Integer; IndK: Integer; Value: Integer);
begin
  FPoints[Index][IndK] := Value;
end;

function  TBaseRecht.GetPoints  (Index: Integer; IndK: Integer): Integer;
begin
  Result := FPoints[Index][IndK];
end;

procedure TBaseRecht.Paint (Canvas: TCanvas);
begin
  //inherited Paint (Canvas);
  Canvas.Pen.Width := 1;
  Canvas.Pen.Color := clGreen;
  Canvas.Brush.Color := FFillColor;
  Canvas.Rectangle (Points[0,0] , Points[0,1], Points[2,0], Points[2,1]);
end;

procedure TBaseRecht.SetStepX(const Value: Double);
begin
  FStepX := Value;
end;

procedure TBaseRecht.SetStepY(const Value: Double);
begin
  FStepY := Value;
end;

procedure TBaseRecht.SetPositionX(const Value: Integer);
begin
  FPositionX := Value;
end;

procedure TBaseRecht.SetPositionY(const Value: Integer);
begin
  FPositionY := Value;
end;

procedure TBaseRecht.SetSize(const Value: Integer);
begin
  FSize := Value;
end;

procedure TBaseRecht.SetFillColor(const Value: Integer);
begin
  FFillColor := Value;
end;

end.

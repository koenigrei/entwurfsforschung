program network_02_evolve;

{%File 'ModelSupport\CellForm\CellForm.txvpck'}
{%File 'ModelSupport\cell_P\cell_P.txvpck'}
{%File 'ModelSupport\agenten\agenten.txvpck'}
{%File 'ModelSupport\default.txvpck'}
{%File 'ModelSupport\Calcer\Calcer.txvpck'}

uses
  Forms,
  CellForm in 'CellForm.pas' {Form1},
  cell_P in 'cell_P.pas',
  agenten in 'agenten.pas',
  Calcer in 'Calcer.pas';

{$R *.res}

begin
  Application.Initialize;
  Application.CreateForm(TForm1, Form1);
  Application.Run;
end.

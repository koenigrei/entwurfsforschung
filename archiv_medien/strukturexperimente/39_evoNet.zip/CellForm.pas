(********************************************************************)
(*                                                                  *) 
(*                                                                  *)
(*                          Network 01                              *)
(*                          Version 1.1                             *)
(*                                                                  *)
(*                                                                  *)
(*     Programmierer: Reinhard K�nig                     April 2006 *)
(*                    http://www.entwurfsforschung.de               *)
(*                                                                  *)
(*     Last Update: Apr-24, 2006                                    *)
(*                                                                  *)
(********************************************************************) 
{revision history:

1.0     [Apr-21, 2006]
        first release to the public
1.0     [Apr-24, 2006]
        genetic algorithm to find the best values for angleThresh and wiggle Thresh
}

unit CellForm;

interface

uses
  Windows, Messages, SysUtils, Variants, Classes, Graphics, Controls, Forms,
  Dialogs, StdCtrls, cell_P, ExtCtrls, ButtonGroup, ComCtrls, Math, ToolWin,
  ImgList, Epina.SDL.rchart, agenten, CategoryButtons, Calcer;

type
  TForm1 = class(TForm)
    ZeichenPanel   : TPanel;
    Timer1         : TTimer;
    RChart1        : TRChart;
    Lbl_mutate: TLabel;
    Label3         : TLabel;
    SB_mutate: TScrollBar;
    RadioGroup1    : TRadioGroup;
    rb_rulette     : TRadioButton;
    GroupBox1      : TGroupBox;
    B_setup        : TButton;
    B_stop         : TButton;
    B_oneStep      : TButton;
    CB_mCent       : TCheckBox;
    Edit_anzAg     : TEdit;
    Lbl_TextAnzahl : TLabel;
    Edit_size      : TEdit;
    Label2         : TLabel;
    rb_hill        : TRadioButton;
    GroupBox2      : TGroupBox;
    lbl_Steps      : TLabel;
    CB_diffuse     : TCheckBox;
    Lbl_strenght   : TLabel;
    Label5         : TLabel;
    SB_strenght    : TScrollBar;
    Lbl_evapo      : TLabel;
    Label6         : TLabel;
    SB_evapo       : TScrollBar;
    Lbl_sniff      : TLabel;
    Label7         : TLabel;
    SB_sniff       : TScrollBar;
    Lbl_visible    : TLabel;
    Label8         : TLabel;
    SB_visible     : TScrollBar;
    CB_hideAgs     : TCheckBox;
    Cb_cellUpdt    : TCheckBox;
    GroupBox3      : TGroupBox;
    Lbl_avgAngle   : TLabel;
    Label4         : TLabel;
    Lbl_avgWiggle  : TLabel;
    Label10        : TLabel;
    procedure SB_visibleChange     (Sender: TObject);
    procedure SB_sniffChange       (Sender: TObject);
    procedure SB_evapoChange       (Sender: TObject);
    procedure SB_strenghtChange    (Sender: TObject);
    procedure ZeichenPanelMouseUp  (Sender: TObject; Button: TMouseButton;
                                    Shift: TShiftState; X, Y: Integer);
    procedure ZeichenPanelMouseMove(Sender: TObject; Shift: TShiftState; X, Y: Integer);
    procedure ZeichenPanelMouseDown(Sender: TObject; Button: TMouseButton;
                                    Shift: TShiftState; X, Y: Integer);
    procedure Edit_sizeChange  (Sender: TObject);
    procedure SB_mutateChange  (Sender: TObject);
    procedure B_oneStepClick   (Sender: TObject);
    procedure B_stopClick      (Sender: TObject);
    procedure B_setupClick     (Sender: TObject);
    procedure Timer1Timer      (Sender: TObject);
    procedure FormDestroy      (Sender: TObject);
    procedure FormCreate       (Sender: TObject);
  private
    AgentList    : TList;
    FamilyList   : Array of Array of Integer;
    cellList     : Array of Array of TCell;
    limboWorld   : Array of Array of Extended;
    procedure createPaintImg;
    procedure createRaster;
    procedure createAgents;
    procedure SetupCells    (market: Array of TPoint);
    procedure SetupAgents   (market: Array of TPoint);
    procedure calcAgents;
    procedure repaintCells;
    procedure repaintAgents;
    procedure checkArea     (I : Integer);
    procedure calculate;
    procedure settings;
    procedure deleter;
    procedure markCell      (X, Y: Integer);
    procedure plot          (value1: Integer; value2: Integer);
    procedure resetGraph;
    procedure checkNei      (K, I: Integer);
    procedure diffuse;
    procedure multiCentre   (market: Array of TPoint);
    procedure SetupSource;
    procedure rebirth(curAgent: TAgent);
    procedure crossover(curAgent: TAgent; par: Array of Integer; fam: Integer);
    procedure mutate(curAgent: TAgent);
    procedure decline;
    procedure markCells(curAgent: TAgent; curCell: TCell; fromCell: TCell);
  public
end;

var
  Form1    : TForm1;
  paintImg : TImage;
  agentImg : TImage;

implementation

{$R *.dfm}

const                          //-- globale Konstanten
  Pi     = 3.141592654;
  AgSize = 2;                  //-- Agenten gr��e
  energy = 100000;

var                            //-- globale Variablen
  reih     : Integer;          //-- Zellen-Reihen gesamt
  spalt    : Integer;          //-- Zellen-Spalten gesamt
  steps    : Integer;
  Xmax     : Integer;
  Ymax     : Integer;
  cellSum  : Integer;
  OldY1    : Double;           //-- Speichert die Position t-1 f�r Graphen
  OldY2    : Double;           //-- Speichert die Position t-1 f�r Graphen
  cellScal : Integer;          //-- Zellen  gr��e
  halfScal : Integer;
  rDown    : Boolean;
  lDown    : Boolean;

// ---------------------------------------------------------------------------//
// *** Initialisierung *********************************************************
procedure TForm1.FormCreate(Sender: TObject);
begin
  settings;
  Lbl_mutate.Caption   := FloatToStr(SB_mutate.Position/100)  + ' %';
  Lbl_strenght.Caption := IntToStr(SB_strenght.Position);
  Lbl_evapo.Caption    := FloatToStr(SB_evapo.Position/100);
  Lbl_sniff.Caption    := FloatToStr(SB_sniff.Position);
  Lbl_visible.Caption  := FloatToStr(SB_visible.Position);

end;

// *** Settings ****************************************************************
procedure TForm1.settings;
var
  I : Integer;
  market  : Array [0..9] of TPoint;
begin
  cellScal  := StrToInt(Edit_size.Text) ;
  halfScal  := round(cellScal/2);
  spalt     := round (ZeichenPanel.Width / cellScal);
  reih      := round (ZeichenPanel.Height / cellScal);
  Xmax      := (spalt) * cellScal;
  Ymax      := (reih ) * cellScal;
  cellSum   := spalt * reih;
  //Randomize;      // -- activate for new configurations at every start
  for I := 0 to 9 do
  begin
    market[I].X := random(spalt);
    market[I].Y := random(reih);
  end;
  AgentList := TList.Create;
  SetLength(FamilyList, 10, 0);
  SetLength(cellList, spalt, reih);
  SetLength(limboWorld, spalt, reih);
  createPaintImg;
  CreateRaster;
  SetupCells(market);
  SetupSource;
  CreateAgents;
  SetupAgents(market);
  ZeichenPanel.Enabled := true;
  ZeichenPanel.DoubleBuffered := True;       //-- Verhindert Flackern der Zellen
  steps := 0;
  rDown := false;
  lDown := false;
  resetGraph;                                //-- Diagramm initialisieren
end;
// ---------------------------------------------------------------------------//
// ------------------------- Elemente erstellen ------------------------------//
// ---------------------------------------------------------------------------//

// *** Legt eine leere Zeichenfl�che �ber das Zeichenpanel *********************
procedure TForm1.createPaintImg;
begin
  paintImg        := TImage.Create(self);
  paintImg.Parent := ZeichenPanel;
  paintImg.top    := 0;
  paintImg.Left   := 0;
  paintImg.Height := ZeichenPanel.Height;
  paintImg.Width  := ZeichenPanel.Width;
  paintImg.Enabled:= False;               // -- does not reakt on mouseEvents

  agentImg        := TImage.Create(self);
  agentImg.Parent := ZeichenPanel;
  agentImg.top    := 0;
  agentImg.Left   := 0;
  agentImg.Height := ZeichenPanel.Height;
  agentImg.Width  := ZeichenPanel.Width;
  agentImg.Transparent := true;
  agentImg.Enabled:= False;
end;

// *** Agenten erstellen *******************************************************
procedure TForm1.CreateAgents;
var
  I        : Integer;
  curAgent : TAgent;
begin
  for I := 1 to StrToInt(Edit_anzAg.Text) do //   StrToInt(Edi_NrRed.Text) Do
  begin
    curAgent := TAgent.Create;
    AgentList.Add (curAgent);     // ---  add to the list
  end;
end;

// *** Agenten initialisieren **************************************************
procedure TForm1.SetupAgents(market: Array of TPoint);
var
  curAgent : TAgent;
  I , M    : Integer;
  val      : Integer;
begin
  Randomize();
  If CB_mCent.Checked = true Then val := 1 Else val := 0;
  for I := 0 to AgentList.Count - 1 do
  begin
    M := round(I mod 10);//random(10);
    curAgent := AgentList.Items [I];
    SetLength(FamilyList[M], length(FamilyList[M]) + 1);
    FamilyList[M, High(FamilyList[M])] := I;
    curAgent.family   := M;
    curAgent.Home.X   := market[M].X;
    curAgent.Home.Y   := market[M].Y;
    curAgent.onCell.X := market[M].X; //random (spalt);
    curAgent.onCell.Y := market[M].Y; // random (reih);
    curAgent.PosX     := curAgent.onCell.X * cellScal + halfScal;
    curAgent.PosY     := curAgent.onCell.Y * cellScal + halfScal;
    curAgent.Size     := AgSize;
    curAgent.State    := val;
    curAgent.Seeking  := true;
    curAgent.Heading  := random (360);
    curAgent.centr.X  := round(spalt/2);
    curAgent.centr.Y  := round(reih/2);
    curAgent.Paint   (agentImg.Canvas);
    curAgent.angleTh  := random (180);
    curAgent.wiggleTh := random (180);
    curAgent.energy   := energy;
    curAgent.success  := 0;
    curAgent.setChroma;
  end;
end;

// *** Zellen erstellen ********************************************************
procedure TForm1.CreateRaster;
var
  curCell : TCell;
  I       : Integer;
  K       : Integer;
begin
  for I := 0 to reih -1 do
  begin
    for K := 0 to spalt -1 do
    begin
      curCell := TCell.Create(halfScal + K * cellScal, halfScal + I * cellScal, halfScal, 0);
      cellList[K,I] := curCell;
    end;
  end;
end;

procedure TForm1.SetupSource;
var
  K, I, U, V : Integer;
begin
  K := round(spalt/2);
  I := round(reih/2);
  For U := -2 to 2 do
  begin
    For V := -2 to 2 do
    begin
      cellList[K+V ,I+U].source := true;
      cellList[K+V ,I+U].mark   := 10;
    end;
  end;
end;

// *** Zellen initialisieren ***************************************************
procedure TForm1.SetupCells(market: Array of TPoint);
begin
  OldY1   := 0;                          // -- Ausgangswert t=0 f�r Graphen
  Randomize();
  multiCentre(market);
end;

// *** setup cells with several centres across the field ***********************
procedure TForm1.multiCentre (market: Array of TPoint);
var
  curCell : TCell;
  I, K, M : Integer;
begin
  for I := 0 to reih -1 do
  begin
    for K := 0 to spalt -1 do
    begin
      curCell         := cellList[K,I];
      //curCell.besetzt := false;
      curCell.colr    := 255;
      curCell.mark    := 1;
      curCell.oldMark := 100;
      curCell.cent    := false;
      curCell.source  := false;
      curCell.Dist    := 10000;
      //curCell.indM    := 0;
      for M := 0 to 9 do
      begin
        curCell.distM[M] := calcDistance(K, I, market[M].X, market[M].Y);// -- distance to center for every cell
        If curCell.distM[M] < curCell.Dist then
        begin
          curCell.Dist := curCell.distM[M];
          //curCell.indM := M;
          curCell.mark := 10;
        end;
      end;
      curCell.Paint(paintImg.Canvas, 0);
    end;
  end;
  // -- mark the centerCells --
  for I := 0 to 9 do
  begin
    cellList[market[I].X,market[I].Y].cent := true;
    cellList[market[I].X,market[I].Y].Paint(paintImg.Canvas, 0);
  end;
end;

// ###########################################################################//
// ---------------------------- Berechnungen ---------------------------------//
// ###########################################################################//

// *** TIMER - Rekursive Befehle ausf�hren *************************************
procedure TForm1.Timer1Timer(Sender: TObject);
begin
  calculate;
end;

// *** the main procedures *****************************************************
procedure TForm1.calculate;
begin
  decline;
  repaintCells;
  repaintAgents;

  calcAgents; // -- ver�ndert die Position der Agenten

  If CB_diffuse.Checked = true Then diffuse;

  steps := steps +1;
  lbl_Steps.Caption := intToStr (steps);

end;

// *** diffuse the mark-values *************************************************
procedure TForm1.diffuse;
var
  curCell  : TCell;
  I, K     : Integer;
  evapo    : Real;
begin
  for I := 0 to reih -1 do
  begin
    for K := 0 to spalt -1 do
    begin
      checkNei (K, I);
    end;
  end;
  evapo := 1 - StrToFloat(Lbl_evapo.Caption);
  for I := 0 to reih -1 do
  begin
    for K := 0 to spalt -1 do
    begin
      curCell := cellList[K,I];
      curCell.mark := round(limboWorld[K, I]/8);
      curCell.mark := round(curCell.mark *evapo);
      If curCell.mark < 1 Then curCell.mark := 1;
    end;
  end;
end;

// *** check the moore-neighbourhood *******************************************
procedure TForm1.checkNei (K, I: Integer);
var
  u, v   : Integer;
  Xp, Yp : Integer;
begin
  // --- Summe berechnen ---
  limboWorld[K, I] := 0;
  for u := -1 to 1 do
  begin
    for v := -1 to 1 do
    begin
      Xp := K + v;
      Yp := I + u;
      torus(Xp, Yp, spalt, reih);  // -- Torus
      limboWorld[K, I] := limboWorld[K, I] + cellList[Xp, Yp].mark;
    end;
  end;
  limboWorld[K, I] := limboWorld[K, I] - cellList[K, I].mark;
end;

// *** plot value **************************************************************
procedure TForm1.plot(value1: Integer; value2: Integer);
begin
  if steps mod 999 = 0 then begin                      // -- Plotten bis maximum
    resetGraph;
  end;
//  If (value1+50) > RChart1.Scale1Y.RangeHigh Then RChart1.Scale1Y.RangeHigh := value1 + 100;
  RChart1.ActiveLayer:= 1;
  RChart1.DataColor := clRed;
  RChart1.Line((Steps / 100)-1, OldY1, (Steps / 100), value1);
  OldY1 := value1;
  RChart1.ActiveLayer:= 3;
  RChart1.DataColor := clGreen;
  RChart1.Line((Steps / 100)-1, OldY2, (Steps / 100), value2);
  OldY2 := value2;
end;

// *** reset the plot-graph ****************************************************
procedure TForm1.resetGraph;
begin
  RChart1.ClearGraf;
  RChart1.MoveTo (0,0);
  RChart1.Scale1Y.RangeLow  := -5;
  RChart1.Scale1Y.RangeHigh := 180;
  RChart1.Scale1X.RangeLow  := steps;
  RChart1.Scale1X.RangeHigh := steps + 500;
end;

// *** paint the agents ********************************************************
procedure TForm1.repaintAgents;
var
  curAgent : TAgent;
  I        : Integer;
  sumM     : Integer;
  sumW     : Integer;
begin
  agentImg.Canvas.brush.Color := clWhite;
  agentImg.Canvas.pen.Color   := clWhite;
  agentImg.Canvas.Rectangle(0,0,ZeichenPanel.Height,ZeichenPanel.Width);
  // --- repaint the agents ---
  If CB_hideAgs.Checked = false Then
  for I := 0 to AgentList.Count - 1 do
  begin
    curAgent := AgentList.Items [I];
    curAgent.Paint (agentImg.Canvas);
  end;

  // --- plot the agent parameters ---
  sumM  := 0;
  sumW  := 0;
  If (steps mod 100 = 0) Then
  begin
    for I := 0 to AgentList.Count - 1 do
    begin
      curAgent := AgentList.Items [I];
      sumM := sumM + curAgent.angleTh;
      sumW := sumW + curAgent.wiggleTh;
    end;
    sumM := round(sumM / AgentList.Count);
    sumW := round(sumW / AgentList.Count);
    Lbl_avgAngle.Caption  := IntToStr(sumM);
    Lbl_avgWiggle.Caption := IntToStr(sumW);
    If steps < 49800 Then
      plot(sumM, sumW);
  end;
end;

// *** decline *****************************************************************
procedure TForm1.decline;
var
  curCell  : TCell;
  I, K     : Integer;
  evapo    : Integer;
begin
  evapo := round(StrToFloat(Lbl_evapo.Caption)*10);
  // --- repaint the cells ---
  for I := 0 to reih -1 do
  begin
    for K := 0 to spalt -1 do
    begin
      curCell := cellList[K,I];
      If curCell.mark > (evapo+2) Then begin
        If CB_diffuse.Checked = false Then curCell.mark := curCell.mark - evapo;
      end;
    end;
  end;
end;

// *** paint the cells *********************************************************
procedure TForm1.repaintCells;
var
  curCell  : TCell;
  I, K     : Integer;
  visiTh   : Integer;
begin
  visiTh:= StrToInt(Lbl_visible.Caption);
  // --- repaint the cells ---
  for I := 0 to reih -1 do
  begin
    for K := 0 to spalt -1 do
    begin
      curCell := cellList[K,I];
      If Cb_cellUpdt.Checked = false Then
      curCell.Paint (paintImg.Canvas, visiTh);
    end;
  end;
end;

// *****************************************************************************
// *** look at the cells in the neigbourhood defined by the horizon-parameter **
// *****************************************************************************
procedure TForm1.checkArea (I : Integer);
var
  curCell  : TCell;
  curAgent : TAgent;
  M        : Integer;
  Angle    : Array [0..1] of Real;
  horizon  : Integer;
  neib     : TPoint;
  comper   : Real;
  wList    : Array of Integer;
  wSum     : Integer;
  tmP      : TPoint;
  fromTo   : Array [0..1] of Integer;
  curNr    : Integer;
begin
  //horizon := TrB_thresh.Position;
  curAgent := AgentList.Items [I];
  horizon  := curAgent.angleTh;
  Angle[0] := curAgent.Heading - horizon - 22.5;     // -- minAngle
  Angle[1] := curAgent.Heading + horizon - 22.5;     // -- maxAngle
  angelBorder (Angle[0]);
  angelBorder (Angle[1]);
  //-- find the cells to look at
  SetLength(curAgent.lookToList, 0);

  for M := 0 to 1 do
  begin
    comper   := Angle[M];
    case round(comper) of           // find start and end cell in the (cell)field
      0..45:    fromTo[M] := 1;
      46..90:   fromTo[M] := 2;
      91..135:  fromTo[M] := 3;
      136..180: fromTo[M] := 4;
      181..225: fromTo[M] := 5;
      226..270: fromTo[M] := 6;
      271..315: fromTo[M] := 7;
      316..360: fromTo[M] := 8;
    end;
  end;

  curNr := fromTo[0] -1;
  repeat
  inc(curNr);
  If curNr > 8 Then curNr := 1;
    case curNr of                   // set the direction to the cell-positions
      1: begin neib.X := 1;  neib.Y := 1;  end;
      2: begin neib.X := 0;  neib.Y := 1;  end;
      3: begin neib.X := -1; neib.Y := 1;  end;
      4: begin neib.X := -1; neib.Y := 0;  end;
      5: begin neib.X := -1; neib.Y := -1; end;
      6: begin neib.X := 0;  neib.Y := -1; end;
      7: begin neib.X := 1;  neib.Y := -1; end;
      8: begin neib.X := 1;  neib.Y := 0;  end;
    end;
    SetLength(curAgent.lookToList, length(curAgent.lookToList) + 1);
    curAgent.lookToList[High(curAgent.lookToList)] := neib;
  until curNr = fromTo[1];

  SetLength(wList, length(curAgent.lookToList));
  wSum := 0;
  curAgent.sumChem := 0;
  For M := 0 To High(curAgent.lookToList) Do
  begin
    tmP.X := curAgent.onCell.X + curAgent.lookToList[M].X;
    tmP.Y := curAgent.onCell.Y + curAgent.lookToList[M].Y;
    torus (tmP.X, tmP.Y, spalt, reih);
    curCell := cellList[tmP.X, tmP.Y];
    curAgent.sumChem := curAgent.sumChem + curCell.mark;
    wSum := wSum + curCell.mark;
    wList[M] := curCell.mark;
  end;

  SetLength(curAgent.weightList, 0);
  SetLength(curAgent.weightList, length(curAgent.lookToList));
  For M := 0 To High(curAgent.lookToList) Do
  begin
    If wSum > 0 Then begin
      curAgent.weightList[M] := wList[M]/wSum * 100;
    end else begin
      curAgent.weightList[M] := 0;
    end;
  end;
end;

// *****************************************************************************
// *** Ver�ndert die Position der Agenten **************************************
// *****************************************************************************
procedure TForm1.calcAgents;
var
  curCell  : TCell;
  curAgent : TAgent;
  I        : Integer;
  tempPos  : TPoint;
  horizon  : Integer;
  wiggle   : Integer;
  method   : Integer;
  sniffTh  : Integer;
  fromCell : TCell;
begin
  sniffTh := StrToInt(Lbl_sniff.Caption);
  method  := 0;
  If rb_rulette.Checked = true Then begin method := 1; end
  else begin If rb_hill.Checked = true Then method := 2; end;
  for I := 0 to AgentList.Count - 1 do
  begin
    curAgent := AgentList.Items [I];
    If curAgent.energy < 1 Then begin
      rebirth(curAgent);
    end;
    horizon := curAgent.angleTh;
    wiggle  := curAgent.wiggleTh;
    checkArea (I);
    curAgent.ChangeHeading(horizon, 1, wiggle, method, sniffTh);              // -- Richtungsspektrum und Distanz
    tempPos.X := curAgent.onCell.X + curAgent.stepX;
    tempPos.Y := curAgent.onCell.Y + curAgent.stepY;
    torus (tempPos.X, tempPos.Y, spalt, reih);                                // -- Torus --
    curCell := cellList[tempPos.X, tempPos.Y];
    fromCell:= cellList[curAgent.onCell.X, curAgent.onCell.Y];
    markCells(curAgent, curCell, fromCell);                                   // -- mark the cells under the agent

    curAgent.onCell.X := tempPos.X;
    curAgent.onCell.Y := tempPos.Y;
    curAgent.PosX     := curAgent.onCell.X * cellScal + halfScal;             // -- Wenn Zelle frei, Agent bewegen ---
    curAgent.PosY     := curAgent.onCell.Y * cellScal + halfScal;
    curCell.State     := curAgent.State;
    curCell.AgNr      := I;                                                   // -- Agenten index in Zelle speichern
    If curCell.source = true Then curAgent.Seeking := false;
  end;
end;

// *** mark the cells **********************************************************
procedure TForm1.markCells(curAgent: TAgent; curCell: TCell; fromCell: TCell);
var
  visiTh   : Integer;
  markStr  : Integer;
begin
  visiTh        := StrToInt(Lbl_visible.Caption);
  markStr       := StrToInt(Lbl_strenght.Caption);
  If curAgent.Seeking = false Then
  begin
    fromCell.mark := markStr + fromCell.mark;
    if curCell.mark < visiTh Then begin
      curAgent.energy := curAgent.energy - markStr;
    end else
      curAgent.energy := curAgent.energy - round (markStr/2);
  end else begin
    if curCell.mark < visiTh Then begin
      curAgent.energy := curAgent.energy - markStr*3;
    end else
      curAgent.energy := curAgent.energy - round (markStr/2);
  end;
end;

procedure TForm1.rebirth(curAgent: TAgent);
var
  fam        : Integer;
  weightList : wigList;
  tmpAgent   : TAgent;
  allSum     : Integer;
  I          : Integer;
  lgh        : Integer;
  par        : Array [0..1] of Integer;
begin
  fam := curAgent.family;
  lgh := length(FamilyList[fam]);
  SetLength (weightList, lgh);
  allSum := 0;
  par[0] := 0;
  par[1] := 0;
  For I := 0 To lgh-1 Do
  begin
    tmpAgent := AgentList.Items[FamilyList[fam, I]];
    allSum   := allSum + tmpAgent.success;
  end;
  If allSum > 0 Then begin
    For I := 0 To lgh-1 Do
    begin
      tmpAgent := AgentList.Items[FamilyList[fam, I]];
      weightList[I] := (tmpAgent.success / allSum) * 100;
    end;
  end else begin
    For I := 0 To lgh-1 Do
    begin
      weightList[I] := 5;
    end;
  end;
  // --- select the two parents ------- ---
  par[0] := rouletteWheel (weightList);
  par[1] := rouletteWheel (weightList);
  // --- combine the parents chromosome ---
  crossover(curAgent, par, fam);
  mutate   (curAgent);
end;

procedure TForm1.mutate(curAgent: TAgent);
var
  mRate : Real;
  rndP  : Integer;
  val   : Integer;
  toChr : String;
begin
  mRate := SB_mutate.Position/100;
  If mRate > random() Then
  begin
    rndP  := random (15)+1;
    val   := StrToInt(curAgent.Chroma[rndP]);
    val   := (val + 1) mod 2;
    toChr := IntToStr(val);
    curAgent.Chroma[rndP] := toChr[1];
  end;
end;

procedure TForm1.crossover(curAgent: TAgent; par: Array of Integer; fam: Integer);
var
  I          : Integer;
  crossP     : Integer;
  parAgent   : TAgent;
  newChrom   : String;
  chroA : String;
  chroB : String;
begin
  Randomize;
  crossP   := random(16)+1; // -- set the crossover point
  newChrom := '';           // -- to create the new chromosome
  parAgent := AgentList.Items[FamilyList[fam, par[0]]];
  for I:= 1 To crossP Do
  begin
    newChrom := newChrom + parAgent.Chroma[I];
  end;
  parAgent := AgentList.Items[FamilyList[fam, par[1]]];
  for I:= crossP+1 To 16 Do
  begin
    newChrom := newChrom + parAgent.Chroma[I];
  end;
  chroA := '';
  chroB := '';
  for I:= 1 To 8 Do
  begin
    chroA := chroA + newChrom[I];
  end;
  for I:= 9 To 16 Do
  begin
    chroB := chroB + newChrom[I];
  end;
  // --- reset the 'new' agent ---------------
  curAgent.success  := 0;
  curAgent.Seeking  := true;
  curAgent.energy   := energy;
  curAgent.angleTh  := BinToInt(chroA);
  curAgent.Chroma   := chroA;
  curAgent.wiggleTh := BinToInt(chroB);
  curAgent.Chroma   := curAgent.Chroma + chroB;
  curAgent.PosX     := curAgent.home.X;
  curAgent.PosY     := curAgent.home.Y;
end;

// ---------------------------------------------------------------------------//
// ------------------------------- Schalter ----------------------------------//
// ---------------------------------------------------------------------------//
// *** buttons sliders and edit-fields *****************************************
procedure TForm1.B_setupClick(Sender: TObject);
begin
  deleter;
  settings;
end;

// *****************************************************************************
procedure TForm1.B_stopClick(Sender: TObject);
begin
  Timer1.enabled := not(Timer1.enabled);
end;

// *****************************************************************************
procedure TForm1.SB_mutateChange(Sender: TObject);
begin
  Lbl_mutate.Caption := FloatToStr(SB_mutate.Position/100) + ' %';
end;

// *****************************************************************************
procedure TForm1.SB_strenghtChange(Sender: TObject);
begin
  Lbl_strenght.Caption := IntToStr(SB_strenght.Position);
end;

// *****************************************************************************
procedure TForm1.SB_evapoChange(Sender: TObject);
begin
  Lbl_evapo.Caption := FloatToStr(SB_evapo.Position/100);
end;

// *****************************************************************************
procedure TForm1.SB_sniffChange(Sender: TObject);
begin
  Lbl_sniff.Caption := FloatToStr(SB_sniff.Position);
end;

// *****************************************************************************
procedure TForm1.SB_visibleChange(Sender: TObject);
begin
  Lbl_visible.Caption := FloatToStr(SB_visible.Position);
end;

// *****************************************************************************
procedure TForm1.B_oneStepClick(Sender: TObject);
begin
  calculate;
end;

// *****************************************************************************
procedure TForm1.Edit_sizeChange(Sender: TObject);
begin
  If StrToInt(Edit_size.Text) > 10 Then Edit_size.Text := '10';
  If StrToInt(Edit_size.Text) < 1  Then Edit_size.Text := '1' ;
end;

// *****************************************************************************
// *** the mouse interactions **************************************************
// *****************************************************************************
procedure TForm1.ZeichenPanelMouseDown(Sender: TObject; Button: TMouseButton;
  Shift: TShiftState; X, Y: Integer);
begin
   If Button = mbRight then  rDown := true;
   If Button = mbLeft  then  lDown := true;
end;
// *****************************************************************************
procedure TForm1.ZeichenPanelMouseMove(Sender: TObject; Shift: TShiftState; X, Y: Integer);
begin
  If (rDown = true) or (lDown = true) Then
  begin
    markCell (X, Y);
  end;
end;
// *****************************************************************************
procedure TForm1.ZeichenPanelMouseUp(Sender: TObject; Button: TMouseButton;
  Shift: TShiftState; X, Y: Integer);
begin
  rDown := false;
  lDown := false;
end;
// *****************************************************************************
procedure TForm1.markCell (X, Y: Integer);
var
  curCell : TCell;
  cPos    : TPoint;
begin
  cPos.X  := round(X / cellScal);
  cPos.Y  := round(Y / cellScal);
  curCell := cellList[cPos.X, cPos.Y];
  If (lDown = true) Then
  begin
    curCell.mark := 255;
  end else
  If (rDown = true) Then
  begin
    curCell.mark := 1;
    curCell.Paint (paintImg.Canvas, 0);
  end;
end;
// *****************************************************************************
// *****************************************************************************
procedure TForm1.FormDestroy(Sender: TObject);
begin
  deleter;
  ZeichenPanel.Free;
end;

// *****************************************************************************
procedure TForm1.deleter;
begin
  steps := 0;
  AgentList.Free;
  paintImg.Free;
  agentImg.Free;
  SetLength(cellList, 0, 0);
  SetLength(limboWorld, 0, 0);
end;

end.

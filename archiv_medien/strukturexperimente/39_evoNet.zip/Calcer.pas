unit Calcer;

interface

uses
  Math, SysUtils;

type
  wigList = Array of Real;

const                            //-- globale Konstanten
  DegToRad  = 3.141592654/180;
  RadToDeg  = 180/3.141592654;

function  IntToBin     (Int: Integer): String;
function  BinToInt     (Binary: String): Integer;
function  CalcDistance (pAX: Integer; pAY: Integer; pBX: Integer; pBY: Integer): Integer;
procedure torus        (var Xp: Integer; var Yp: Integer; spalt, reih:Integer);
function  rouletteWheel(weightList: wigList): Integer;
procedure angelBorder  (var angle : Integer); overload;
procedure angelBorder  (var angle : Real);    overload;

implementation

// *** roulette wheel selection ************************************************
function rouletteWheel(weightList: wigList): Integer;
var
  M      : Integer;
  rnd    : Extended;
  sum    : Extended;
begin
  Randomize;
  rnd := random (100);
  sum := 0;
  M := 0;
  repeat
    sum := sum + weightList[M];
    Result := M;
    M := M +1;
  until (sum >= rnd) Or (M > length(weightList)-1);
end;

// *** Entferung berechnen *****************************************************
function CalcDistance(pAX: Integer; pAY: Integer; pBX: Integer; pBY: Integer): Integer;
var
  temp : double;
begin
  temp := sqrt(Power((pAX - pBX), 2) + Power((pAY - pBY), 2));
  Result := Round(temp);
end;

// *** Integer To Binary *******************************************************
function IntToBin(Int: Integer): String;
var
  I : Integer;
begin
  Result := '';
  for I := 7 downto 0 do
    Result := Result + IntToStr((Int shr I) and 1);
end;

// *** Binary To Integer *******************************************************
function BinToInt(Binary: String): Integer;
var
  I : Integer;
begin
  Result := 0;
  for I := Length(Binary) downto 1 do
    Inc(Result, StrToInt(Binary[I]) * 1 shl (Length(Binary) - I));
end;

// *** Torusfunktion ***********************************************************
procedure torus (var Xp: Integer; var Yp: Integer; spalt, reih:Integer);
begin
  if Xp < 0     then begin
     Xp := spalt + Xp;
  end else
  if Xp > spalt-1  then begin
     Xp := 0 + (Xp - spalt) ;
  end;
  if Yp < 0     then begin
     Yp := reih + Yp;
  end else
  if Yp > reih-1  then begin
     Yp := 0 + (Yp - reih) ;
  end;
end;

// *** borders of the angle-value **********************************************
procedure angelBorder (var angle : Integer);
begin
  If angle < 0   Then angle := 360 + angle;
  If angle > 360 Then angle := angle -360;
end;

procedure angelBorder  (var angle : Real);
begin
  If angle < 0   Then angle := 360 + angle;
  If angle > 360 Then angle := angle -360;
end;

end.
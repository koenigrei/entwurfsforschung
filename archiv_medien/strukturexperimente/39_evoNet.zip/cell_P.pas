unit cell_P;

interface

uses
  Windows, Graphics, Classes, node, Math;

type
  TCell = class
  private
  public
    AgNr       : Integer;                  // -- Nummer der Agenten auf einer Zelle
    cent       : Boolean;                  // -- in the cell is a market cell.
    source     : Boolean;                  // -- in the cell is a market cell.
    Dist       : Integer;                  // -- Distance to nexgt market
    distM      : Array [0..9] of Integer;  // -- distances to all markets
    //indM       : Integer;                  // -- index of the next market
    //besetzt    : Boolean;                  // -- in an agent is on the cell
    colr       : Integer;                  // -- Farbwert der Zelle
    mark       : Integer;                  // -- marking where the agents are gone
    oldMark    : Integer;
    FPos       : TPoint;
    FSize      : Integer;
    FFillColor : Integer;
    FState     : Integer;                  // -- Status speichert die Anzahl der Agenten auf Zelle
    procedure Paint         (Canvas: TCanvas; visiTh:Integer);
    procedure SetPositionX  (const Value: Integer);
    procedure SetPositionY  (const Value: Integer);
    procedure SetSize       (const Value: Integer);
    procedure SetFillColor  (const Value: Integer);
    procedure SetState      (const Value: Integer);
    constructor create      (xPos, yPos, size, colr: Integer);
  published
    property PositionX: Integer read FPos.X     write SetPositionX;
    property PositionY: Integer read FPos.Y     write SetPositionY;
    property Size     : Integer read FSize      write SetSize;
    property FillColor: Integer read FFillColor write SetFillColor;
    property State    : Integer read FState     write SetState;
  end;

// ---------------------------------------------------------------------------//

implementation

constructor TCell.create(xPos, yPos, size, colr: Integer);
begin
  inherited create;
  FPos.X := xPos;
  FPos.Y := yPos;
  FSize  := size;
  FFillColor := colr;
end;

//------------------------------------------------------------------------------

procedure TCell.SetPositionX(const Value: Integer);
begin
  FPos.X := Value;
end;

procedure TCell.SetPositionY(const Value: Integer);
begin
  FPos.Y := Value;
end;

procedure TCell.SetSize(const Value: Integer);
begin
  FSize := Value;
end;

procedure TCell.SetFillColor(const Value: Integer);
begin
  FFillColor := Value;
end;

procedure TCell.SetState(const Value: Integer);
begin
  FState := Value;
end;

procedure TCell.Paint(Canvas: TCanvas; visiTh:Integer);
var
  val : Integer;
  col : Array [0..2] of Integer;
  I : Integer;
begin
  If abs(oldMark - mark) >= 5 Then   // -- only repaint if there was a relevant value-change
  begin
    If mark > visiTh Then begin
      val := mark;
    end else begin
      val := 0;
    end;
    colr  := 255 - val;
    If colr < 0 then colr := 0;
    If colr > 255 then colr := 255;
    col[0]:= colr;//round(255 - 3*val);
    col[1]:= colr;//255 - val;
    col[2]:= colr;//round(255 - 3*val);
    {For I := 0 To 2 Do begin
      If col[I] < 0 then col[I] := 0;
      If col[I] > 255 then col[I] := 255;
    end; }

    {col[0]:= round(3*val);
    col[1]:= val*8;
    col[2]:= round(3*val);
    For I := 0 To 2 Do begin
      If col[I] > 255 then col[I] := 255;
      If col[I] < 0 then col[I] := 0;
    end; }

    If cent = true   then begin
      Canvas.Brush.Color := clred;
      Canvas.Pen.Color   := clred;
    end else
    If source = true then
    begin
      Canvas.Brush.Color := clgreen;
      Canvas.Pen.Color   := clgreen;
    end else
    begin
      Canvas.Pen.Color   := RGB (col[0], col[1], col[2]);
      Canvas.Brush.Color := RGB (col[0], col[1], col[2]);
    end;
    Canvas.Rectangle (FPos.X - FSize , FPos.Y - FSize, FPos.X + FSize, FPos.Y + FSize);
    oldMark := mark;
  end;
end;

end.

(********************************************************************)
(*                                                                  *)
(*                                                                  *)
(*                       2D Cellular Automata                       *)
(*                    Growth with Diffusion Field                   *)
(*                           Version 1.0                            *)
(*                                                                  *)
(*                                                                  *)
(*     Programmierer: Reinhard K�nig                   January 2006 *)
(*                    http://www.entwurfsforschung.de               *)
(*                                                                  *)
(*     Last Update: Jan-28, 2006                                    *)
(*                                                                  *)
(********************************************************************) 
{revision history:

1.0     [Jan-28, 2006]
        first release to the public
}

unit CellForm;

interface

uses
  Windows, Messages, SysUtils, Variants, Classes, Graphics, Controls, Forms,
  Dialogs, StdCtrls, cell_P, ExtCtrls, ButtonGroup, ComCtrls, Math, ToolWin,
  ImgList, Epina.SDL.rchart;

type
  TForm1 = class(TForm)
    ZeichenPanel   : TPanel;
    Timer1         : TTimer;
    lbl_Steps      : TLabel;
    B_setup        : TButton;
    lbl_timesteps  : TLabel;
    B_stop         : TButton;
    RChart1        : TRChart;
    Lbl_Sphere     : TLabel;
    E_dist         : TEdit;
    Lbl_statProb   : TLabel;
    E_Noise        : TEdit;
    Cb_aging       : TCheckBox;
    Lbl_death      : TLabel;
    E_death        : TEdit;
    procedure E_distChange(Sender: TObject);
    procedure E_NoiseChange(Sender: TObject);
    procedure B_stopClick   (Sender: TObject);
    procedure B_setupClick  (Sender: TObject);
    procedure Timer1Timer   (Sender: TObject);
    procedure FormDestroy   (Sender: TObject);
    procedure FormCreate    (Sender: TObject);
  private
    AgentList  : TList;
    cellList   : Array of Array of TCell;
    limboWorld : Array of Array of Integer;
    limboPot   : Array of Array of Real;
    function  CalcDistance  (pAX: Integer; pAY: Integer; pBX: Integer; pBY: Integer): Integer;
    function  rndN          (lower: Integer; upper: Integer):Integer;
    procedure checkNei      (K, I: Integer; var sumState : Integer);
    procedure checkPot      (K, I: Integer);
    procedure plot          (stateSum: Integer);
    procedure createPaintImg;
    procedure createRaster;
    procedure setupCells;
    procedure ageCheck;
    procedure equiPot;
    procedure infl_Field;
    procedure dev_Cell;
    procedure paint_Field;
  public
end;

var
  Form1    : TForm1;
  paintImg : TImage;

implementation

{$R *.dfm}

const                            //-- globale Konstanten
  cellScal = 4;                  //-- Zellen  gr��e
  AgSize   = 1;                  //-- Agenten gr��e
  halfScal = round(cellScal/2);
var                              //-- globale Variablen
  reih    : Integer;             //-- Zellen-Reihen gesamt
  spalt   : Integer;             //-- Zellen-Spalten gesamt
  steps   : Integer;
  Xmax    : Integer;
  Ymax    : Integer;
  cellSum : Integer;
  OldY1   : Integer;              //-- Speichert die Position t-1 f�r Graphen
  OldY2   : Integer;              //-- Speichert die Position t-1 f�r Graphen
  OldY3   : Integer;
  rDist   : Integer;              //-- distance to the cluster-boundary
  rSize   : Integer;
  noise   : Real;

// ---------------------------------------------------------------------------//
// *** Initialisierung ***
procedure TForm1.FormCreate(Sender: TObject);
begin
  spalt     := round (ZeichenPanel.Width / cellScal);
  reih      := round (ZeichenPanel.Height / cellScal);
  Xmax      := (spalt) * cellScal;
  Ymax      := (reih ) * cellScal;
  AgentList := TList.Create;
  SetLength(cellList, spalt, reih);
  SetLength(limboPot, spalt, reih);
  SetLength(limboWorld, spalt, reih);
  createPaintImg;
  CreateRaster;
  ZeichenPanel.DoubleBuffered := True;       //-- Verhindert Flackern der Zellen
  steps := 0;
  rDist := 1;

  // -- Diagramm initialisieren --
  RChart1.Scale1X.RangeLow  := 0;    //-- range of chart area
  RChart1.Scale1X.RangeHigh := StrToInt(E_death.Text);  //-- Maximale Reichweite = 1000 bei Testversion!!!
  RChart1.Scale1Y.RangeLow  := 0;    //0.45;
  RChart1.Scale1Y.RangeHigh := 600; //0.55;
  RChart1.ShowGraf;
end;

// ---------------------------------------------------------------------------//
// ------------------------- Elemente erstellen ------------------------------//
// ---------------------------------------------------------------------------//

// *** Legt eine leere Zeichenfl�che �ber das Zeichenpanel *********************
procedure TForm1.createPaintImg;
begin
  paintImg        := TImage.Create(self);
  paintImg.Parent := ZeichenPanel;
  paintImg.top    := 0;
  paintImg.Left   := 0;
  paintImg.Height := ZeichenPanel.Height;
  paintImg.Width  := ZeichenPanel.Width;
end;

// *** Zellen erstellen ***
procedure TForm1.CreateRaster;
var
  curCell : TCell;
  I       : Integer;
  K       : Integer;
  upperB  : Integer;
  lowerB  : Integer;
begin
  for I := 0 to reih -1 do
  begin
    for K := 0 to spalt -1 do
    begin
      curCell := TCell.Create(halfScal + K * cellScal, halfScal + I * cellScal, halfScal, 0);
      cellList[K,I] := curCell;
    end;
  end;
  setupCells;
end;

// *** Zellen initialisieren ***************************************************
procedure TForm1.setupCells;
var
  curCell : TCell;
  I       : Integer;
  K       : Integer;
begin
  OldY1   := 0; // -- Ausgangswert t=0 f�r Graphen
  OldY2   := 0;
  OldY3   := 0;
  cellSum := spalt * reih;
  Randomize();
  // -- setup --
  for I := 0 to reih -1 do
  begin
    for K := 0 to spalt -1 do
    begin
      curCell          := cellList[K,I];
      curCell.State    := 0;               // -- set D(0) = 0;
      curCell.Pot      := 0;               // -- set P(0) = 0;
      limboWorld[K, I] := 0;
      curCell.probab   := 0.5;//StrToInt(E_probab.Text)/100;
      curCell.colr     := curCell.State * 255;
      curCell.birth    := 0;
      curCell.dist     := 0;
      curCell.dist     := CalcDistance(curCell.FPos.X, curCell.FPos.Y, cellList[50,50].FPos.X, cellList[50,50].FPos.Y);
      curCell.Paint(paintImg.Canvas);
    end;
  end;

  curCell := cellList[round(spalt/2),round(reih/2)];
  curCell.State := 1;                                //  -- one seed
  curCell.colr  := curCell.State * 255;
  curCell.Paint(paintImg.Canvas);

  rDist := cellScal;
  RChart1.ClearGraf;                                 // -- initialize chart
  RChart1.MoveTo (0,0);
  noise := StrToInt(E_noise.Text);
  rSize := StrToInt(E_dist.Text);
  RChart1.Scale1X.RangeHigh := StrToInt(E_death.Text);
end;


// ---------------------------------------------------------------------------//
// ---------------------------- Calculations ---------------------------------//
// ---------------------------------------------------------------------------//

// *** Rekursive Prozeduren ausf�hren ******************************************
procedure TForm1.Timer1Timer(Sender: TObject);
var
  curCell  : TCell;
  K, I, M  : Integer;
begin

  ageCheck;      // -- check the age of the cells --

  infl_Field;    // -- sphere of influence

  for I:= 0 to 1 do
  begin
    equiPot;     // -- bring the potential field to equilibrium
  end;

  dev_Cell;      // -- one cell per step will develop

  paint_Field;   // -- count and paint the cells ---

  steps := steps +1;                              // -- increase steps
  lbl_Steps.Caption := intToStr (steps);

  If steps = StrToInt(E_death.Text) Then begin    // -- stop condition
    Timer1.enabled := false;                      // -- stop automata
  end;
end;

// *** check age or the developed cell *****************************************
procedure TForm1.ageCheck;
var
  curCell : TCell;
  K, I    : Integer;
  death   : Integer;
begin
  death  := StrToInt(E_death.Text);
  for I  := 0 to reih -1 do
  begin
    for K := 0 to spalt -1 do
    begin
      curCell := cellList[K,I];
      If Cb_aging.State = cbChecked Then
      begin
        curCell.age := (steps - curCell.birth);    // -- increase age every step
        If curCell.age > death Then begin          // -- Cell dies on overaging
          curCell.age    := 0;
          curCell.pot    := 0;
          curCell.state  := 0;
        end;
      end;
    end;
  end;
end;

// *** Check Moore-Neigborhood for state and potential *************************
procedure TForm1.checkPot (K, I: Integer);
var
  curCell  : TCell;
  u,v      : Integer;
  Xp, Yp   : Integer;koNei    : Array [0..3] of TPoint;
begin
  limboPot[K,I] := 0;
  // --- Summe berechnen ---
  koNei[0].X := K;    koNei[0].Y := I + 1;
  koNei[1].X := K;    koNei[1].Y := I - 1;
  koNei[2].X := K+1;  koNei[2].Y := I;
  koNei[3].X := K-1;  koNei[3].Y := I;
  for v := 0 to 3 do
  begin
    Xp := koNei[v].X;
    Yp := koNei[v].Y;
    // -- Torus --
    if Xp < 0       then Xp := spalt-1;
    if Xp > spalt-1 then Xp := 0;
    if Yp < 0       then Yp := reih-1;
    if Yp > reih-1  then Yp := 0;
    If Not ((Xp = K) and (Yp = I)) Then begin
      limboPot[K,I] := limboPot[K,I] + (cellList[Xp, Yp].Pot);
    end;
  end;
  limboPot[K,I] := limboPot[K,I] /4;
end;

// *** calculate the potential field *******************************************
procedure TForm1.equiPot;
var
  K, I, M  : Integer;
begin
  for I := 0 to reih -1 do
  begin
    for K := 0 to spalt -1 do
    begin
      If cellList[K,I].state = 0 then  // -- If Di(t+1) = 0 then
      begin
        checkPot(K, I);                // -- set limboPot
      end;
    end;
  end;                                      // -- limboPot to aktual pot-value
  for I := 0 to reih -1 do
  begin
    for K := 0 to spalt -1 do
    begin
       cellList[K,I].Pot := limboPot[K, I];
    end;
  end;
end;

// *** defines the sphere of influence - dependent of the cluster-size *********
procedure TForm1.infl_Field;
var
  curCell  : TCell;
  K, I     : Integer;
begin
  for I := 0 to reih -1 do
  begin
    for K := 0 to spalt -1 do
    begin
      curCell := cellList[K,I];
      If curCell.dist > (rDist + rSize * cellScal) then
      begin
        curCell.pot := 1;
      end;
    end;
  end;
end;

// *** find the cell for development *******************************************
procedure TForm1.dev_Cell;
var
  curCell  : TCell;
  K, I     : Integer;
  maxPos   : TPoint;
  maxPot   : Extended;
  temp     : Extended;
  sumState : Integer;
begin
  maxPot := 0;
  for I := 0 to reih -1 do
  begin
    for K := 0 to spalt -1 do
    begin
      curCell := cellList[K,I];
      checkNei(K, I, sumState);
      If (sumState >= 1) and (curCell.state = 0) then
      begin
        temp := 0;
        Randomize;
        temp := random() * noise;
        If (curCell.Pot + temp) > maxPot Then
        begin
          maxPot   := curCell.Pot + temp;
          maxPos.X := K;
          maxPos.Y := I;
        end;
      end;
    end;
  end;
  // -- settings for the developed cell --
  curCell := cellList[maxPos.X, maxPos.Y];
  curCell.state := 1;  // -- set Di(t+1)
  curCell.Pot   := 0;
  curCell.birth := steps;                 // -- save the birthtime of development
  curCell.age   := 0;
  If curCell.dist > rDist Then rDist := curCell.dist;
  limboPot[maxPos.X, maxPos.Y]   := 0;  // -- set Pi(t+1)
end;

// *** defines the sphere of influence - dependent of the cluster-size *********
procedure TForm1.paint_Field;
var
  curCell  : TCell;
  K, I     : Integer;
  stateSum : Integer;
begin
  stateSum := 0; // -- sum-Value of all states
  for I := 0 to reih -1 do
  begin
    for K := 0 to spalt -1 do
    begin
      curCell     := cellList[K,I];
      If curCell.state > 0 Then stateSum := stateSum + 1;          // -- count cells
      //curCell.colr  := curCell.State * (255 - colM*curCell.age );//- colM*curCell.age);
      If curCell.State = 1 then begin
        curCell.colr  := 0 + round (0.5 * curCell.age);
      end else begin
        curCell.colr  := round((curCell.Pot+0.5) * 170 );
      end;
      curCell.Paint (paintImg.Canvas);
    end;
  end;
  plot(stateSum);                                 // -- plot the number of cells
end;

// *** Check Moore-Neigborhood for state and potential *************************
procedure TForm1.checkNei (K, I: Integer; var sumState : Integer);
var
  u,v      : Integer;
  Xp, Yp   : Integer;
  koNei    : Array [0..3] of TPoint;
begin
  sumState := 0;
  // --- Summe berechnen ---
  koNei[0].X := K;    koNei[0].Y := I + 1;
  koNei[1].X := K;    koNei[1].Y := I - 1;
  koNei[2].X := K+1;  koNei[2].Y := I;
  koNei[3].X := K-1;  koNei[3].Y := I;
  for v := 0 to 3 do
  begin
    Xp := koNei[v].X;
    Yp := koNei[v].Y;
    // -- Torus --
    if Xp < 0       then Xp := spalt-1;
    if Xp > spalt-1 then Xp := 0;
    if Yp < 0       then Yp := reih-1;
    if Yp > reih-1  then Yp := 0;
    sumState := sumState + cellList[Xp, Yp].State;  // -- count the states of the neighbours
  end;
end;

// ---------------------------------------------------------------------------//
//*** Ausgabe in Graph *********************************************************
procedure TForm1.plot(stateSum: Integer);
begin
  if steps < 1000 then begin                        // -- bis Maximalwert Plotten
    RChart1.ActiveLayer:= 1;
    RChart1.DataColor := clRed;
    RChart1.Line(steps-1, OldY1, steps, stateSum);
    OldY1 := stateSum;
  end;
end;

// ---------------------------------------------------------------------------//
// -------------------------- Funktionen -------------------------------------//
// ---------------------------------------------------------------------------//
// *** Entferung berechnen *****************************************************
function TForm1.CalcDistance(pAX: Integer; pAY: Integer; pBX: Integer; pBY: Integer): Integer;
var
  temp : double;
begin
  temp := sqrt(Power((pAX - pBX), 2) + Power((pAY - pBY), 2));
  Result := Round(temp);
end;

// *** Zufallszahl innerhalb eines Bereichs berechnen **************************
function TForm1.rndN(lower : Integer; upper : Integer):Integer;
begin
  Result := round ((upper - lower + 1) * Random() + lower);
end;

// ---------------------------------------------------------------------------//
// ------------------------------- Schalter ----------------------------------//
// ---------------------------------------------------------------------------//
procedure TForm1.B_setupClick(Sender: TObject);
begin
  steps := 0;
  setupCells;
 // Timer1.enabled := true;

end;

procedure TForm1.B_stopClick(Sender: TObject);
begin
  Timer1.enabled := not(Timer1.enabled);
end;

procedure TForm1.FormDestroy(Sender: TObject);
begin
  paintImg.Free;
  ZeichenPanel.Free;
  AgentList.Destroy;
end;

procedure TForm1.E_NoiseChange(Sender: TObject);
begin
  noise := StrToFloat(E_noise.Text);
end;

procedure TForm1.E_distChange(Sender: TObject);
begin
  rSize := StrToInt(E_dist.Text);
end;

end.

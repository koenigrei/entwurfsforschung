unit Node;

interface

uses
  SysUtils, Classes, Controls, StdCtrls, Graphics, Windows, Forms, Dialogs, Messages, ExtCtrls;
  //SysUtils, Classes, Controls, ExtCtrls, Graphics, Windows, Forms, Dialogs, Messages;

type TNachb = record     // --- f�r A* Heuristik
      nr   : Integer;    // --- = NeigborList
      dist : Integer;    // --- entfernung zum Nachbarn
      Usage: Double;     // --- Str�me zwischen den Nodes
end;

type
  TNode = class(TCustomControl )
  private
    { Private-Deklarationen }
  protected
    procedure Paint; override;
  public
    F           : Integer;
    G           : Integer;
    H           : Integer;
    Popul       : Integer;
    NachbList   : Array of TNachb;
    KonSum      : Array of Integer;
    Nachbar     : TNachb;
    State       : Integer;
    Closed      : Boolean;
    Vorg        : Pointer;
    Pos         : TPoint;
    konLabel    : TLabel;
    nrLabel     : TLabel;
    idx         : Integer;
    //Usage       : Array of Double;  // speichert die Str�me zwischen den Nodes
    procedure setPos;
    procedure setKon (par : TWinControl);// (par : TWinControl);
    procedure setNr;
    constructor Create(AOwner: TComponent); override;
  published
    property OnMouseDown;
    property OnMouseUp;
    property OnMouseMove;
    property OnKeyPress;
    property OnKeyDown;
    property OnKeyUp;
  end;

procedure Register;

implementation

constructor TNode.Create(AOwner: TComponent) ;
begin
  inherited Create (Aowner);
  width                := 20;
  height               := 20;
  Popul                := 20;
  Brush.Color          := clCream;
  konLabel             := TLabel.Create(self);
  konLabel.Enabled     := True;
  konLabel.Transparent := true;
  nrLabel              := TLabel.Create(self);
  nrLabel.Enabled      := True;
  nrLabel.Transparent  := true;
  SetLength(NachbList, 0);
end;

procedure TNode.Paint;
begin
  Canvas.Brush.Color := clRed;
  setNr;
  Canvas.Pen.Color := clBlack;
  Canvas.Ellipse (1, 1, Width-1, Height-1);
end;

procedure TNode.setPos;
begin
  Pos.X := Left + round(Height / 2);
  Pos.Y := Top  + round(Width / 2);
end;

procedure TNode.setKon (par : TWinControl);
begin
  konLabel.Caption := IntToStr(KonSum[High(KonSum)]);
  konLabel.Parent  := par;
  konLabel.Left    := Left - konLabel.Width +1;
  konLabel.Top     := Top  - konLabel.Height +1;
end;

procedure TNode.setNr;
begin
  canvas.Font.Color := clWhite;
  canvas.TextOut(round(Width / 2)-5, round(Height / 2)-7, IntToStr(idx));
end;

procedure Register;
begin
  RegisterComponents('Samples', [TNode]);
end;

end.

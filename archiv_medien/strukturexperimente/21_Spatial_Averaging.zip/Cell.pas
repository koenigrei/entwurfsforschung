unit Cell;

interface

uses
  SysUtils, Classes, Controls, ExtCtrls, Graphics, Windows, Forms, Dialogs, Messages;

type
  TCell = class(TImage)
  private
    { Private-Deklarationen }
  protected
    { Protected-Deklarationen }
  public
    { Public-Deklarationen }
    used : Integer;
    constructor Create(AOwner: TComponent); override;
  published
    { Published-Deklarationen }
    procedure rePaint;
  end;


procedure Register;

implementation

constructor TCell.Create(AOwner: TComponent) ;
var
  rect   : Trect;
begin
  inherited Create (Aowner);
  Rect.Left := 0;
  Rect.Top := 0;
  Rect.Right := width;
  Rect.Bottom := height;
  Canvas.Brush.Color := clCream;
  Canvas.FillRect(Rect);
  used := 255;
end;

procedure TCell.rePaint;
var
  rect   : Trect;
begin
  Rect.Left := 0;
  Rect.Top := 0;
  Rect.Right := width;
  Rect.Bottom := height;
  Canvas.Brush.Color := RGB (used, 200, used);
  Canvas.Pen.Color := clWhite;
  Canvas.FillRect(Rect);
  Canvas.Rectangle(Rect);
end;

procedure Register;
begin
  RegisterComponents('Samples', [TCell]);
end;

end.

(********************************************************************)
(*                                                                  *) 
(*                                                                  *)
(*               Verteilung st�dtischer Fl�chennutzungen            *)
(*                      nach William Alonso                         *)
(*                          Version 1.0                             *)
(*                                                                  *)
(*     Programmierer: Reinhard K�nig                   August 2005  *)
(*                    http://www.entwurfsforschung.de/              *)
(*                                                                  *)
(*     Last Update: Aug-15, 2005                                   *)
(*                                                                  *) 
(********************************************************************) 
{revision history:

1.0     [Aug-15, 2005]
        first release to the public
}

unit facsSteer;

interface

uses
  Windows, Messages, SysUtils, Variants, Classes, Graphics, Controls, Forms, cell,
  Dialogs, ExtCtrls, Grids, agenten, Math, ConvUtils, StdCtrls, AppEvnts,    //ActnMan ,
  Menus;

type
  TMovePlate = class(TForm)
    ScrollBar1          : TScrollBar;
    ApplicationEvents1  : TApplicationEvents;
    Label1              : TLabel;
    Label2              : TLabel;
    Button2             : TButton;
    Label3              : TLabel;
    Label_Radius        : TLabel;
    CB_moveMarkt        : TCheckBox;
    ButtonPause         : TButton;
    CB_Distanz          : TCheckBox;
    GB_Backgr           : TGroupBox;
    ImagePaint          : TImage;
    GroupBox2           : TGroupBox;
    Label_Betrieb       : TLabel;
    Lbl_BetrGr          : TLabel;
    SB_BetrGr           : TScrollBar;
    Lbl_Trans           : TLabel;
    Lbl_TransKostAbh    : TLabel;
    SB_Gewinn           : TScrollBar;
    Label_Kunden        : TLabel;
    Lbl_KundSens        : TLabel;
    SB_KundSens         : TScrollBar;
    Lbl_GewinnText      : TLabel;
    Lbl_Gewinn          : TLabel;
    SB_TransKostAbh     : TScrollBar;
    CB_ProdKost         : TCheckBox;
    B_delMarkt          : TButton;
    Graph1              : TImage;
    Label_Umsatzkurve   : TLabel;
    Graph2              : TImage;
    Label5              : TLabel;
    Graph3              : TImage;
    Label4              : TLabel;
    cb_Umsatz           : TCheckBox;
    cb_bidPrice         : TCheckBox;
    Label6              : TLabel;
    GroupBox1           : TGroupBox;
    lbl_MaxPrText       : TLabel;
    Lbl_MaxPr           : TLabel;
    lbl_preisAbnText    : TLabel;
    Lbl_PreisAb         : TLabel;
    Sb_MaxPr            : TScrollBar;
    Sb_PreisAb          : TScrollBar;
    Label7              : TLabel;
    cb_nutzSto          : TCheckBox;
    Label8              : TLabel;
    cb_showG            : TCheckBox;
    procedure Sb_PreisAbChange(Sender: TObject);
    procedure Sb_MaxPrChange(Sender: TObject);
    procedure cb_UmsatzClick(Sender: TObject);
    procedure CB_ProdKostClick(Sender: TObject);
    procedure cb_bidPriceClick(Sender: TObject);
    procedure SB_GewinnChange(Sender: TObject);
    procedure B_delMarktClick(Sender: TObject);
    procedure SB_TransKostAbhChange(Sender: TObject);
    procedure SB_KundSensChange(Sender: TObject);
    procedure SB_BetrGrChange(Sender: TObject);
    procedure ImagePaintClick(Sender: TObject);
    procedure ButtonPauseClick(Sender: TObject);
    procedure Button_DeleteClick(Sender: TObject);
    procedure Button2MouseUp(Sender: TObject; Button: TMouseButton;
      Shift: TShiftState; X, Y: Integer);
    procedure FormDestroy(Sender: TObject);
    procedure ImagePaintMouseMove(Sender: TObject; Shift: TShiftState; X,
      Y: Integer);
    procedure ApplicationEvents1Idle(Sender: TObject; var Done: Boolean);
    procedure PaintBox1Paint(Sender: TObject);
    procedure ScrollBar1Change(Sender: TObject);
    procedure FormCreate(Sender: TObject);
  private
    { Private declarations }
    ShapesList: TList;
    CurrShape: TBaseShape;
    procedure CommonPaint (Canvas: TCanvas);
    procedure GraphUmsatz;
    procedure checkNeighbour (Canvas: TCanvas; xPos : Integer; yPos : Integer);
    procedure lookCell (Canvas: TCanvas);
    procedure cellStates (Canvas: TCanvas);
    procedure RectanglPaint  (Canvas: TCanvas);
    procedure RectanglCreate (Canvas: TCanvas);
    procedure SetzeBetrGr;
    procedure SetzeGewinn;
    procedure SetzeKundSens;
    procedure SetzeTranspKost;
  public
    { Public declarations }
  end;

var
  MovePlate: TMovePlate;

implementation

{$R *.dfm}

const
    NUM_BALLS = 100;
    cellScal  = 6;
    NumProd   = 3;
var
  reih      : Integer;
  spalt     : Integer;
  Dir       : Integer = 1;
  StepX     : Integer;
  StepY     : Integer;
  LEFT_BORDER   : Integer;
  TOP_BORDER    : Integer;
  RIGHT_BORDER  : Integer;
  BOTTOM_BORDER : Integer;
  Mouse_Rad     : Integer;
  MouseX        : Integer;
  MouseY        : Integer;
  Backpuffer    : TBitmap;
  cellList      : Array of Array of TCell;
  limboWorld    : Array of Array of Integer;
  oldPos        : Array of Array of Integer;
  limboPos      : Array of Array of Double;
  Abstand       : Integer;
  Sichtfeld     : Integer;
  test          : Integer;
  fertig        : Boolean;

function distance(pX1: Integer; pY1: Integer; pX2: Integer; pY2: Integer): Integer;
  var temp: double;
  begin
  temp := sqrt(Power((pX1 - pX2), 2) + Power((pY1 - pY2), 2));
  distance := Round(temp);
end;

procedure TMovePlate.FormCreate(Sender: TObject);
begin
  fertig := false;
  // --- deklarieren des Arrays f�r die 'Cellen' -------------------------------
  spalt := round (ImagePaint.Width / cellScal);
  reih  := round (ImagePaint.Height / cellScal);
  SetLength(cellList, reih, spalt);
  SetLength(limboWorld, reih, spalt);
  // --- initialization and creation of the list -------------------------------
  ShapesList                    := TList.Create;
  MovePlate.Color               := clBlack;
  MovePlate.Canvas.Pen.Color    := clred;
  MovePlate.Canvas.Brush.Color  := clred;
  LEFT_BORDER                   := ImagePaint.Left-5;
  TOP_BORDER                    := ImagePaint.Top-5;
  RIGHT_BORDER                  := ImagePaint.Width-5;
  BOTTOM_BORDER                 := ImagePaint.Height-5;
  // --- Slider & Label --------------------------------------------------------
  Mouse_Rad                     := ScrollBar1.Position;
  Label_Radius.Caption          := IntToStr(Mouse_Rad);
  Lbl_TransKostAbh.Caption      := FloatToStr(SB_TransKostAbh.Position / 10);
  Lbl_BetrGr.Caption            := IntToStr(SB_BetrGr.Position);
  Lbl_KundSens.Caption          := FloatToStr(SB_KundSens.Position / 10);
  Lbl_Gewinn.Caption            := IntToStr(SB_Gewinn.Position);
  Lbl_MaxPr.Caption             := IntToStr(Sb_MaxPr.Position);
  Lbl_PreisAb.Caption           := FloatToStr(Sb_PreisAb.Position/10);
  // --- Zwischenspeicher f�r die Bildaktualisierung ---------------------------
  Backpuffer                    := TBitmap.create;
  Backpuffer.width              := ImagePaint.width;
  Backpuffer.height             := ImagePaint.height;
  Backpuffer.canvas.brush.color := clgreen;
  Backpuffer.canvas.rectangle   (10,10,Backpuffer.width,Backpuffer.height);
  RectanglCreate (Backpuffer.Canvas);
end;

// *********************************
// *** ------- Agenten --------- ***
//**********************************
// *** Zeichnet die Agenten ***
procedure TMovePlate.PaintBox1Paint(Sender: TObject);
begin
  MovePlate.Color := clBlack;
  MovePlate.canvas.brush.color := clgreen;
  MovePlate.canvas.pen.color := clgreen;
  MovePlate.canvas.pen.width := 2;
  MovePlate.canvas.rectangle(5,5,810,610);
  MovePlate.refresh;
  CommonPaint (Canvas);
end;

procedure TMovePlate.CommonPaint (Canvas: TCanvas);
var
  I     : Integer;
  AShape: TAgent;
begin
  // repaint each shape of the list
  for I := 0 to ShapesList.Count - 1 do
  begin
    AShape := ShapesList.Items [I];
    AShape.BindungSet := 0; // --- Anzahl Bindungen je Typ zur�cksetzen
    AShape.Paint (Canvas);
  end;
end;

// *** Aktualisierungen je Durchlauf***
procedure TMovePlate.ApplicationEvents1Idle(Sender: TObject; var Done: Boolean);
var
  I         : Integer;
  J         : Integer;
  AShape    : TAgent;
  distMouse : Integer;
  Area      : Trect;
begin
  If fertig = false then done := false;
  If fertig = true  then begin done := true; exit; end;
  //------------------------------------------//
  If (CB_moveMarkt.State = cbChecked) Then Begin
    for I := 0 to ShapesList.Count - 1 do
    begin
      AShape := ShapesList.Items [I];
      distMouse := distance (AShape.PositionX, AShape.PositionY, MouseX, MouseY);
      If (distMouse < Mouse_Rad) // --- MausInteraktion
      then begin
        AShape.FStepX := Dir * round ((AShape.PositionX - MouseX) * 0.1); //AShape.FStepX * -3;
        AShape.FStepY := Dir * round ((AShape.PositionY - MouseY) * 0.1); //AShape.FStepY * -3;
      end;
      AShape.SetRndDir (1.0001);
      // --- Randlos Torus--- // Rand nicht �berschreiten
      if AShape.PositionX < LEFT_BORDER  then
        AShape.PositionX := RIGHT_BORDER;
      if AShape.PositionX > RIGHT_BORDER then
        AShape.PositionX := LEFT_BORDER;
      if AShape.PositionY < TOP_BORDER then
        AShape.PositionY := BOTTOM_BORDER;
      if AShape.PositionY > BOTTOM_BORDER then
        AShape.PositionY := TOP_BORDER;
      // ++++ Position aktualisieren ++++
      AShape.PositionX := AShape.FPositionX + round(AShape.FStepX);
      AShape.PositionY := AShape.FPositionY + round(AShape.FStepY);
    end;
  end;

  // --- berechnen, zeichnen und verbinden ----
  RectanglPaint (Backpuffer.Canvas);        // --- L�scht Zeichung und Aktualisiert Zellen
  CommonPaint (Backpuffer.Canvas);
  If ShapesList.Count > 0 then GraphUmsatz; // --- Zeichnet die  Graphen
  /// --- Bild aktualisieren ---
  //BitBlt(Backpuffer.Canvas.Handle, bildleft, bildtop, Bild.Width, Bild.Height, Bild.canvas.handle, 0, 0, SRCCOPY);//Bild auf Backpuffer kopieren
  ImagePaint.Invalidate;
  BitBlt(ImagePaint.Canvas.Handle, 0, 0, Backpuffer.Width, Backpuffer.Height, Backpuffer.canvas.handle, 0, 0, SRCCOPY);//Backpuffer auf das Formular kopieren
end;

procedure TMovePlate.ImagePaintMouseMove(Sender: TObject; Shift: TShiftState; X, Y: Integer);
begin
  MouseX := X;
  MouseY := Y;
end;


// *********************************
// *** ------- Zellen ---------- ***
//**********************************
// *** Erstellt das ZellenRaster ***
procedure TMovePlate.RectanglCreate (Canvas: TCanvas);
var
  I: Integer;
  K: Integer;
  J: Integer;
begin
  for I := 0 to reih -1 do
  begin
    for K := 0 to spalt -1 do
    begin
      cellList[I,K] := TCell.Create;
      //--- Variablen in Abh. der Produkte dimensionieren ---
      SetLength(cellList[I,K].FLagerente,  NumProd);
      SetLength(cellList[I,K].FErtrag,     NumProd);
      SetLength(cellList[I,K].FErzeugKost, NumProd);
      SetLength(cellList[I,K].FTranspKost, NumProd);
      SetLength(cellList[I,K].FMarktPreis, NumProd);
      cellList[I,K].PositionX := K * cellScal + round(cellScal / 2);
      cellList[I,K].PositionY := I * cellScal + round(cellScal / 2);
      cellList[I,K].Size := round (cellScal / 2)+1;
      //ARecht.FillColor :=  RGB (I*K mod 255, I, K);
      cellList[I,K].Paint(Canvas);
    end ;
  end;
  //--- Werte in Veariablen schreiben ---
  for J := 0 to NumProd -1 do
  begin
    SetzeBetrGr;
    SetzeKundSens;
    SetzeGewinn;
    SetzeTranspKost;
  end;
end;

// *** Aktualisiert das ZellenRaster ***
procedure TMovePlate.RectanglPaint (Canvas: TCanvas);
var
  I    : Integer;
  K    : Integer;
  used : Integer;
  dist : Integer;
  distl: Single;
begin
  //--- Backbuffer l�schen
  canvas.brush.color := clGreen;
  canvas.pen.color := clGreen;
  canvas.rectangle(10,10,Backpuffer.width,Backpuffer.height);
  for I := 0 to reih -1 do
  begin
    for K := 0 to spalt -1 do
    begin
      // --- Cellen anpassen ---
      cellList[I,K].FillColor := clBlack;  // --- Cellen l�schen
      cellList[I,K].NextMarkt(ShapesList); // --- N�chsten Markt berechnen
      cellList[I,K].CalcUmsatz;            // --- Umsatz je Standort berechnen
      cellList[I,K].CalcProdKost;          // --- Produktionskosten am Standort
      cellList[I,K].CalcBidPr;             // --- Preis-Angebot f�r den jeweiligen Standort
      cellList[I,K].CalcBodenPreis(Sb_MaxPr.Position, Sb_PreisAb.Position);
      used := cellList[I,K].State;
      // --- Entfernungen anzeigen ---------------------------------------------
      If (CB_Distanz.State = cbChecked) Then Begin
        dist := 255 - round (cellList[I,K].Distance /2);
        If dist < 0 then dist := 0;
        cellList[I,K].FillColor := RGB (dist,dist,dist);
      end
      // --- Produktionskosten darstellen --------------------------------------
      else If (CB_ProdKost.State = cbChecked) Then Begin
        dist := 255 - round(cellList[I,K].ProdKost);
        If dist < 0 then dist := 0;
        cellList[I,K].FillColor := RGB (dist,0,0);
      end
      // --- Bid-Price = Kaufangebot anzeigen ----------------------------------
      else If (cb_bidPrice.State = cbChecked) Then Begin
        dist := cellList[I,K].BidPrice *3;
        If dist < 0 then dist := 0;
        If dist > 255 then dist := 255;
        cellList[I,K].FillColor := RGB (0,dist,0);
      end
      // --- Umsatz anzeigen ---------------------------------------------------
      else If (CB_Umsatz.State = cbChecked) Then begin
        dist := cellList[I,K].Umsatz *2;
        If dist < 0 then dist := 0;
        If dist > 255 then dist := 255;
        cellList[I,K].FillColor := RGB (dist,dist,0);
      end;
      // --- Wenn Angebotspreis dem Marktpreis entspricht: ---------------------
      If (cb_nutzSto.State = cbChecked) Then
      If (cellList[I,K].BidPrice = cellList[I,K].BodenPreis) then
      begin
        cellList[I,K].FillColor := clYellow;
      end;
      cellList[I,K].Paint(Canvas);
    end ;
  end;
end;

// *** Zeichnet die Graphen ***
procedure TMovePlate.GraphUmsatz;
var
  I      : Integer;
  K      : Integer;
  Wert  : Integer;
  AShape : TAgent;
  XCell  : Integer;
  YCell  : Integer;
  dir    : Integer;
begin
  Graph1.picture.LoadFromFile('Graph.bmp');
  Graph2.picture.LoadFromFile('Graph2.bmp');
  Graph3.picture.LoadFromFile('Graph3.bmp');
  AShape := ShapesList.Items [0];
  XCell := round((AShape.FPositionX - (cellScal / 2)) / (cellScal));
  YCell := round((AShape.FPositionY - (cellScal / 2)) / (cellScal));
  If not (((XCell < 0) or (XCell > spalt-1)) or ((YCell < 0) or (YCell > reih-1))) then
  begin
    dir := 1;
    // --- Umsatz-Kurve darstellen -------------------------------------------
    Wert := round (cellList[YCell,XCell].Umsatz /2);
    Graph1.Canvas.MoveTo (6, Graph1.Height - Wert);
    If XCell > round(spalt/2) then dir := -1;
    for K := 0 to 20 do
    begin
      Graph1.Canvas.Pen.Color := clBlue;
      Wert := round(cellList[YCell,XCell + (dir * K)].Umsatz / 2);
      Graph1.picture.Bitmap.Canvas.LineTo (6 + K * 6, Graph1.Height - Wert);
    end;
    // --- Produktionskosten-Kurve darstellen --------------------------------
    Wert := cellList[YCell,XCell].ProdKost;
    Graph2.Canvas.MoveTo (6, Graph2.Height - Wert);
    For K := 0 to 20 do
    begin
      Graph2.Canvas.Pen.Color := clRed;
      Wert := cellList[YCell,XCell + (dir * K)].ProdKost;
      Graph2.picture.Bitmap.Canvas.LineTo (6 + K * 6, Graph2.Height - Wert);
    end;
    // --- Bid-Price-Kurve darstellen ----------------------------------------
    Wert := cellList[YCell,XCell].BidPrice;
    Graph3.Canvas.MoveTo (6, Graph3.Height - Wert);
    For K := 0 to 20 do
    begin
      Graph3.Canvas.Pen.Color := clGreen;
      Wert := cellList[YCell,XCell + (dir * K)].BidPrice;
      Graph3.picture.Bitmap.Canvas.LineTo (6 + K * 6, Graph3.Height - Wert);
    end;
    // --- Bodenpreis-Kurve darstellen ---------------------------------------
    Wert := cellList[YCell,XCell].BodenPreis;
    Graph3.Canvas.MoveTo (6, Graph3.Height - Wert);
    For K := 0 to 20 do
    begin
      Graph3.Canvas.Pen.Color := clOlive;
      Graph3.Canvas.Pen.Width := 2;
      Wert := cellList[YCell,XCell + (dir * K)].BodenPreis;
      Graph3.picture.Bitmap.Canvas.LineTo (6 + K * 6, Graph3.Height - Wert);
    end;
    // --- anzeigen, wo Graph ausgelesen wird ----------------------------------
    If (cb_showG.State = cbChecked) Then
    begin
      Backpuffer.Canvas.Pen.Color := clMoneyGreen; //clPurple
      Backpuffer.Canvas.MoveTo (AShape.FPositionX, AShape.FPositionY);
      Backpuffer.Canvas.LineTo (AShape.FPositionX + 20 * dir * cellScal, AShape.FPositionY);
    end;
  end;
end;

//*** Berechnet die Celle unter dem Agenten ***
procedure TMovePlate.lookCell (Canvas: TCanvas);
var
  I      : Integer;
  AShape : TAgent;
  XCell  : Integer;
  YCell  : Integer;
begin
  for I := 0 to ShapesList.Count - 1 do
  begin
    AShape := ShapesList.Items [I];
    XCell := round((AShape.FPositionX - (cellScal / 2)) / (cellScal));
    YCell := round((AShape.FPositionY - (cellScal / 2)) / (cellScal));
    If not (((XCell < 0) or (XCell > spalt-1)) or ((YCell < 0) or (YCell > reih-1))) then
    begin
      cellList[YCell,XCell].State := AShape.FState +1; //+ RGB (3,4,5);
    end;
  end;
end;

procedure TMovePlate.cellStates (Canvas: TCanvas);
var
  I: Integer;
  K: Integer;
begin
  for I := 1 to reih -2 do
  begin
    for K := 1 to spalt -2 do
    begin
      checkNeighbour (Backpuffer.Canvas, I, K);
    end ;
  end;
end;

procedure TMovePlate.checkNeighbour (Canvas: TCanvas; xPos : Integer; yPos : Integer);
var
  I: Integer;
  K: Integer;
  state : Integer;
begin
  state := 0;
  for I := xPos - 1 to xPos + 1 do
  begin
    for K := yPos - 1 to yPos + 1 do
    begin
      //If not ((I = xPos) and (K = yPos)) then
      If (cellList[I,K].State = 1) then state := state - 55;
      If (cellList[I,K].State = 2) then state := state + 50;
    end;
  end;
  limboWorld[xPos,yPos] := state;
end;

// ***************************
// ********* Buttons *********
// ***************************
//
// *** Repel - Attract - Button ***
procedure TMovePlate.Button2MouseUp(Sender: TObject; Button: TMouseButton;
  Shift: TShiftState; X, Y: Integer);
begin
  Dir := Dir * (-1);
end;

// *** einzelne Agenten erstellen ***
procedure TMovePlate.ImagePaintClick(Sender: TObject);
begin
  CurrShape := TAgent.Create;
  CurrShape.PositionX :=  MouseX;
  CurrShape.PositionY :=  MouseY;
  CurrShape.StepX := (random(3) - 1);
  CurrShape.StepY := (random(3) - 1);
  CurrShape.Size := 3;
  CurrShape.Connect := 0;
  CurrShape.State := 0;
  CurrShape.basicSettings;
  ShapesList.Add (CurrShape);
  CommonPaint (ImagePaint.Canvas);
  Label2.Caption := IntToStr(ShapesList.Count);
end;


procedure TMovePlate.B_delMarktClick(Sender: TObject);
begin
  // --- delete each market
  ShapesList.Count := 0;
end;

// *** Alle Zellen wieder schwarz ***
procedure TMovePlate.ButtonPauseClick(Sender: TObject);
begin
  fertig := Not fertig; //true;
  If GB_Backgr.Color = clRed Then begin
    GB_Backgr.Color := clBlack;
    exit;
  end;
  GB_Backgr.Color := clRed;
end;

// *** Agenten l�schen ***
procedure TMovePlate.Button_DeleteClick(Sender: TObject);
begin
ShapesList.Count := ShapesList.Count - 100;
  Label2.Caption := IntToStr(ShapesList.Count);
end;

// ***************************
// ******* ScrollBars ********
// ***************************

// *** MausInteraktionsRadius ***
procedure TMovePlate.ScrollBar1Change(Sender: TObject);
begin
    Mouse_Rad            := ScrollBar1.Position;
    Label_Radius.Caption := IntToStr(Mouse_Rad);
end;

// *** ***
procedure TMovePlate.SB_BetrGrChange(Sender: TObject);
begin
  Lbl_BetrGr.Caption := IntToStr(SB_BetrGr.Position);
  SetzeBetrGr;
end;

procedure TMovePlate.cb_bidPriceClick(Sender: TObject);
begin
  CB_ProdKost.State := cbunChecked;
  cb_Umsatz.State := cbunChecked;
end;

procedure TMovePlate.CB_ProdKostClick(Sender: TObject);
begin
  cb_bidPrice.State := cbunChecked;
  cb_Umsatz.State := cbunChecked;
end;

procedure TMovePlate.cb_UmsatzClick(Sender: TObject);
begin
  cb_bidPrice.State := cbunChecked;
  CB_ProdKost.State := cbunChecked;
end;

procedure TMovePlate.Sb_MaxPrChange(Sender: TObject);
begin
  Lbl_MaxPr.Caption := IntToStr(Sb_MaxPr.Position);
end;

procedure TMovePlate.Sb_PreisAbChange(Sender: TObject);
begin
  Lbl_PreisAb.Caption := FloatToStr(Sb_PreisAb.Position/10);
end;

procedure TMovePlate.SetzeBetrGr;
var
  I : Integer;
  K : Integer;
begin
  for I := 0 to reih -1 do
  begin
    for K := 0 to spalt -1 do
    begin
      cellList[I,K].BetrGr := SB_BetrGr.Position;
    end;
  end;
end;

// ***  ***
procedure TMovePlate.SB_GewinnChange(Sender: TObject);
begin
  Lbl_Gewinn.Caption := IntToStr(SB_Gewinn.Position);
  SetzeGewinn;
end;

procedure TMovePlate.SetzeGewinn;
var
  I : Integer;
  K : Integer;
begin
  for I := 0 to reih -1 do
  begin
    for K := 0 to spalt -1 do
    begin
      cellList[I,K].Gewinn := SB_Gewinn.Position;
    end;
  end;
end;

// *** ***
procedure TMovePlate.SB_KundSensChange(Sender: TObject);
begin
  Lbl_KundSens.Caption := FloatToStr(SB_KundSens.Position / 10);
  SetzeKundSens;
end;

procedure TMovePlate.SetzeKundSens;
var
  I : Integer;
  K : Integer;
begin
  for I := 0 to reih -1 do
  begin
    for K := 0 to spalt -1 do
    begin
      cellList[I,K].KundenSens := SB_KundSens.Position;
    end;
  end;
end;

procedure TMovePlate.SB_TransKostAbhChange(Sender: TObject);
begin
  Lbl_TransKostAbh.Caption := FloatToStr(SB_TransKostAbh.Position / 10);;
  SetzeTranspKost;
end;

procedure TMovePlate.SetzeTranspKost;
var
  I : Integer;
  K : Integer;
begin
  for I := 0 to reih -1 do
  begin
    for K := 0 to spalt -1 do
    begin
      cellList[I,K].TransAbh := SB_TransKostAbh.Position;
    end;
  end;
end;

// ******************************
// *** Array und Liste L�schen***
// ******************************
procedure TMovePlate.FormDestroy(Sender: TObject);
var
  I: Integer;
  J: Integer;
  K: Integer;
begin
  // --- delete each agent
  for I := ShapesList.Count - 1 downto 0 do
    TBaseShape (ShapesList [I]).Free;
  ShapesList.Free;
  // --- delete each cell
  for J := reih -1 downto 0 do
  begin
    for K := spalt -1 downto 0 do
    begin
      TBaseShape (cellList[J,K]).Free;
    end;
  end;
end;

end.

object Form1: TForm1
  Left = 0
  Top = 0
  Width = 750
  Height = 700
  Caption = 'path system & slime mold'
  Color = clBtnFace
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -10
  Font.Name = 'Tahoma'
  Font.Style = []
  OldCreateOrder = False
  OnCreate = FormCreate
  OnDestroy = FormDestroy
  PixelsPerInch = 96
  TextHeight = 12
  object Lbl_B: TLabel
    Left = 530
    Top = 277
    Width = 15
    Height = 12
    Caption = '___'
  end
  object Label1: TLabel
    Left = 442
    Top = 277
    Width = 76
    Height = 12
    Caption = 'angle threshold :'
  end
  object Lbl_wiggle: TLabel
    Left = 530
    Top = 325
    Width = 15
    Height = 12
    Caption = '___'
  end
  object Label3: TLabel
    Left = 442
    Top = 325
    Width = 81
    Height = 12
    Caption = 'wiggle threshold :'
  end
  object Lbl_strenght: TLabel
    Left = 530
    Top = 373
    Width = 15
    Height = 12
    Caption = '___'
  end
  object Label5: TLabel
    Left = 442
    Top = 373
    Width = 70
    Height = 12
    Caption = 'mark strenght :'
  end
  object Lbl_evapo: TLabel
    Left = 674
    Top = 373
    Width = 15
    Height = 12
    Caption = '___'
  end
  object Label6: TLabel
    Left = 578
    Top = 373
    Width = 72
    Height = 12
    Caption = 'evaporate rate :'
  end
  object Lbl_sniff: TLabel
    Left = 674
    Top = 325
    Width = 15
    Height = 12
    Caption = '___'
  end
  object Label7: TLabel
    Left = 578
    Top = 325
    Width = 70
    Height = 12
    Caption = 'sniff threshold :'
  end
  object Lbl_visible: TLabel
    Left = 674
    Top = 277
    Width = 15
    Height = 12
    Caption = '___'
  end
  object Label8: TLabel
    Left = 578
    Top = 277
    Width = 87
    Height = 12
    Caption = 'visibility threshold :'
  end
  object ZeichenPanel: TPanel
    Left = 8
    Top = 9
    Width = 404
    Height = 404
    BorderStyle = bsSingle
    DockSite = True
    TabOrder = 0
    OnMouseDown = ZeichenPanelMouseDown
    OnMouseMove = ZeichenPanelMouseMove
    OnMouseUp = ZeichenPanelMouseUp
  end
  object RChart1: TRChart
    Left = 8
    Top = 416
    Width = 721
    Height = 249
    AllocSize = 1000
    AutoRedraw = True
    RRim = 20
    TRim = 20
    BRim = 40
    BackGroundImg.IncludePath = False
    BackGroundImg.FillMode = bfStretch
    ClassDefault = 0
    GridStyle = gsNone
    Isometric = False
    JointLayers.L01xControlledBy = 1
    JointLayers.L01yControlledBy = 1
    JointLayers.L02xControlledBy = 2
    JointLayers.L02yControlledBy = 2
    Caption = 'sum of marked cells [mark-value > round(evaporate-rate*10)]'
    CaptionPosX = 0
    CaptionPosY = -16
    CaptionAlignment = taRightJustify
    CaptionAnchorHoriz = cahChartRight
    CaptionAnchorVert = cavChartTop
    CrossHair1.Color = clBlack
    CrossHair1.Layer = 1
    CrossHair1.Mode = chOff
    CrossHair1.LineType = psSolid
    CrossHair1.LineWid = 1
    CrossHair2.Color = clBlack
    CrossHair2.Layer = 2
    CrossHair2.Mode = chOff
    CrossHair2.LineType = psSolid
    CrossHair2.LineWid = 1
    CrossHair3.Color = clBlack
    CrossHair3.Layer = 3
    CrossHair3.Mode = chOff
    CrossHair3.LineType = psSolid
    CrossHair3.LineWid = 1
    CrossHair4.Color = clBlack
    CrossHair4.Layer = 4
    CrossHair4.Mode = chOff
    CrossHair4.LineType = psSolid
    CrossHair4.LineWid = 1
    MouseAction = maNone
    MouseCursorFixed = True
    Scale1X.CaptionPosX = 0
    Scale1X.CaptionPosY = 22
    Scale1X.CaptionAlignment = taCenter
    Scale1X.CaptionAnchor = uaSclCenter
    Scale1X.ColorScale = clBlack
    Scale1X.DateFormat.TimeFormat = tfHHMMSS
    Scale1X.DateFormat.DateSeparator = '-'
    Scale1X.DateFormat.TimeSeparator = ':'
    Scale1X.DateFormat.YearLength = ylYYYY
    Scale1X.DateFormat.MonthName = True
    Scale1X.DateFormat.DateOrder = doDDMMYY
    Scale1X.DateFormat.DateForTime = dtOnePerDay
    Scale1X.DecPlaces = -2
    Scale1X.Font.Charset = DEFAULT_CHARSET
    Scale1X.Font.Color = clWindowText
    Scale1X.Font.Height = -11
    Scale1X.Font.Name = 'Tahoma'
    Scale1X.Font.Style = []
    Scale1X.Logarithmic = False
    Scale1X.LabelType = ftNum
    Scale1X.MinTicks = 3
    Scale1X.MinRange = 0.000000000100000000
    Scale1X.RangeHigh = 1.000000000000000000
    Scale1X.ShortTicks = True
    Scale1X.ScalePos = 0
    Scale1X.Visible = True
    Scale1X.ScaleLocation = slBottom
    Scale1Y.CaptionPosX = 0
    Scale1Y.CaptionPosY = -16
    Scale1Y.CaptionAlignment = taLeftJustify
    Scale1Y.CaptionAnchor = uaSclTopLft
    Scale1Y.ColorScale = clBlack
    Scale1Y.DateFormat.TimeFormat = tfHHMMSS
    Scale1Y.DateFormat.DateSeparator = '-'
    Scale1Y.DateFormat.TimeSeparator = ':'
    Scale1Y.DateFormat.YearLength = ylYYYY
    Scale1Y.DateFormat.MonthName = True
    Scale1Y.DateFormat.DateOrder = doDDMMYY
    Scale1Y.DateFormat.DateForTime = dtOnePerDay
    Scale1Y.DecPlaces = -2
    Scale1Y.Font.Charset = DEFAULT_CHARSET
    Scale1Y.Font.Color = clWindowText
    Scale1Y.Font.Height = -11
    Scale1Y.Font.Name = 'Tahoma'
    Scale1Y.Font.Style = []
    Scale1Y.Logarithmic = False
    Scale1Y.LabelType = ftNum
    Scale1Y.MinTicks = 3
    Scale1Y.MinRange = 0.000000000100000000
    Scale1Y.RangeHigh = 1.000000000000000000
    Scale1Y.ShortTicks = True
    Scale1Y.ScalePos = 0
    Scale1Y.Visible = True
    Scale1Y.ScaleLocation = slLeft
    Scale2X.CaptionPosX = 10
    Scale2X.CaptionPosY = 100
    Scale2X.CaptionAlignment = taCenter
    Scale2X.CaptionAnchor = uaSclCenter
    Scale2X.ColorScale = clMaroon
    Scale2X.DateFormat.TimeFormat = tfHHMMSS
    Scale2X.DateFormat.DateSeparator = '-'
    Scale2X.DateFormat.TimeSeparator = ':'
    Scale2X.DateFormat.YearLength = ylYYYY
    Scale2X.DateFormat.MonthName = True
    Scale2X.DateFormat.DateOrder = doDDMMYY
    Scale2X.DateFormat.DateForTime = dtOnePerDay
    Scale2X.DecPlaces = -2
    Scale2X.Font.Charset = DEFAULT_CHARSET
    Scale2X.Font.Color = clWindowText
    Scale2X.Font.Height = -11
    Scale2X.Font.Name = 'Tahoma'
    Scale2X.Font.Style = []
    Scale2X.Logarithmic = False
    Scale2X.LabelType = ftNum
    Scale2X.MinTicks = 3
    Scale2X.MinRange = 0.000000000100000000
    Scale2X.RangeHigh = 1.000000000000000000
    Scale2X.ShortTicks = True
    Scale2X.ScalePos = 0
    Scale2X.Visible = False
    Scale2X.ScaleLocation = slBottom
    Scale2Y.CaptionPosX = 10
    Scale2Y.CaptionPosY = 100
    Scale2Y.CaptionAlignment = taRightJustify
    Scale2Y.CaptionAnchor = uaSclTopLft
    Scale2Y.ColorScale = clMaroon
    Scale2Y.DateFormat.TimeFormat = tfHHMMSS
    Scale2Y.DateFormat.DateSeparator = '-'
    Scale2Y.DateFormat.TimeSeparator = ':'
    Scale2Y.DateFormat.YearLength = ylYYYY
    Scale2Y.DateFormat.MonthName = True
    Scale2Y.DateFormat.DateOrder = doDDMMYY
    Scale2Y.DateFormat.DateForTime = dtOnePerDay
    Scale2Y.DecPlaces = -2
    Scale2Y.Font.Charset = DEFAULT_CHARSET
    Scale2Y.Font.Color = clWindowText
    Scale2Y.Font.Height = -11
    Scale2Y.Font.Name = 'Tahoma'
    Scale2Y.Font.Style = []
    Scale2Y.Logarithmic = False
    Scale2Y.LabelType = ftNum
    Scale2Y.MinTicks = 3
    Scale2Y.MinRange = 0.000000000100000000
    Scale2Y.RangeHigh = 1.000000000000000000
    Scale2Y.ShortTicks = True
    Scale2Y.ScalePos = 0
    Scale2Y.Visible = False
    Scale2Y.ScaleLocation = slLeft
    ShadowStyle = ssFlying
    ShadowColor = clGrayText
    ShadowBakColor = clBtnFace
    TextFontStyle = []
    TextBkStyle = tbClear
    TextBkColor = clWhite
    TextAlignment = taCenter
  end
  object TrB_thresh: TScrollBar
    Left = 440
    Top = 296
    Width = 121
    Height = 17
    LargeChange = 5
    Max = 180
    PageSize = 0
    Position = 45
    TabOrder = 2
    OnChange = TrB_threshChange
  end
  object SB_wiggle: TScrollBar
    Left = 440
    Top = 344
    Width = 121
    Height = 17
    LargeChange = 5
    Max = 180
    PageSize = 0
    Position = 40
    TabOrder = 3
    OnChange = SB_wiggleChange
  end
  object RadioGroup1: TRadioGroup
    Left = 440
    Top = 192
    Width = 257
    Height = 49
    Caption = 'sniff chemicals with'
    TabOrder = 4
  end
  object rb_rulette: TRadioButton
    Left = 448
    Top = 216
    Width = 81
    Height = 17
    Caption = 'rulette wheel'
    TabOrder = 5
  end
  object GroupBox1: TGroupBox
    Left = 440
    Top = 8
    Width = 257
    Height = 129
    Caption = 'setup settings'
    TabOrder = 6
    object Lbl_TextAnzahl: TLabel
      Left = 54
      Top = 76
      Width = 129
      Height = 12
      Caption = ': number of agents for setup'
    end
    object Label2: TLabel
      Left = 54
      Top = 100
      Width = 127
      Height = 12
      Caption = ': cell size -> number of cells '
    end
    object B_setup: TButton
      Left = 6
      Top = 16
      Width = 75
      Height = 25
      Caption = 'new Setup'
      TabOrder = 0
      OnClick = B_setupClick
    end
    object B_stop: TButton
      Left = 86
      Top = 16
      Width = 75
      Height = 25
      Caption = 'start / stop'
      TabOrder = 1
      OnClick = B_stopClick
    end
    object B_oneStep: TButton
      Left = 166
      Top = 16
      Width = 75
      Height = 25
      Caption = 'one step'
      TabOrder = 2
      OnClick = B_oneStepClick
    end
    object CB_mCent: TCheckBox
      Left = 8
      Top = 48
      Width = 161
      Height = 17
      Caption = 'setup with ten spred centers'
      Checked = True
      Enabled = False
      State = cbChecked
      TabOrder = 3
    end
    object Edit_anzAg: TEdit
      Left = 8
      Top = 72
      Width = 41
      Height = 20
      TabOrder = 4
      Text = '175'
    end
    object Edit_size: TEdit
      Left = 8
      Top = 96
      Width = 41
      Height = 20
      TabOrder = 5
      Text = '7'
      OnChange = Edit_sizeChange
    end
  end
  object rb_hill: TRadioButton
    Left = 576
    Top = 216
    Width = 81
    Height = 17
    Caption = 'hill climbing'
    Checked = True
    TabOrder = 7
    TabStop = True
  end
  object GroupBox2: TGroupBox
    Left = 440
    Top = 144
    Width = 257
    Height = 41
    Caption = 'timesteps'
    TabOrder = 8
    object lbl_Steps: TLabel
      Left = 72
      Top = 18
      Width = 39
      Height = 12
      Alignment = taCenter
      BiDiMode = bdRightToLeft
      Caption = 'lbl_Steps'
      ParentBiDiMode = False
    end
  end
  object CB_diffuse: TCheckBox
    Left = 448
    Top = 248
    Width = 105
    Height = 17
    Caption = 'diffuse chemicals'
    Checked = True
    State = cbChecked
    TabOrder = 9
  end
  object SB_strenght: TScrollBar
    Left = 440
    Top = 392
    Width = 121
    Height = 17
    LargeChange = 5
    PageSize = 0
    Position = 20
    TabOrder = 10
    OnChange = SB_strenghtChange
  end
  object SB_evapo: TScrollBar
    Left = 576
    Top = 392
    Width = 121
    Height = 17
    LargeChange = 5
    PageSize = 0
    Position = 13
    TabOrder = 11
    OnChange = SB_evapoChange
  end
  object SB_sniff: TScrollBar
    Left = 576
    Top = 344
    Width = 121
    Height = 17
    LargeChange = 5
    PageSize = 0
    Position = 10
    TabOrder = 12
    OnChange = SB_sniffChange
  end
  object SB_visible: TScrollBar
    Left = 576
    Top = 296
    Width = 121
    Height = 17
    LargeChange = 5
    PageSize = 0
    Position = 3
    TabOrder = 13
    OnChange = SB_visibleChange
  end
  object Timer1: TTimer
    Interval = 1
    OnTimer = Timer1Timer
    Left = 704
    Top = 16
  end
end

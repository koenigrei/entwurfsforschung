(********************************************************************)
(*                                                                  *) 
(*                                                                  *)
(*                     Interaction Patterns                         *)
(*                          Version 1.0                             *)
(*                                                                  *)
(*                                                                  *)
(*     Programmierer: Reinhard K�nig                      June 2006 *)
(*                    http://www.entwurfsforschung.de               *)
(*                                                                  *)
(*     Last Update: Jun-11, 2006                                    *)
(*                                                                  *)
(********************************************************************) 
{revision history:

1.0     [Jun-11, 2006]
        first release to the public
}

unit CellForm;

interface

uses
  Windows, Messages, SysUtils, Classes, Graphics, Controls, Forms, Series ,
  Dialogs, StdCtrls, cell_P, ExtCtrls, Math, agenten, calcer, TeeProcs,
  TeEngine, Chart;

type
  TForm1 = class(TForm)
    ZeichenPanel   : TPanel;
    RadioGroup1    : TRadioGroup;
    rb_rulette     : TRadioButton;
    GroupBox1      : TGroupBox;
    B_setup        : TButton;
    B_stop         : TButton;
    B_oneStep      : TButton;
    Edit_anzAg     : TEdit;
    Lbl_TextAnzahl : TLabel;
    Edit_size      : TEdit;
    Label2         : TLabel;
    rb_hill        : TRadioButton;
    GroupBox2      : TGroupBox;
    lbl_Steps      : TLabel;
    Timer1         : TTimer;
    GroupBox3      : TGroupBox;
    TrB_thresh     : TScrollBar;
    Label1         : TLabel;
    Lbl_B          : TLabel;
    SB_wiggle      : TScrollBar;
    Label3         : TLabel;
    Lbl_wiggle     : TLabel;
    E_noise        : TEdit;
    Label6         : TLabel;
    Button1        : TButton;
    E_stop         : TEdit;
    Label4         : TLabel;
    CB_pre         : TComboBox;
    Chart1         : TChart;
    Series1        : TLineSeries;
    GroupBox4      : TGroupBox;
    CB_noTracks    : TCheckBox;
    CB_gravity     : TCheckBox;
    CB_showAB      : TCheckBox;
    CB_showAg      : TCheckBox;
    E_decay        : TEdit;
    Label7         : TLabel;
    E_grav         : TEdit;
    CB_decay       : TCheckBox;
    procedure E_gravChange(Sender: TObject);
    procedure CB_gravityClick(Sender: TObject);
    procedure CB_noTracksClick(Sender: TObject);
    procedure CB_preChange(Sender: TObject);
    procedure E_stopChange(Sender: TObject);
    procedure Button1Click(Sender: TObject);
    procedure CB_showABClick(Sender: TObject);
    procedure E_noiseChange   (Sender: TObject);
    procedure Edit_sizeChange (Sender: TObject);
    procedure SB_wiggleChange (Sender: TObject);
    procedure B_oneStepClick  (Sender: TObject);
    procedure TrB_threshChange(Sender: TObject);
    procedure B_stopClick     (Sender: TObject);
    procedure B_setupClick    (Sender: TObject);
    procedure Timer1Timer     (Sender: TObject);
    procedure FormDestroy     (Sender: TObject);
    procedure FormCreate      (Sender: TObject);
  private
    AgentList  : TList;
    cellList   : TCellList;
    limboWorld : TLimbo;
    destiList  : Array of TDestiList;
    procedure createPaintImg;
    procedure createRaster;
    procedure createAgents;
    procedure setupCells;
    procedure setupAgents;
    procedure calcAgents;
    procedure repaintAgents;
    procedure repaintCells;
    procedure checkArea   (I : Integer);
    procedure calculate;
    procedure settings;
    procedure deleter;
    procedure calcCellDist;
    procedure findMaxMin;
    procedure setDestinations;
    procedure setOrigins;
    procedure repaintAllCells;
    procedure whiteAgImg;
    procedure drawConns;
    procedure resetGraph;
    procedure drawCh(value1, value2, value3, value4, value5 : Integer);
    procedure calcGraph;
    procedure decayMarks;
  public
end;

var
  Form1    : TForm1;
  paintImg : TImage;
  agentImg : TImage;

implementation

{$R *.dfm}

const
  AgSize = 2;                    //-- Agenten gr��e

var
  reih     : Integer;            //-- Zellen-Reihen gesamt
  spalt    : Integer;            //-- Zellen-Spalten gesamt
  steps    : Integer;
  cellScal : Integer;            //-- Zellen  gr��e
  halfScal : Integer;
  maxM     : Extended;           //-- maximal mark value
  minM     : Extended;           //-- minimal mark value
  stopTime : Integer;
  setupMode: Integer;
  sSer, tSer, eSer, xSer, cSer : TLineSeries;    //-- series for graph-plotting

// ---------------------------------------------------------------------------//
// *** Initialisierung *********************************************************
procedure TForm1.FormCreate(Sender: TObject);
begin
  settings;
  CB_pre.AddItem('Random Destinations', Sender);
  CB_pre.AddItem('Circle Destinations', Sender);
  CB_pre.AddItem('Raster Destinations', Sender);
end;

// *****************************************************************************
procedure TForm1.settings;
begin
  cellScal  := StrToInt(Edit_size.Text) ;
  halfScal  := round(cellScal/2);
  spalt     := round (ZeichenPanel.Width / cellScal);
  reih      := round (ZeichenPanel.Height / cellScal);
  stopTime  := StrToInt(E_stop.Text);
  Lbl_B.Caption := IntToStr(TrB_thresh.Position) + ' Grad';
  Lbl_wiggle.Caption := IntToStr(SB_wiggle.Position) + ' Grad';
  AgentList := TList.Create;
  SetLength(cellList, spalt, reih);
  SetLength(limboWorld, spalt, reih);
  createPaintImg;
  CreateRaster;
  CreateAgents;
  ZeichenPanel.Enabled := true;
  ZeichenPanel.DoubleBuffered := True;
  steps := 0;
  setDestinations;
  setOrigins;
  resetGraph;
end;
// ---------------------------------------------------------------------------//
// ------------------------- Elemente erstellen ------------------------------//
// ---------------------------------------------------------------------------//

// *** Legt eine leere Zeichenfl�che �ber das Zeichenpanel *********************
procedure TForm1.createPaintImg;
begin
  paintImg        := TImage.Create(self);
  paintImg.Parent := ZeichenPanel;
  paintImg.top    := 0;
  paintImg.Left   := 0;
  paintImg.Height := ZeichenPanel.Height;
  paintImg.Width  := ZeichenPanel.Width;
  paintImg.Enabled:= False;                  // -- does not reakt on mouseEvents

  agentImg        := TImage.Create(self);
  agentImg.Parent := ZeichenPanel;
  agentImg.top    := 0;
  agentImg.Left   := 0;
  agentImg.Height := ZeichenPanel.Height;
  agentImg.Width  := ZeichenPanel.Width;
  agentImg.Transparent := true;
  agentImg.Enabled:= False;
end;

// *****************************************************************************
procedure TForm1.CreateAgents;
var
  I        : Integer;
  curAgent : TAgent;
begin
  for I := 1 to StrToInt(Edit_anzAg.Text) do
  begin
    curAgent := TAgent.Create;
    AgentList.Add (curAgent);
  end;
  setupAgents;
end;

// *** Agenten initialisieren **************************************************
procedure TForm1.setupAgents;
var
  curAgent : TAgent;
  I        : Integer;
  middle   : Integer;
begin
  middle := round(reih/2);
  Randomize();
  for I := 0 to AgentList.Count - 1 do
  begin
    curAgent := AgentList.Items [I];
    curAgent.onCell.X := middle;
    curAgent.onCell.Y := middle;
    curAgent.Home.X   := curAgent.onCell.X;
    curAgent.Home.Y   := curAgent.onCell.Y;
    curAgent.PosX     := curAgent.onCell.X * cellScal + halfScal;
    curAgent.PosY     := curAgent.onCell.Y * cellScal + halfScal;
    curAgent.Size     := AgSize;
    curAgent.succeed  := 0;
    curAgent.Heading  := random (360);
    curAgent.Modus    := 0;                       // --- 0 for exploration mode
  end;                                            // --- 1 for returning mode
  repaintAgents;
end;

// *** Zellen erstellen ********************************************************
procedure TForm1.CreateRaster;
var
  curCell : TCell;
  I       : Integer;
  K       : Integer;
begin
  for I := 0 to reih -1 do
  begin
    for K := 0 to spalt -1 do
    begin
      curCell := TCell.Create(halfScal + K * cellScal, halfScal + I * cellScal, halfScal, 0);
      cellList[K,I] := curCell;
    end;
  end;
  setupCells;
end;

// *** Zellen initialisieren ***************************************************
procedure TForm1.setupCells;
var
  curCell : TCell;
  I, K    : Integer;
begin
  Randomize();
  for I := 0 to reih -1 do
  begin
    for K := 0 to spalt -1 do
    begin
      curCell         := cellList[K,I];
      curCell.colr    := 255;
      curCell.state   := 0;
      curCell.maxM    := 1;
      curCell.markA   := 0;
      curCell.markB   := curCell.markA;
      curCell.oldMark := curCell.markA;
    end;
  end;
  findMaxMin;
  repaintCells;
end;

// *****************************************************************************
procedure TForm1.calcCellDist;
var
  onCell   : TCell;
  curCell  : TCell;
  curAgent : TAgent;
  I, K, M  : Integer;
  tempPos  : TPoint;
  cellPos  : TPoint;
  halfSpalt : Real;
  dScale    : Real;
begin
  halfSpalt := spalt / 2;
  onCell    := cellList[round(spalt/2), round(reih/2)];
  for I := 0 to reih -1 do
  begin
    for K := 0 to spalt -1 do
    begin
      curCell   := cellList[K,I];
      cellPos.X := curCell.FPos.X;
      cellPos.Y := curCell.FPos.Y;
      // -- calculate and sum the distances --
      curCell.Dist    := calcDistance(cellPos.X, cellPos.Y, onCell.FPos.X,onCell.FPos.Y);
      curCell.markH   := (1000 - curCell.Dist)*10;
    end;
  end;
end;

// *** set the destination places **********************************************
procedure TForm1.setDestinations;
var
  curCell    : TCell;
  pos        : TPoint;
  Xp, Yp     : Integer;
  M, L, I, K : Integer;
  count      : Integer;
begin
  Randomize();
  SetLength (destiList, 0);
  case setupMode of
  // --- 10 random destinations ---
  0: begin
  E_noise.Text :='30';
  for M := 0 to 9 do
  begin
    pos.X := random(spalt);
    pos.Y := random(reih);
    SetLength (destiList, length(destiList)+1);                               // -- save the coordinates of the destination-core in a list
    destiList[high(destiList)].Pos.X   := pos.X * cellScal + halfScal;
    destiList[high(destiList)].Pos.Y   := pos.Y * cellScal + halfScal;
    destiList[high(destiList)].numbers := 0;
    for I := -1 to 1 do
    begin
      for K := -1 to 1 do
      begin
        Xp := pos.X + K;
        Yp := pos.Y + I;
        torus(Xp, Yp, spalt, reih);
        curCell         := cellList[Xp, Yp];
        curCell.state   := 2;                                                 // --- 2 for destination-state
        curCell.desiNr  := M;
        curCell.rePaint(paintImg.Canvas, 0);
      end;
    end;
  end;
  end;
  // --- circle destinations ---
  1: begin
  calcCellDist;
  M := 0;
  E_noise.Text :='50';
  for I := 0 to reih -1 do
  begin
    for K := 0 to spalt -1 do
    begin
      curCell         := cellList[K,I];
      If curCell.Dist > 180 Then
      begin
        curCell.State  := 2;
        curCell.desiNr := M;
        SetLength (destiList, length(destiList)+1);                           // -- save the coordinates of the destination-core in a list
        destiList[high(destiList)].Pos.X   := K * cellScal + halfScal;
        destiList[high(destiList)].Pos.Y   := I * cellScal + halfScal;
        destiList[high(destiList)].numbers := 0;
        curCell.rePaint(paintImg.Canvas, 0);
        Inc(M);
      end;
    end;
  end;
  end;
  // --- raster destinations ---
  2: begin
  count := 0;
  E_noise.Text :='30';
  for I := 0 to 4 do
  begin
    for K := 0 to 4 do
    begin
      pos.X :=  round(K * (spalt/5)+ 0.5*(spalt/5));
      pos.Y :=  round(I * (reih/5) + 0.5*(reih/5));
      SetLength (destiList, length(destiList)+1);                             // -- save the coordinates of the destination-core in a list
      destiList[high(destiList)].Pos.X   := pos.X * cellScal + halfScal;
      destiList[high(destiList)].Pos.Y   := pos.Y * cellScal + halfScal;
      destiList[high(destiList)].numbers := 0;
      for L := -1 to 1 do
      begin
        for M := -1 to 1 do
        begin
          Xp := pos.X + M;
          Yp := pos.Y + L;
          torus(Xp, Yp, spalt, reih);
          curCell         := cellList[Xp, Yp];
          curCell.state   := 2;                                               // --- 2 for destination-state
          curCell.desiNr  := count;
          curCell.rePaint(paintImg.Canvas, 0);
        end;
      end;
      Inc(count);
    end;
  end;
  end;
  end;
end;

// *** set the origin places **********************************************
procedure TForm1.setOrigins;
var
  curCell : TCell;
  pos     : TPoint;
  Xp, Yp  : Integer;
  M, I, K : Integer;
begin
  Randomize();
  pos.X := round(spalt/2);
  pos.Y := round(reih/2);
  for I := -1 to 1 do
  begin
    for K := -1 to 1 do
    begin
      Xp := pos.X + K;
      Yp := pos.Y + I;
      torus(Xp, Yp, spalt, reih);
      curCell         := cellList[Xp, Yp];
      curCell.state   := 1;                     // --- 1 for origin-state
      curCell.rePaint(paintImg.Canvas, 0);
    end;
  end;
end;

// ---------------------------------------------------------------------------//
// ---------------------------- Berechnungen ---------------------------------//
// ---------------------------------------------------------------------------//

// *** Rekursive Befehle ausf�hren *********************************************
procedure TForm1.Timer1Timer(Sender: TObject);
begin
  calculate;
end;

// *** Rekursive Befehle ausf�hren ***
procedure TForm1.whiteAgImg;
begin
  agentImg.Canvas.brush.Color := clWhite;
  agentImg.Canvas.pen.Color   := clWhite;
  agentImg.Canvas.Rectangle(0,0,ZeichenPanel.Height,ZeichenPanel.Width);
end;

// *****************************************************************************
procedure TForm1.calculate;
begin
  //diffuse(StrToFloat(E_diffuse.Text), spalt, reih, limboWorld, cellList);     // -- diffuse procedure in calcer

  //calcCellDist;

  findMaxMin;

  whiteAgImg;

  repaintCells;

  If CB_gravity.Checked = True Then drawConns;

  If CB_showAg.Checked  = True Then repaintAgents;

  calcAgents; // -- ver�ndert die Position der Agenten

  If CB_decay.Checked Then decayMarks;

  steps := steps +1;
  lbl_Steps.Caption := intToStr (steps);

  If steps = stopTime Then timer1.enabled := false;

  calcGraph;

end;

//******************************************************************************
procedure TForm1.calcGraph;
var
  curAgent   : TAgent;
  curCell    : TCell;
  I,K        : Integer;
  allsucceed : Integer;
  numAg      : Integer;
  returnAg   : Integer;
begin
  numAg      := StrToInt(Edit_anzAg.Text);
  allsucceed := 0;
  returnAg    := 0;
  for I := 0 to AgentList.Count - 1 do
  begin
    curAgent   := AgentList.Items [I];
    allsucceed := allsucceed + curAgent.succeed;
    returnAg   := returnAg + curAgent.Modus;
  end;
  If allsucceed > 0 Then allsucceed := round((allsucceed / numAg) *100);
  If returnAg   > 0 Then returnAg   := round((returnAg / numAg) *100);
  drawCh(allsucceed, returnAg, 0, 0, 0);
end;

// ---------------------------------------------------------------------------//
// ---------------------------------------------------------------------------//
//--- Ausgabe in Graph --- *****************************************************
procedure TForm1.drawCh(value1, value2, value3, value4, value5 : Integer);
begin
  sSer.AddXY(steps, value1);
  eSer.AddXY(steps, value2);
  tSer.AddXY(steps, maxM);
  {eSer.AddXY(steps, value4);
  cSer.AddXY(steps, value5); }
end;

//******************************************************************************
procedure TForm1.resetGraph;
begin
  with Chart1 do
  begin
    RemoveAllSeries;
    Title.Text.Clear;                                // Title of the Chart
    Title.Text.Add('average values');

    sSer := TLineSeries.Create(nil);                 // Create first Series
    sSer.Clear;                                      // Clear it
    sSer.Title := 'successful Ag`s';                 // set the title
    sSer.ParentChart := Chart1;                      // determine the chart, this series belongs to
    sSer.VertAxis := aRightAxis;

    tSer := TLineSeries.Create(nil);                 // create the second Series
    tSer.Clear;
    tSer.Title       := 'max mark';
    tSer.ParentChart := Chart1;
    tSer.VertAxis := aLeftAxis;                     // this series uses the right axis
    tSer.LinePen.Width := 1;

    eSer := TLineSeries.Create(nil);                 // create the second Series
    eSer.Clear;
    eSer.Title       := 'returning Ag';             //'efficiency';
    eSer.ParentChart := Chart1;
    eSer.VertAxis := aRightAxis;
    eSer.LinePen.Width := 2;

    {xSer := TLineSeries.Create(nil);                 // create the second Series
    xSer.Clear;
    xSer.Title       := 'ROM';                       //'return on management';
    xSer.ParentChart := Chart1;
    xSer.VertAxis := aRightAxis;
    xSer.LinePen.Width := 1;

    cSer := TLineSeries.Create(nil);                 // create the second Series
    cSer.Clear;
    cSer.Title       := 'Clusterkoeff.';             //'Clusterkoeffizient';
    cSer.ParentChart := Chart1;
    cSer.VertAxis := aRightAxis;
    cSer.LinePen.Width := 2; }
  end;
end;

// *****************************************************************************
// *** Ver�ndert die Position der Agenten **************************************
// *****************************************************************************
procedure TForm1.calcAgents;
var
  curAgent : TAgent;
  fromCell : TCell;
  curCell  : TCell;
  I        : Integer;
  tempPos  : TPoint;
  horizon  : Integer;
  wiggle   : Integer;
  method   : Integer;
  noise    : Integer;
begin
  horizon := TrB_thresh.Position;
  wiggle  := SB_wiggle.Position;
  noise   := round(StrToFloat(E_noise.Text));
  If rb_rulette.Checked = true Then begin method := 1; end
  else begin If rb_hill.Checked = true Then method := 2; end;
  for I := 0 to AgentList.Count - 1 do
  begin
    curAgent := AgentList.Items [I];
    checkArea (I);
    curAgent.ChangeHeading(horizon, 1, wiggle, method, noise);                // -- Richtungsspektrum und Distanz
    tempPos.X := curAgent.onCell.X + curAgent.stepX;
    tempPos.Y := curAgent.onCell.Y + curAgent.stepY;
    torus     (tempPos.X, tempPos.Y, spalt, reih);                            // -- Torus --
    curCell            := cellList[tempPos.X, tempPos.Y];
    fromCell           := cellList[curAgent.onCell.X, curAgent.onCell.Y];
    fromCell.markA     := fromCell. markA + 10;                               // -- mark all visited places
    If curAgent.Modus = 1 Then fromCell.markB := fromCell. markB + 10;        // -- mark the way home
    // --- change the agent's mode ---
    If (curCell.State = 1) And (curAgent.Modus = 1) Then
    begin
      curAgent.Modus   := 0;                                                  // -- agent is at home again
      curAgent.succeed := 1;
      inc(destiList[curAgent.DestiNr].numbers);
    end;
    If (curCell.State = 2) And (curAgent.Modus = 0) Then
    begin
      curAgent.Modus   := 1;                                                  // -- agents has found a destination an has to return home
      curAgent.DestiNr := curCell.desiNr;
    end;
    curAgent.onCell.X  := tempPos.X;
    curAgent.onCell.Y  := tempPos.Y;
    curAgent.PosX      := curAgent.onCell.X * cellScal + halfScal;            // -- Wenn Zelle frei, Agent bewegen ---
    curAgent.PosY      := curAgent.onCell.Y * cellScal + halfScal;
    end;
end;

// *** find the max and min of the mark values *********************************
procedure TForm1.findMaxMin;
var
  curCell : TCell;
  I, K    : Integer;
begin
  maxM      := 0.1;
  minM      := 999999999999999;
  for I := 0 to reih -1 do
  begin
    for K := 0 to spalt -1 do
    begin
      curCell   := cellList[K,I];
      If CB_showAB.Checked Then begin
        If curCell.markB > maxM Then maxM := curCell.markB;
        If curCell.markB < minM Then minM := curCell.markB;
      end else begin
        If curCell.markA > maxM Then maxM := curCell.markA;
        If curCell.markA < minM Then minM := curCell.markA;
      end;
    end;
  end;
end;

// *****************************************************************************
procedure TForm1.drawConns;
var
  I        : Integer;
  homePos  : TPoint;
  scale    : Real;
begin
  scale := StrToFloat(E_grav.Text);
  paintImg.Canvas.Pen.Color := clMaroon;
  paintImg.Canvas.Pen.Style := psSolid;
  homePos.X := round(spalt/2)* cellScal + halfScal;;
  homePos.Y := round(reih/2) * cellScal + halfScal;;
  for I := 0 to High(destiList) do
  begin
    IF destiList[I].numbers > 1 Then
    begin
      paintImg.Canvas.Pen.Width := round(destiList[I].numbers/steps * scale);
      paintImg.Canvas.MoveTo(destiList[I].Pos.X, destiList[I].Pos.Y);
      paintImg.Canvas.LineTo(homePos.X, homePos.Y);
    end;
  end;
end;

// *****************************************************************************
procedure TForm1.repaintCells;
var
  curCell  : TCell;
  I, K     : Integer;
  what     : Integer;
  rect     : TRect;
begin
  If CB_noTracks.checked = True Then begin
    rect.Left := 0; rect.Top := 0; rect.Right := ZeichenPanel.Width; rect.Bottom := ZeichenPanel.Height;
    paintImg.Canvas.Brush.Color := clWhite;
    paintImg.Canvas.FillRect(rect);
  end else begin
    If CB_showAB.Checked Then begin what := 1; end
    else begin what := 0; end;
    for I := 0 to reih -1 do
    begin
      for K := 0 to spalt -1 do
      begin
        curCell := cellList[K,I];
        curCell.maxM := maxM;
        curCell.minM := minM;
        curCell.Paint (paintImg.Canvas, what);
      end;
    end;
  end;
end;

// *****************************************************************************
procedure TForm1.decayMarks;
var
  curCell : TCell;
  I, K    : Integer;
  dRate   : Real;
begin
  dRate := StrToFloat(E_decay.Text);
  for I := 0 to reih -1 do
  begin
    for K := 0 to spalt -1 do
    begin
      curCell := cellList[K,I];
      curCell.markA := curCell.markA * dRate;
      curCell.markB := curCell.markB * dRate;
    end;
  end;
end;

// *****************************************************************************
procedure TForm1.repaintAllCells;
var
  curCell  : TCell;
  I, K     : Integer;
  what     : Integer;
begin
  If CB_showAB.Checked Then begin what := 1; end
  else begin what := 0; end;
  for I := 0 to reih -1 do
  begin
    for K := 0 to spalt -1 do
    begin
      curCell := cellList[K,I];
      curCell.maxM := maxM;
      curCell.minM := minM;
      curCell.rePaint (paintImg.Canvas, what);
    end;
  end;
end;

// *****************************************************************************
procedure TForm1.repaintAgents;
var
  curAgent : TAgent;
  I        : Integer;
begin
  for I := 0 to AgentList.Count - 1 do
  begin
    curAgent := AgentList.Items [I];
    curAgent.Paint (agentImg.Canvas);
  end;
end;

// *****************************************************************************
// *** look at the cells in the neigbourhood defined by the horizon-parameter **
// *****************************************************************************
procedure TForm1.checkArea (I : Integer);
var
  curCell  : TCell;
  curAgent : TAgent;
  M        : Integer;
  Angle    : Array [0..1] of Real;
  horizon  : Integer;
  neib     : TPoint;
  comper   : Real;
  wList    : Array of Double;
  wSum     : Double;
  tmP      : TPoint;
  fromTo   : Array [0..1] of Integer;
  curNr    : Integer;
  noise    : Double;
  strN     : Real;
begin
  horizon := TrB_thresh.Position;
  curAgent := AgentList.Items [I];
  Angle[0] := curAgent.Heading - horizon - 22.5;     // -- minAngle
  Angle[1] := curAgent.Heading + horizon - 22.5;     // -- maxAngle
  angelBorder (Angle[0]);
  angelBorder (Angle[1]);
  //-- find the cells to look at
  SetLength(curAgent.lookToList, 0);

  for M := 0 to 1 do
  begin
    comper   := Angle[M];
    case round(comper) of           // find start and end field (cell)
      0..45:    fromTo[M] := 1;
      46..90:   fromTo[M] := 2;
      91..135:  fromTo[M] := 3;
      136..180: fromTo[M] := 4;
      181..225: fromTo[M] := 5;
      226..270: fromTo[M] := 6;
      271..315: fromTo[M] := 7;
      316..360: fromTo[M] := 8;
    end;
  end;

  curNr := fromTo[0] -1;
  repeat
  inc(curNr);
  If curNr > 8 Then curNr := 1;
    case curNr of                   // set the direction to the cell-positions
      1: begin neib.X := 1;  neib.Y := 1;  end;
      2: begin neib.X := 0;  neib.Y := 1;  end;
      3: begin neib.X := -1; neib.Y := 1;  end;
      4: begin neib.X := -1; neib.Y := 0;  end;
      5: begin neib.X := -1; neib.Y := -1; end;
      6: begin neib.X := 0;  neib.Y := -1; end;
      7: begin neib.X := 1;  neib.Y := -1; end;
      8: begin neib.X := 1;  neib.Y := 0;  end;
    end;
    SetLength(curAgent.lookToList, length(curAgent.lookToList) + 1);
    curAgent.lookToList[High(curAgent.lookToList)] := neib;
  until curNr = fromTo[1];

  SetLength(wList, length(curAgent.lookToList));
  wSum := 0;
  curAgent.sumChem := 0;
  strN := minM+1;
  For M := 0 To High(curAgent.lookToList) Do
  begin
    noise := strN*(random()-0.5);
    tmP.X := curAgent.onCell.X + curAgent.lookToList[M].X;
    tmP.Y := curAgent.onCell.Y + curAgent.lookToList[M].Y;
    torus (tmP.X, tmP.Y, spalt, reih);
    curCell := cellList[tmP.X, tmP.Y];
    If curAgent.Modus = 0 Then           // -- exploration Mode
    begin
      curAgent.sumChem := curAgent.sumChem + curCell.markB + noise;
      wSum := wSum + curCell.markB + noise;
      wList[M] := curCell.markB + noise;
    end else If curAgent.Modus = 1 Then  // -- return Mode
    begin
      curAgent.sumChem := curAgent.sumChem + curCell.markH + noise;
      wSum := wSum + curCell.markH + noise;
      wList[M] := curCell.markH + noise;
    end;
  end;

  SetLength(curAgent.weightList, 0);
  SetLength(curAgent.weightList, length(curAgent.lookToList));
  For M := 0 To High(curAgent.lookToList) Do
  begin
    // --- write in the agent's weight list ---
    curAgent.weightList[M] := wList[M]/wSum * 100;
  end;
end;

// ---------------------------------------------------------------------------//
// ------------------------------- Schalter ----------------------------------//
// ---------------------------------------------------------------------------//
procedure TForm1.B_setupClick(Sender: TObject);
begin
  deleter;
  settings;
end;

procedure TForm1.B_stopClick(Sender: TObject);
begin
  Timer1.enabled := not(Timer1.enabled);
end;

procedure TForm1.TrB_threshChange(Sender: TObject);
begin
  Lbl_B.Caption := IntToStr(TrB_thresh.Position) + ' Grad';
end;

procedure TForm1.SB_wiggleChange(Sender: TObject);
begin
  Lbl_wiggle.Caption := IntToStr(SB_wiggle.Position) + ' Grad';
end;

procedure TForm1.B_oneStepClick(Sender: TObject);
begin
  calculate;
end;

procedure TForm1.Edit_sizeChange(Sender: TObject);
begin
  If StrToInt(Edit_size.Text) > 10 Then Edit_size.Text := '10';
  If StrToInt(Edit_size.Text) < 1  Then Edit_size.Text := '1';
end;

procedure TForm1.E_noiseChange(Sender: TObject);
begin
  If (E_noise.text = '') Then E_noise.text := '0';
end;

procedure TForm1.CB_showABClick(Sender: TObject);
begin
  findMaxMin;
  repaintAllCells;
end;

procedure TForm1.Button1Click(Sender: TObject);
begin
  findMaxMin;
  whiteAgImg;
  If CB_showAg.Checked = True Then begin
    repaintAgents;
  end;
  repaintAllCells;
end;

procedure TForm1.E_stopChange(Sender: TObject);
begin
  stopTime := StrToInt(E_stop.Text);
end;

procedure TForm1.CB_preChange(Sender: TObject);
begin
  setupMode := CB_pre.ItemIndex;
end;

procedure TForm1.CB_noTracksClick(Sender: TObject);
begin
  repaintAllCells;
end;

procedure TForm1.CB_gravityClick(Sender: TObject);
begin
  repaintAllCells;
end;

procedure TForm1.E_gravChange(Sender: TObject);
begin
  repaintAllCells;
end;

// *****************************************************************************
procedure TForm1.FormDestroy(Sender: TObject);
begin
  deleter;
  ZeichenPanel.Free;
end;

procedure TForm1.deleter;
begin
  steps := 0;
  AgentList.Free;
  paintImg.Free;
  agentImg.Free;
  SetLength(cellList, 0, 0);
  SetLength(limboWorld, 0, 0);
end;

end.

unit cell_P;

interface

uses
  Windows, Graphics, Classes, Math;

type
  TCell = class
  private
  public
    Dist       : Integer;            // -- Distance to nexgt market
    colr       : Integer;            // -- color value of the cell
    markA      : Double;             // -- mark of all Agents
    markB      : Double;             // -- mark of returning Agents
    markH      : Double;             // -- the home gradient
    desiNr     : Integer;            // -- number of the destination     
    oldMark    : Double;
    maxM       : Extended;
    minM       : Extended;
    FPos       : TPoint;
    FSize      : Integer;
    FFillColor : Integer;
    State      : Integer;            // -- Status speichert die Anzahl der Agenten auf Zelle
    procedure Paint         (Canvas: TCanvas; what: Integer);
    procedure rePaint       (Canvas: TCanvas; what: Integer);
    procedure SetPositionX  (const Value: Integer);
    procedure SetPositionY  (const Value: Integer);
    procedure SetSize       (const Value: Integer);
    procedure SetFillColor  (const Value: Integer);
    constructor create      (xPos, yPos, size, colr: Integer);
  published
    property PositionX: Integer read FPos.X     write SetPositionX;
    property PositionY: Integer read FPos.Y     write SetPositionY;
    property Size     : Integer read FSize      write SetSize;
    property FillColor: Integer read FFillColor write SetFillColor;
  end;

// ---------------------------------------------------------------------------//

implementation

constructor TCell.create(xPos, yPos, size, colr: Integer);
begin
  inherited create;
  FPos.X := xPos;
  FPos.Y := yPos;
  FSize  := size;
  FFillColor := colr;
end;

//------------------------------------------------------------------------------

procedure TCell.SetPositionX(const Value: Integer);
begin
  FPos.X := Value;
end;

procedure TCell.SetPositionY(const Value: Integer);
begin
  FPos.Y := Value;
end;

procedure TCell.SetSize(const Value: Integer);
begin
  FSize := Value;
end;

procedure TCell.SetFillColor(const Value: Integer);
begin
  FFillColor := Value;
end;

procedure TCell.Paint(Canvas: TCanvas; what: Integer);
begin
  If (abs(markA - oldMark) > 1) Then rePaint(Canvas, what);
end;

procedure TCell.rePaint(Canvas: TCanvas; what: Integer);
var
  scalF : Double;
  tmp   : Double;
  mark  : Double;
begin
  Canvas.Pen.Width := 0;
  scalF := 235 / (maxM-minM);
  If what = 0 Then begin mark := markA; end
  else If what = 1 Then begin mark := markB; end;

  tmp   := (mark - minM)* scalF;
  If mark > 0 Then tmp := tmp+20;
  //mark  :=  mark - minM;         // -- down-scale the mark values
  colr  := round(255 - tmp);
  {If colr <  0 then begin
    colr := 0;
  end;
  If colr >  255 then begin
    colr := 255;
  end; }
  case state of
  0 : begin
      Canvas.Pen.Color   := RGB (colr, colr, colr);
      Canvas.Brush.Color := RGB (colr, colr, colr);
    end;
  1 : begin
      Canvas.Pen.Color   := clblue;
      Canvas.Brush.Color := clblue;
    end;
  2 : begin
      Canvas.Pen.Color   := clgreen;
      Canvas.Brush.Color := clgreen;
    end;
  end;
  Canvas.Rectangle (FPos.X - FSize , FPos.Y - FSize, FPos.X + FSize, FPos.Y + FSize);
  oldMark := markA;
end;

end.

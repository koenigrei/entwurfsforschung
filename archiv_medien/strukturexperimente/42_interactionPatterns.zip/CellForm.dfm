object Form1: TForm1
  Left = 0
  Top = 0
  Width = 734
  Height = 734
  Caption = 'Interaction Patterns 01'
  Color = clBtnFace
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -10
  Font.Name = 'Tahoma'
  Font.Style = []
  OldCreateOrder = False
  OnCreate = FormCreate
  OnDestroy = FormDestroy
  PixelsPerInch = 96
  TextHeight = 12
  object ZeichenPanel: TPanel
    Left = 8
    Top = 9
    Width = 404
    Height = 404
    BorderStyle = bsSingle
    DockSite = True
    TabOrder = 0
  end
  object RadioGroup1: TRadioGroup
    Left = 440
    Top = 176
    Width = 257
    Height = 41
    Caption = 'sniff chemicals with'
    TabOrder = 1
  end
  object rb_rulette: TRadioButton
    Left = 448
    Top = 192
    Width = 81
    Height = 17
    Caption = 'rulette wheel'
    TabOrder = 2
  end
  object GroupBox1: TGroupBox
    Left = 440
    Top = 8
    Width = 257
    Height = 121
    Caption = 'setup settings'
    TabOrder = 3
    object Lbl_TextAnzahl: TLabel
      Left = 54
      Top = 52
      Width = 129
      Height = 12
      Caption = ': number of agents for setup'
    end
    object Label2: TLabel
      Left = 54
      Top = 76
      Width = 127
      Height = 12
      Caption = ': cell size -> number of cells '
    end
    object B_setup: TButton
      Left = 6
      Top = 16
      Width = 75
      Height = 25
      Caption = 'new Setup'
      TabOrder = 0
      OnClick = B_setupClick
    end
    object B_stop: TButton
      Left = 86
      Top = 16
      Width = 75
      Height = 25
      Caption = 'start / stop'
      TabOrder = 1
      OnClick = B_stopClick
    end
    object B_oneStep: TButton
      Left = 166
      Top = 16
      Width = 75
      Height = 25
      Caption = 'one step'
      TabOrder = 2
      OnClick = B_oneStepClick
    end
    object Edit_anzAg: TEdit
      Left = 8
      Top = 48
      Width = 41
      Height = 20
      TabOrder = 3
      Text = '800'
    end
    object Edit_size: TEdit
      Left = 8
      Top = 72
      Width = 41
      Height = 20
      TabOrder = 4
      Text = '2'
      OnChange = Edit_sizeChange
    end
    object CB_pre: TComboBox
      Left = 8
      Top = 96
      Width = 121
      Height = 20
      ItemHeight = 12
      TabOrder = 5
      Text = 'Choose SetupMode'
      OnChange = CB_preChange
    end
  end
  object rb_hill: TRadioButton
    Left = 576
    Top = 192
    Width = 81
    Height = 17
    Caption = 'hill climbing'
    Checked = True
    TabOrder = 4
    TabStop = True
  end
  object GroupBox2: TGroupBox
    Left = 440
    Top = 131
    Width = 257
    Height = 41
    Caption = 'timesteps'
    TabOrder = 5
    object lbl_Steps: TLabel
      Left = 48
      Top = 18
      Width = 39
      Height = 12
      Alignment = taCenter
      BiDiMode = bdRightToLeft
      Caption = 'lbl_Steps'
      ParentBiDiMode = False
    end
    object Label4: TLabel
      Left = 144
      Top = 18
      Width = 58
      Height = 12
      Caption = 'stop at time :'
    end
    object E_stop: TEdit
      Left = 208
      Top = 13
      Width = 41
      Height = 20
      TabOrder = 0
      Text = '10000'
      OnChange = E_stopChange
    end
  end
  object GroupBox3: TGroupBox
    Left = 440
    Top = 220
    Width = 257
    Height = 125
    Caption = 'interaction parameters'
    TabOrder = 6
    object Label1: TLabel
      Left = 8
      Top = 21
      Width = 76
      Height = 12
      Caption = 'angle threshold :'
    end
    object Lbl_B: TLabel
      Left = 90
      Top = 21
      Width = 15
      Height = 12
      Caption = '___'
    end
    object Label3: TLabel
      Left = 136
      Top = 21
      Width = 81
      Height = 12
      Caption = 'wiggle threshold :'
    end
    object Lbl_wiggle: TLabel
      Left = 218
      Top = 21
      Width = 15
      Height = 12
      Caption = '___'
    end
    object Label6: TLabel
      Left = 55
      Top = 78
      Width = 61
      Height = 12
      Caption = ': return noise'
    end
    object Label7: TLabel
      Left = 140
      Top = 102
      Width = 67
      Height = 12
      Caption = 'gravLine scale:'
    end
    object TrB_thresh: TScrollBar
      Left = 8
      Top = 40
      Width = 113
      Height = 17
      LargeChange = 5
      Max = 180
      PageSize = 0
      Position = 30
      TabOrder = 0
      OnChange = TrB_threshChange
    end
    object SB_wiggle: TScrollBar
      Left = 136
      Top = 40
      Width = 113
      Height = 17
      LargeChange = 5
      Max = 180
      PageSize = 0
      Position = 20
      TabOrder = 1
      OnChange = SB_wiggleChange
    end
    object E_noise: TEdit
      Left = 8
      Top = 74
      Width = 41
      Height = 20
      TabOrder = 2
      Text = '30'
      OnChange = E_noiseChange
    end
    object Button1: TButton
      Left = 174
      Top = 64
      Width = 75
      Height = 25
      Caption = 'repaint all'
      TabOrder = 3
      OnClick = Button1Click
    end
    object E_decay: TEdit
      Left = 8
      Top = 98
      Width = 41
      Height = 20
      TabOrder = 4
      Text = '0,95'
    end
    object E_grav: TEdit
      Left = 208
      Top = 98
      Width = 41
      Height = 20
      TabOrder = 5
      Text = '5'
      OnChange = E_gravChange
    end
    object CB_decay: TCheckBox
      Left = 55
      Top = 100
      Width = 81
      Height = 17
      Caption = ':decay rate'
      TabOrder = 6
    end
  end
  object Chart1: TChart
    Left = 8
    Top = 416
    Width = 713
    Height = 281
    BackWall.Brush.Color = clWhite
    BackWall.Brush.Style = bsClear
    Title.Text.Strings = (
      'TChart')
    RightAxis.Automatic = False
    RightAxis.AutomaticMaximum = False
    RightAxis.AutomaticMinimum = False
    RightAxis.Maximum = 101.000000000000000000
    View3D = False
    TabOrder = 7
    object Series1: TLineSeries
      Marks.ArrowLength = 8
      Marks.Visible = False
      SeriesColor = clRed
      Pointer.InflateMargins = True
      Pointer.Style = psRectangle
      Pointer.Visible = False
      XValues.DateTime = False
      XValues.Name = 'X'
      XValues.Multiplier = 1.000000000000000000
      XValues.Order = loAscending
      YValues.DateTime = False
      YValues.Name = 'Y'
      YValues.Multiplier = 1.000000000000000000
      YValues.Order = loNone
    end
  end
  object GroupBox4: TGroupBox
    Left = 440
    Top = 352
    Width = 257
    Height = 57
    Caption = 'graphic'
    TabOrder = 8
    object CB_noTracks: TCheckBox
      Left = 8
      Top = 32
      Width = 81
      Height = 17
      Caption = 'no tracks'
      TabOrder = 0
      OnClick = CB_noTracksClick
    end
    object CB_gravity: TCheckBox
      Left = 120
      Top = 32
      Width = 129
      Height = 17
      Caption = 'show gravity linies'
      TabOrder = 1
      OnClick = CB_gravityClick
    end
    object CB_showAB: TCheckBox
      Left = 120
      Top = 16
      Width = 129
      Height = 17
      Caption = 'show only return tracks'
      Checked = True
      State = cbChecked
      TabOrder = 2
      OnClick = CB_showABClick
    end
    object CB_showAg: TCheckBox
      Left = 8
      Top = 16
      Width = 81
      Height = 17
      Caption = 'show agents'
      Checked = True
      State = cbChecked
      TabOrder = 3
    end
  end
  object Timer1: TTimer
    Interval = 1
    OnTimer = Timer1Timer
    Left = 704
    Top = 16
  end
end

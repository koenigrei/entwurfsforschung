unit agenten;

interface

uses
  Windows, Graphics, Math, Classes, calcer;

type
  TAgent = class
  public
    onCell     : TPoint;
    Home       : TPoint;
    Modus      : Integer;
    DestiNr    : Integer;                           // -- number of the found destination
    succeed    : Integer;                           // -- true, if found at least once a destination
    Farbe      : Integer;
    FPosX      : Integer;
    FPosY      : Integer;
    FSize      : Integer;
    FHeading   : Integer;                           // -- Anfangsausrichtung
    FStepX     : Integer;
    FStepY     : Integer;
    lookToList : Array of TPoint;
    weightList : Array of Real;
    sumChem    : Double;
    procedure Paint       (Canvas: TCanvas);
    procedure SetPosX     (const Value: Integer);
    procedure SetPosY     (const Value: Integer);
    procedure SetStepX    (const Value: Integer);
    procedure SetStepY    (const Value: Integer);
    procedure SetHeading  (const Value: Integer);
    procedure SetSize     (const Value: Integer);
  published
    property PosX    : Integer read FPosX    write SetPosX;
    property PosY    : Integer read FPosY    write SetPosY;
    property StepX   : Integer read FStepX   write SetStepX;
    property StepY   : Integer read FStepY   write SetStepY;
    property Heading : Integer read FHeading write SetHeading;
    property Size    : Integer read FSize    write SetSize;
    procedure ChangeHeading(const degree: Integer; const dist: Integer; wiggle: Integer;
                            method: Integer; noiseV: Integer); // -- Maximale Richtungs�nderung angeben
    procedure rouletteWheel(wiggle: Integer);
    procedure hillClimbing(wiggle: Integer);
    procedure randomWalk(wiggle: Integer; degree: Integer);
  end;

implementation

// *****************************************************************************
procedure TAgent.SetHeading(const Value: Integer);
begin
  FHeading := Value;
end;

procedure TAgent.ChangeHeading(const degree: Integer; const dist: Integer; wiggle: Integer;
                               method: Integer; noiseV: Integer);
var
  dX, dY : Integer;
  co, si : Extended;
  radD   : Double;
  noiseRe: Integer;
begin
  If Modus = 1 Then             // -- returning mode
  begin
    //hillClimbing(10)
    co := 0;
    si := 0;
    dX := Home.X - onCell.X;
    dY := Home.Y - onCell.Y;
    FHeading := round((arcTan2(dY, dX)) *RadToDeg);
    noiseRe  := random(noiseV+1)* (random(2)*2 -1);
    FHeading := FHeading + noiseRe;
    radD := Heading * DegToRad;
    SinCos(radD, si, co);       // -- SinCos is twice as fast as calling Sin and Cos separately for the same angle
    dX := round(co);
    dy := round(si);
    SetStepX(dX);
    SetStepY(dY);
  end else

  If Modus = 0 Then begin
  If sumChem > 0 Then           // -- threshold of chemicals in the neighbuerhood
  begin
    If method = 1 Then          // -- choose one neighbor-cell via roulette wheel
    begin
      rouletteWheel(wiggle);
    end else
    If method = 2 Then          // -- choose one neighbor-cell via hill climbing
    begin
      hillClimbing(wiggle);
    end;
  end else begin                // -- random walk, if there are no chemicals in the neigbourhood
    randomWalk(wiggle, degree);
  end;
  end;

  angelBorder (FHeading);
end;

procedure TAgent.rouletteWheel(wiggle: Integer);
var
  dX, dY : Integer;
  M      : Integer;
  rnd    : Extended;
  sum    : Extended;
  temp   : Integer;
begin
  rnd := random (100);
  sum := 0;
  M := 0;
  repeat
    sum := sum + weightList[M];
    dX := lookToList[M].X;
    dY := lookToList[M].Y;
    M := M +1;
  until sum >= rnd;
  FHeading := round((arcTan2(dY, dX)) *RadToDeg);
  temp := random(wiggle+1)* (random(2)*2 -1);
  FHeading := FHeading + temp;
  SetStepX(dX);
  SetStepY(dY);
end;

procedure TAgent.hillClimbing(wiggle: Integer);
var
  dX, dY : Integer;
  M      : Integer;
  temp   : Integer;
  max    : Real;
begin
  max := 0;
  For M := 0 To High(weightList) Do
  begin
    If weightList[M] > max Then
    begin
      max := weightList[M];
      dX := lookToList[M].X;
      dY := lookToList[M].Y;
    end;
  end;
  FHeading := round((arcTan2(dY, dX)) *RadToDeg);
  temp := random(wiggle+1)* (random(2)*2 -1);
  FHeading := FHeading + temp;
  SetStepX(dX);
  SetStepY(dY);
end;

procedure TAgent.randomWalk(wiggle: Integer; degree: Integer);
var
  dX, dY : Integer;
  M      : Integer;
  temp   : Integer;
  co, si : Extended;
  radD   : Double;
begin
  co := 0;
  si := 0;
  temp := 0;
  temp := random(degree+1)* (random(2)*2 -1);
  FHeading := FHeading + temp;
  radD := Heading * DegToRad;
  SinCos(radD, si, co);                               // -- SinCos is twice as fast as calling Sin and Cos separately for the same angle
  dX := round(co);
  dy := round(si);
  SetStepX(dX);
  SetStepY(dY);
end;

// *****************************************************************************
procedure TAgent.SetStepX(const Value: Integer);
begin
  FStepX := Value;
end;

// *****************************************************************************
procedure TAgent.SetStepY(const Value: Integer);
begin
  FStepY := Value;
end;

// *****************************************************************************
procedure TAgent.SetPosX(const Value: Integer);
begin
  FPosX := Value;
end;

// *****************************************************************************
procedure TAgent.SetPosY(const Value: Integer);
begin
  FPosY := Value;
end;

// *****************************************************************************
procedure TAgent.SetSize(const Value: Integer);
begin
  FSize := Value;
end;

// *****************************************************************************
procedure TAgent.Paint (Canvas: TCanvas);
var
  dX : Integer;
  dY : Integer;
  radD : Double;
  temp : Double;
  temp2 : Integer;
  co, si : Extended;
  lang : Integer;
begin
  Canvas.Pen.Width := 1;
  case Modus of
    0 : begin
        Canvas.Pen.Color   := clgray;
        Canvas.Brush.Color := clred;
      end;
    1 : begin
        Canvas.Pen.Color   := clgray;
        Canvas.Brush.Color := cllime;
      end;
    end;
  Canvas.Ellipse (FPosX - FSize , FPosY - (FSize), FPosX + (FSize), FPosY + (FSize));

  lang := 6;
  Canvas.Pen.Color := clgreen;
  Canvas.MoveTo(FPosX,  FPosY);
  radD := Heading * DegToRad;
  SinCos(radD, si, co);
  dX := round(co)*lang;
  dy := round(si)*lang;
  Canvas.LineTo(FPosX+dX, FPosY+dy);
end;

end.

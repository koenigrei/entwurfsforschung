object Form1: TForm1
  Left = 0
  Top = 0
  Width = 800
  Height = 512
  Caption = 'CA-Crystal Growth'
  Color = clBtnFace
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -10
  Font.Name = 'Tahoma'
  Font.Style = []
  OldCreateOrder = False
  OnCreate = FormCreate
  OnDestroy = FormDestroy
  PixelsPerInch = 96
  TextHeight = 12
  object lbl_Steps: TLabel
    Left = 670
    Top = 108
    Width = 39
    Height = 12
    Caption = 'lbl_Steps'
  end
  object lbl_timesteps: TLabel
    Left = 613
    Top = 108
    Width = 50
    Height = 12
    Alignment = taRightJustify
    Caption = 'Timesteps :'
  end
  object Lbl_Sphere: TLabel
    Left = 464
    Top = 76
    Width = 63
    Height = 12
    Alignment = taRightJustify
    Caption = 'interface size :'
  end
  object Lbl_statProb: TLabel
    Left = 418
    Top = 52
    Width = 109
    Height = 12
    Caption = 'undercooling threshold:'
  end
  object Lbl_death: TLabel
    Left = 613
    Top = 52
    Width = 50
    Height = 12
    Caption = 'die at age :'
  end
  object Label1: TLabel
    Left = 451
    Top = 100
    Width = 76
    Height = 12
    Alignment = taRightJustify
    Caption = 'noise amplitude :'
  end
  object Label2: TLabel
    Left = 299
    Top = 428
    Width = 68
    Height = 12
    Alignment = taRightJustify
    Caption = 'iteration steps :'
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clNone
    Font.Height = -10
    Font.Name = 'Tahoma'
    Font.Style = []
    ParentFont = False
  end
  object Label3: TLabel
    Left = 611
    Top = 76
    Width = 52
    Height = 12
    Caption = 'pot. multi. :'
  end
  object Label4: TLabel
    Left = 148
    Top = 428
    Width = 75
    Height = 12
    Alignment = taRightJustify
    Caption = 'interface const. :'
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clNone
    Font.Height = -10
    Font.Name = 'Tahoma'
    Font.Style = []
    ParentFont = False
  end
  object Label5: TLabel
    Left = 12
    Top = 428
    Width = 75
    Height = 12
    Alignment = taRightJustify
    Caption = 'diffusion const. :'
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clNone
    Font.Height = -10
    Font.Name = 'Tahoma'
    Font.Style = []
    ParentFont = False
  end
  object ZeichenPanel: TPanel
    Left = 8
    Top = 9
    Width = 404
    Height = 404
    BorderStyle = bsSingle
    DockSite = True
    TabOrder = 0
  end
  object B_setup: TButton
    Left = 526
    Top = 8
    Width = 75
    Height = 25
    Caption = 'new Setup'
    TabOrder = 1
    OnClick = B_setupClick
  end
  object B_stop: TButton
    Left = 444
    Top = 8
    Width = 75
    Height = 25
    Caption = 'start / stop'
    TabOrder = 2
    OnClick = B_stopClick
  end
  object RChart1: TRChart
    Left = 416
    Top = 144
    Width = 369
    Height = 320
    AllocSize = 1000
    AutoRedraw = True
    RRim = 20
    TRim = 20
    BRim = 40
    BackGroundImg.IncludePath = False
    BackGroundImg.FillMode = bfStretch
    ClassDefault = 0
    GridStyle = gsNone
    Isometric = False
    JointLayers.L01xControlledBy = 1
    JointLayers.L01yControlledBy = 1
    JointLayers.L02xControlledBy = 2
    JointLayers.L02yControlledBy = 2
    Caption = 'entire potential'
    CaptionPosX = 0
    CaptionPosY = -16
    CaptionAlignment = taRightJustify
    CaptionAnchorHoriz = cahChartRight
    CaptionAnchorVert = cavChartTop
    CrossHair1.Color = clBlack
    CrossHair1.Layer = 1
    CrossHair1.Mode = chOff
    CrossHair1.LineType = psSolid
    CrossHair1.LineWid = 1
    CrossHair2.Color = clBlack
    CrossHair2.Layer = 2
    CrossHair2.Mode = chOff
    CrossHair2.LineType = psSolid
    CrossHair2.LineWid = 1
    CrossHair3.Color = clBlack
    CrossHair3.Layer = 3
    CrossHair3.Mode = chOff
    CrossHair3.LineType = psSolid
    CrossHair3.LineWid = 1
    CrossHair4.Color = clBlack
    CrossHair4.Layer = 4
    CrossHair4.Mode = chOff
    CrossHair4.LineType = psSolid
    CrossHair4.LineWid = 1
    MouseAction = maNone
    MouseCursorFixed = True
    Scale1X.CaptionPosX = 0
    Scale1X.CaptionPosY = 22
    Scale1X.CaptionAlignment = taCenter
    Scale1X.CaptionAnchor = uaSclCenter
    Scale1X.ColorScale = clBlack
    Scale1X.DateFormat.TimeFormat = tfHHMMSS
    Scale1X.DateFormat.DateSeparator = '-'
    Scale1X.DateFormat.TimeSeparator = ':'
    Scale1X.DateFormat.YearLength = ylYYYY
    Scale1X.DateFormat.MonthName = True
    Scale1X.DateFormat.DateOrder = doDDMMYY
    Scale1X.DateFormat.DateForTime = dtOnePerDay
    Scale1X.DecPlaces = -2
    Scale1X.Font.Charset = DEFAULT_CHARSET
    Scale1X.Font.Color = clWindowText
    Scale1X.Font.Height = -11
    Scale1X.Font.Name = 'Tahoma'
    Scale1X.Font.Style = []
    Scale1X.Logarithmic = False
    Scale1X.LabelType = ftNum
    Scale1X.MinTicks = 3
    Scale1X.MinRange = 0.000000000100000000
    Scale1X.RangeHigh = 1.000000000000000000
    Scale1X.ShortTicks = True
    Scale1X.ScalePos = 0
    Scale1X.Visible = True
    Scale1X.ScaleLocation = slBottom
    Scale1Y.CaptionPosX = 0
    Scale1Y.CaptionPosY = -16
    Scale1Y.CaptionAlignment = taLeftJustify
    Scale1Y.CaptionAnchor = uaSclTopLft
    Scale1Y.ColorScale = clBlack
    Scale1Y.DateFormat.TimeFormat = tfHHMMSS
    Scale1Y.DateFormat.DateSeparator = '-'
    Scale1Y.DateFormat.TimeSeparator = ':'
    Scale1Y.DateFormat.YearLength = ylYYYY
    Scale1Y.DateFormat.MonthName = True
    Scale1Y.DateFormat.DateOrder = doDDMMYY
    Scale1Y.DateFormat.DateForTime = dtOnePerDay
    Scale1Y.DecPlaces = -2
    Scale1Y.Font.Charset = DEFAULT_CHARSET
    Scale1Y.Font.Color = clWindowText
    Scale1Y.Font.Height = -11
    Scale1Y.Font.Name = 'Tahoma'
    Scale1Y.Font.Style = []
    Scale1Y.Logarithmic = False
    Scale1Y.LabelType = ftNum
    Scale1Y.MinTicks = 3
    Scale1Y.MinRange = 0.000000000100000000
    Scale1Y.RangeHigh = 1.000000000000000000
    Scale1Y.ShortTicks = True
    Scale1Y.ScalePos = 0
    Scale1Y.Visible = True
    Scale1Y.ScaleLocation = slLeft
    Scale2X.CaptionPosX = 10
    Scale2X.CaptionPosY = 100
    Scale2X.CaptionAlignment = taCenter
    Scale2X.CaptionAnchor = uaSclCenter
    Scale2X.ColorScale = clMaroon
    Scale2X.DateFormat.TimeFormat = tfHHMMSS
    Scale2X.DateFormat.DateSeparator = '-'
    Scale2X.DateFormat.TimeSeparator = ':'
    Scale2X.DateFormat.YearLength = ylYYYY
    Scale2X.DateFormat.MonthName = True
    Scale2X.DateFormat.DateOrder = doDDMMYY
    Scale2X.DateFormat.DateForTime = dtOnePerDay
    Scale2X.DecPlaces = -2
    Scale2X.Font.Charset = DEFAULT_CHARSET
    Scale2X.Font.Color = clWindowText
    Scale2X.Font.Height = -11
    Scale2X.Font.Name = 'Tahoma'
    Scale2X.Font.Style = []
    Scale2X.Logarithmic = False
    Scale2X.LabelType = ftNum
    Scale2X.MinTicks = 3
    Scale2X.MinRange = 0.000000000100000000
    Scale2X.RangeHigh = 1.000000000000000000
    Scale2X.ShortTicks = True
    Scale2X.ScalePos = 0
    Scale2X.Visible = False
    Scale2X.ScaleLocation = slBottom
    Scale2Y.CaptionPosX = 10
    Scale2Y.CaptionPosY = 100
    Scale2Y.CaptionAlignment = taRightJustify
    Scale2Y.CaptionAnchor = uaSclTopLft
    Scale2Y.ColorScale = clMaroon
    Scale2Y.DateFormat.TimeFormat = tfHHMMSS
    Scale2Y.DateFormat.DateSeparator = '-'
    Scale2Y.DateFormat.TimeSeparator = ':'
    Scale2Y.DateFormat.YearLength = ylYYYY
    Scale2Y.DateFormat.MonthName = True
    Scale2Y.DateFormat.DateOrder = doDDMMYY
    Scale2Y.DateFormat.DateForTime = dtOnePerDay
    Scale2Y.DecPlaces = -2
    Scale2Y.Font.Charset = DEFAULT_CHARSET
    Scale2Y.Font.Color = clWindowText
    Scale2Y.Font.Height = -11
    Scale2Y.Font.Name = 'Tahoma'
    Scale2Y.Font.Style = []
    Scale2Y.Logarithmic = False
    Scale2Y.LabelType = ftNum
    Scale2Y.MinTicks = 3
    Scale2Y.MinRange = 0.000000000100000000
    Scale2Y.RangeHigh = 1.000000000000000000
    Scale2Y.ShortTicks = True
    Scale2Y.ScalePos = 0
    Scale2Y.Visible = False
    Scale2Y.ScaleLocation = slLeft
    ShadowStyle = ssFlying
    ShadowColor = clGrayText
    ShadowBakColor = clBtnFace
    TextFontStyle = []
    TextBkStyle = tbClear
    TextBkColor = clWhite
    TextAlignment = taCenter
  end
  object E_interf: TEdit
    Left = 534
    Top = 72
    Width = 43
    Height = 20
    TabOrder = 4
    Text = '0,02'
  end
  object E_thresh: TEdit
    Left = 534
    Top = 48
    Width = 43
    Height = 20
    TabOrder = 5
    Text = '0,09'
  end
  object Cb_aging: TCheckBox
    Left = 624
    Top = 0
    Width = 89
    Height = 17
    Caption = 'activate aging'
    TabOrder = 6
  end
  object E_death: TEdit
    Left = 670
    Top = 48
    Width = 35
    Height = 20
    TabOrder = 7
    Text = '500'
  end
  object E_noise: TEdit
    Left = 534
    Top = 96
    Width = 43
    Height = 20
    TabOrder = 8
    Text = '0,4'
  end
  object E_iterate: TEdit
    Left = 374
    Top = 424
    Width = 35
    Height = 20
    TabOrder = 9
    Text = '5'
  end
  object E_multi: TEdit
    Left = 670
    Top = 72
    Width = 35
    Height = 20
    TabOrder = 10
    Text = '2'
    OnChange = E_multiChange
  end
  object E_interEff: TEdit
    Left = 230
    Top = 424
    Width = 43
    Height = 20
    TabOrder = 11
    Text = '1,5'
  end
  object E_diffEff: TEdit
    Left = 94
    Top = 424
    Width = 35
    Height = 20
    TabOrder = 12
    Text = '1,0'
  end
  object Cb_rand: TCheckBox
    Left = 624
    Top = 16
    Width = 89
    Height = 17
    Caption = 'random seed'
    TabOrder = 13
  end
  object Cb_Field: TCheckBox
    Left = 712
    Top = 72
    Width = 73
    Height = 17
    Caption = 'just the field'
    TabOrder = 14
    OnClick = Cb_FieldClick
  end
  object Timer1: TTimer
    Interval = 1
    OnTimer = Timer1Timer
    Left = 760
    Top = 16
  end
end

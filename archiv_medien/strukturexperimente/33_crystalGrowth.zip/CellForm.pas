(********************************************************************)
(*                                                                  *)
(*                                                                  *)
(*                         Crystal Growth                           *)
(*                    Growth with Diffusion Field                   *)
(*                           Version 1.0                            *)
(*                                                                  *)
(*                                                                  *)
(*     Programmierer: Reinhard K�nig                     March 2006 *)
(*                    http://www.entwurfsforschung.de               *)
(*                                                                  *)
(*     Last Update: Mar-11, 2006                                    *)
(*                                                                  *)
(********************************************************************) 
{revision history:

1.0     [Mar-11, 2006]
        first release to the public
}

unit CellForm;

interface

uses
  Windows, Messages, SysUtils, Variants, Classes, Graphics, Controls, Forms,
  Dialogs, StdCtrls, cell_P, ExtCtrls, ButtonGroup, ComCtrls, Math, ToolWin,
  ImgList, Epina.SDL.rchart;

type
  TForm1 = class(TForm)
    ZeichenPanel   : TPanel;
    Timer1         : TTimer;
    lbl_Steps      : TLabel;
    B_setup        : TButton;
    lbl_timesteps  : TLabel;
    B_stop         : TButton;
    RChart1        : TRChart;
    Lbl_Sphere     : TLabel;
    E_interf       : TEdit;
    Lbl_statProb   : TLabel;
    E_thresh: TEdit;
    Cb_aging       : TCheckBox;
    Lbl_death      : TLabel;
    E_death        : TEdit;
    Label1         : TLabel;
    E_noise        : TEdit;
    Label2         : TLabel;
    E_iterate      : TEdit;
    Label3         : TLabel;
    E_multi        : TEdit;
    Label4         : TLabel;
    E_interEff     : TEdit;
    Label5         : TLabel;
    E_diffEff      : TEdit;
    Cb_rand        : TCheckBox;
    Cb_Field: TCheckBox;
    procedure E_multiChange(Sender: TObject);
    procedure Cb_FieldClick(Sender: TObject);
    procedure B_stopClick   (Sender: TObject);
    procedure B_setupClick  (Sender: TObject);
    procedure Timer1Timer   (Sender: TObject);
    procedure FormDestroy   (Sender: TObject);
    procedure FormCreate    (Sender: TObject);
  private
    AgentList  : TList;
    cellList   : Array of Array of TCell;
    limboWorld : Array of Array of Integer;
    limboPot   : Array of Array of Extended;
    function  CalcDistance  (pAX: Integer; pAY: Integer; pBX: Integer; pBY: Integer): Integer;
    function  rndN          (lower: Integer; upper: Integer):Integer;
    procedure checkNei      (K, I: Integer; var sumState : Extended; var nrD: Integer);
    procedure checkPot      (K, I: Integer);
    procedure plot          (stateSum: Integer; potSum: Integer);
    procedure createPaintImg;
    procedure createRaster;
    procedure setupCells;
    procedure ageCheck;
    procedure equiPot;
    procedure dev_Cell;
    procedure paint_Field;
  public
end;

var
  Form1    : TForm1;
  paintImg : TImage;

implementation

{$R *.dfm}

const                            //-- globale Konstanten
  cellScal = 4;                  //-- Zellen  gr��e
  AgSize   = 1;                  //-- Agenten gr��e
  halfScal = round(cellScal/2);

var                              //-- globale Variablen
  reih    : Integer;             //-- Zellen-Reihen gesamt
  spalt   : Integer;             //-- Zellen-Spalten gesamt
  steps   : Integer;
  Xmax    : Integer;
  Ymax    : Integer;
  cellSum : Integer;
  OldY1   : Integer;              //-- Speichert die Position t-1 f�r Graphen
  OldY2   : Integer;
  OldY3   : Integer;
  rSize   : Integer;
  repi    : Integer;
  diffEff : Real;                 //-- size of the diffusion effect
  interEff: Real;                 //-- scaling parameter for the interface effect
  colSize : Real;

// ---------------------------------------------------------------------------//
// *** Initialisierung ***
procedure TForm1.FormCreate(Sender: TObject);
begin
  spalt     := round (ZeichenPanel.Width / cellScal);
  reih      := round (ZeichenPanel.Height / cellScal);
  Xmax      := (spalt) * cellScal;
  Ymax      := (reih ) * cellScal;
  steps     := 0;
  repi      := StrToInt(E_iterate.Text) -1;
  diffEff   := StrToFloat(E_diffEff.Text);
  interEff  := StrToFloat(E_interEff.Text);
  AgentList := TList.Create;
  SetLength(cellList, spalt, reih);
  SetLength(limboPot, spalt, reih);
  SetLength(limboWorld, spalt, reih);
  createPaintImg;
  CreateRaster;
  ZeichenPanel.DoubleBuffered := True;       //-- Verhindert Flackern der Zellen

  // -- Diagramm initialisieren --
  RChart1.Scale1X.RangeLow  := 0;    //-- range of chart area
  RChart1.Scale1X.RangeHigh := StrToInt(E_death.Text);  //-- Maximale Reichweite = 1000 bei Testversion!!!
  RChart1.Scale1Y.RangeLow  := 0;    //0.45;
  RChart1.Scale1Y.RangeHigh := 3000; //0.55;
  RChart1.ShowGraf;
end;

// ---------------------------------------------------------------------------//
// ------------------------- Elemente erstellen ------------------------------//
// ---------------------------------------------------------------------------//

// *** Legt eine leere Zeichenfl�che �ber das Zeichenpanel *********************
procedure TForm1.createPaintImg;
begin
  paintImg        := TImage.Create(self);
  paintImg.Parent := ZeichenPanel;
  paintImg.top    := 0;
  paintImg.Left   := 0;
  paintImg.Height := ZeichenPanel.Height;
  paintImg.Width  := ZeichenPanel.Width;
end;

// *** Zellen erstellen ***
procedure TForm1.CreateRaster;
var
  curCell : TCell;
  I       : Integer;
  K       : Integer;
  upperB  : Integer;
  lowerB  : Integer;
begin
  for I := 0 to reih -1 do
  begin
    for K := 0 to spalt -1 do
    begin
      curCell := TCell.Create(halfScal + K * cellScal, halfScal + I * cellScal, halfScal, 0);
      cellList[K,I] := curCell;
    end;
  end;
  setupCells;
end;

// *** Zellen initialisieren ***************************************************
procedure TForm1.setupCells;
var
  curCell : TCell;
  I       : Integer;
  K       : Integer;
begin
  OldY1   := 0; // -- Ausgangswert t=0 f�r Graphen
  OldY2   := 0;
  OldY3   := 0;
  cellSum := spalt * reih;
  Randomize();
  // -- setup --
  for I := 0 to reih -1 do
  begin
    for K := 0 to spalt -1 do
    begin
      curCell          := cellList[K,I];
      curCell.State    := 0;               // -- set D(0) = 0;
      curCell.Pot      := 0;               // -- set P(0) = 0;
      limboWorld[K, I] := 0;
      curCell.probab   := 0.5;
      curCell.colr     := curCell.State * 255;
      curCell.birth    := 0;
      curCell.dist     := 0;
      curCell.dist     := CalcDistance(curCell.FPos.X, curCell.FPos.Y, cellList[50,50].FPos.X, cellList[50,50].FPos.Y);
      curCell.Paint(paintImg.Canvas);
    end;
  end;

  If Cb_rand.Checked = true Then
  begin
    For I:= 0 To 3 Do                                    //  -- four random seeds
    begin
      curCell := cellList[random(spalt),random(reih)];
      curCell.State := 1;
      curCell.Pot   := 1;
      curCell.colr  := curCell.State * 255;
      curCell.Paint(paintImg.Canvas);
    end;
  end else begin
    curCell := cellList[round(spalt/2),round(reih/2)];
    curCell.State := 1;                                  //  -- one seed
    curCell.Pot   := 1;
    curCell.colr  := curCell.State * 255;
    curCell.Paint(paintImg.Canvas);
  end;
  // --- initialize chart ---
  RChart1.ClearGraf;
  RChart1.MoveTo (0,0);
  RChart1.Scale1X.RangeHigh := StrToInt(E_death.Text);
end;


// ---------------------------------------------------------------------------//
// ---------------------------- Calculations ---------------------------------//
// ---------------------------------------------------------------------------//

// *** Rekursive Prozeduren ausf�hren ******************************************
procedure TForm1.Timer1Timer(Sender: TObject);
var
  curCell  : TCell;
  K, I, M  : Integer;
begin
  ageCheck;        // -- check the age of the cells --

  for I:= 0 to repi - 1 do
  begin
    equiPot;       // -- bring the potential field to "equilibrium"
  end;

  paint_Field;     // -- count and paint the cells ---

  dev_Cell;        // -- develop cells

  steps := steps +1;                              // -- increase steps
  lbl_Steps.Caption := intToStr (steps);

  If steps = 999 Then begin                       // -- stop condition
    Timer1.enabled := false;                      // -- stop automata
  end;
end;

// *** check age or the developed cell *****************************************
procedure TForm1.ageCheck;
var
  curCell : TCell;
  K, I    : Integer;
  death   : Integer;
begin
  death  := StrToInt(E_death.Text);
  for I  := 0 to reih -1 do
  begin
    for K := 0 to spalt -1 do
    begin
      curCell := cellList[K,I];
      If Cb_aging.State = cbChecked Then
      begin
        curCell.age := (steps - curCell.birth);    // -- increase age every step
        If curCell.age > death Then begin          // -- Cell dies on overaging
          curCell.age    := 0;
          curCell.pot    := 0;
          curCell.state  := 0;
        end;
      end;
    end;
  end;
end;

// *** Check Moore-Neigborhood for state and potential *************************
procedure TForm1.checkPot (K, I: Integer);
var
  curCell  : TCell;
  u,v      : Integer;
  Xp, Yp   : Integer;koNei    : Array [0..7] of TPoint;
begin
  limboPot[K,I] := 0;
  // --- orthogonal nearest neigbors ---
  koNei[0].X := K;    koNei[0].Y := I + 1;
  koNei[1].X := K;    koNei[1].Y := I - 1;
  koNei[2].X := K+1;  koNei[2].Y := I;
  koNei[3].X := K-1;  koNei[3].Y := I;
  // --- diagonal next nearest neigbors ---
  koNei[4].X := K+1;  koNei[4].Y := I + 1;
  koNei[5].X := K+1;  koNei[5].Y := I - 1;
  koNei[6].X := K-1;  koNei[6].Y := I - 1;
  koNei[7].X := K-1;  koNei[7].Y := I + 1;
  for v := 0 to 3 do
  begin
    Xp := koNei[v].X;
    Yp := koNei[v].Y;
    // -- Torus --
    if Xp < 0       then Xp := spalt-1;
    if Xp > spalt-1 then Xp := 0;
    if Yp < 0       then Yp := reih-1;
    if Yp > reih-1  then Yp := 0;
    If Not ((Xp = K) and (Yp = I)) Then begin
      limboPot[K,I] := limboPot[K,I] + (1/6) *(cellList[Xp, Yp].Pot - cellList[K, I].Pot);
    end;
  end;
  for v := 4 to 7 do
  begin
    Xp := koNei[v].X;
    Yp := koNei[v].Y;
    // -- Torus --
    if Xp < 0       then Xp := spalt-1;
    if Xp > spalt-1 then Xp := 0;
    if Yp < 0       then Yp := reih-1;
    if Yp > reih-1  then Yp := 0;
    If Not ((Xp = K) and (Yp = I)) Then begin
      limboPot[K,I] := limboPot[K,I] + (1/12) *(cellList[Xp, Yp].Pot - cellList[K, I].Pot);
    end;
  end;
end;

// *** calculate the potential field *******************************************
procedure TForm1.equiPot;
var
  K, I, M  : Integer;
begin
  for I := 0 to reih -1 do
  begin
    for K := 0 to spalt -1 do
    begin
      checkPot(K, I);                // -- set limboPot
    end;
  end;                               // -- limboPot to aktual pot-value
  for I := 0 to reih -1 do
  begin
    for K := 0 to spalt -1 do
    begin
       cellList[K,I].Pot := cellList[K,I].Pot + (diffEff/repi*(limboPot[K, I]));
    end;
  end;
end;

// *** find the cell for development *******************************************
procedure TForm1.dev_Cell;
var
  curCell  : TCell;
  K, I     : Integer;
  temp     : Extended;
  sumState : Extended;
  nrD      : Integer;
  amplit   : Real;
  Ut       : Real;
  interF   : Real;
begin
  Ut     := StrToFloat(E_thresh.Text);
  interF := StrToFloat(E_interf.Text);
  amplit := StrToFloat(E_noise.Text);
  Randomize;
  for I := 0 to reih -1 do
  begin
    for K := 0 to spalt -1 do
    begin
      curCell := cellList[K,I];
      checkNei(K, I, sumState, nrD);
      // --- aggregating tests ----------------------
      If (sumState > 0) and (curCell.state = 0) then
      begin
        temp := 0;
        temp := Ut *(1+ (amplit * (random()*2-1))) + interF*(sumState - nrD * interEff);
        // -- develop the cell
        If (curCell.Pot <= temp) and (sumState > 0)Then
        begin
          // -- settings for the developed cell --
          limboWorld[K,I] := 1;
        end;
      end;
    end;
  end;

  for I := 0 to reih -1 do
  begin
    for K := 0 to spalt -1 do
    begin
      curCell := cellList[K,I];
      If limboWorld[K,I] = 1 then
      begin
        curCell.state := 1;
        curCell.Pot     := curCell.Pot +1;
        curCell.birth   := steps;                 // -- save the birthtime of development
        curCell.age     := 0;
        limboWorld[K,I] := 0;
      end;
    end;
  end;
end;

// *** paint it all ************************************************************
procedure TForm1.paint_Field;
var
  curCell  : TCell;
  K, I     : Integer;
  potSum   : Extended;
  stateSum : Integer;
begin
  stateSum := 0; // -- sum-Value of all states
  potSum := 0;
  colSize  := StrToFloat(E_multi.Text);
  If Cb_Field.Checked = true Then
  begin                               // -- show just the potential field
    for I := 0 to reih -1 do
    begin
      for K := 0 to spalt -1 do
      begin
        curCell     := cellList[K,I];
        If curCell.state > 0 Then stateSum := stateSum + 1;  // -- count cells
        potSum := potSum + curCell.Pot;
        curCell.colr  := round(255 * colSize * curCell.Pot);         // -- the potential field
        curCell.Paint (paintImg.Canvas);
      end;
    end;
  end else begin                      // -- show the developed cellc with the surrounding potential field
    for I := 0 to reih -1 do
    begin
      for K := 0 to spalt -1 do
      begin
        curCell     := cellList[K,I];
        If curCell.state > 0 Then stateSum := stateSum + 1;  // -- count cells
        potSum := potSum + curCell.Pot;
        If curCell.State = 1 then begin
          curCell.colr  := 255 - round(0.5 * curCell.age);
        end else begin
          curCell.colr  := round(255 * colSize * curCell.Pot);         // -- the potential field
        end;
        curCell.Paint (paintImg.Canvas);
      end;
    end;
  end;

  plot(stateSum, round(potSum));                                 // -- plot the number of cells
end;

// *** Check Moore-Neigborhood for state ***************************************
procedure TForm1.checkNei (K, I: Integer; var sumState : Extended; var nrD: Integer);
var
  u,v      : Integer;
  Xp, Yp   : Integer;
  koNei    : Array [0..7] of TPoint;
begin
  sumState := 0;
  nrD      := 0;
 // --- orthogonal nearest neigbors ---
  koNei[0].X := K;    koNei[0].Y := I + 1;
  koNei[1].X := K;    koNei[1].Y := I - 1;
  koNei[2].X := K+1;  koNei[2].Y := I;
  koNei[3].X := K-1;  koNei[3].Y := I;
  // --- diagonal next nearest neigbors ---
  koNei[4].X := K+1;  koNei[4].Y := I + 1;
  koNei[5].X := K+1;  koNei[5].Y := I - 1;
  koNei[6].X := K-1;  koNei[6].Y := I - 1;
  koNei[7].X := K-1;  koNei[7].Y := I + 1;
  for v := 0 to 7 do
  begin
    Xp := koNei[v].X;
    Yp := koNei[v].Y;
    // -- Torus --
    if Xp < 0       then Xp := spalt-1;
    if Xp > spalt-1 then Xp := 0;
    if Yp < 0       then Yp := reih-1;
    if Yp > reih-1  then Yp := 0;
    if cellList[Xp, Yp].State = 1 Then nrD := nrD + 1;      // -- count the states of developed cells around
    if v < 4 then begin
      sumState := sumState + 2 * (cellList[Xp, Yp].State);  // -- count the states of the neighbours - nearest neigbors with weight 2
    end else begin
      sumState := sumState + 1 * (cellList[Xp, Yp].State);  // -- count the states of the neighbours
    end;
  end;
end;

// ---------------------------------------------------------------------------//
//*** Ausgabe in Graph *********************************************************
procedure TForm1.plot(stateSum: Integer; potSum: Integer);
begin
  if steps < 1000 then begin                        // -- bis Maximalwert Plotten
    {RChart1.ActiveLayer:= 1;
    RChart1.DataColor := clRed;
    RChart1.Line(steps-1, OldY1, steps, potSum);
    OldY1 := potSum;  }

    RChart1.ActiveLayer:= 3;
    RChart1.DataColor := clGreen;
    RChart1.Line(steps-1, OldY2, steps, stateSum);
    OldY2 := stateSum;
  end;
end;

// ---------------------------------------------------------------------------//
// -------------------------- Funktionen -------------------------------------//
// ---------------------------------------------------------------------------//
// *** Entferung berechnen *****************************************************
function TForm1.CalcDistance(pAX: Integer; pAY: Integer; pBX: Integer; pBY: Integer): Integer;
var
  temp : double;
begin
  temp := sqrt(Power((pAX - pBX), 2) + Power((pAY - pBY), 2));
  Result := Round(temp);
end;

// *** Zufallszahl innerhalb eines Bereichs berechnen **************************
function TForm1.rndN(lower : Integer; upper : Integer):Integer;
begin
  Result := round ((upper - lower + 1) * Random() + lower);
end;

// ---------------------------------------------------------------------------//
// ------------------------------- Schalter ----------------------------------//
// ---------------------------------------------------------------------------//
procedure TForm1.B_setupClick(Sender: TObject);
begin
  steps := 0;
  setupCells;
  repi    := StrToInt(E_iterate.Text) -1;
  diffEff := StrToFloat(E_diffEff.Text);
  interEff:= StrToFloat(E_interEff.Text);
end;

procedure TForm1.B_stopClick(Sender: TObject);
begin
  Timer1.enabled := not(Timer1.enabled);
end;

procedure TForm1.FormDestroy(Sender: TObject);
begin
  paintImg.Free;
  ZeichenPanel.Free;
  AgentList.Destroy;
end;

procedure TForm1.Cb_FieldClick(Sender: TObject);
begin
  paint_Field;
end;

procedure TForm1.E_multiChange(Sender: TObject);
begin
  paint_Field;
end;

end.

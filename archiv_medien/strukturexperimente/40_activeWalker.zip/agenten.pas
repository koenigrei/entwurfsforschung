unit agenten;

interface

uses
  Windows, Graphics, Math, Classes;

type
  TAgent = class
  public
    onCell     : TPoint;
    State      : Integer;
    Farbe      : Integer;
    Stopped    : Boolean;
    FPosX      : Integer;
    FPosY      : Integer;
    FSize      : Integer;
    FHeading   : Integer;                           // -- Anfangsausrichtung
    FStepX     : Integer;
    FStepY     : Integer;
    lookToList : Array of TPoint;
    weightList : Array of Real;
    sumChem    : Double;//Integer;
    procedure Paint       (Canvas: TCanvas);
    procedure SetPosX     (const Value: Integer);
    procedure SetPosY     (const Value: Integer);
    procedure SetStepX    (const Value: Integer);
    procedure SetStepY    (const Value: Integer);
    procedure SetHeading  (const Value: Integer);
    procedure SetSize     (const Value: Integer);
  published
    property PosX    : Integer read FPosX    write SetPosX;
    property PosY    : Integer read FPosY    write SetPosY;
    property StepX   : Integer read FStepX   write SetStepX;
    property StepY   : Integer read FStepY   write SetStepY;
    property Heading : Integer read FHeading write SetHeading;
    property Size    : Integer read FSize    write SetSize;
    procedure ChangeHeading(const degree: Integer; const dist: Integer; wiggle: Integer; method: Integer); // -- Maximale Richtungs�nderung angeben
  end;

implementation

const                            //-- globale Konstanten
  DegToRad  = 3.141592654/180;
  RadToDeg  = 180/3.141592654;

// *****************************************************************************
procedure TAgent.SetHeading(const Value: Integer);
begin
  FHeading := Value;
end;

// *****************************************************************************
procedure TAgent.ChangeHeading(const degree: Integer; const dist: Integer; wiggle: Integer; method: Integer);
var
  dX : Integer;
  dY : Integer;
  co, si : Extended;
  radD : Double;
  temp : Integer;
  tmp2 : Integer;
  M   : Integer;
  sum : Extended;
  rnd : Extended;
  pro : Extended;
  max : Real;
begin
  If sumChem > 3 Then         // -- threshold of chemicals in the neighbuerhood
  begin
    If method = 1 Then        // -- choose one neighbor-cell via roulette wheel
    begin
      rnd := random (100);
      sum := 0;
      M := 0;
      repeat
        sum := sum + weightList[M];
        dX := lookToList[M].X;
        dY := lookToList[M].Y;
        M := M +1;
      until sum >= rnd;
    end else

    If method = 2 Then        // -- choose one neighbor-cell via hill climbing
    begin
      max := 0;
      For M := 0 To High(weightList) Do
      begin
        If weightList[M] > max Then
        begin
          max := weightList[M];
          dX := lookToList[M].X;
          dY := lookToList[M].Y;
        end;
      end;
    end;

    FHeading := round((arcTan2(dY, dX)) *RadToDeg);
    temp := random(wiggle+1)* (random(2)*2 -1);
    FHeading := FHeading + temp;

  end else begin  // --- if there are no chemicals in the neigbourhood ---
    si := 0;
    co := 0;
    temp := 0;
    temp := random(degree+1)* (random(2)*2 -1);
    FHeading := FHeading + temp;
    radD := Heading * DegToRad;
    tmp2 := 1;//random(dist+1);
    SinCos(radD, si, co);                               // -- SinCos is twice as fast as calling Sin and Cos separately for the same angle
    dX := round(co)*tmp2;
    dy := round(si)*tmp2;
  end;

  If FHeading < 0   Then FHeading := 360 + FHeading;
  If FHeading > 360 Then FHeading := FHeading - 360;

  SetStepX(dX);
  SetStepY(dY);
end;

// *****************************************************************************
procedure TAgent.SetStepX(const Value: Integer);
begin
  FStepX := Value;
end;

// *****************************************************************************
procedure TAgent.SetStepY(const Value: Integer);
begin
  FStepY := Value;
end;

// *****************************************************************************
procedure TAgent.SetPosX(const Value: Integer);
begin
  FPosX := Value;
end;

// *****************************************************************************
procedure TAgent.SetPosY(const Value: Integer);
begin
  FPosY := Value;
end;

// *****************************************************************************
procedure TAgent.SetSize(const Value: Integer);
begin
  FSize := Value;
end;

// *****************************************************************************
procedure TAgent.Paint (Canvas: TCanvas);
var
  dX : Integer;
  dY : Integer;
  radD : Double;
  temp : Double;
  temp2 : Integer;
  co, si : Extended;
  lang : Integer;
begin
  //farbe := 255 * state;
  Canvas.Pen.Width := 1;
  Canvas.Pen.Color := clgray; //RGB (farbe, farbe, farbe);
  Canvas.Brush.Color := clred;// RGB (farbe, farbe, farbe);
  //Canvas.Brush.Color := clRed;
  Canvas.Ellipse (FPosX - FSize , FPosY - (FSize), FPosX + (FSize), FPosY + (FSize));

  lang := 6;
  Canvas.Pen.Color := clgreen;
  Canvas.MoveTo(FPosX,  FPosY);
  radD := Heading * DegToRad;
  SinCos(radD, si, co);
  dX := round(co)*lang;
  dy := round(si)*lang;
  Canvas.LineTo(FPosX+dX, FPosY+dy);
end;

end.

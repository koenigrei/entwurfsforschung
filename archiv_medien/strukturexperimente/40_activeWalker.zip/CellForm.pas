(********************************************************************)
(*                                                                  *) 
(*                                                                  *)
(*                         Active Walker                            *)
(*                          Version 1.0                             *)
(*                                                                  *)
(*                                                                  *)
(*     Programmierer: Reinhard K�nig                      June 2006 *)
(*                    http://www.entwurfsforschung.de               *)
(*                                                                  *)
(*     Last Update: Jun-03, 2006                                    *)
(*                                                                  *)
(********************************************************************) 
{revision history:

1.0     [Jun-03, 2006]
        first release to the public
}

unit CellForm;

interface

uses
  Windows, Messages, SysUtils, Variants, Classes, Graphics, Controls, Forms,
  Dialogs, StdCtrls, cell_P, ExtCtrls, ButtonGroup, ComCtrls, Math, ToolWin,
  ImgList, Epina.SDL.rchart, agenten, CategoryButtons;

type
  TForm1 = class(TForm)
    ZeichenPanel   : TPanel;
    Lbl_B          : TLabel;
    Label1         : TLabel;
    TrB_thresh     : TScrollBar;
    Lbl_wiggle     : TLabel;
    Label3         : TLabel;
    SB_wiggle      : TScrollBar;
    RadioGroup1    : TRadioGroup;
    rb_rulette     : TRadioButton;
    GroupBox1      : TGroupBox;
    B_setup        : TButton;
    B_stop         : TButton;
    B_oneStep      : TButton;
    Edit_anzAg     : TEdit;
    Lbl_TextAnzahl : TLabel;
    Edit_size      : TEdit;
    Label2         : TLabel;
    rb_hill        : TRadioButton;
    GroupBox2      : TGroupBox;
    lbl_Steps      : TLabel;
    Timer1: TTimer;
    procedure Edit_sizeChange(Sender: TObject);
    procedure SB_wiggleChange(Sender: TObject);
    procedure B_oneStepClick(Sender: TObject);
    procedure TrB_threshChange(Sender: TObject);
    procedure B_stopClick   (Sender: TObject);
    procedure B_setupClick  (Sender: TObject);
    procedure Timer1Timer   (Sender: TObject);
    procedure FormDestroy   (Sender: TObject);
    procedure FormCreate    (Sender: TObject);
  private
    AgentList    : TList;
    cellList     : Array of Array of TCell;
    limboWorld   : Array of Array of Extended;
    function  CalcDistance  (pAX: Integer; pAY: Integer; pBX: Integer; pBY: Integer): Integer;
    procedure torus         (var Xp: Integer; var Yp: Integer);
    procedure createPaintImg;
    procedure createRaster;
    procedure createAgents;
    procedure setupCells;
    procedure setupAgents;
    procedure calcAgents;
    procedure repaintAll;
    procedure checkArea   (I : Integer);
    procedure angelBorder (var angle : Real);
    procedure calculate;
    procedure settings;
    procedure deleter;
    procedure markCell    (X, Y: Integer);
    procedure calcCellDist;
  public
end;

var
  Form1    : TForm1;
  paintImg : TImage;
  agentImg : TImage;

implementation

{$R *.dfm}

const                            //-- globale Konstanten
  Pi     = 3.141592654;
  AgSize = 2;                    //-- Agenten gr��e
  //
var                              //-- globale Variablen
  reih     : Integer;            //-- Zellen-Reihen gesamt
  spalt    : Integer;            //-- Zellen-Spalten gesamt
  steps    : Integer;
  Xmax     : Integer;
  Ymax     : Integer;
  cellSum  : Integer;
  OldY1    : Double;             //-- Speichert die Position t-1 f�r Graphen
  OldY2    : Double;             //-- Speichert die Position t-1 f�r Graphen
  cellScal : Integer;            //-- Zellen  gr��e
  halfScal : Integer;
  rDown    : Boolean;
  lDown    : Boolean;
  maxM     : Double;             // -- maximal mark value
  minM     : Double;             // -- minimal mark value

// ---------------------------------------------------------------------------//
// *** Initialisierung *********************************************************
procedure TForm1.FormCreate(Sender: TObject);
begin
  settings;
  Lbl_B.Caption := IntToStr(TrB_thresh.Position) + ' Grad';
  Lbl_wiggle.Caption := IntToStr(SB_wiggle.Position) + ' Grad';
end;

// *****************************************************************************
procedure TForm1.settings;
begin
  cellScal  := StrToInt(Edit_size.Text) ;
  halfScal  := round(cellScal/2);
  spalt     := round (ZeichenPanel.Width / cellScal);
  reih      := round (ZeichenPanel.Height / cellScal);
  Xmax      := (spalt) * cellScal;
  Ymax      := (reih ) * cellScal;
  AgentList := TList.Create;
  SetLength(cellList, spalt, reih);
  SetLength(limboWorld, spalt, reih);
  createPaintImg;
  CreateRaster;
  CreateAgents;
  ZeichenPanel.Enabled := true;
  ZeichenPanel.DoubleBuffered := True;       //-- Verhindert Flackern der Zellen
  steps := 0;
  rDown := false;
  lDown := false;
end;
// ---------------------------------------------------------------------------//
// ------------------------- Elemente erstellen ------------------------------//
// ---------------------------------------------------------------------------//

// *** Legt eine leere Zeichenfl�che �ber das Zeichenpanel *********************
procedure TForm1.createPaintImg;
begin
  paintImg        := TImage.Create(self);
  paintImg.Parent := ZeichenPanel;
  paintImg.top    := 0;
  paintImg.Left   := 0;
  paintImg.Height := ZeichenPanel.Height;
  paintImg.Width  := ZeichenPanel.Width;
  paintImg.Enabled:= False;               // -- does not reakt on mouseEvents

  agentImg        := TImage.Create(self);
  agentImg.Parent := ZeichenPanel;
  agentImg.top    := 0;
  agentImg.Left   := 0;
  agentImg.Height := ZeichenPanel.Height;
  agentImg.Width  := ZeichenPanel.Width;
  agentImg.Transparent := true;
  agentImg.Enabled:= False;
end;

// *****************************************************************************
procedure TForm1.CreateAgents;
var
  I        : Integer;
  curAgent : TAgent;
begin
  for I := 1 to StrToInt(Edit_anzAg.Text) do //   StrToInt(Edi_NrRed.Text) Do
  begin
    curAgent := TAgent.Create;
    AgentList.Add (curAgent);     // ---  add to the list
  end;
  setupAgents;
end;

// *** Agenten initialisieren **************************************************
procedure TForm1.setupAgents;
var
  curAgent : TAgent;
  I        : Integer;
begin
  Randomize();
  for I := 0 to AgentList.Count - 1 do
  begin
    curAgent := AgentList.Items [I];
    curAgent.onCell.X := 50;
    curAgent.onCell.Y := 50;
    curAgent.PosX     := curAgent.onCell.X * cellScal + halfScal;
    curAgent.PosY     := curAgent.onCell.Y * cellScal + halfScal;
    curAgent.Size     := AgSize;
    curAgent.State    := random(2);
    curAgent.Stopped  := false;
    curAgent.Heading  := random (360);
    curAgent.Paint   (agentImg.Canvas);
  end;
end;

// *** Zellen erstellen ********************************************************
procedure TForm1.CreateRaster;
var
  curCell : TCell;
  I       : Integer;
  K       : Integer;
  upperB  : Integer;
  lowerB  : Integer;
begin
  for I := 0 to reih -1 do
  begin
    for K := 0 to spalt -1 do
    begin
      curCell := TCell.Create(halfScal + K * cellScal, halfScal + I * cellScal, halfScal, 0);
      cellList[K,I] := curCell;
    end;
  end;
  setupCells;
end;

// *** Zellen initialisieren ***************************************************
procedure TForm1.setupCells;
var
  curCell : TCell;
  I, K, M : Integer;
begin
  OldY1   := 0; // -- Ausgangswert t=0 f�r Graphen
  cellSum := spalt * reih;
  Randomize();
  // -- calculate the distance to the center --
    for I := 0 to reih -1 do
    begin
      for K := 0 to spalt -1 do
      begin
        curCell         := cellList[K,I];
        curCell.colr    := 255;
        curCell.maxM    := 1;
        curCell.mark    := 0;// random(10)+1;
        curCell.Paint(paintImg.Canvas);
      end;
    end;
end;

// ---------------------------------------------------------------------------//
// ---------------------------- Berechnungen ---------------------------------//
// ---------------------------------------------------------------------------//

// *** Rekursive Befehle ausf�hren ***
procedure TForm1.Timer1Timer(Sender: TObject);
begin
  calculate;
end;

// *****************************************************************************
procedure TForm1.calculate;
begin
  calcCellDist;

  repaintAll;

  calcAgents; // -- ver�ndert die Position der Agenten

  steps := steps +1;
  lbl_Steps.Caption := intToStr (steps);
end;

// *****************************************************************************
procedure TForm1.calcCellDist;
var
  onCell   : TCell;
  curCell  : TCell;
  curAgent : TAgent;
  I, K     : Integer;
  tempPos  : TPoint;
  cellPos  : TPoint;
  halfField : Real;
  halfSpalt : Real;
  test : double;
begin
  curAgent  := AgentList.Items [0];
  tempPos.X := curAgent.onCell.X;
  tempPos.Y := curAgent.onCell.Y;
  onCell    := cellList[tempPos.X, tempPos.Y];
  onCell.walked := true;
  maxM      := 0.1;
  minM      := 99999999999;
  halfField := ZeichenPanel.Width / 2;
  halfSpalt := spalt / 2;
  for I := 0 to reih -1 do
  begin
    for K := 0 to spalt -1 do
    begin
      curCell   := cellList[K,I];
      cellPos.X := curCell.FPos.X;
      cellPos.Y := curCell.FPos.Y;
      //curCell.Dist    := abs(tempPos.X - K) + abs(tempPos.Y - I);           // -- Manhatten Distance
      // --- distance-torus measure --------
      If abs(tempPos.X - K) > halfSpalt Then
        If K < halfSpalt Then cellPos.X := (K + spalt) * cellScal + halfScal
                         Else cellPos.X := (K - spalt) * cellScal + halfScal;
      If abs(tempPos.Y - I) > halfSpalt Then
        If I < halfSpalt Then cellPos.Y := (I + spalt) * cellScal + halfScal
                         Else cellPos.Y := (I - spalt) * cellScal + halfScal;

      curCell.Dist    := calcDistance(cellPos.X, cellPos.Y, onCell.FPos.X,onCell.FPos.Y);
      curCell.mark    := curCell.mark + sqrt(0.01 *curCell.Dist);
      If curCell.mark > maxM Then maxM := curCell.mark;
      If curCell.mark < minM Then minM := curCell.mark;
    end;
  end;
end;

// *****************************************************************************
procedure TForm1.repaintAll;
var
  curAgent : TAgent;
  curCell  : TCell;
  I, K     : Integer;
  sumM     : Integer;
begin
  agentImg.Canvas.brush.Color := clWhite;
  agentImg.Canvas.pen.Color   := clWhite;
  agentImg.Canvas.Rectangle(0,0,ZeichenPanel.Height,ZeichenPanel.Width);
  sumM := 0;
  for I := 0 to reih -1 do
  begin
    for K := 0 to spalt -1 do
    begin
      curCell := cellList[K,I];
      curCell.Paint (paintImg.Canvas);
      curCell.maxM := maxM;
      curCell.minM := minM;
    end;
  end;

  for I := 0 to AgentList.Count - 1 do
  begin
    curAgent := AgentList.Items [I];
    curAgent.Paint (agentImg.Canvas);
  end;

end;

// *****************************************************************************
procedure TForm1.angelBorder (var angle : Real);
begin
  If angle < 0   Then angle := 360 + angle;
  If angle > 360 Then angle := angle -360;
end;

// *****************************************************************************
// *** look at the cells in the neigbourhood defined by the horizon-parameter **
// *****************************************************************************
procedure TForm1.checkArea (I : Integer);
var
  curCell  : TCell;
  curAgent : TAgent;
  M        : Integer;
  Angle    : Array [0..1] of Real;
  tmpAngle : Real;
  horizon  : Integer;
  neib     : TPoint;
  comper   : Real;
  wList    : Array of Double;//Integer;
  wSum     : Double;//Integer;
  tmP      : TPoint;
  fromTo   : Array [0..1] of Integer;
  curNr    : Integer;
begin
  horizon := TrB_thresh.Position;
  curAgent := AgentList.Items [I];
  Angle[0] := curAgent.Heading - horizon - 22.5;     // -- minAngle
  Angle[1] := curAgent.Heading + horizon - 22.5;     // -- maxAngle
  angelBorder (Angle[0]);
  angelBorder (Angle[1]);
  //-- find the cells to look at
  SetLength(curAgent.lookToList, 0);

  for M := 0 to 1 do
  begin
    comper   := Angle[M];
    case round(comper) of           // find start and end field (cell)
      0..45:    fromTo[M] := 1;
      46..90:   fromTo[M] := 2;
      91..135:  fromTo[M] := 3;
      136..180: fromTo[M] := 4;
      181..225: fromTo[M] := 5;
      226..270: fromTo[M] := 6;
      271..315: fromTo[M] := 7;
      316..360: fromTo[M] := 8;
    end;
  end;

  curNr := fromTo[0] -1;
  repeat
  inc(curNr);
  If curNr > 8 Then curNr := 1;
    case curNr of                   // set the direction to the cell-positions
      1: begin neib.X := 1;  neib.Y := 1;  end;
      2: begin neib.X := 0;  neib.Y := 1;  end;
      3: begin neib.X := -1; neib.Y := 1;  end;
      4: begin neib.X := -1; neib.Y := 0;  end;
      5: begin neib.X := -1; neib.Y := -1; end;
      6: begin neib.X := 0;  neib.Y := -1; end;
      7: begin neib.X := 1;  neib.Y := -1; end;
      8: begin neib.X := 1;  neib.Y := 0;  end;
    end;
    SetLength(curAgent.lookToList, length(curAgent.lookToList) + 1);
    curAgent.lookToList[High(curAgent.lookToList)] := neib;
  until curNr = fromTo[1];

  SetLength(wList, length(curAgent.lookToList));
  wSum := 0;
  curAgent.sumChem := 0;
  For M := 0 To High(curAgent.lookToList) Do
  begin
    tmP.X := curAgent.onCell.X + curAgent.lookToList[M].X;
    tmP.Y := curAgent.onCell.Y + curAgent.lookToList[M].Y;
    torus (tmP.X, tmP.Y);
    curCell := cellList[tmP.X, tmP.Y];
    curAgent.sumChem := curAgent.sumChem + curCell.mark;
    wSum := wSum + curCell.mark;
    wList[M] := curCell.mark;
  end;

  SetLength(curAgent.weightList, 0);
  SetLength(curAgent.weightList, length(curAgent.lookToList));
  For M := 0 To High(curAgent.lookToList) Do
  begin
    // --- write in the agent's weight list ---
    curAgent.weightList[M] := wList[M]/wSum * 100;
  end;
end;

// *****************************************************************************
// *** Ver�ndert die Position der Agenten **************************************
// *****************************************************************************
procedure TForm1.calcAgents;
var
  curCell  : TCell;
  curAgent : TAgent;
  I        : Integer;
  agCount  : Integer;
  tempPos  : TPoint;
  resc     : Integer;
  horizon  : Integer;
  wiggle   : Integer;
  method   : Integer;
begin
  agCount := 0;
  horizon := TrB_thresh.Position;
  wiggle  := SB_wiggle.Position;
  If rb_rulette.Checked = true Then begin method := 1; end
  else begin If rb_hill.Checked = true Then method := 2; end;
  for I := 0 to AgentList.Count - 1 do
  begin
    curAgent := AgentList.Items [I];
    checkArea (I);
    curAgent.ChangeHeading(horizon, 1, wiggle, method);                       // -- Richtungsspektrum und Distanz
    tempPos.X := curAgent.onCell.X + curAgent.stepX;
    tempPos.Y := curAgent.onCell.Y + curAgent.stepY;
    torus (tempPos.X, tempPos.Y);                                             // -- Torus --
    curCell := cellList[tempPos.X, tempPos.Y];
    //cellList[curAgent.onCell.X, curAgent.onCell.Y].mark := 20 + cellList[curAgent.onCell.X, curAgent.onCell.Y].mark;
    curAgent.onCell.X := tempPos.X;
    curAgent.onCell.Y := tempPos.Y;
    curAgent.PosX     := curAgent.onCell.X * cellScal + halfScal;             // -- Wenn Zelle frei, Agent bewegen ---
    curAgent.PosY     := curAgent.onCell.Y * cellScal + halfScal;
    curCell.State     := curAgent.State;
    end;
end;

// ---------------------------------------------------------------------------//
// -------------------------- Funktionen -------------------------------------//
// ---------------------------------------------------------------------------//
// *** Torusfunktion ***
procedure TForm1.torus (var Xp: Integer; var Yp: Integer);
begin
  if Xp < 0     then begin
     Xp := spalt + Xp;
  end else
  if Xp > spalt-1  then begin
     Xp := 0 + (Xp - spalt) ;
  end;
  if Yp < 0     then begin
     Yp := reih + Yp;
  end else
  if Yp > reih-1  then begin
     Yp := 0 + (Yp - reih) ;
  end;
end;

// *** Entferung berechnen ***
function TForm1.CalcDistance(pAX: Integer; pAY: Integer; pBX: Integer; pBY: Integer): Integer;
var
  temp : double;
begin
  temp := sqrt(Power((pAX - pBX), 2) + Power((pAY - pBY), 2));
  Result := Round(temp);
end;

// ---------------------------------------------------------------------------//
// ------------------------------- Schalter ----------------------------------//
// ---------------------------------------------------------------------------//
procedure TForm1.B_setupClick(Sender: TObject);
begin
  deleter;
  //RChart1.Scale1Y.RangeHigh := StrToInt(Edit_anzAg.Text);
  settings;
end;

procedure TForm1.B_stopClick(Sender: TObject);
begin
  Timer1.enabled := not(Timer1.enabled);
end;

procedure TForm1.FormDestroy(Sender: TObject);
begin
  deleter;
  ZeichenPanel.Free;
end;

procedure TForm1.deleter;
begin
  steps := 0;
  AgentList.Free;
  paintImg.Free;
  agentImg.Free;
  SetLength(cellList, 0, 0);
  SetLength(limboWorld, 0, 0);
end;

procedure TForm1.TrB_threshChange(Sender: TObject);
begin
  Lbl_B.Caption := IntToStr(TrB_thresh.Position) + ' Grad';
end;

procedure TForm1.SB_wiggleChange(Sender: TObject);
begin
  Lbl_wiggle.Caption := IntToStr(SB_wiggle.Position) + ' Grad';
end;

procedure TForm1.B_oneStepClick(Sender: TObject);
begin
  calculate;
end;

procedure TForm1.Edit_sizeChange(Sender: TObject);
begin
  If StrToInt(Edit_size.Text) > 10 Then Edit_size.Text := '10';
  If StrToInt(Edit_size.Text) < 1  Then Edit_size.Text := '1';
end;

procedure TForm1.markCell (X, Y: Integer);
var
  curCell : TCell;
  cPos    : TPoint;
begin
  cPos.X  := round(X / cellScal);
  cPos.Y  := round(Y / cellScal);
  curCell := cellList[cPos.X, cPos.Y];
  If (lDown = true) Then
  begin
    curCell.mark := 255;
  end else
  If (rDown = true) Then
  begin
    curCell.mark := 1;
    curCell.Paint (paintImg.Canvas);
  end;
end;

end.

object Form1: TForm1
  Left = 0
  Top = 0
  Width = 750
  Height = 455
  Caption = 'path system'
  Color = clBtnFace
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -10
  Font.Name = 'Tahoma'
  Font.Style = []
  OldCreateOrder = False
  OnCreate = FormCreate
  OnDestroy = FormDestroy
  PixelsPerInch = 96
  TextHeight = 12
  object Lbl_B: TLabel
    Left = 530
    Top = 261
    Width = 15
    Height = 12
    Caption = '___'
  end
  object Label1: TLabel
    Left = 442
    Top = 261
    Width = 76
    Height = 12
    Caption = 'angle threshold :'
  end
  object Lbl_wiggle: TLabel
    Left = 530
    Top = 309
    Width = 15
    Height = 12
    Caption = '___'
  end
  object Label3: TLabel
    Left = 442
    Top = 309
    Width = 81
    Height = 12
    Caption = 'wiggle threshold :'
  end
  object ZeichenPanel: TPanel
    Left = 8
    Top = 9
    Width = 404
    Height = 404
    BorderStyle = bsSingle
    DockSite = True
    TabOrder = 0
  end
  object TrB_thresh: TScrollBar
    Left = 440
    Top = 280
    Width = 145
    Height = 17
    LargeChange = 5
    Max = 180
    PageSize = 0
    Position = 157
    TabOrder = 1
    OnChange = TrB_threshChange
  end
  object SB_wiggle: TScrollBar
    Left = 440
    Top = 328
    Width = 145
    Height = 17
    LargeChange = 5
    Max = 180
    PageSize = 0
    TabOrder = 2
    OnChange = SB_wiggleChange
  end
  object RadioGroup1: TRadioGroup
    Left = 440
    Top = 192
    Width = 257
    Height = 49
    Caption = 'sniff chemicals with'
    TabOrder = 3
  end
  object rb_rulette: TRadioButton
    Left = 448
    Top = 216
    Width = 81
    Height = 17
    Caption = 'rulette wheel'
    Enabled = False
    TabOrder = 4
  end
  object GroupBox1: TGroupBox
    Left = 440
    Top = 8
    Width = 257
    Height = 129
    Caption = 'setup settings'
    TabOrder = 5
    object Lbl_TextAnzahl: TLabel
      Left = 54
      Top = 76
      Width = 129
      Height = 12
      Caption = ': number of agents for setup'
    end
    object Label2: TLabel
      Left = 54
      Top = 100
      Width = 127
      Height = 12
      Caption = ': cell size -> number of cells '
    end
    object B_setup: TButton
      Left = 6
      Top = 16
      Width = 75
      Height = 25
      Caption = 'new Setup'
      TabOrder = 0
      OnClick = B_setupClick
    end
    object B_stop: TButton
      Left = 86
      Top = 16
      Width = 75
      Height = 25
      Caption = 'start / stop'
      TabOrder = 1
      OnClick = B_stopClick
    end
    object B_oneStep: TButton
      Left = 166
      Top = 16
      Width = 75
      Height = 25
      Caption = 'one step'
      TabOrder = 2
      OnClick = B_oneStepClick
    end
    object Edit_anzAg: TEdit
      Left = 8
      Top = 72
      Width = 41
      Height = 20
      Enabled = False
      TabOrder = 3
      Text = '1'
    end
    object Edit_size: TEdit
      Left = 8
      Top = 96
      Width = 41
      Height = 20
      TabOrder = 4
      Text = '4'
      OnChange = Edit_sizeChange
    end
  end
  object rb_hill: TRadioButton
    Left = 576
    Top = 216
    Width = 81
    Height = 17
    Caption = 'hill climbing'
    Checked = True
    TabOrder = 6
    TabStop = True
  end
  object GroupBox2: TGroupBox
    Left = 440
    Top = 144
    Width = 257
    Height = 41
    Caption = 'timesteps'
    TabOrder = 7
    object lbl_Steps: TLabel
      Left = 72
      Top = 18
      Width = 39
      Height = 12
      Alignment = taCenter
      BiDiMode = bdRightToLeft
      Caption = 'lbl_Steps'
      ParentBiDiMode = False
    end
  end
  object Timer1: TTimer
    Interval = 1
    OnTimer = Timer1Timer
    Left = 704
    Top = 16
  end
end

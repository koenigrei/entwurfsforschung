unit agenten;

interface

uses
  Windows, Graphics, Classes, Math;

type
  TBaseShape = class
  private
  public
    FPositionX    : Integer;
    FPositionY    : Integer;
    FSize         : Integer;
    FStepX        : Double;
    FStepY        : Double;
    FFillColor    : Integer;
    FState        : Integer;
    FDistance     : Integer;
    FShortestD    : Double;
    FNeigborList  : Array of Integer;
    procedure SetNeigbor  (Index: Integer; Value: Integer);
    function  GetNeigbor  (Index: Integer): Integer;
    property  NeigborList [Index: Integer]: Integer read GetNeigbor write SetNeigbor;
    function CalcDistance (pX, pY: Integer):Integer;
    procedure SetDistance (const Value: Integer);
    procedure Paint (Canvas: TCanvas); virtual;
    procedure SetPositionX(const Value: Integer);
    procedure SetPositionY(const Value: Integer);
    procedure SetStepX    (const Value: Double);
    procedure SetStepY    (const Value: Double);
    procedure SetSize     (const Value: Integer);
    procedure SetRndDir   (const damp: Double);
    procedure SetFillColor(const Value: Integer);
    procedure SetState    (const Value: Integer);
    procedure SetShortestD(const Value: Double);
  published
    procedure NeigborCheck(const Abstand: Integer; const MinAbstand: Integer; const Sichtfeld: Integer;
                           const AgentList: TList; const I: Integer; var limboPos: Array of Double);
    property PositionX: Integer read FPositionX write SetPositionX;
    property PositionY: Integer read FPositionY write SetPositionY;
    property StepX    : Double  read FStepX     write SetStepX;
    property StepY    : Double  read FStepY     write SetStepY;
    property Size     : Integer read FSize      write SetSize;
    property FillColor: Integer read FFillColor write SetFillColor;
    property State    : Integer read FState     write SetState;
    property Distance : Integer read FDistance  write SetDistance;
    property ShortestD: Double  read FShortestD write SetShortestD;
  end;

type
  TAgent = class (TBaseShape)
    procedure Paint (Canvas: TCanvas); override;
  end;

implementation

const PI = 3.14159265358979323846;
//*********************************************************************************************//
// ********** Berechnet Nachbarn und Abst�nde zu den anderen Agenten **************************//
//*********************************************************************************************//
// --- Eingagen : Abstand   : Interaktionsradius der Agenten                                   //
//                MinAbstand: Mindestabstand zwischen den Agenten                              //
//                AgentList : Liste mit allen Agenten                                          //
//                I         : Nr des Aktuellen Agenten um Doppelvergleiche zu vermeiden (K+I)  //
//                limboPos  : LimboPos zum zwischenspeichern der neuen Bewegungsrichtung       //
// --- Ausgaben : NeigborList   : Nr.-Liste mit den Nachbarn innerhalb des Radius              //
//                NeigborList[0]: Nr. des n�chsten Nachbarn                                    //
//                ShortestD     : Entfernung zum n�chsten Nachbarn                             //
//*********************************************************************************************//
procedure TBaseShape.NeigborCheck (const Abstand: Integer; const MinAbstand: Integer; const Sichtfeld: Integer;
                                   const AgentList: TList; const I: Integer; var limboPos: Array of Double);
var
  K               : Integer;
  U               : Integer;
  BShape          : TAgent;
  CShape          : TAgent;
  distNode        : Integer;
  XProd           : Double;
  YProd           : Double;
  zaehler         : Double;
  nenner          : Double;
  temp            : Double;
  Winkel          : Extended;
  compWink        : Integer;
  freieSicht      : Boolean;
begin
  SetLength(FNeigborList, 1);
  limboPos[0] := FStepX;
  limboPos[1] := FStepY;
  ShortestD   := 1000;
  //For K := I+1 to AgentList.Count - 1 do
  For K := 0 to AgentList.Count - 1 do
  If Not (K = I) then
  begin
    BShape := AgentList.Items[K];
    Distance := CalcDistance(BShape.PositionX, BShape.PositionY);
    freieSicht := true;
    If Distance < Abstand // --- Innerhalb Radius
    then begin
      If Distance < ShortestD  // --- bestimme den n�chsten Nachbarn
      then begin
        ShortestD := Distance;
        FNeigborList[0] := K; // Index 0 = nearestNeigbor
      end;
      // --- Winkelberechnung f�r "Sichtfeld"
      zaehler := FStepX * BShape.FStepX + FStepY * BShape.FStepY;
      nenner  := Sqrt(Power(FStepX, 2) + Power(FStepY, 2)) * Sqrt(Power(BShape.FStepX, 2) + Power(BShape.FStepY, 2));
      If nenner > 0 then begin
        Winkel  := Math.ArcSin (zaehler / nenner) / PI * 180;
      end
      else begin
        Winkel  := 0;
      end;
      If Winkel < -180 then Winkel := 360 + Winkel;
      If Winkel >  180 then Winkel := 360 - Winkel;
      Winkel := Abs(Winkel);
      compWink  := round (Sichtfeld / 2);
      // --- Speichert die Nachbarn in einer Liste, wenn innerhalb des Sichtfeldes ---
      If (Winkel < compWink) then begin
        SetLength(FNeigborList, length(FNeigborList) + 1);
        NeigborList[High(FNeigborList)]  := K;
        If Winkel < 5 then freieSicht := false
      end;
    end;
  end;

  // --- Nachbarn - Swarming ---
  If (length(FNeigborList) > 1) then  // ### Falls Nachbarn innerhalb des Sichtfeldes gefunden wurden
  begin
    If  (ShortestD > MinAbstand) and (freieSicht = true) then // ### Mindestabstand und freie Sicht
    begin                    // ### Wenn Nachbarn nicht zu nahe beieinander und Sicht frei
      XProd := 0;
      YProd := 0;
      for U := 1 to length(FNeigborList) -1 do
      begin
        CShape:= AgentList.Items[FNeigborList[U]];  // --- Alle X- und Y-Werte addieren
        XProd := XProd + CShape.FStepX;
        YProd := YProd + CShape.FStepY;
      end;
      limboPos[0] := (XProd / (length(FNeigborList)-1)); // --- Quersummen bilden
      limboPos[1] := (YProd / (length(FNeigborList)-1)); // --- und in LimboPos zwischenspeichern
    end
    else begin                        // ### Wenn Nachbarn zu nahe beieinander oder Sicht verstellt
      SetRndDir (0.15);                // ### Bewegung in zuf�llige Richtung
    end;
  end;
end;

// ********************* Zuf�llige Richtungs�nderung *************************//
procedure TBaseShape.SetRndDir (const damp: Double); // --- damp bestimmt die St�rke des Richtungswechsels
begin
  StepX := FStepX + (random(3) - 1) * damp;
  StepY := FStepY + (random(3) - 1) * damp;
end;

// **************** Funktion zur Entfernungsberechnung **********************//
function TBaseShape.CalcDistance(pX: Integer; pY: Integer): Integer;
  var temp: double;
  begin
  temp := sqrt(Power((pX - FPositionX), 2) + Power((pY - FPositionY), 2));
  Result := Round(temp);
end;

// ********* Zeichnungseinstellungen f�r die Agentenrepr�sentation **********//
procedure TAgent.Paint(Canvas: TCanvas);
begin
  inherited Paint (Canvas);
  Canvas.Pen.Color := clGreen;
  Canvas.Brush.Color := FFillColor;
  Canvas.Ellipse (FPositionX - FSize , FPositionY - (FSize), FPositionX + (FSize), FPositionY + (FSize));
end;

procedure TBaseShape.SetNeigbor (Index: Integer; Value: Integer);
begin
  FNeigborList[Index] := Value;
end;

function  TBaseShape.GetNeigbor  (Index: Integer): Integer;
begin
  Result := FNeigborList[index];
end;

procedure TBaseShape.Paint (Canvas: TCanvas);
begin
  Canvas.Pen.Width := 1;
end;

procedure TBaseShape.SetDistance (const Value: Integer);
begin
  FDistance := Value;
end;

procedure TBaseShape.SetShortestD (const Value: Double);
begin
  FShortestD := Value;
end;

procedure TBaseShape.SetStepX(const Value: Double);
begin
  FStepX := Value;
end;

procedure TBaseShape.SetStepY(const Value: Double);
begin
  FStepY := Value;
end;

procedure TBaseShape.SetPositionX(const Value: Integer);
begin
  FPositionX := Value;
end;

procedure TBaseShape.SetPositionY(const Value: Integer);
begin
  FPositionY := Value;
end;

procedure TBaseShape.SetSize(const Value: Integer);
begin
  FSize := Value;
end;

procedure TBaseShape.SetFillColor(const Value: Integer);
begin
  FFillColor := Value;
end;

procedure TBaseShape.SetState(const Value: Integer);
begin
  FState := Value;
end;

end.

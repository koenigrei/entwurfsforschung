(********************************************************************)
(*                                                                  *) 
(*                                                                  *)
(*                        Krugman�s Model                           *)
(*                          Version 1.0                             *)
(*                                                                  *)
(*                                                                  *)
(*    Programmierer: Reinhard K�nig                   December 2005 *)
(*                   http://www.entwurfsforschung.de                *)
(*                   - R�umliche Prozesse -                         *)
(*                                                                  *)
(*    Last Update: Dec-22, 2005                                     *)
(*                                                                  *)
(********************************************************************) 
{revision history:

1.0     [Dec-22, 2005]
        first release to the public
}

unit CellForm;

interface

uses
  Windows, Messages, SysUtils, Variants, Classes, Graphics, Controls, Forms,
  Dialogs, StdCtrls, cell_P, ExtCtrls, ButtonGroup, ComCtrls, Math, ToolWin,
  ImgList, Epina.SDL.rchart, agenten;

type
  TForm1 = class(TForm)
    ZeichenPanel   : TPanel;
    Timer1         : TTimer;
    lbl_Steps      : TLabel;
    B_setup        : TButton;
    lbl_timesteps  : TLabel;
    Lbl_TextSwelle : TLabel;
    E_K1           : TEdit;
    B_stop         : TButton;
    RChart1        : TRChart;
    Lbl_TextAnzahl : TLabel;
    E_K2           : TEdit;
    Label1         : TLabel;
    Label2         : TLabel;
    E_alpha        : TEdit;
    E_beta         : TEdit;
    Label3         : TLabel;
    E_growth       : TEdit;
    procedure B_stopClick   (Sender: TObject);
    procedure B_setupClick  (Sender: TObject);
    procedure Timer1Timer   (Sender: TObject);
    procedure FormDestroy   (Sender: TObject);
    procedure FormCreate    (Sender: TObject);
  private
    ZellList    : TList;
    cellList    : Array of Array of TCell;
    limboWorld  : Array of Array of Extended;
    function  CalcDistance  (pAX: Double; pAY: Double; pBX: Double; pBY: Double): Double;
    function  rndN          (lower: Integer; upper: Integer):Integer;
    procedure setDist       (const idx: Integer);
    procedure createPaintImg;
    procedure createRaster;
    procedure setupCells;
    procedure calcCells;
  public
end;

var
  Form1    : TForm1;
  paintImg : TImage;

implementation

{$R *.dfm}

const                            // -- globale Konstanten
  cellScal = 15;                 // -- Zellen  gr��e
  AgSize   = 4;                  // -- Agenten gr��e
  halfScal = round(cellScal/2);
  nCells   = 24;                 // -- Anzahl der Zellen im Kreis f�r Krugman Modell
  Pi       = 3.14159265358;
var                              // -- globale Variablen
  reih    : Integer;             // -- Zellen-Reihen gesamt
  spalt   : Integer;             // -- Zellen-Spalten gesamt
  steps   : Integer;             // -- Z�hlt die Zeiteinheiten / Systemschritte
  ticks   : Integer;             // --     "                   "
  Xmax    : Integer;
  Ymax    : Integer;
  cellSum : Integer;
  OldY1   : Double;              // -- Speichert die Position t-1 f�r Graphen
  OldY2   : Double;              // -- Speichert die Position t-1 f�r Graphen
  happy   : Integer;             // -- z�hlt die angelagerten Agenten
  unhappy : Integer;             // -- z�hlt die noch freien Agenten

  growth  : Real;                // -- Wachstumsrate pro Zeitschritt
  alpha   : Real;                // -- Scalierungs-Parameter, der auf die Entfernungen angewandt wird
  beta    : Real;                // --     "                   "
  K1      : Real;                // -- Gr��en-Parameter f�r das Potential
  K2      : Real;                // --     "                   "

  graphTick : Integer;           // -- Z�hlt die Zeichnungsschritte des Graphen
  graphOn   : Boolean;           // -- stoppt bei 1000 da light-version
// ---------------------------------------------------------------------------//
// *** Initialisierung ***
procedure TForm1.FormCreate(Sender: TObject);
begin
  spalt     := round (ZeichenPanel.Width / cellScal);
  reih      := round (ZeichenPanel.Height / cellScal);
  Xmax      := (spalt) * cellScal;
  Ymax      := (reih ) * cellScal;
  ZellList := TList.Create;
  SetLength(cellList, spalt, reih);
  SetLength(limboWorld, spalt, reih);
  createPaintImg;
  CreateRaster;
  ZeichenPanel.DoubleBuffered := True;       //-- Verhindert Flackern der Zellen
  steps := 0;
  ticks := 999;
  
  // -- Diagramm initialisieren --
  RChart1.Scale1X.RangeLow  := 0;    //-- range of chart area 
  RChart1.Scale1X.RangeHigh := 25;   //-- Maximale Reichweite = 1000 bei Testversion!!!
  RChart1.Scale1Y.RangeLow  := -30;
  RChart1.Scale1Y.RangeHigh := 5;
  RChart1.ShowGraf;
  graphOn := true;
end;

// ---------------------------------------------------------------------------//
// ------------------------- Elemente erstellen ------------------------------//
// ---------------------------------------------------------------------------//

// *** Legt eine leere Zeichenfl�che �ber das Zeichenpanel ***
procedure TForm1.createPaintImg;
begin
  paintImg        := TImage.Create(self);
  paintImg.Parent := ZeichenPanel;
  paintImg.top    := 0;
  paintImg.Left   := 0;
  paintImg.Height := ZeichenPanel.Height;
  paintImg.Width  := ZeichenPanel.Width;
end;

// *** Zellen erstellen ***
procedure TForm1.CreateRaster;
var
  curCell : TCell;
  I       : Integer;
  winkel  : Double;
  XKoord  : Integer;
  YKoord  : Integer;
  dist    : double;
begin
  winkel  := (2 *Pi/nCells);           // Umrechnung Grad := Bogenma� * 180 / pi
  for I   := 0 to nCells-1 do
  begin
    XKoord := round(sin(I*Winkel)*100 +200 );
    YKoord := round(cos(I*Winkel)*100 +200 );
    curCell := TCell.Create(XKoord, YKoord, halfScal, 0);
    ZellList.Add (curCell);
  end;
  curCell := ZellList.Items[0];
  dist := calcDistance(sin(0*Winkel),cos(0*Winkel), sin(1*Winkel),cos(1*Winkel));
  lbl_Steps.Caption := FloatToStr (dist);
  setupCells
end;

// *** Zellen initialisieren ***
procedure TForm1.setupCells;
var
  curCell : TCell;
  toCell  : TCell;
  I,K     : Integer;
  cSum    : Double;
begin
  Randomize();
  for I := 0 to ZellList.Count - 2 do
  begin
    curCell := ZellList.Items [I];
    curCell.Popul := (random()*2)/nCells;
    cSum    := cSum + curCell.Popul;
    curCell.colr    := round(curCell.Popul * nCells * 255);
    curCell.Paint(paintImg.Canvas);
    setDist(I);
  end;
  curCell := ZellList.Items [nCells-1];
  curCell.Popul := 1 - cSum;
  if curCell.Popul < 0 then setupCells;
  curCell.colr    := round(curCell.Popul * nCells * 255);
  setDist(nCells-1);
  curCell.Paint(paintImg.Canvas);
  RChart1.ClearGraf;                                      // -- initialize chart

  // -- Parameter aus Interface:
  K1    := StrToFloat(E_K1.Text);
  K2    := StrToFloat(E_K2.Text);
  alpha := StrToFloat(E_alpha.Text);
  beta  := StrToFloat(E_beta.Text);
  growth:= StrToFloat(E_growth.Text);
end;

procedure TForm1.setDist(const idx: Integer);
var
  curCell : TCell;
  toCell  : TCell;
  I       : Integer;
begin
  curCell := ZellList.Items [idx];
  for I := 0 to ZellList.Count - 1 do begin
    toCell := ZellList.Items [I];
    curCell.dist[I] := calcDistance((curCell.FPos.X-200)/100, (curCell.Fpos.Y-200)/100,
                                    ( toCell.FPos.X-200)/100, ( toCell.Fpos.Y-200)/100)
  end;

end;
// ---------------------------------------------------------------------------//
// ---------------------------- Berechnungen ---------------------------------//
// ---------------------------------------------------------------------------//

// *** Rekursive Befehle ausf�hren ***
procedure TForm1.Timer1Timer(Sender: TObject);
var
  M : Integer;
  curCell : TCell;
begin

  calcCells;  // -- berechnet die Zellennachbarschaften

  ticks := ticks +1;
  steps := steps +1;
  lbl_Steps.Caption := intToStr (steps);

  //--- Ausgabe in Graph ---
  if (ticks = 1000) and (graphOn = true) then begin // -- Plotten bis
    ticks := 0;
    RChart1.ActiveLayer:= 1;
    RChart1.DataColor := clBlack;

    curCell := ZellList.Items [ nCells-1];
    RChart1.MoveTo(0, log10 (100 * curCell.Popul));
    graphTick := graphTick +1;

    for M := 0 to ZellList.Count - 1 do
      begin
      curCell := ZellList.Items [M];
      RChart1.DrawTo(M+1, log10 (100 * curCell.Popul));
      graphTick := graphTick +1;
    end;
    If graphTick > 970 Then graphOn := false;
    RChart1.ShowGraf;
  end;
end;


// *** Berechnet die Zellen ***
procedure TForm1.calcCells;
var
  curCell     : TCell;
  atCell      : TCell;
  I,K       : Integer;
  sum1        : Double;
  sum2        : Double;
  avgPotenz   : Double;
  deltaPopul  : Double;
  maxP        : Double;
begin

  // --- Berechnung der zentripetalen und zentrifugalen Kr�fte und des Potentials einer Zelle ---
  for I := 0 to ZellList.Count - 1 do
  begin
    sum1 := 0;
    sum2 := 0;
    curCell := ZellList.Items [I];
    for K := 0 to ZellList.Count - 1 do begin
      atCell := ZellList.Items [K];
      sum1   := sum1 + (atCell.Popul* exp(-1*alpha * atCell.dist[I]));
      sum2   := sum2 + (atCell.Popul* exp(-1*beta  * atCell.dist[I]));
    end;
    curCell.Pot1 := K1 * sum1;
    curCell.Pot2 := K2 * sum2;
    curCell.Potenz := curCell.Pot1 - curCell.Pot2;
  end;

  // --- Berechnung des duchschnittlichen, globalen Potentials ---
  avgPotenz := 0;
  for I := 0 to ZellList.Count - 1 do
  begin
    curCell := ZellList.Items [I];
    avgPotenz  := avgPotenz + (curCell.Popul * curCell.Potenz);
  end;
  avgPotenz  := avgPotenz / nCells;                               // -- DurchschnittsPotential

  // --- Berechnung der Ver�nderungsrate der Population ---
  deltaPopul := 0;
  maxP       := 0;
  for I := 0 to ZellList.Count - 1 do
  begin
    deltaPopul    := 0;
    curCell       := ZellList.Items [I];
    deltaPopul    := (curCell.Potenz - avgPotenz)* curCell.Popul; // -- Ver�nderung der Population
    curCell.Popul := growth *(curCell.Popul + deltaPopul);        // -- �bertragen auf neue Population + Wachstumsrate
    If curCell.Popul > maxP then maxP := curCell.Popul;           // -- Maximalwert f�r Population berechnen
  end;

  // --- Zellen in Abh�ngigkeit vom Maximalwert zeichnen ---
  for I := 0 to ZellList.Count - 1 do
  begin
    curCell       := ZellList.Items [I];
    curCell.colr  := round(curCell.Popul * round(255/maxP));
    curCell.Paint(paintImg.Canvas);
  end;
end;

// ---------------------------------------------------------------------------//
// -------------------------- Funktionen -------------------------------------//
// ---------------------------------------------------------------------------//

// *** Entferung berechnen ***
function TForm1.CalcDistance(pAX: Double; pAY: Double; pBX: Double; pBY: Double): Double;
var
  temp : double;
begin
  Result := sqrt(Power((pAX - pBX), 2) + Power((pAY - pBY), 2));
end;

// *** Zufallszahl innerhalb eines Bereichs berechnen ***
function TForm1.rndN(lower : Integer; upper : Integer):Integer;
begin
  Result := round ((upper - lower + 1) * Random() + lower);
end;

// ---------------------------------------------------------------------------//
// ------------------------------- Schalter ----------------------------------//
// ---------------------------------------------------------------------------//
procedure TForm1.B_setupClick(Sender: TObject);
begin
  steps := 0;
  setupCells;
  ticks := 999;
  RChart1.ClearGraf; 
  graphOn := true;
end;

procedure TForm1.B_stopClick(Sender: TObject);
begin
  Timer1.enabled := not(Timer1.enabled);
end;

procedure TForm1.FormDestroy(Sender: TObject);
begin
  paintImg.Free;
  ZeichenPanel.Free;
  ZellList.Destroy;
end;

end.

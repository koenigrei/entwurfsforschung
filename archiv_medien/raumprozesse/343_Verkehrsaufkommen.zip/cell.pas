unit cell;

interface

uses
  Windows, Graphics, Classes, Math;

type
  TWorker = Record
    workPlace : TPoint;             //-- the place of work
    route     : TList;              //-- the route to work
    transport : Boolean;            //-- kind of the transport medium (public or privat)
    departM   : Extended;           //-- morning
    departE   : Extended;           //-- evening
  end;

type
  TCell = class
  private
  {privates}
  public
    nearNode   : Cardinal;          //-- the number of the nerarest node form the AgentList
    Worker     : Array of TWorker;
    tmpInfo    : Array[0..2] of Byte;
    noWorker   : Byte;              //-- Anzahl der Arbeiter
    noWorkPl   : Byte;              //-- Anzahl der Arbeitspl�tze
    noRetail   : Byte;              //-- Anazhl der Einzelhandels Einheiten
    colr       : TColor;            //-- Farbwert der Zelle
    FPos       : TPoint;
    Koord      : TPoint;
    FSize      : Integer;
    FFillColor : Integer;
    FState     : Integer;           //-- Status speichert die Anzahl der Agenten auf Zelle
    procedure Paint         (Canvas: TCanvas);
    procedure SetPositionX  (const Value: Integer);
    procedure SetPositionY  (const Value: Integer);
    procedure SetSize       (const Value: Integer);
    procedure SetFillColor  (const Value: Integer);
    procedure SetState      (const Value: Integer);
    constructor create      (xPos, yPos, size, colr: Integer);
  published
    property PositionX: Integer read FPos.X     write SetPositionX;
    property PositionY: Integer read FPos.Y     write SetPositionY;
    property Size     : Integer read FSize      write SetSize;
    property FillColor: Integer read FFillColor write SetFillColor;
    property State    : Integer read FState     write SetState;
  end;

//==============================================================================

implementation

constructor TCell.create(xPos, yPos, size, colr: Integer);
begin
  inherited create;
  FPos.X := xPos;
  FPos.Y := yPos;
  FSize  := size;
  FFillColor := colr;
end;

//------------------------------------------------------------------------------

procedure TCell.SetPositionX(const Value: Integer);
begin
  FPos.X := Value;
end;

procedure TCell.SetPositionY(const Value: Integer);
begin
  FPos.Y := Value;
end;

procedure TCell.SetSize(const Value: Integer);
begin
  FSize := Value;
end;

procedure TCell.SetFillColor(const Value: Integer);
begin
  FFillColor := Value;
end;

procedure TCell.SetState(const Value: Integer);
begin
  FState := Value;
end;

procedure TCell.Paint(Canvas: TCanvas);
var col:Integer;
begin
  Canvas.Pen.Width   := 0;
  Canvas.Pen.Color   := clSilver; //clgray;
  Canvas.Brush.Color := colr;     //RGB (colr, colr, colr);
  Canvas.Rectangle (FPos.X - FSize , FPos.Y - FSize, FPos.X + FSize, FPos.Y + FSize);
end;

end.

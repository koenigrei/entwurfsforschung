object Form2: TForm2
  Left = 0
  Top = 0
  Caption = 'Form2'
  ClientHeight = 300
  ClientWidth = 890
  Color = clBtnFace
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -11
  Font.Name = 'Tahoma'
  Font.Style = []
  OldCreateOrder = False
  PixelsPerInch = 96
  TextHeight = 13
  object Chart_Fahrtzeiten: TChart
    Left = 0
    Top = 0
    Width = 889
    Height = 297
    BackWall.Brush.Color = clWhite
    BackWall.Brush.Style = bsClear
    Border.Visible = True
    Gradient.Balance = 99
    Gradient.Direction = gdFromTopLeft
    Gradient.EndColor = 753908
    Gradient.MidColor = 16059031
    Gradient.StartColor = 14540754
    Legend.Visible = False
    Title.Text.Strings = (
      'Fahrtzeiten'
      '')
    BottomAxis.Automatic = False
    BottomAxis.AutomaticMaximum = False
    BottomAxis.AutomaticMinimum = False
    BottomAxis.Maximum = 24.000000000000000000
    BottomAxis.Title.Caption = 'Uhrzeit'
    DepthAxis.Automatic = False
    DepthAxis.AutomaticMaximum = False
    DepthAxis.AutomaticMinimum = False
    DepthAxis.Maximum = 0.500000000000000000
    DepthAxis.Minimum = -0.500000000000000000
    DepthTopAxis.Automatic = False
    DepthTopAxis.AutomaticMaximum = False
    DepthTopAxis.AutomaticMinimum = False
    DepthTopAxis.Maximum = 0.500000000000000000
    DepthTopAxis.Minimum = -0.500000000000000000
    LeftAxis.ExactDateTime = False
    LeftAxis.Grid.Visible = False
    LeftAxis.MinorGrid.Color = clSilver
    LeftAxis.MinorGrid.Style = psDot
    LeftAxis.MinorGrid.SmallDots = True
    LeftAxis.MinorGrid.Visible = True
    LeftAxis.MinorTickCount = 1
    LeftAxis.Title.Caption = 'Abfahrten'
    RightAxis.Title.Caption = 'segregation index'
    TopAxis.Automatic = False
    TopAxis.AutomaticMaximum = False
    TopAxis.AutomaticMinimum = False
    TopAxis.Visible = False
    View3D = False
    Zoom.UpLeftZooms = True
    Color = clWhite
    TabOrder = 0
    object PSerTime: TPointSeries
      Marks.Callout.Brush.Color = clBlack
      Marks.Callout.Length = 8
      Marks.Visible = False
      ClickableLine = False
      Pointer.HorizSize = 2
      Pointer.InflateMargins = True
      Pointer.Style = psCircle
      Pointer.VertSize = 2
      Pointer.Visible = True
      XValues.Name = 'X'
      XValues.Order = loAscending
      YValues.Name = 'Y'
      YValues.Order = loNone
    end
    object PageNumTool2: TPageNumTool
      Active = False
      Callout.Brush.Color = clBlack
      Callout.Arrow.Visible = False
      Text = 'Page %d of %d'
      Format = 'Page %d of %d'
    end
    object ChartTool1: TColorLineTool
      AllowDrag = False
      Draw3D = False
      DrawBehind = True
      Pen.Color = 16744448
      Pen.Width = 5
      Pen.EndStyle = esSquare
      Value = 11.000000000000000000
      AxisID = 0
    end
  end
end

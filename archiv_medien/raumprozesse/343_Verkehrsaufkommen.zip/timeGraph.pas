unit timeGraph;

interface

uses
  Windows, Messages, SysUtils, Variants, Classes, Graphics, Controls, Forms,
  Dialogs, TeEngine, TeeTools, TeePageNumTool, Series, ExtCtrls, TeeProcs, Chart;

type
  TForm2 = class(TForm)
    Chart_Fahrtzeiten : TChart;
    PageNumTool2      : TPageNumTool;
    PSerTime          : TPointSeries;
    ChartTool1        : TColorLineTool;
  private
    { Private-Deklarationen }
  public
    { Public-Deklarationen }
  end;

var
  Form2: TForm2;

implementation

{$R *.dfm}

end.

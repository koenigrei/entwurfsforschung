object Form1: TForm1
  Left = 0
  Top = 0
  Caption = 'traffic rhythms'
  ClientHeight = 666
  ClientWidth = 890
  Color = clBtnFace
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -11
  Font.Name = 'Tahoma'
  Font.Style = []
  OldCreateOrder = False
  OnClose = FormClose
  OnCreate = FormCreate
  PixelsPerInch = 96
  TextHeight = 13
  object Image_Cells: TImage
    Left = 0
    Top = 0
    Width = 640
    Height = 666
    Align = alLeft
  end
  object TabControl1: TTabControl
    Left = 640
    Top = 0
    Width = 250
    Height = 666
    Align = alRight
    TabOrder = 0
    object GroupBox1: TGroupBox
      Left = 5
      Top = 3
      Width = 242
      Height = 166
      Caption = 'setup'
      TabOrder = 0
      object Lbl_worker: TLabel
        Left = 123
        Top = 101
        Width = 52
        Height = 13
        Caption = 'Lbl_worker'
      end
      object Lbl_workPl: TLabel
        Left = 123
        Top = 120
        Width = 50
        Height = 13
        Caption = 'Lbl_workPl'
      end
      object Lbl_retail: TLabel
        Left = 123
        Top = 139
        Width = 43
        Height = 13
        Caption = 'Lbl_retail'
      end
      object Label1: TLabel
        Left = 181
        Top = 13
        Width = 46
        Height = 13
        Caption = 'cell scale:'
      end
      object Label2: TLabel
        Left = 20
        Top = 101
        Width = 97
        Height = 13
        Caption = 'Arbeitsbev'#246'lkerung:'
      end
      object Label3: TLabel
        Left = 50
        Top = 120
        Width = 67
        Height = 13
        Caption = 'Arbeitspl'#228'tze:'
      end
      object Label4: TLabel
        Left = 5
        Top = 139
        Width = 112
        Height = 13
        Caption = 'Einzelhandelseinheiten:'
      end
      object B_loadData: TButton
        Left = 3
        Top = 55
        Width = 75
        Height = 25
        Caption = 'load data'
        TabOrder = 0
        OnClick = B_loadDataClick
      end
      object B_lineWork: TButton
        Left = 84
        Top = 55
        Width = 75
        Height = 25
        Caption = 'lines to work'
        TabOrder = 1
        OnClick = B_lineWorkClick
      end
      object B_deleteAll: TButton
        Left = 3
        Top = 24
        Width = 75
        Height = 25
        Caption = 'delete all'
        TabOrder = 2
        OnClick = B_deleteAllClick
      end
      object B_setup: TButton
        Left = 84
        Top = 24
        Width = 75
        Height = 25
        Caption = 'new setup'
        TabOrder = 3
        OnClick = FormCreate
      end
      object E_cellScale: TEdit
        Left = 181
        Top = 26
        Width = 53
        Height = 21
        TabOrder = 4
        Text = '30'
      end
      object RadioGroup1: TRadioGroup
        Left = 179
        Top = 64
        Width = 58
        Height = 95
        Caption = 'show'
        TabOrder = 5
      end
      object RB_sAll: TRadioButton
        Left = 185
        Top = 83
        Width = 43
        Height = 15
        Caption = 'all'
        Checked = True
        TabOrder = 6
        TabStop = True
        OnClick = RB_sAllClick
      end
      object RB_sRed: TRadioButton
        Left = 185
        Top = 99
        Width = 43
        Height = 17
        Caption = 'red'
        TabOrder = 7
        OnClick = RB_sAllClick
      end
      object RB_sGreen: TRadioButton
        Left = 185
        Top = 118
        Width = 50
        Height = 17
        Caption = 'green'
        TabOrder = 8
        OnClick = RB_sAllClick
      end
      object RB_sBlue: TRadioButton
        Left = 185
        Top = 137
        Width = 43
        Height = 17
        Caption = 'blue'
        TabOrder = 9
        OnClick = RB_sAllClick
      end
    end
    object GroupBox3: TGroupBox
      Left = 5
      Top = 415
      Width = 242
      Height = 122
      Caption = 'traffic'
      TabOrder = 1
      object Label14: TLabel
        Left = 135
        Top = 44
        Width = 67
        Height = 13
        Caption = 'timer interval:'
      end
      object Label11: TLabel
        Left = 151
        Top = 17
        Width = 51
        Height = 13
        Caption = 'scale: no./'
      end
      object Label15: TLabel
        Left = 115
        Top = 74
        Width = 83
        Height = 13
        Caption = 'time scale: hour /'
      end
      object Label16: TLabel
        Left = 141
        Top = 95
        Width = 61
        Height = 13
        Caption = 'time scale = '
      end
      object Lal_min: TLabel
        Left = 204
        Top = 95
        Width = 16
        Height = 13
        Caption = 'min'
      end
      object B_startT: TButton
        Left = 5
        Top = 27
        Width = 75
        Height = 25
        Caption = 'startTimer'
        TabOrder = 0
        OnClick = B_startTClick
      end
      object B_oneStep: TButton
        Left = 5
        Top = 58
        Width = 75
        Height = 25
        Caption = 'oneStep'
        TabOrder = 1
        OnClick = B_oneStepClick
      end
      object E_tInterv: TEdit
        Left = 204
        Top = 40
        Width = 30
        Height = 21
        TabOrder = 2
        Text = '1'
        OnChange = E_tIntervChange
      end
      object E_tScale: TEdit
        Left = 204
        Top = 13
        Width = 30
        Height = 21
        TabOrder = 3
        Text = '10'
      end
      object E_timeScale: TEdit
        Left = 204
        Top = 70
        Width = 30
        Height = 21
        TabOrder = 4
        Text = '6'
        OnChange = E_timeScaleChange
      end
    end
    object GroupBox4: TGroupBox
      Left = 5
      Top = 302
      Width = 242
      Height = 107
      Caption = 'commutation to and from work'
      TabOrder = 2
      object Label6: TLabel
        Left = 173
        Top = 30
        Width = 23
        Height = 13
        Caption = 'STD:'
      end
      object Label7: TLabel
        Left = 129
        Top = 52
        Width = 67
        Height = 13
        Caption = 'morning dep.:'
      end
      object Label8: TLabel
        Left = 131
        Top = 76
        Width = 65
        Height = 13
        Caption = 'evenng dep.:'
      end
      object B_workPath: TButton
        Left = 3
        Top = 24
        Width = 75
        Height = 25
        Caption = 'workers path'
        TabOrder = 0
        OnClick = B_workPathClick
      end
      object E_STD: TEdit
        Left = 202
        Top = 26
        Width = 29
        Height = 21
        TabOrder = 1
        Text = '1,0'
      end
      object B_findPath: TButton
        Left = 84
        Top = 24
        Width = 75
        Height = 25
        Caption = 'find path'
        TabOrder = 2
        OnClick = B_findPathClick
      end
      object B_showGraph: TButton
        Left = 3
        Top = 79
        Width = 75
        Height = 25
        Caption = 'show graph1'
        TabOrder = 3
        OnClick = B_showGraphClick
      end
      object E_mDep: TEdit
        Left = 202
        Top = 49
        Width = 29
        Height = 21
        TabOrder = 4
        Text = '8'
      end
      object E_eDep: TEdit
        Left = 202
        Top = 73
        Width = 29
        Height = 21
        TabOrder = 5
        Text = '17'
      end
    end
    object GroupBox2: TGroupBox
      Left = 3
      Top = 175
      Width = 242
      Height = 121
      Caption = 'graph'
      TabOrder = 3
      object Label5: TLabel
        Left = 84
        Top = 30
        Width = 40
        Height = 13
        Caption = 'number:'
      end
      object Label12: TLabel
        Left = 3
        Top = 98
        Width = 85
        Height = 13
        Caption = 'connect distance:'
      end
      object Label13: TLabel
        Left = 133
        Top = 98
        Width = 71
        Height = 13
        Caption = 'repel distance:'
      end
      object B_agCreate: TButton
        Left = 3
        Top = 24
        Width = 75
        Height = 25
        Caption = 'agents create'
        TabOrder = 0
        OnClick = B_agCreateClick
      end
      object E_nodeNumber: TEdit
        Left = 130
        Top = 26
        Width = 29
        Height = 21
        TabOrder = 1
        Text = '41'
      end
      object B_agDelete: TButton
        Left = 84
        Top = 55
        Width = 75
        Height = 25
        Caption = 'agents delete'
        TabOrder = 2
        OnClick = B_agDeleteClick
      end
      object E_conDist: TEdit
        Left = 90
        Top = 94
        Width = 29
        Height = 21
        TabOrder = 3
        Text = '130'
        OnChange = E_conDistChange
      end
      object E_repDist: TEdit
        Left = 206
        Top = 94
        Width = 29
        Height = 21
        TabOrder = 4
        Text = '40'
        OnChange = E_conDistChange
      end
    end
    object GroupBox5: TGroupBox
      Left = 6
      Top = 543
      Width = 242
      Height = 90
      Caption = 'dynamic'
      TabOrder = 4
      object Label9: TLabel
        Left = 105
        Top = 15
        Width = 24
        Height = 13
        Caption = 'time:'
      end
      object Lbl_time: TLabel
        Left = 135
        Top = 15
        Width = 20
        Height = 13
        Caption = 'time'
      end
      object Label10: TLabel
        Left = 96
        Top = 34
        Width = 33
        Height = 13
        Caption = 'traffic:'
      end
      object lbl_onRoad: TLabel
        Left = 135
        Top = 34
        Width = 37
        Height = 13
        Caption = 'onRoad'
      end
      object Label17: TLabel
        Left = 99
        Top = 63
        Width = 30
        Height = 13
        Caption = 'steps:'
      end
      object Lbl_steps: TLabel
        Left = 135
        Top = 63
        Width = 26
        Height = 13
        Caption = 'steps'
      end
    end
  end
  object Timer1: TTimer
    Enabled = False
    Interval = 1
    OnTimer = Timer1Timer
    Left = 600
    Top = 632
  end
end

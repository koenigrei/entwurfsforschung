(********************************************************************)
(*                                                                  *)
(*                         Verkersmodell                            *)
(*                          Version 1.0                             *)
(*                                                                  *)
(*     Programmierer: Reinhard K�nig                   January 2007 *)
(*                    http://www.entwurfsforschung.de               *)
(*                                                                  *)
(*     Last Update: Jan-07, 2007                                    *)
(*                                                                  *)
(********************************************************************) 
{revision history:

1.0     [Jan-07, 2007]
        first operational release!
}

unit Main;

interface

uses
  Windows, Messages, SysUtils, Variants, Classes, Graphics, Controls, Forms, timeGraph,
  Dialogs, ExtCtrls, ComCtrls, cell, math, ImgList, StdCtrls, agent, calc_AStern;

type
  TRGBTripleCol = TRGBTriple;       //-- 32768 = maximale Anzahl der Pixel in der Breite eines Bildes (also eine "ScanLine")
  pRGBTripleCol = ^TRGBTripleCol;   //-- Pointer auf TRGBTripleArray

type
  TForm1 = class(TForm)
    TabControl1 : TTabControl;
    Image_Cells : TImage;
    Timer1      : TTimer;
    GroupBox1   : TGroupBox;
    B_loadData  : TButton;
    B_lineWork  : TButton;
    Lbl_worker  : TLabel;
    Lbl_workPl  : TLabel;
    Lbl_retail  : TLabel;
    B_deleteAll : TButton;
    B_setup     : TButton;
    Label1      : TLabel;
    E_cellScale : TEdit;
    Label2      : TLabel;
    Label3      : TLabel;
    Label4      : TLabel;
    GroupBox3   : TGroupBox;
    B_startT    : TButton;
    B_oneStep   : TButton;
    GroupBox4   : TGroupBox;
    B_workPath  : TButton;
    Label6      : TLabel;
    E_STD       : TEdit;
    B_findPath  : TButton;
    B_showGraph : TButton;
    E_mDep      : TEdit;
    Label7      : TLabel;
    Label8      : TLabel;
    E_eDep      : TEdit;
    GroupBox2   : TGroupBox;
    Label5      : TLabel;
    B_agCreate  : TButton;
    E_nodeNumber: TEdit;
    B_agDelete  : TButton;
    GroupBox5   : TGroupBox;
    Label9      : TLabel;
    Lbl_time    : TLabel;
    Label10     : TLabel;
    lbl_onRoad  : TLabel;
    E_conDist   : TEdit;
    Label12     : TLabel;
    Label13     : TLabel;
    E_repDist   : TEdit;
    Label14     : TLabel;
    E_tInterv   : TEdit;
    Label11     : TLabel;
    E_tScale    : TEdit;
    Label15     : TLabel;
    E_timeScale : TEdit;
    Label16: TLabel;
    Lal_min: TLabel;
    Label17: TLabel;
    Lbl_steps: TLabel;
    RadioGroup1: TRadioGroup;
    RB_sAll: TRadioButton;
    RB_sRed: TRadioButton;
    RB_sGreen: TRadioButton;
    RB_sBlue: TRadioButton;
    procedure FormCreate        (Sender: TObject);
    procedure B_loadDataClick   (Sender: TObject);
    procedure B_agCreateClick   (Sender: TObject);
    procedure B_findPathClick   (Sender: TObject);
    procedure B_lineWorkClick   (Sender: TObject);
    procedure B_workPathClick   (Sender: TObject);
    procedure B_showGraphClick  (Sender: TObject);
    procedure Timer1Timer       (Sender: TObject);
    procedure B_startTClick     (Sender: TObject);
    procedure B_oneStepClick    (Sender: TObject);
    procedure B_agDeleteClick   (Sender: TObject);
    procedure B_deleteAllClick  (Sender: TObject);
    procedure E_conDistChange   (Sender: TObject);
    procedure E_tIntervChange   (Sender: TObject);
    procedure FormClose         (Sender: TObject; var Action: TCloseAction);
    procedure E_timeScaleChange (Sender: TObject);
    procedure RB_sAllClick(Sender: TObject);
  private
    cellList   : Array of Array of TCell;
    WorkerList : TList;
    workPlList : TList;
    RetailList : TList;
    PfadList   : TList;
    TravelList : TList;
    procedure Setup;
    procedure CellsCreate;
    procedure CellsSetup;
    procedure CellsPaint;
    procedure BmpInfoRead;
    procedure AssignWorkers;
    procedure LineToWork;
    procedure AgentsCreate;
    procedure AgentsPaint;
    procedure Ag_clearBack;
    procedure Image_AgentsCreate;
    procedure Agents_Organise;
    procedure Verbinden;
    procedure drawPath;
    procedure drawTraffic;
    procedure NodesListSetup;
    procedure CellsNearNode;
    procedure CellsPathToWork;
    procedure KantenDim;
    procedure KantenReset;
    procedure WorkDeparture;
    procedure execute;
    procedure travel;
    procedure deleteAll;
    procedure torus             (var Xp: Integer; var Yp: Integer);
  public

  end;

var
  AgentList    : TList;
  Form1        : TForm1;
  Image_Agents : TImage;
  reih         : Integer;                     //-- Zellen-Reihen gesamt
  spalt        : Integer;                     //-- Zellen-Spalten gesamt
  cellScal     : Integer;                     //-- Zellen  gr��e
  halfScal     : Integer;
  tester       : Integer;
  oldPos       : Array of Array of Integer;
  limboPos     : Array of Array of Double;
  time, rTime  : Double;
  steps        : Cardinal;
  timeSca      : ShortInt;                    //-- time scale   = 60/X
  globSca      : SmallInt;                    //-- global scale = 24*X
  leftBorder, bottomBorder : Integer;

implementation

{$R *.dfm}

//======================================================================== setup
procedure TForm1.Setup;
begin
  cellScal   := StrToInt(E_cellScale.Text);
  spalt      := floor (Image_Cells.Width  / cellScal);
  reih       := floor (Image_Cells.Height / cellScal);
  leftBorder := spalt * cellScal;
  bottomBorder:= reih  * cellScal;
  halfScal   := floor (cellScal/2);
  SetLength  (cellList, spalt, reih);
  WorkerList := TList.Create;
  workPlList := TList.Create;
  RetailList := TList.Create;
  AgentList  := TList.Create;
  PfadList   := TList.Create;
  TravelList := TList.Create;
  Image_AgentsCreate;
  CellsCreate;
  CellsSetup;
end;

//=========================================================Fahrtzeiten erstellen
procedure TForm1.WorkDeparture;
var
  curCell     : TCell;
  I, K, M,idx : Integer;
  tmpVals     : Array of Real;
  STD, mD, eD : Single;
begin
  STD := StrToFloat(E_STD.Text);
  mD  := StrToFloat(E_mDep.Text);
  eD  := StrToFloat(E_eDep.Text);
  SetLength(tmpVals, 240);
  for I := 0 to reih -1 do
  begin
    for K := 0 to spalt -1 do
    begin
      curCell := cellList[K,I];
      For M := 0 to length(curCell.Worker)-1 Do
      begin
        curCell.Worker[M].departM := roundTo(RandG(mD, STD),-1);             // morgentliche Fahrten zur Arbeit
        idx :=  round(curCell.Worker[M].departM * 10);
        tmpVals[idx] := tmpVals[idx]+1;
        curCell.Worker[M].departE := roundTo(RandG(eD, STD),-1);             // abendliche Fahrten nach Hause
        idx :=  round(curCell.Worker[M].departE * 10);
        tmpVals[idx] := tmpVals[idx]+1;
      end;
    end;
  end;
  Form2.PSerTime.Clear;
  For I := 0 to Length(tmpVals) -1 Do
  begin
    Form2.PSerTime.AddXY((I/10),tmpVals[I]);
  end;
end;

//=========================================================Kanten dimensionieren
procedure TForm1.KantenDim;
var
  curNode : TAgent;
  I       : Integer;
begin
  For I :=  0 to AgentList.Count -1 Do
  begin
    curNode := AgentList.Items[I];
    SetLength(curNode.Usage, AgentList.Count);                               // Usage-Adressen der Nodes dimensionieren
  end;
end;

//===========================================================Kanten zur�cksetzen
procedure TForm1.KantenReset;
var
  curNode : TAgent;
  I, K    : Integer;
begin
  For I :=  0 to AgentList.Count -1 Do
  begin
    curNode := AgentList.Items[I];
    For K := 0 to AgentList.Count -1 Do
    begin
      curNode.Usage[K] := 0;
    end;
  end;
end;

//===================================================k�rzesten Arbeitsweg suchen
procedure TForm1.CellsPathToWork;
var
  curCell, toCell     : TCell;
  I, K, M             : Integer;
  startNode, zielNode : TAgent;
begin
  for I := 0 to reih -1 do
  begin
    for K := 0 to spalt -1 do
    begin
      curCell := cellList[K,I];
      for M := 0 to length(curCell.Worker) - 1 do
      begin
        curCell.Worker[M].route := TList.Create;
        NodesListSetup;
        startNode := AgentList.Items[curCell.nearNode];
        toCell    := cellList[curCell.Worker[M].workPlace.X, curCell.Worker[M].workPlace.Y];
        zielNode  := AgentList.Items[toCell.nearNode];
        findPath (pfadList, startNode, zielNode);
        curCell.Worker[M].route.Assign(pfadList);                            // copy the pfadList to the worker.route
      end;
    end;
  end;
end;

//===========================================================setup the AgentList
procedure TForm1.NodesListSetup;
var
  curNode  : TAgent;
  I        : Integer;
begin
  pfadList.Free;
  pfadList := TList.Create;
  for I := 0 to AgentList.Count-1 do
  begin
    curNode := AgentList.Items [I];
    curNode.F:= 0;
    curNode.G:= 0;
    curNode.H:= 0;
    curNode.closed := false;
  end;
end;

//===============================================================organise Agents
procedure TForm1.Agents_Organise;
var
  J        : Integer;
  CurAgent : TAgent;
begin
  SetLength(limboPos, AgentList.Count, 2);                                   // definiert die Gr��e der LimboPos
  SetLength(oldPos, AgentList.Count, 2);                                     // definiert die Gr��e der oldPos
  for J := 0 to AgentList.Count - 1 do
  begin
    CurAgent := AgentList.Items [J];                                         // Alte Positionen Speichern
    oldPos[J][0] := CurAgent.PositionX;
    oldPos[J][1] := CurAgent.PositionY;
    begin
      CurAgent.NeigborCheck (J, limboPos[J]);                                // Berechnet die Nachbarn
    end;
    CurAgent.PositionX := CurAgent.FPositionX + round(CurAgent.FStepX);
    CurAgent.PositionY := CurAgent.FPositionY + round(CurAgent.FStepY);
    torus (CurAgent.FPositionX, CurAgent.FPositionY);
  end;
end;

//==============================================================clear background
procedure TForm1.Ag_clearBack;
begin
  Image_Agents.Canvas.Brush.Color := clBlack;
  Image_Agents.Canvas.Pen.Color   := clBlack;
  Image_Agents.Canvas.Pen.Width   := 1;
  Image_Agents.Canvas.Rectangle (0, 0, Image_Cells.width,Image_Cells.height);
end;
//==============================================================Agenten zeichnen
procedure TForm1.AgentsPaint;
var
  I        : Integer;
  CurAgent : TAgent;
begin
  Image_Agents.Canvas.Pen.Width   := 1;
  for I := 0 to AgentList.Count - 1 do                                       // repaint each agent of the list
  begin
    CurAgent := AgentList.Items [I];
    CurAgent.Paint (Image_Agents.Canvas);
  end;
end;

//===============================================================Zellen zeichnen
procedure TForm1.CellsPaint;
var I, K : Integer;
    curCell : TCell;
    ColInfo : Array[0..2] of Byte;
begin
  for I := 0 to reih -1 do
  begin
    for K := 0 to spalt -1 do
    begin
      curCell := cellList[K,I];
      If RB_sAll.Checked Then begin
        ColInfo[0] := curCell.noWorker;
        ColInfo[1] := curCell.noWorkPl;
        ColInfo[2] := curCell.noRetail;
      end else If RB_sRed.Checked Then begin
        ColInfo[0] := curCell.noWorker;
        ColInfo[1] := 0;
        ColInfo[2] := 0;
      end else If RB_sGreen.Checked Then begin
        ColInfo[0] := 0;
        ColInfo[1] := curCell.noWorkPl;
        ColInfo[2] := 0;
      end else If RB_sBlue.Checked Then begin
        ColInfo[0] := 0;
        ColInfo[1] := 0;
        ColInfo[2] := curCell.noRetail;
      end;
      curCell.colr := RGB(ColInfo[0], ColInfo[1], ColInfo[2]);
      curCell.Paint(Image_Cells.Canvas);
    end;
  end;
end;

//=====================================================Verbinde n�chste Nachbarn
procedure TForm1.Verbinden;
var
  J, K     : Integer;
  curAgent : TAgent;
begin
  Image_Agents.Canvas.Pen.Color := clRed;
  Image_Agents.Canvas.Pen.Style := psSolid;
  for J := 0 to AgentList.Count -1 do
  begin
    curAgent := AgentList.Items [J];
    Image_Agents.Canvas.Pen.Width := 1;
    K := 0;
    While  K < length(curAgent.NachbList) Do
    Begin
      Image_Agents.Canvas.Pen.Width := 2;// 1 + round(AShape.Usage[AShape.NachbList[K].Nr]/10);
      Image_Agents.Canvas.MoveTo(oldPos[J][0], oldPos[J][1]);                // Verbindungen mit oldPosition zeichnen
      Image_Agents.Canvas.LineTo(oldPos[curAgent.NachbList[K].Nr][0], oldPos[curAgent.NachbList[K].Nr][1]);
      K := K + 1;
    end;
  end;
end;

//========================================================================= step
procedure TForm1.execute;
var I, K, M, J, idx : Integer;
    curCell         : TCell;
    curTrav         : TTraveller;
    tmpAgent        : TAgent;
begin
  inc(steps);
  time := SimpleRoundTo(((steps mod globSca)/timeSca),-2);
  for I := 0 to reih -1 do
  begin
    for K := 0 to spalt -1 do
    begin
      curCell := cellList[K,I];
      //------------------------------------------------------------------------which agents start travelling
      For M := 0 to length(curCell.Worker)-1 Do
      begin
        IF InRange(curCell.Worker[M].departE, rTime+0.01, time) = true Then // start a travel agent
        begin                                                               // for the way home
          If (curCell.Worker[M].route.Count > 1) Then
          begin
            curTrav          := TTraveller.Create;
            curTrav.path     := TList.Create;
            curTrav.path.Assign(curCell.Worker[M].route);
            curTrav.aktNode  := curTrav.path.Items[0];
            curTrav.vorgNode := nil;
            curTrav.dir      := false;
            TravelList.Add(curTrav);
          end;
        end else
        IF InRange(curCell.Worker[M].departM, rTime+0.01, time) = true Then  // start a travel agent
        begin                                                                // for the way to work
          If (curCell.Worker[M].route.Count > 1) Then
          begin
            curTrav          := TTraveller.Create;
            curTrav.path     := TList.Create;
            idx              := curCell.Worker[M].route.Count -1;
            For J := 0 To idx Do
            begin
              tmpAgent := curCell.Worker[M].route[idx-J];                    // reverse the path
              curTrav.path.Add(tmpAgent);
            end;
            curTrav.aktNode  := curTrav.path.Items[0];
            curTrav.vorgNode := nil;
            curTrav.dir      := true;
            TravelList.Add(curTrav);
          end;
        end;
      end;
    end;
  end;
  lbl_onRoad.Caption := IntToStr(TravelList.Count);
  travel;
  Lbl_time.Caption := FloatToStr(time);
  Lbl_steps.Caption := IntToStr(steps);
  rTime := time;
  Form2.ChartTool1.Value := time;
end;

//========================================================================travel
procedure TForm1.travel;
var idx, pathInd, vorgIdx, M : Integer;
    curTrav                  : TTraveller;
    AShape, BShape, lastNode : TAgent;
    delList                  : TList;
begin
  delList := TList.Create;
  For M := 0 to TravelList.Count-1 Do //----------------------------------------agent's travel is calculated stepwise
  begin
    curTrav := TravelList.Items[M];
    AShape  := curTrav.aktNode;                                              // where the traveller come from
    idx     := AgentList.IndexOf(AShape);
    pathInd := curTrav.path.IndexOf(AShape);
    BShape  := curTrav.path.Items[pathInd+1];                                // next step in the path = where the traveller go to
    inc(BShape.Usage[idx]);//                                                // mark the used edge
    If Not(curTrav.vorgNode = nil) Then begin
      vorgIdx := AgentList.IndexOf(curTrav.vorgNode);
      dec(AShape.Usage[vorgIdx]);                                            // previous edge not used any more
    end;
    lastNode := curTrav.path.Last;
    If BShape = lastNode Then
    begin
      delList.Add(curTrav);
    end;
    curTrav.aktNode := BShape;
    curTrav.vorgNode:= AShape;
  end;
  
  For M := 0 To delList.Count -1 Do                                          // delete travellers that arrive the destination
  begin
    curTrav := delList.Items[M];
    vorgIdx := AgentList.IndexOf(curTrav.vorgNode);
    AShape  := curTrav.aktNode;
    dec(AShape.Usage[vorgIdx]);                                              // previous edge not used any more
    idx     := TravelList.IndexOf(curTrav);
    curTrav := TravelList.Items[idx];
    curTrav.Free;
    TravelList.Delete(idx);
  end;
  delList.Free;
  Ag_clearBack;
  drawTraffic;
  Verbinden;                                                                 // repaint the graph
  AgentsPaint;
end;

//===================================================draw all the pathes at once
procedure TForm1.drawTraffic;
var
  J, K ,tScale     : Integer;
  curAgent, AShape : TAgent;
begin
  tScale := StrToInt(E_tScale.Text);
  Image_Agents.Canvas.Pen.Color := clYellow;
  Image_Agents.Canvas.Pen.Style := psSolid;
  for J := 0 to AgentList.Count -1 do
  begin
    curAgent := AgentList.Items [J];
    AShape   := AgentList.Items [J];
    Image_Agents.Canvas.Pen.Width := 1;
    K := 0;
    While  K < length(curAgent.NachbList) Do
    Begin
      Image_Agents.Canvas.Pen.Width := 2 + ceil(AShape.Usage[AShape.NachbList[K].Nr]/tScale);
      Image_Agents.Canvas.MoveTo(oldPos[J][0], oldPos[J][1]);                // Verbindungen mit oldPosition zeichnen
      Image_Agents.Canvas.LineTo(oldPos[curAgent.NachbList[K].Nr][0], oldPos[curAgent.NachbList[K].Nr][1]);
      K := K + 1;
    end;
  end;
end;

//============================================================draw a single path
procedure TForm1.drawPath;
var
  AShape, BShape : TAgent;
  idx            : Integer;
  lastNode       : TAgent;
begin
  If pfadList.Count > 1 Then begin
    Image_Agents.Canvas.Pen.Color := clYellow;
    Image_Agents.Canvas.Pen.Style := psSolid;
    lastNode := pfadList.Last;
    AShape   := pfadList.Items [0];
    While Not (AShape = lastNode) Do
    begin
      BShape := AShape.vorg;
      idx    := AgentList.IndexOf(AShape);
      inc(BShape.Usage[idx]);
      Image_Agents.Canvas.Pen.Width := 1+ round(BShape.Usage[idx]) ;
      Image_Agents.Canvas.MoveTo(AShape.PositionX, AShape.PositionY);
      Image_Agents.Canvas.LineTo(BShape.PositionX, BShape.PositionY);
      AShape := AShape.vorg;
    end
  end;
end;

//============================================================Image_AgentsCreate
procedure TForm1.Image_AgentsCreate;
begin
  Image_Agents := TImage.Create(self);
  Image_Agents.Parent := Form1;
  Image_Agents.top    := 0;
  Image_Agents.Left   := 0;
  Image_Agents.Width  := Image_Cells.Width;
  Image_Agents.Height := Image_Cells.Height;
  Image_Agents.Transparent := True;
  Image_Agents.Enabled:= False;
  Form1.DoubleBuffered := True;
  Image_Agents.Canvas.Brush.Color := clBlack;
  Image_Agents.Canvas.Rectangle (0 , 0, Image_Cells.width,Image_Cells.height);
end;

//==============================================================Zellen erstellen
procedure TForm1.CellsCreate;
var
  curCell : TCell;
  I       : Integer;
  K       : Integer;
  creaPt  : TPoint;
begin
  for I := 0 to reih -1 do
  begin
    for K := 0 to spalt -1 do
    begin
      creaPt.X := halfScal + K * cellScal;
      creaPt.Y := halfScal + I * cellScal;
      curCell  := TCell.Create(creaPt.X, creaPt.Y, halfScal, 0);
      cellList[K,I] := curCell;
    end;
  end;
end;

//=========================================================Zellen initialisieren
procedure TForm1.CellsSetup;
var
  curCell : TCell;
  I, K    : Integer;
begin
  for I := 0 to reih -1 do
  begin
    for K := 0 to spalt -1 do
    begin
      curCell         := cellList[K,I];
      curCell.colr    := RGB(255, 255, 255);
      //curCell.state   := 0;
      curCell.Koord.X := K;
      curCell.Koord.Y := I;
      curCell.Paint(Image_Cells.Canvas);
    end;
  end;
end;

//========================================================n�chsten Knoten suchen
procedure TForm1.CellsNearNode;
var
  curCell          : TCell;
  curAgent         : TAgent;
  I, K, M          : Integer;
  minDist, tmpDist : Integer;
begin
  for I := 0 to reih -1 do
  begin
    for K := 0 to spalt -1 do
    begin
      minDist := 999999;
      curCell := cellList[K,I];
      For M:=0 To AgentList.Count -1 Do
      begin
        curAgent := AgentList.Items[M];
        tmpDist  := distance (curCell.PositionX, curCell.PositionY, curAgent.PositionX ,curAgent.PositionY);
        If tmpDist < minDist Then
        begin
          minDist := tmpDist;
          curCell.nearNode := M;
        end;
      end;
    end;
  end;
end;

//=================================================================create agents
procedure TForm1.AgentsCreate;
var
  I        : Integer;
  CurAgent : TAgent;
begin
  For I := 0 To StrToInt(E_nodeNumber.Text) Do
  begin
  CurAgent           := TAgent.Create;
  CurAgent.PositionX :=  random(Image_Cells.width);
  CurAgent.PositionY :=  random(Image_Cells.height);
  CurAgent.StepX     := (random(3) - 1);
  CurAgent.StepY     := (random(3) - 1);
  CurAgent.Size      := 3;
  CurAgent.Connect   := 0;
  CurAgent.State     := 0;
  CurAgent.AnlDist   := 130;
  CurAgent.RepelDist := 40;
  AgentList.Add      (CurAgent);
  end;
end;

//========================================================= create data from bmp
procedure TForm1.BmpInfoRead;
var
  curCell : TCell;
  I, K    : Integer;
  ColInfo : Array[0..2] of Byte;
  TmpBmp  : Array[0..2] of TBitmap;
  path    : String;
  Filename: String;
  sumWorker, sumWorkP, sumRetail : Cardinal;
begin
  sumWorker := 0;
  sumWorkP  := 0;
  sumRetail := 0;
  path := ExtractFilePath(Application.ExeName);
  for I := 0 to 2 do
  begin
    TmpBmp[I] := TBitmap.Create;
    ColInfo[I]:=0;
  end;
  Filename := path+'pictures\'+'arbeiter.bmp';
  TmpBmp[0].LoadFromFile(Filename);
  Filename := path+'pictures\'+'arbeitsstaetten.bmp';
  TmpBmp[1].LoadFromFile(Filename);
  Filename := path+'pictures\'+'verkaufsflaechen.bmp';
  TmpBmp[2].LoadFromFile(Filename);
  for I := 0 to reih -1 do
  begin
    for K := 0 to spalt -1 do
    begin
      curCell := cellList[K,I];
      curCell.noWorker   := 255-GetRValue(TmpBmp[0].Canvas.Pixels[curCell.FPos.X, curCell.FPos.Y]);
      curCell.noWorkPl   := 255-GetGValue(TmpBmp[1].Canvas.Pixels[curCell.FPos.X, curCell.FPos.Y]);
      curCell.noRetail   := 255-GetBValue(TmpBmp[2].Canvas.Pixels[curCell.FPos.X, curCell.FPos.Y]);
      curCell.tmpInfo[0] := curCell.noWorker;
      curCell.tmpInfo[1] := curCell.noWorkPl;
      curCell.tmpInfo[2] := curCell.noRetail;
      sumWorker          := sumWorker + curCell.noWorker;
      sumWorkP           := sumWorkP  + curCell.noWorkPl;
      sumRetail          := sumRetail + curCell.noRetail;
      //curCell.colr     := RGB(ColInfo[0], ColInfo[1], ColInfo[2]);
      //curCell.Paint(Image_Cells.Canvas);
      If curCell.noWorker > 0 Then begin
        WorkerList.Add(curCell);
        SetLength(curCell.Worker, curCell.noWorker);
      end;
      If curCell.noWorkPl > 0 Then workPlList.Add(curCell);
      If curCell.noRetail > 0 Then RetailList.Add(curCell);
    end;
  end;
  for I := 0 to 2 do
  begin
    TmpBmp[I].Free;
  end;
  CellsPaint;
  Lbl_worker.Caption := IntToStr(sumWorker);
  Lbl_workPl.Caption := IntToStr(sumWorkP);
  Lbl_retail.Caption := IntToStr(sumRetail);
end;

//==================================== randomly assign workers to places of work
procedure TForm1.AssignWorkers;
var
  curOrig, curDest : TCell;
  idxWor, idxWPl   : Integer;
begin
  While (WorkerList.Count > 0) And (workPlList.Count > 0) Do
  begin
    idxWor  := RandomRange (0, WorkerList.Count);
    idxWPl  := RandomRange (0, workPlList.Count);
    curOrig := WorkerList.Items[idxWor];
    curDest := workPlList.Items[idxWPl];
    curOrig.Worker[curOrig.tmpInfo[0]-1].workPlace.X := curDest.Koord.X;      // assign the place of work
    curOrig.Worker[curOrig.tmpInfo[0]-1].workPlace.Y := curDest.Koord.Y;
    dec(curOrig.tmpInfo[0]);                                                  // delete searching worker
    dec(curDest.tmpInfo[1]);                                                  // delete free place of work
    If curOrig.tmpInfo[0] = 0 Then WorkerList.Delete(WorkerList.IndexOf(curOrig));
    If curDest.tmpInfo[1] = 0 Then workPlList.Delete(workPlList.IndexOf(curDest));
  end;
end;

//==============================================draw the lines to the workplaces
procedure TForm1.LineToWork;
var
  curCell, curDesti : TCell;
  I, K, M           : Integer;
begin
  for I := 0 to reih -1 do
  begin
    for K := 0 to spalt -1 do
    begin
      curCell := cellList[K,I];
      for M := 0 To length(curCell.Worker)-1 Do
      begin
        Image_Cells.Canvas.Pen.Color := curCell.Colr;
        Image_Cells.Canvas.MoveTo(curCell.FPos.X, curCell.FPos.Y);
        curDesti := cellList[curCell.Worker[M].workPlace.X, curCell.Worker[M].workPlace.Y];
        Image_Cells.Canvas.LineTo(curDesti.FPos.X, curDesti.FPos.Y);
      end;
    end;
  end;
end;

//================================================================torus funktion
procedure TForm1.torus (var Xp: Integer; var Yp: Integer);
begin
  if Xp < 0 then begin
     Xp := 0;
  end else
  if Xp > leftBorder then begin
     Xp := leftBorder ;
  end;
  if Yp < 0 then begin
     Yp := 0;
  end else
  if Yp > bottomBorder then begin
     Yp := bottomBorder ;
  end;
end;

//##############################################################################
//######################### interface elements #################################
//##############################################################################
//=========================================================================setup
procedure TForm1.FormCreate(Sender: TObject); //--------------------------------FormCreate
begin
  Setup;
  E_timeScaleChange(Sender);
end;

procedure TForm1.B_loadDataClick(Sender: TObject); //---------------------------load the data for residents, workplaces and retail
begin
  WorkerList.Free;
  WorkPlList.Free;
  WorkerList := TList.Create;
  workPlList := TList.Create;
  BmpInfoRead;
  AssignWorkers;
end;

procedure TForm1.B_lineWorkClick(Sender: TObject); //---------------------------draw the lines to the workplaces
begin
  LineToWork;
end;

procedure TForm1.RB_sAllClick(Sender: TObject); //------------------------------repaint the cells
begin
  CellsPaint;
end;

procedure TForm1.B_deleteAllClick(Sender: TObject); //--------------------------delete all
begin
  Timer1.Enabled := false;
  deleteAll;
end;

//=========================================================================graph
procedure TForm1.B_agCreateClick(Sender: TObject); //---------------------------create the agents
var I : Integer;
begin
  AgentsCreate;
  Ag_clearBack;
  For I := 0 To AgentList.Count*5 Do Agents_Organise;                        // order the agents
  KantenDim;                                                                 // dimension for the usage edges
  Ag_clearBack;                                                              // clear the background
  AgentsPaint;
  Verbinden;                                                                 // draw the connections
  CellsNearNode;
  AgentsPaint;                                                               // find the nearest traffic-node for each cell
end;

procedure TForm1.B_agDeleteClick(Sender: TObject); //---------------------------delete the agents
var
  I        : Integer;
  CurAgent : TAgent;
begin
  Timer1.Enabled := false;
  KantenReset;
  For I := 0 To AgentList.Count-1 Do
  begin
    CurAgent := AgentList.Items[I];
    CurAgent.Free;
  end;
  AgentList.Free;
  AgentList := TList.Create;
  Ag_clearBack;
  AgentsPaint;
end;

procedure TForm1.E_conDistChange(Sender: TObject); //---------------------------change the connection and repel Distance
var
  I        : Integer;
  CurAgent : TAgent;
begin
  For I := 0 To AgentList.Count -1 Do
  begin
    CurAgent           := AgentList.Items[I];
    CurAgent.AnlDist   := StrToInt(E_conDist.Text);
    CurAgent.RepelDist := StrToInt(E_REPDist.Text);
  end;
end;

//==================================================commutation to and from work
procedure TForm1.B_workPathClick(Sender: TObject); //---------------------------create the pathes form residents to workplaces
begin
  WorkDeparture;
  CellsPathToWork;
  Form2.show;
end;

procedure TForm1.B_findPathClick(Sender: TObject); //---------------------------find a random choosen path
var startNode, zielNode : TAgent;
begin
  NodesListSetup;
  startNode := AgentList.Items[random(AgentList.Count -1)];
  zielNode  := AgentList.Items[random(AgentList.Count -1)];
  findPath (pfadList, startNode, zielNode);
  AgentsPaint;
  Verbinden;
  drawPath;
end;

procedure TForm1.B_showGraphClick(Sender: TObject); //--------------------------show the graph with departure times
begin
  Form2.show;
end;

//=======================================================================traffic
procedure TForm1.B_startTClick(Sender: TObject); //-----------------------------start and stop the timer
begin
  Timer1.Enabled := Not(Timer1.Enabled);
end;

procedure TForm1.B_oneStepClick(Sender: TObject); //----------------------------execute one step
begin
  execute;
end;

procedure TForm1.E_timeScaleChange(Sender: TObject);
var minT : shortInt;
begin
  timeSca := StrToInt(E_timeScale.Text);
  globSca := 24 * timeSca;
  minT    := round(1/timeSca * 60);
  Lal_min.Caption := IntToStr(minT)+' min';
end;

procedure TForm1.E_tIntervChange(Sender: TObject); //---------------------------change the timer interval
begin
  Timer1.Interval := StrToInt(E_tInterv.Text);
end;

//=========================================================================timer
procedure TForm1.Timer1Timer(Sender: TObject); //-------------------------------timer object
begin
  execute;
end;

//===================================================================end program
procedure TForm1.FormClose(Sender: TObject; var Action: TCloseAction); //-------close the form
begin
  deleteAll;
end;

procedure TForm1.deleteAll; //--------------------------------------------------delete all
var I, K     : Integer;
    curCell  : TCell;
    curAgent : TAgent;
    curTrav  : TTraveller;
begin
  If length(cellList)>0 Then
  begin
    for I := 0 to reih -1 do
    begin
      for K := 0 to spalt -1 do
      begin
        curCell := cellList[K,I];
        curCell.Free;
      end;
    end;
    SetLength  (cellList, 0, 0);
    WorkerList.Free;
    workPlList.Free;
    RetailList.Free;
  end;
  If AgentList.Count >0 Then
  begin
    for I := 0 to AgentList.Count -1 do
    begin
      curAgent := AgentList.Items[I];
      curAgent.Free;
    end;
    AgentList.Free;
    Image_Agents.Free;
  end;
  If TravelList.Count >0 Then
  begin
  for I := 0 to TravelList.Count -1 do
    begin
      curTrav := TravelList.Items[I];
      curTrav.Free;
    end;
    PfadList.Free;
    TravelList.Free;
  end;
  Image_Cells.Canvas.Brush.Color := clWhite;
  Image_Cells.Canvas.Pen.Color   := clWhite;
  Image_Cells.Canvas.Pen.Width   := 1;
  Image_Cells.Canvas.Rectangle (0, 0, Image_Cells.width,Image_Cells.height);
end;

end.

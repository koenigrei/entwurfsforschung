program Verkehr_01;

uses
  Forms,
  Main in 'Main.pas' {Form1},
  cell in 'cell.pas',
  agent in 'agent.pas',
  calc_AStern in 'calc_AStern.pas',
  timeGraph in 'timeGraph.pas' {Form2};

{$R *.res}

begin
  Application.Initialize;
  Application.CreateForm(TForm1, Form1);
  Application.CreateForm(TForm2, Form2);
  Application.Run;
end.

unit Main;

interface

uses
  Windows, Messages, SysUtils, Variants, Classes, Graphics, Controls, Forms, calc_AStern,
  Dialogs, Node, ExtCtrls, Math, CreateStructure, StdCtrls, Agent, ComCtrls,
  Grids, ValEdit;

type
  TForm1 = class(TForm)
    MainImage         : TImage;
    Panel1            : TPanel;
    GroupBox1         : TGroupBox;
    Label1            : TLabel;
    Label2            : TLabel;
    Label3            : TLabel;
    Lbl_NrStr         : TLabel;
    Lbl_NrHou         : TLabel;
    Lbl_NrFla         : TLabel;
    B_showPlots       : TButton;
    Button1           : TButton;
    GroupBox2         : TGroupBox;
    E_nrStreets       : TEdit;
    Label4            : TLabel;
    UpD_nrStreets     : TUpDown;
    Label5            : TLabel;
    E_nrHouses        : TEdit;
    UpD_nrHouses      : TUpDown;
    Label6            : TLabel;
    E_nrFlats         : TEdit;
    UpD_nrFlats       : TUpDown;
    Label7            : TLabel;
    E_anzAg           : TEdit;
    UpD_nrAgents      : TUpDown;
    ValueListEditor1  : TValueListEditor;
    Timer1            : TTimer;
    Lbl_TimeCt        : TLabel;
    B_setupStruct     : TButton;
    B_oneStep         : TButton;
    Button2           : TButton;
    B_newAgents       : TButton;
    Label8            : TLabel;
    E_StrNeigh        : TEdit;
    UpD_StrNeigh      : TUpDown;
    Label9            : TLabel;
    Edit5             : TEdit;
    UpD_nrGroups      : TUpDown;
    Button3           : TButton;
    E_Delete          : TEdit;
    UpD_delete        : TUpDown;
    B_advAna          : TButton;
    Panel_PBar        : TPanel;
    ProgressBar1      : TProgressBar;
    Lbl_ct            : TLabel;
    Lbl_pathOut       : TLabel;
    B_phaseAna: TButton;
    Button4: TButton;
    E_pFree: TEdit;
    Label10: TLabel;
    procedure B_draw_RPathClick(Sender: TObject);
    procedure Button1Click(Sender: TObject);
    procedure Timer1Timer(Sender: TObject);
    procedure B_setupStructClick(Sender: TObject);
    procedure B_oneStepClick(Sender: TObject);
    procedure Button2Click(Sender: TObject);
    procedure B_newAgentsClick(Sender: TObject);
    procedure FormCreate(Sender: TObject);
    procedure ValueListEditor1StringsChange(Sender: TObject);
    procedure B_showPlotsClick(Sender: TObject);
    procedure Button3Click(Sender: TObject);
    procedure FormShow(Sender: TObject);
    procedure B_advAnaClick(Sender: TObject);
    procedure UpD_nrStreetsClick(Sender: TObject; Button: TUDBtnType);
    procedure E_nrStreetsChange(Sender: TObject);
    procedure B_phaseAnaClick(Sender: TObject);
    procedure Button4Click(Sender: TObject);
    procedure E_pFreeChange(Sender: TObject);
  private
    Procedure NeighPathes;
    Procedure SetNbLength;
    procedure DrawPath(PfadList: TList);
    Function  PSum(n:Integer):Integer;
    Procedure CalcWeights (PfadList: Tlist; CurInd:Integer);
    Procedure AgentNeighInflu;
    Procedure CalcFraction(CurNode: TNode; state: Integer; var Same, Others : Real);
    Procedure SearchNewHome;
    Procedure MoveToNewLocation(CurAgent: TAgent; CurFlat: TNode; idx : Integer);
    Function  SetWeights(PfadList: TList): Real;
    Procedure StreetPathes;
    Procedure AggregateFractions;
    Procedure NeighSum;
    Procedure InitStruct;
  public
    procedure SetupStruct;
    procedure Execute;
    procedure Deleter;
    procedure CreateNewAgents;
    Procedure CalcWeightsNew;
    Procedure ConnectionDelete;
    Procedure ConnectionDeleteAuto;
  end;

var                                                                           // global variables
  Form1       : TForm1;
  NodeList    : TList;         // List of all nodes
  FlatList    : TList;         // List of the flat nodes
  FreeList    : TList;         // List of the free flats
  StreetList  : TList;         // List of the street nodes
  HouseList   : TList;         // List of the house nodes
  AgentList   : TList;         // List of all agents
  UnhappyList : TList;         // List of all unsatisfied agents
  globCount   : Integer;       // global Counter

implementation

{$R *.dfm}
uses basicAnalysis, advancedAnalysis, phaseTransAna, spatialAnalysis;

//===================================================================form create
procedure TForm1.FormCreate(Sender: TObject);
begin
  SetupStruct;
  NetValues;
end;

procedure TForm1.FormShow(Sender: TObject);
begin
  Form3.show;
  Form3.resetCharts;
end;

//=================================================================form activate
procedure TForm1.SetupStruct;
begin
  globCount := 0;
  Lbl_TimeCt.Caption := IntToStr(globCount);
  oldMax := StrToFloat(Form1.ValueListEditor1.Values['settleDown']);
  oldMin := StrToFloat(Form1.ValueListEditor1.Values['leavePlace']);
  MainImage.Canvas.Brush.Color := clWhite;
  MainImage.Canvas.Pen.Color   := clBlack;
  MainImage.Canvas.Pen.Width   := 1;
  MainImage.Canvas.Rectangle (0, 0, MainImage.Width, MainImage.Height);
  NodeList    := TList.Create;
  FreeList    := TList.Create;
  FlatList    := TList.Create;
  AgentList   := TList.Create;
  UnHappyList := TList.Create;
  StreetList  := TList.Create;
  HouseList   := TList.Create;
  CreateNetwork;                                                              // create the network structure
  AgentsCreate;
  InitStruct;
end;

//=========================================check if there is already a path file
Procedure TForm1.InitStruct;
begin
  Lbl_ct.update;
  SetNbLength;
  StreetPathes;
  AggregateFractions;
  NeighPathes;
end;

//=============================Calculate the shortest pathes between the streets
Procedure TForm1.StreetPathes;
var I, K, L                    : Integer;
    CurStreet, ToStreet, PNode : TNode;
    PfadList                   : TList;
begin
  For I:=0 To StreetList.Count-1 Do
  begin
    CurStreet := StreetList.Items[I];
    SetLength(CurStreet.NachbStr, StreetList.Count);                         // pathes to all other streets (except to itself)
    For K:=I+1 To StreetList.Count-1 Do
    begin
      PfadList := TList.Create;
      ToStreet := StreetList.Items[K];
      FindPath (PfadList, CurStreet, ToStreet);
      CurStreet.NachbStr[K] := TList.Create;
      CurStreet.NachbStr[K].Assign(PfadList);                              // the sequence of the pfadList is from the zielNode to the startNode
      SetLength(ToStreet.NachbStr, StreetList.Count);
      ToStreet.NachbStr[I] := TList.Create;
      For L:=0 To PfadList.Count-1 Do                                        // save the reverse sequence of the path to the ToNode
      begin
        PNode := PfadList.Items[PfadList.Count-1 -L];                        // the indeces ot the NachbStr Array are the indices ot the StreetList
        ToStreet.NachbStr[I].Add(PNode);
      end;
      PfadList.Free;
    end;
  end;
end;

//=========================================================Calculate the weights
Procedure TForm1.NeighPathes;
var I, K, cter, all, CurInd                : Integer;
    CurFlat, CurHouse, CurStreet, ToStreet : TNode;
    PfadList                               : TList;
begin
  PfadList := TList.Create;
  Panel_PBar.Visible := true;
  all := (FlatList.Count)*(StreetList.Count) ;
  Lbl_ct.Caption := IntToStr(all);
  cter := 0;
  For I:=0 To FlatList.Count-1 Do
  begin
    PfadList.Clear;
    CurFlat := FlatList.Items[I];
    // --- first the path to the own street ---
    CurStreet := NodeList.Items[CurFlat.toStreet];
    CurHouse  := NodeList.Items[CurFlat.toHouse];
    PfadList.Add(CurStreet);
    PfadList.Add(CurHouse);
    PfadList.Add(CurFlat);
    CalcWeights(PfadList, 0);                                                // the first path to the street
    // --- second the path to the own house ---
    PfadList.Delete(0);                                                      // the same path without the street
    CalcWeights(PfadList, 1);                                                // the second path to the house
    // --- third the pathes to the other streets
    CurInd := 2;                                                             // the other pathes to other streets
    For K:=0 To StreetList.Count-1 Do
    begin
      PfadList.Clear;
      ToStreet := StreetList.Items[K];
      If Not (CurStreet = ToStreet) Then
      begin
        PfadList.Assign(CurStreet.NachbStr[K]);
        PfadList.Add(CurHouse);
        PfadList.Add(CurFlat);
        CalcWeights(PfadList, CurInd);
        inc(CurInd);
      end;
      inc(cter);
      ProgressBar1.Position := round(cter/all*100);
    end;
    Lbl_pathOut.Caption:=IntToStr(cter);
    Lbl_pathOut.Update;
  end;
  Panel_PBar.Visible := false;
  PfadList.Free;
end;

//==============================================================set array lenght
Procedure TForm1.SetNbLength;
var I       : Integer;
    CurNode : TNode;
begin
  For I:=0 To FlatList.Count-1 Do
  begin
    CurNode := FlatList.Items[I];
    Setlength(CurNode.StaWgList, 0);
    Setlength(CurNode.StaWgList, StreetList.Count+1);                        // all streets; the own-street with a diferent weigth; plus one house
  end;
end;

//=========================================================Summarise the weights
Procedure TForm1.CalcWeights (PfadList: Tlist; CurInd:Integer);
var StartNode, EndNode : TNode;
    wght               : Real;
    I                  : Integer;
begin
  StartNode := PfadList.Last;
  EndNode   := PfadList.First;
  SetLength(StartNode.StaWgList[CurInd].State, NGroups);
  For I:=0 To NGroups-1 Do                                                   // transfer the aggregated states to the considered nodes
  begin
    StartNode.StaWgList[CurInd].State[I] := EndNode.typeRatio[I];
  end;
  StartNode.StaWgList[CurInd].Path  := TList.Create;
  StartNode.StaWgList[CurInd].Path.Assign(PfadList);
  wght := SetWeights(PfadList);
  StartNode.StaWgList[CurInd].Weight := wght;
end;

//========================================================New weight calculation
Procedure TForm1.CalcWeightsNew;
var I, K     : Integer;
    CurNode  : TNode;
    wght     : Real;
    PfadList : TList;
begin
  PfadList := TList.Create;
  For I:=0 To FlatList.Count-1 Do
  begin
    CurNode := FlatList.Items[I];
    For K:=0 To length(CurNode.StaWgList)-1 Do
    begin
      If Not (CurNode.StaWgList[K].Path = nil) Then
      begin
        PfadList.Clear;
        PfadList.Assign(CurNode.StaWgList[K].Path);
        wght := SetWeights(PfadList);
        CurNode.StaWgList[K].Weight := wght;
      end;
    end;
  end;
  PfadList.Free;
end;

//===============================================================Set the weights
Function TForm1.SetWeights(PfadList: TList): Real;
var I             : Integer;
    curWght, wght : Real;
    curNode       : TNode;
begin
  wght := 1;                                                                 // initial weight
  If PfadList.Count = 2 Then
  begin
    wght := StrToFloat(ValueListEditor1.Values['weigthHouses']);             // in the same house
  end else If PfadList.Count = 3 Then
  begin
    wght := IntPower(StrToFloat(ValueListEditor1.Values['weigthHouses']),2); // we have to count two houses per path. The second one is aggregated in the toStreet!
    wght := wght * StrToFloat(ValueListEditor1.Values['weigthStreets']);     // in the same street
  end else If PfadList.Count > 3 Then
  begin
    For I :=0 To PfadList.Count-2 Do                                         // the last one is the flat itself
    begin
      CurNode := PfadList.Items[I];                                          // distant neighbours
      case CurNode.NStat of
        0: curWght := StrToFloat(ValueListEditor1.Values['weigthStreets']);  // street weight
        1: curWght := IntPower(StrToFloat(ValueListEditor1.Values['weigthHouses']),2); // we have to count two houses per path. The second one is aggregated in the toStreet!
      end;
      wght := wght*curWght;
    end;
  end;
  Result := wght;
end;

//******************************************************************************
//*************************** Timer Section ************************************
//==============================================================Start/Stop Timer
procedure TForm1.Button1Click(Sender: TObject);
begin
  Timer1.Enabled := Not Timer1.Enabled;
end;

procedure TForm1.B_oneStepClick(Sender: TObject);
begin
 Execute;
end;

//=========================================================================Timer
procedure TForm1.Timer1Timer(Sender: TObject);
begin
  Execute;
end;

procedure TForm1.UpD_nrStreetsClick(Sender: TObject; Button: TUDBtnType);
begin
  NetValues;
end;

//=======================================================================Execute
procedure TForm1.Execute;
begin
  Form3.IDissimilar;
  AggregateFractions;
  NeighSum;
  AgentNeighInflu;
  SearchNewHome;
  Inc(globCount);
  Lbl_TimeCt.Caption := IntToStr(globCount);
end;

//==============================================================================
Procedure TForm1.NeighSum;
var I, K, L         : Integer;
    CurFlat, ToNode : TNode;
begin
  For I:=0 To FlatList.Count-1 Do
  begin
    CurFlat := FlatList.Items[I];
    For K:=0 To StreetList.Count Do
    begin
      SetLength(CurFlat.StaWgList[K].State, 0);
      SetLength(CurFlat.StaWgList[K].State, NGroups);
      ToNode := CurFlat.StaWgList[K].Path.First;
      For L:=0 To NGroups-1 Do                                                   // transfer the aggregated states to the considered nodes
      begin
        CurFlat.StaWgList[K].State[L] := ToNode.typeRatio[L];
      end;
    end;
  end;
end;

//==========================================================Aggregate the states
Procedure TForm1.AggregateFractions;
var I, K, L                               : Integer;
    CurStreet, CurHouse, CurFlat, CurNode : TNode;
begin
  For I:=0 To NodeList.Count-1 Do
  begin
    CurNode := NodeList.Items[I];
    SetLength(CurNode.typeRatio, 0);                                         // delete the typeRation
    SetLength(CurNode.typeRatio, NGroups);
  end;
  // --- aggregate the flat-states to the houses ---
  For I:=0 To HouseList.Count-1 Do
  begin
    CurHouse := HouseList.Items[I];
    For K:=0 To CurHouse.FlatList.Count-1 Do                                 // summarise the flats
    begin
      CurFlat := CurHouse.FlatList.Items[K];
      If CurFlat.FState >= 0 Then Inc(CurHouse.typeRatio[CurFlat.FState]);   // add state if the flat is not empty (state = -1)
    end;
  end;
  // --- aggregate the house-state to the streets ---
  For I:=0 To StreetList.Count-1 Do
  begin
    CurStreet := StreetList.Items[I];
    For K:=0 To CurStreet.HouseList.Count-1 Do                               // summarise the houses
    begin
      CurHouse :=  CurStreet.HouseList.Items[K];
      For L:=0 To length(CurHouse.typeRatio)-1 Do
      begin
        CurStreet.typeRatio[L] := CurStreet.typeRatio[L] + CurHouse.typeRatio[L];
      end;
    end;
  end;
end;

//===============================================================Check happiness
Procedure TForm1.AgentNeighInflu;
var I, idx               : Integer;
    CurAgent             : TAgent;
    CurNode              : TNode;
    thresh, Same, Others : Real;
    TmpList              : TList;
begin
  thresh := StrToFloat(ValueListEditor1.Values['leavePlace']);               // threshold to leave the olc location
  UnHappyList.Free;                                                          // Delete the old List
  UnHappyList := TList.Create;                                               // and create a new one
  TmpList := TList.Create;                                                   // list to choose a random agent to avoid artefacts in the simulation
  TmpList.Assign(AgentList);
  For I:=0 To AgentList.Count-1 Do
  begin
    idx := random(TmpList.Count);
    CurAgent := TmpList.Items[idx];
    CurNode  := FlatList.Items[CurAgent.NrFlat];
    CalcFraction(CurNode, CurAgent.FState, Same, Others);
    If (Others+Same) > 0 Then begin
      CurAgent.NeighFract := Same / (Others + Same);
    end else CurAgent.NeighFract := 1;
    If CurAgent.NeighFract < thresh Then begin                               // if the agent is not satisfied with his neighbourhood
      UnHappyList.Add(CurAgent);
    end;
    TmpList.Delete(idx);
  end;
  TmpList.Free;
end;

//======================================================Search a better location
Procedure TForm1.SearchNewHome;
var I, K, moveCter  : Integer;
    CurAgent        : TAgent;
    CurFlat         : TNode;
    thresh, Same, Others,NeighFract, happyRat, moveRat : Real;
begin
  thresh := StrToFloat(ValueListEditor1.Values['settleDown']);               // threshold to move to a new location
  moveCter := 0;
  For I:=0 To UnHappyList.Count-1 Do
  begin
    CurAgent := UnHappyList.Items[I];
    For K:=0 To FreeList.Count-1 Do
    begin
      CurFlat := FreeList.Items[K];
      CalcFraction(CurFlat, CurAgent.FState, Same, Others);
      If (Others+Same) > 0 Then
      begin
        NeighFract := Same / (Others + Same);
      end else NeighFract := 1;
      If (NeighFract > thresh) and (NeighFract > CurAgent.NeighFract) Then   // the fraction at a new location have to be better than a given threshold
      begin                                                                  // as well as the the fraction at the old location
        CurAgent.NeighFract := NeighFract;                                   // before the agent moves to the new location
        MoveToNewLocation(CurAgent, CurFlat, K);
        inc(moveCter);
        Break;
      end;
    end;
  end;
  happyRat := (UnhappyList.Count-1)/(AgentList.Count-1)*100;
  moveRat  := (moveCter)/(AgentList.Count-1)*100;
  Form3.Ser_happy.AddXY(globCount, happyRat);                                // plot the happy/unhappy ratio
  Form3.Ser_moving.AddXY(globCount, moveRat);                                // plot the ration of moving agents
  Form3.Ser_moveTh.AddXY(globCount, StrToFloat(ValueListEditor1.Values['leavePlace']));
  Form3.Ser_settleTh.AddXY(globCount, StrToFloat(ValueListEditor1.Values['settleDown']));
  Form6.ser_change.AddXY(globCount, moveCter);
  //Form6.ser_UnHappy.AddXY(globCount, UnhappyList.Count);
end;

//===============================================Move an agent to a new location
Procedure TForm1.MoveToNewLocation(CurAgent: TAgent; CurFlat: TNode; idx : Integer);
var OldFlat : TNode;
    ind     : Integer;
begin
  OldFlat         := FlatList.Items[CurAgent.NrFlat];
  CurAgent.FPos.X := CurFlat.FPos.X;
  CurAgent.FPos.Y := CurFlat.FPos.Y;
  ind := FlatList.IndexOf(CurFlat);
  CurAgent.NrFlat := ind;
  CurFlat.FState  := CurAgent.FState;
  OldFlat.FState  := -1;
  CurAgent.Paint(Form1.MainImage.Canvas);
  OldFlat.Paint(Form1.MainImage.Canvas);
  FreeList.Delete(idx);
  FreeList.Add(OldFlat);
end;

//===========================================================Calculate fractions
Procedure TForm1.CalcFraction(CurNode: TNode; state: Integer; var Same, Others : Real);
var K, I : Integer;
begin
  Same   := 0;
  Others := 0;
  For K:=0 To length(CurNode.StaWgList)-1 Do
  begin
    For I:=0 To length(CurNode.StaWgList[K].State)-1 Do
    begin
      If I = state Then begin
        Same := Same + CurNode.StaWgList[K].State[I] * CurNode.StaWgList[K].Weight;     // increase counter of same kinded agents
      end else begin
        Others := Others + CurNode.StaWgList[K].State[I] * CurNode.StaWgList[K].Weight; // increase counter of different agents
      end;
    end;
  end;
end;

//===================================================================Draw a path
procedure TForm1.DrawPath(PfadList: TList);
var
  AShape, BShape : TNode;
  idx, I         : Integer;
begin
  idx := 1;
  If PfadList.Count > 1 Then begin
    Form1.MainImage.Canvas.Pen.Color := clYellow;
    Form1.MainImage.Canvas.Pen.Style := psSolid;
    For I:= 0 To PfadList.Count-2 Do
    begin
      AShape := PfadList.Items [I];
      BShape := PfadList.Items [I+1];
      inc(idx);
      Form1.MainImage.Canvas.Pen.Width := idx;
      Form1.MainImage.Canvas.MoveTo(AShape.FPos.X, AShape.FPos.Y);
      Form1.MainImage.Canvas.LineTo(BShape.FPos.X, BShape.FPos.Y);
    end;
  end;
end;

//====================================================================delete all
procedure TForm1.Deleter;
var
 I, K     : Integer;
 CurNode  : TNode;
 curAgent : TAgent;
begin
  Timer1.enabled := false;
  for I:=0 to StreetList.Count-1 do
  begin
    CurNode := StreetList.Items[I];
    For K:=0 To length(CurNode.NachbStr)-1 Do
    begin
      CurNode.NachbStr[K].Free;
    end;
    SetLength(CurNode.NachbStr, 0);
  end;
  for I:=0 to NodeList.Count-1 do
  begin
    CurNode := NodeList.Items[I];
    For K:=0 To length(CurNode.StaWgList)-1 Do
    begin
      CurNode.StaWgList[K].Path.Free;
    end;
    SetLength(CurNode.StaWgList, 0);
    SetLength(CurNode.typeRatio, 0);
    SetLength(CurNode.NachbStr, 0);
    SetLength(CurNode.ConnList, 0);
    SetLength(CurNode.NachbList, 0);
    CurNode.HouseList.Free;
    CurNode.FlatList.Free;
    CurNode.Free;
  end;
  for I := 0 to AgentList.Count - 1 do
  begin
    curAgent := AgentList.Items [I];
    curAgent.Free;
  end;
  NodeList.Free;
  StreetList.Free;
  HouseList.Free;
  FlatList.Free;
  FreeList.Free;
  AgentList.Free;
  UnhappyList.Free;
  SetLength(groupSz, 0);
end;

//******************************************************************************
//*********************** Buttons and Interact.*********************************
//============================================================draw a random path
procedure TForm1.B_advAnaClick(Sender: TObject);
begin
  Form2.Show;
end;

procedure TForm1.B_phaseAnaClick(Sender: TObject);
begin
  Form6.Show;
end;

procedure TForm1.B_draw_RPathClick(Sender: TObject);
var CurNode, ToNode : TNode;
    PfadList        : TList;
begin
  Randomize;
  PfadList:= TList.Create;
  CurNode := FlatList.Items[Random(FlatList.Count)];
  ToNode  := FlatList.Items[Random(FlatList.Count)];
  FindPath (PfadList, CurNode, ToNode);
  DrawPath(PfadList);
  PfadList.Free;
end;

//=================================================================form activate
procedure TForm1.B_setupStructClick(Sender: TObject);
begin
  Deleter;
  SetupStruct;
  Form3.resetCharts;
end;

//=============================================================new set of agents
procedure TForm1.B_newAgentsClick(Sender: TObject);
begin
  CreateNewAgents;
end;

procedure TForm1.CreateNewAgents;
var I       : Integer;
    CurFlat : TNode;
    CurAgent: TAgent;
begin
  Timer1.Enabled := false;
  For I:=0 To FlatList.Count-1 Do
  begin
    CurFlat := FlatList.Items[I];
    CurFlat.FState := -1;
  end;
  FreeList.Clear;
  FreeList.Assign(FlatList);                                                  // all flats are free again
  For I:=0 To AgentList.Count-1 Do
  begin
    CurAgent := AgentList.Items[I];
    CurAgent.Free;
  end;
  AgentList.Free;
  AgentList := TList.Create;
  NodesPaint;
  AgentsCreate;
  globCount := 0;
  Lbl_TimeCt.Caption := IntToStr(globCount);
  Form3.resetCharts;
end;

//==============================================================================
procedure TForm1.Button2Click(Sender: TObject);
begin
  CalcWeightsNew;
end;

//===============================================================show the charts
procedure TForm1.B_showPlotsClick(Sender: TObject);
begin
  Form3.show;
end;

//==============================================================================
procedure TForm1.Button3Click(Sender: TObject);
begin
  ConnectionDelete;
end;

procedure TForm1.Button4Click(Sender: TObject);
begin
  Form2.Show;
  Form4.Show;
end;

procedure TForm1.E_nrStreetsChange(Sender: TObject);
begin
  NetValues;
end;

procedure TForm1.E_pFreeChange(Sender: TObject);
begin
  NetValues;
end;

Procedure TForm1.ConnectionDelete;
var I, wert : Integer;
begin
  For I:=0 To UpD_delete.Position-1 Do
  begin
    If DeleteConnection = False Then
    begin
      wert := Application.MessageBox('Graph would be not connected anymore. Connection is not deleted','Graph property', MB_RETRYCANCEL);
      If wert = 2 Then Exit;                                                 // user has canceled further deletions
    end;
  end;
  InitStruct;
  Form3.GraphConnectivity;
end;

Procedure TForm1.ConnectionDeleteAuto;
var I : Integer;
begin
  For I:=0 To UpD_delete.Position-1 Do
  begin
    If DeleteConnection = False Then
    begin
      Exit;                                                                   // cancele further deletions
    end;
  end;
  InitStruct;
  Form3.GraphConnectivity;
end;

//==============================================================================
procedure TForm1.ValueListEditor1StringsChange(Sender: TObject);
var tester : Real;
begin
  try
    tester:=StrToFloat(ValueListEditor1.Values['settleDown']);
    tester:=StrToFloat(ValueListEditor1.Values['leavePlace']);
    tester:=StrToFloat(ValueListEditor1.Values['weigthStreets']);
    tester:=StrToFloat(ValueListEditor1.Values['weigthHouses']);
    //Form3.setMinMax;
  except
    ShowMessage('This is not a valid value!');
    Timer1.Enabled := false;
  end;
end;

//==============================================================================
Function TForm1.PSum(n:Integer):Integer;
begin
  If n<=1 then PSum:=0
else
  PSum:=PSum (n-1)+n;
end;

//======================================================================Fakult�t
function fak (n:integer):integer; 
begin
  if n=1 then
    fak:=1
  else
    fak:=fak (n-1)*n;
end;

end.

unit CreateStructure;

interface

uses
  Math, SysUtils, Types, Classes, Node, Graphics, ColourSelect, Agent, Forms;

var
  NNoS    : Integer; // Number of street nodes
  NNoH    : Integer; // Number of house nodes per street
  NNoF    : Integer; // Number of households/flats per house
  dist0   : Integer; // Distance to the street nodes
  Pos0    : TPoint;  // Centre of the cycle
  NGroups : Integer; // Number of Groups
  ColList : ColourList;
  groupSz : Array of Integer;           // -- number of agents in each group (color)

Procedure CreateNetwork;
Procedure CreateSNodes;
Procedure CreateHNodes;
Procedure CreateFNodes;
Procedure AssignNeighb;
Procedure DrawLinks;
Procedure Torus(var Value: Integer);
Procedure NodesPaint;
Procedure NetValues;
Procedure AgentsCreate;
Function DeleteConnection : Boolean;
Procedure DeleteArrayElement(var arr: TNbArray; const index: integer);
Procedure RepaintAgents;
Procedure RepaintNodes;
Function TestGraphConnect: Boolean;

implementation

uses Main, calc_AStern, basicAnalysis;

procedure CreateNetwork;
begin
  CreateSNodes;                                                               // ----------------
  CreateHNodes;                                                               // -- create the --
  CreateFNodes;                                                               // -- network    --
  AssignNeighb;                                                               // -- structure  --
  DrawLinks;                                                                  // ---           --
  NodesPaint;                                                                 // ----------------

end;

procedure NetValues;
var pFree : Real;
begin
  NNoS := Form1.UpD_nrStreets.Position - 1;
  NNoH := Form1.UpD_nrHouses.Position - 1;
  NNoF := Form1.UpD_nrFlats.Position - 1;
  Form1.Lbl_NrStr.Caption := IntToStr(NNoS+1);
  Form1.Lbl_NrHou.Caption := IntToStr((NNoS+1)*(NNoH+1));
  Form1.Lbl_NrFla.Caption := IntToStr((NNoS+1)*(NNoH+1)*(NNoF+1));
  pFree := 1-(StrToInt(Form1.E_pFree.Text)/100);
  Form1.UpD_nrAgents.Position := round(StrToInt(Form1.Lbl_NrFla.Caption)*pFree);
end;

//=============================================================Create the agents
Procedure AgentsCreate;
var
  I,num, ind, idx : Integer;
  CurFlat    : TNode;
  CurAgent   : TAgent;
begin
  Randomize;
  NGroups := Form1.UpD_nrGroups.Position;
  num := Form1.UpD_nrAgents.Position;
  SetLength(groupSz, 0);
  SetLength(groupSz, NGroups);
  //ColoSelec(NGroups+1, ColList);
  //ChooseCol(NGroups, ColList);
  ColPalet (NGroups+1, ColList);
  For I := 0 To num-1 Do begin
    ind := Random(FreeList.Count);
    CurFlat  := FreeList.Items[ind];
    CurAgent := TAgent.Create;
    idx := FlatList.IndexOf(CurFlat);
    CurAgent.FPos.X := CurFlat.FPos.X;
    CurAgent.FPos.Y := CurFlat.FPos.Y;
    CurAgent.NrFlat := idx;
    CurAgent.FSize  := 4;
    CurAgent.FState := random(NGroups);
    inc(groupSz[CurAgent.FState]);
    CurFlat.Fstate  := CurAgent.FState;
    CurAgent.FColor := ColList[CurAgent.FState];
    CurAgent.Paint(Form1.MainImage.Canvas);
    FreeList.Delete(ind);
    AgentList.Add(CurAgent);
  end;
end;

//===========================================================create street nodes
procedure CreateSNodes;
var
  I                : Integer;
  sinX, cosY, degP : Extended;
  CurStreet        : TNode;
begin
  NNoS   := Form1.UpD_nrStreets.Position - 1;
  dist0  := 240;
  degP   := DegToRad(360 / (NNoS+1));
  Pos0.X := round(Form1.MainImage.width /2);
  Pos0.Y := round(Form1.MainImage.height/2);
  For I := 0 To NNoS Do
  begin
    SinCos(degP*I, sinX, cosY);
    CurStreet        := TNode.Create;
    CurStreet.FPos.X :=  round(Pos0.X + sinX*dist0);
    CurStreet.FPos.Y :=  round(Pos0.Y + cosY*dist0);
    CurStreet.FSize  := 8;
    CurStreet.NStat  := 0;
    CurStreet.FFillCol := clBlack;
    CurStreet.FLineCol := clBlack;
    CurStreet.Paint(Form1.MainImage.Canvas);
    CurStreet.F:= 0;
    CurStreet.G:= 0;
    CurStreet.H:= 0;
    CurStreet.closed := false;
    SetLength(CurStreet.typeRatio, NGroups);
    NodeList.Add (CurStreet);
    StreetList.Add(CurStreet);
  end;
end;

//============================================================create house nodes
procedure CreateHNodes;
var
  I, K                         : Integer;
  dist1, ringDist              : Integer;
  sinX, cosY, degP, degH, part : Extended;
  CurHouse, CurStreet          : TNode;
begin
  NNoH     := Form1.UpD_nrHouses.Position - 1;
  ringDist := 40;                                                             // distances of the houses' secondary rings
  degP     := DegToRad(360 / (NNoS+1));
  For I := 0 To NNoS Do
  begin
    CurStreet := NodeList.Items[I];
    CurStreet.houseList := TList.Create;
    For K := 0 To NNoH Do
    begin
      If K < 3 Then begin                                                     // calculate the coordinates
        degH   := degP * 0.6;                                                 //  |
        dist1  := dist0+ringDist;                                             //  |
        part := degH/2;                                                       //  |
        SinCos(degP*I + degH/2 - K*part, sinX, cosY);                         //  |
      end else if K < 7 then begin                                            //  |
        degH   := degP * 0.7;                                                 //  |
        dist1  := dist0+ringDist*2;                                           //  |
        part := degH/3;                                                       //  |
        SinCos(degP*I + degH/2 - (K-3)*part, sinX, cosY);                     //  |
      end  else if K < 13 then begin                                          //  |
        degH   := degP * 0.75;                                                //  |
        dist1  := dist0+ringDist*3;                                           //  |
        part := degH/4;                                                       //  |
        SinCos(degP*I + degH/2 - (K-7)*part, sinX, cosY);                     //  |
      end;                                                                    // ----
      CurHouse        := TNode.Create;
      CurHouse.FPos.X := round(Pos0.X + sinX*dist1);
      CurHouse.FPos.Y := round(Pos0.Y + cosY*dist1);
      CurHouse.FSize  := 4;
      CurHouse.NStat  := 1;
      CurHouse.FFillCol := clWhite;
      CurHouse.FLineCol := clBlack;
      CurHouse.Paint(Form1.MainImage.Canvas);
      CurHouse.F:= 0;
      CurHouse.G:= 0;
      CurHouse.H:= 0;
      CurHouse.closed := false;
      SetLength(CurHouse.typeRatio, NGroups);
      CurHouse.toStreet := NodeList.IndexOf(CurStreet);                       // house is part of the street with index
      CurStreet.houseList.Add (CurHouse);                                     // collect the houses in the street
      NodeList.Add (CurHouse);
      HouseList.Add (CurHouse);
    end;
  end;
end;

//===================================================create household/flat nodes
procedure CreateFNodes;
var
  I, J, K, dist2      : Integer;
  sinX, cosY, degP : Extended;
  CurFlat, CurHouse, CurStreet : TNode;
begin
  NNoF   := Form1.UpD_nrFlats.Position - 1;
  dist2  := 13;
  degP   := DegToRad(360 / (NNoF+1));
  For I:=0 To StreetList.Count-1 Do
  begin
    CurStreet := StreetList.Items[I];
    For J:=0 To CurStreet.HouseList.Count-1 Do
    begin
      CurHouse := CurStreet.HouseList.Items[J];
      CurHouse.FlatList:= TList.Create;
      For K := 0 To NNoF Do
      begin
        SinCos(degP*K, sinX, cosY);
        CurFlat        := TNode.Create;
        CurFlat.FPos.X :=  round(CurHouse.FPos.X + sinX*dist2);
        CurFlat.FPos.Y :=  round(CurHouse.FPos.Y + cosY*dist2);
        CurFlat.FSize  := 4;
        CurFlat.NStat  := 2;
        CurFlat.FState := -1;                                                 // State -1 = empty
        CurFlat.FFree  := true;
        CurFlat.FFillCol := clSilver;
        CurFlat.FLineCol := clBlack;
        CurFlat.Paint(Form1.MainImage.Canvas);
        CurFlat.F:= 0;
        CurFlat.G:= 0;
        CurFlat.H:= 0;
        CurFlat.closed := false;
        CurFlat.toStreet := NodeList.IndexOf(CurStreet);
        CurFlat.toHouse  := NodeList.IndexOf(CurHouse);
        CurHouse.FlatList.Add(CurFlat);
        NodeList.Add (CurFlat);
        FlatList.Add (CurFlat);
        FreeList.Add (CurFlat);
      end;
    end;
  end;
end;

//=============================================================repaint the nodes
procedure NodesPaint;
var
  I       : Integer;
  CurNode : TNode;
begin
  For I := 0 To NodeList.Count-1 Do
  begin
    CurNode := NodeList.Items[I];
    CurNode.Paint(Form1.MainImage.Canvas);
  end;
end;

//=========================================================assign the neighborus
procedure AssignNeighb;
var
  I, J, K, M, nrNb,indNb,indFH : Integer;
  StrNode, HouseNode, FlatNode : TNode;
begin
  nrNb := round(Form1.UpD_StrNeigh.Position/2);                              // number of street neighbours on both sides
  For I := 0 To NNoS Do
  begin
    StrNode := NodeList.Items[I];
    SetLength(StrNode.ConnList, (nrNb*2 + StrNode.HouseList.Count));
    SetLength(StrNode.NachbList, (nrNb*2));                                  // *** change this if there are unregular connections
    For K := 1 To nrNb Do                                                    // connect the street nodes
    begin
      indNb := I+K;
      Torus(indNb);
      StrNode.ConnList[K-1].nr := indNb;
      StrNode.NachbList[K-1].nr := indNb;
      StrNode.ConnList[K-1].Estat := 0;
      indNb := I-K;
      Torus(indNb);
      StrNode.ConnList[K+nrNb-1].nr := indNb;
      StrNode.NachbList[K+nrNb-1].nr := indNb;
      StrNode.ConnList[K+nrNb-1].Estat := 0;
    end;
    For M := 0 To StrNode.HouseList.Count-1 Do                               // connect the street with the houses
    begin
      HouseNode := StrNode.HouseList.Items[M];                               // connect the houses to the street
      indNb := NodeList.IndexOf(HouseNode);
      StrNode.ConnList[nrNb*2+M].nr := indNb;
      StrNode.ConnList[nrNb*2+M].Estat := 1;
      SetLength(HouseNode.ConnList, HouseNode.FlatList.Count +1);            // flats + one street
      HouseNode.ConnList[0].nr := I;
      HouseNode.ConnList[0].Estat := 1;
      For J := 0 To HouseNode.FlatList.Count-1 Do                            // connect the houses with the flats
      begin
        FlatNode := HouseNode.FlatList[J];
        indFH := NodeList.IndexOf(FlatNode);
        HouseNode.ConnList[J+1].nr := indFH;
        HouseNode.ConnList[J+1].Estat := 2;
        SetLength(FlatNode.ConnList, 1);
        FlatNode.ConnList[0].nr := indNb;                                   // connect the flats with the houses
        FlatNode.ConnList[0].Estat := 2;
      end;
    end;
  end;
end;

//==============================================================================
Function DeleteConnection : Boolean;
var idx, I, K : Integer;
    ANode, BNode, TestNode : TNode;
    oldNbArrA,  oldNbArrB  : TNbArray;
    oldConArrA, oldConArrB : TNbArray;
begin
  idx := random(StreetList.Count);
  ANode := StreetList.Items[idx];
  idx := random(length(ANode.NachbList));
  BNode := NodeList.Items[ANode.NachbList[idx].nr];
  SetLength(oldNbArrA, length(ANode.NachbList));
  SetLength(oldConArrA, length(ANode.ConnList));
  For K:=0 To length(ANode.NachbList)-1 Do oldNbArrA[K] := ANode.NachbList[K];  // copy the old NachbList
  For K:=0 To length(ANode.ConnList)-1 Do oldConArrA[K] := ANode.ConnList[K];   // copy the old ConnList
  DeleteArrayElement(ANode.NachbList, idx);                                     // delete one neighbour
  DeleteArrayElement(ANode.ConnList, idx);                                      // delete one connection
  For I:=0 To length(BNode.NachbList)-1 Do
  begin
    TestNode := NodeList.Items[BNode.NachbList[I].nr];
    If TestNode = ANode Then
    begin
      SetLength(oldNbArrB, length(BNode.NachbList));
      SetLength(oldConArrB, length(BNode.ConnList));
      For K:=0 To length(BNode.NachbList)-1 Do oldNbArrB[K] := BNode.NachbList[K];  // copy the old NachbList
      For K:=0 To length(BNode.ConnList)-1 Do oldConArrB[K] := BNode.ConnList[K];   // copy the old ConnList
      DeleteArrayElement(BNode.NachbList, I);
      DeleteArrayElement(BNode.ConnList, I);
      Break;
    end;
  end;
  If TestGraphConnect = False Then                                           // l�schen r�ckg�ngig machen
  begin
    SetLength(ANode.NachbList, length(oldNbArrA));
    SetLength(ANode.ConnList, length(oldConArrA));
    For K:=0 To length(oldNbArrA)-1  Do ANode.NachbList[K] := oldNbArrA[K];  // copy the old NachbList
    For K:=0 To length(oldConArrA)-1 Do ANode.ConnList[K]  := oldConArrA[K]; // copy the old ConnList
    SetLength(BNode.NachbList, length(oldNbArrB));
    SetLength(BNode.ConnList, length(oldConArrB));
    For K:=0 To length(oldNbArrB)-1  Do BNode.NachbList[K] := oldNbArrB[K];  // copy the old NachbList
    For K:=0 To length(oldConArrB)-1 Do BNode.ConnList[K]  := oldConArrB[K]; // copy the old ConnList
    Result := False;
  end else begin
    Result := True;
  end;
  Form1.MainImage.Canvas.Brush.Color := clWhite;
  Form1.MainImage.Canvas.Pen.Color   := clBlack;
  Form1.MainImage.Canvas.Pen.Width   := 1;
  Form1.MainImage.Canvas.Rectangle (0, 0, Form1.MainImage.Width, Form1.MainImage.Height);
  DrawLinks;
  RepaintNodes;
  RepaintAgents;
end;

//=============================Calculate the shortest pathes between the streets
Function TestGraphConnect: Boolean;
var I, K : Integer;
    CurStreet, ToStreet :TNode;
    PfadList  : TList;
begin
  PfadList := TList.Create;
  For I:=0 To StreetList.Count-1 Do
  begin
    CurStreet := StreetList.Items[I];
    For K:=I+1 To StreetList.Count-1 Do
    begin
      PfadList := TList.Create;
      ToStreet := StreetList.Items[K];
      FindPath (PfadList, CurStreet, ToStreet);
      If PfadList.Count = 0 Then
      begin
        Result := False;
        Exit;
      end;
    end;
  end;
  Result := True;
end;

//==============================================================================
Procedure DeleteArrayElement(var arr: TNbArray; const index: integer);
var i: integer;
begin
  if index<high(arr) then
  begin
    for i:=index to high(arr)-1 do
      arr[i]:=arr[i+1];                                                      // eins nach vorne kopieren
  end;
  SetLength(arr, length(arr)-1);                                             // L�nge k�rzen (bei dyn. Arrays)
end;

//==============================================================================
Procedure RepaintAgents;
var I : Integer;
    CurAgent : TAgent;
begin
  For I :=0 To AgentList.Count-1 Do
  begin
    CurAgent := AgentList.Items[I];
    CurAgent.Paint(Form1.MainImage.Canvas);
  end;
end;

//==============================================================================
Procedure RepaintNodes;
var I : Integer;
    CurNode : TNode;
begin
  For I:=0 To NodeList.Count-1 Do
  begin
    CurNode := NodeList.Items[I];
    CurNode.Paint(Form1.MainImage.Canvas);
  end;
end;

//======================================================================torus NB
Procedure Torus(var Value: Integer);
begin
  If Value > NNoS  Then Value := Value - NNoS-1;
  If Value < 0     Then Value := NNoS + Value+1;
end;

//================================================================draw the links
procedure DrawLinks;
var
  I, K, tester    : Integer;
  CurNode, ToNode : TNode;
  BowWth          : Real;
  BezPts          : Array [0..3] of TPoint;
begin
  BowWth := 0.7;
  Form1.MainImage.Canvas.Pen.Color := ClGray;
  For I := 0 To NodeList.Count-1 Do
  begin
    CurNode := NodeList.Items[I];
    BezPts[0].X := CurNode.FPos.X;
    BezPts[0].Y := CurNode.FPos.Y;
    BezPts[1].X := Pos0.X + round((CurNode.FPos.X - Pos0.X)*BowWth);
    BezPts[1].Y := Pos0.Y + round((CurNode.FPos.Y - Pos0.Y)*BowWth);
    For K := 0 To length(CurNode.ConnList)-1 Do
    begin
      If Not (CurNode.ConnList[K].nr = -1) Then
      begin
      ToNode := NodeList.Items[CurNode.ConnList[K].nr];
      Form1.MainImage.Canvas.Pen.Width := 3-CurNode.ConnList[K].Estat;       // pen width depends on edge state
      BezPts[2].X := Pos0.X + round((ToNode.FPos.X - Pos0.X)*BowWth);
      BezPts[2].Y := Pos0.Y + round((ToNode.FPos.Y - Pos0.Y)*BowWth);
      BezPts[3].X := ToNode.FPos.X;
      BezPts[3].Y := ToNode.FPos.Y;
      If (CurNode.ConnList[K].Estat =0) then begin                           // links between primary nodes
        tester := abs(CurNode.ConnList[K].nr - I);
        If (tester>1) And Not (tester>NNoS-1) Then begin
          Form1.MainImage.Canvas.PolyBezier(BezPts);
        end else begin
          Form1.MainImage.Canvas.MoveTo(BezPts[0].X, BezPts[0].Y);
          Form1.MainImage.Canvas.LineTo(BezPts[3].X, BezPts[3].Y);
        end;
      end else begin                                                          // link the secondary and tertiary nodes
        Form1.MainImage.Canvas.MoveTo(BezPts[0].X, BezPts[0].Y);
        Form1.MainImage.Canvas.LineTo(BezPts[3].X, BezPts[3].Y);
      end;
      end;
    end;
  end;
end;

end.

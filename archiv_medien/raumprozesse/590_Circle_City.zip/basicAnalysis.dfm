object Form3: TForm3
  Left = 0
  Top = 0
  Caption = 'Form3'
  ClientHeight = 900
  ClientWidth = 730
  Color = clBtnFace
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -11
  Font.Name = 'Tahoma'
  Font.Style = []
  OldCreateOrder = False
  Position = poDesigned
  PixelsPerInch = 96
  TextHeight = 13
  object Ch_basic: TChart
    Left = 3
    Top = 8
    Width = 721
    Height = 301
    BackWall.Brush.Color = clWhite
    BackWall.Brush.Style = bsClear
    Border.Visible = True
    Gradient.Balance = 99
    Gradient.Direction = gdFromTopLeft
    Gradient.EndColor = 753908
    Gradient.MidColor = 16059031
    Gradient.StartColor = 14540754
    Legend.Visible = False
    Title.Text.Strings = (
      'happyness / movents / thresholds')
    BottomAxis.Title.Caption = 'time'
    DepthAxis.Automatic = False
    DepthAxis.AutomaticMaximum = False
    DepthAxis.AutomaticMinimum = False
    DepthAxis.Maximum = 1.790000000000000000
    DepthAxis.Minimum = 0.790000000000004700
    DepthTopAxis.Automatic = False
    DepthTopAxis.AutomaticMaximum = False
    DepthTopAxis.AutomaticMinimum = False
    DepthTopAxis.Maximum = 1.790000000000000000
    DepthTopAxis.Minimum = 0.790000000000004700
    LeftAxis.Automatic = False
    LeftAxis.AutomaticMaximum = False
    LeftAxis.AutomaticMinimum = False
    LeftAxis.Grid.Visible = False
    LeftAxis.Maximum = 552.500000000000000000
    LeftAxis.MaximumOffset = 3
    LeftAxis.Minimum = 101.599999999999800000
    LeftAxis.MinimumOffset = 5
    LeftAxis.Title.Caption = 'happy/unhappy & moving'
    RightAxis.Automatic = False
    RightAxis.AutomaticMaximum = False
    RightAxis.AutomaticMinimum = False
    RightAxis.Maximum = 370.000000000000000000
    RightAxis.MaximumOffset = 3
    RightAxis.Minimum = 57.500000000000000000
    RightAxis.MinimumOffset = 5
    RightAxis.Title.Caption = 'thresholds'
    TopAxis.Automatic = False
    TopAxis.AutomaticMaximum = False
    TopAxis.AutomaticMinimum = False
    TopAxis.Visible = False
    View3D = False
    Zoom.UpLeftZooms = True
    Color = clWhite
    TabOrder = 0
    object Ser_happy: TFastLineSeries
      Marks.Callout.Brush.Color = clBlack
      Marks.Visible = False
      Title = 'Ser_happy'
      LinePen.Color = clRed
      LinePen.Width = 3
      XValues.Name = 'X'
      XValues.Order = loAscending
      YValues.Name = 'Y'
      YValues.Order = loNone
    end
    object Ser_moving: TFastLineSeries
      Marks.Callout.Brush.Color = clBlack
      Marks.Visible = False
      LinePen.Color = clGreen
      LinePen.Style = psDot
      LinePen.Width = 3
      XValues.Name = 'X'
      XValues.Order = loAscending
      YValues.Name = 'Y'
      YValues.Order = loNone
    end
    object Ser_moveTh: TFastLineSeries
      Marks.Callout.Brush.Color = clBlack
      Marks.Visible = False
      SeriesColor = clBlue
      VertAxis = aRightAxis
      LinePen.Color = clBlue
      LinePen.Style = psDash
      LinePen.Width = 2
      XValues.Name = 'X'
      XValues.Order = loAscending
      YValues.Name = 'Y'
      YValues.Order = loNone
    end
    object Ser_settleTh: TFastLineSeries
      Marks.Callout.Brush.Color = clBlack
      Marks.Visible = False
      SeriesColor = clAqua
      VertAxis = aRightAxis
      LinePen.Color = clAqua
      LinePen.Style = psDashDot
      LinePen.Width = 2
      XValues.Name = 'X'
      XValues.Order = loAscending
      YValues.Name = 'Y'
      YValues.Order = loNone
    end
    object PageNumTool1: TPageNumTool
      Active = False
      Callout.Brush.Color = clBlack
      Callout.Arrow.Visible = False
      Text = 'Page %d of %d'
      Format = 'Page %d of %d'
    end
  end
  object Ch_IS: TChart
    Left = 3
    Top = 314
    Width = 721
    Height = 301
    BackWall.Brush.Color = clWhite
    BackWall.Brush.Style = bsClear
    Border.Visible = True
    Gradient.Balance = 99
    Gradient.Direction = gdFromTopLeft
    Gradient.EndColor = 753908
    Gradient.MidColor = 16059031
    Gradient.StartColor = 14540754
    Legend.Visible = False
    Title.Text.Strings = (
      'TChart')
    BottomAxis.Title.Caption = 'time'
    DepthAxis.Automatic = False
    DepthAxis.AutomaticMaximum = False
    DepthAxis.AutomaticMinimum = False
    DepthAxis.Maximum = 1.790000000000003000
    DepthAxis.Minimum = 0.790000000000004400
    DepthTopAxis.Automatic = False
    DepthTopAxis.AutomaticMaximum = False
    DepthTopAxis.AutomaticMinimum = False
    DepthTopAxis.Maximum = 1.790000000000003000
    DepthTopAxis.Minimum = 0.790000000000004400
    LeftAxis.Grid.Visible = False
    LeftAxis.MaximumOffset = 5
    LeftAxis.MinimumOffset = 5
    LeftAxis.Title.Caption = 'Connectivity'
    RightAxis.MaximumOffset = 5
    RightAxis.MinimumOffset = 5
    RightAxis.Title.Caption = 'segregation index IS'
    TopAxis.Automatic = False
    TopAxis.AutomaticMaximum = False
    TopAxis.AutomaticMinimum = False
    TopAxis.Visible = False
    View3D = False
    Zoom.UpLeftZooms = True
    Color = clWhite
    TabOrder = 1
    object ser_Connect: TFastLineSeries
      Marks.Callout.Brush.Color = clBlack
      Marks.Visible = False
      SeriesColor = clBlack
      LinePen.Style = psDash
      LinePen.Width = 2
      LinePen.EndStyle = esSquare
      XValues.Name = 'X'
      XValues.Order = loAscending
      YValues.Name = 'Y'
      YValues.Order = loNone
    end
    object PageNumTool2: TPageNumTool
      Active = False
      Callout.Brush.Color = clBlack
      Callout.Arrow.Visible = False
      Text = 'Page %d of %d'
      Format = 'Page %d of %d'
    end
  end
  object StringGrid1: TStringGrid
    Left = 3
    Top = 621
    Width = 719
    Height = 276
    ColCount = 15
    DefaultColWidth = 32
    DefaultRowHeight = 16
    RowCount = 14
    TabOrder = 2
  end
end

object Form1: TForm1
  Left = 600
  Top = 0
  Caption = 'Circle City'
  ClientHeight = 766
  ClientWidth = 1016
  Color = clBtnFace
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -11
  Font.Name = 'Tahoma'
  Font.Style = []
  OldCreateOrder = False
  Position = poDesigned
  OnCreate = FormCreate
  OnShow = FormShow
  PixelsPerInch = 96
  TextHeight = 13
  object MainImage: TImage
    Left = 0
    Top = 0
    Width = 766
    Height = 766
  end
  object Panel1: TPanel
    Left = 767
    Top = 0
    Width = 249
    Height = 766
    Align = alRight
    TabOrder = 0
    object Lbl_TimeCt: TLabel
      Left = 24
      Top = 675
      Width = 59
      Height = 13
      Caption = 'Timer_count'
    end
    object GroupBox1: TGroupBox
      Left = 5
      Top = 11
      Width = 236
      Height = 94
      Caption = 'Network Information'
      TabOrder = 0
      object Label1: TLabel
        Left = 32
        Top = 24
        Width = 90
        Height = 13
        Caption = 'number of streets:'
      end
      object Label2: TLabel
        Left = 32
        Top = 43
        Width = 90
        Height = 13
        Caption = 'number of houses:'
      end
      object Label3: TLabel
        Left = 45
        Top = 62
        Width = 77
        Height = 13
        Caption = 'number of flats:'
      end
      object Lbl_NrStr: TLabel
        Left = 128
        Top = 24
        Width = 44
        Height = 13
        Caption = 'Lbl_NrStr'
      end
      object Lbl_NrHou: TLabel
        Left = 128
        Top = 43
        Width = 49
        Height = 13
        Caption = 'Lbl_NrHou'
      end
      object Lbl_NrFla: TLabel
        Left = 128
        Top = 62
        Width = 44
        Height = 13
        Caption = 'Lbl_NrFla'
      end
    end
    object B_showPlots: TButton
      Left = 5
      Top = 521
      Width = 108
      Height = 25
      Caption = 'Basic Plots'
      TabOrder = 1
      OnClick = B_showPlotsClick
    end
    object Button1: TButton
      Left = 5
      Top = 644
      Width = 108
      Height = 25
      Caption = 'Start Timer'
      TabOrder = 2
      OnClick = Button1Click
    end
    object GroupBox2: TGroupBox
      Left = 5
      Top = 111
      Width = 236
      Height = 186
      Caption = 'Setup Structure'
      TabOrder = 3
      object Label4: TLabel
        Left = 71
        Top = 77
        Width = 90
        Height = 13
        Alignment = taRightJustify
        Caption = 'number of streets:'
      end
      object Label5: TLabel
        Left = 20
        Top = 101
        Width = 141
        Height = 13
        Alignment = taRightJustify
        Caption = 'number of houses per street:'
      end
      object Label6: TLabel
        Left = 33
        Top = 126
        Width = 128
        Height = 13
        Alignment = taRightJustify
        Caption = 'number of flats per house:'
      end
      object Label7: TLabel
        Left = 72
        Top = 21
        Width = 89
        Height = 13
        Alignment = taRightJustify
        Caption = 'number of agents:'
      end
      object Label8: TLabel
        Left = 16
        Top = 158
        Width = 145
        Height = 13
        Alignment = taRightJustify
        Caption = 'number of street connections:'
      end
      object Label9: TLabel
        Left = 72
        Top = 44
        Width = 89
        Height = 13
        Alignment = taRightJustify
        Caption = 'number of groups:'
      end
      object Label10: TLabel
        Left = 27
        Top = 21
        Width = 41
        Height = 13
        Alignment = taRightJustify
        Caption = '% free |'
      end
      object E_nrStreets: TEdit
        Left = 167
        Top = 73
        Width = 28
        Height = 21
        TabOrder = 0
        Text = '12'
        OnChange = E_nrStreetsChange
      end
      object UpD_nrStreets: TUpDown
        Left = 195
        Top = 73
        Width = 16
        Height = 21
        Associate = E_nrStreets
        Min = 5
        Position = 12
        TabOrder = 1
        OnClick = UpD_nrStreetsClick
      end
      object E_nrHouses: TEdit
        Left = 167
        Top = 97
        Width = 28
        Height = 21
        TabOrder = 2
        Text = '12'
        OnChange = E_nrStreetsChange
      end
      object UpD_nrHouses: TUpDown
        Left = 195
        Top = 97
        Width = 16
        Height = 21
        Associate = E_nrHouses
        Min = 1
        Position = 12
        TabOrder = 3
        OnClick = UpD_nrStreetsClick
      end
      object E_nrFlats: TEdit
        Left = 167
        Top = 122
        Width = 28
        Height = 21
        TabOrder = 4
        Text = '12'
        OnChange = E_nrStreetsChange
      end
      object UpD_nrFlats: TUpDown
        Left = 195
        Top = 122
        Width = 16
        Height = 21
        Associate = E_nrFlats
        Position = 12
        TabOrder = 5
        OnClick = UpD_nrStreetsClick
      end
      object E_anzAg: TEdit
        Left = 167
        Top = 17
        Width = 44
        Height = 21
        TabOrder = 6
        Text = '1642'
      end
      object UpD_nrAgents: TUpDown
        Left = 211
        Top = 17
        Width = 16
        Height = 21
        Associate = E_anzAg
        Min = 10
        Max = 32767
        Increment = 10
        Position = 1642
        TabOrder = 7
      end
      object E_StrNeigh: TEdit
        Left = 167
        Top = 154
        Width = 28
        Height = 21
        TabOrder = 8
        Text = '6'
      end
      object UpD_StrNeigh: TUpDown
        Left = 195
        Top = 154
        Width = 16
        Height = 21
        Associate = E_StrNeigh
        Min = 2
        Increment = 2
        Position = 6
        TabOrder = 9
      end
      object Edit5: TEdit
        Left = 167
        Top = 40
        Width = 28
        Height = 21
        TabOrder = 10
        Text = '3'
      end
      object UpD_nrGroups: TUpDown
        Left = 195
        Top = 40
        Width = 16
        Height = 21
        Associate = Edit5
        Min = 2
        Max = 13
        Position = 3
        TabOrder = 11
      end
      object E_pFree: TEdit
        Left = 3
        Top = 17
        Width = 22
        Height = 21
        TabOrder = 12
        Text = '05'
        OnChange = E_pFreeChange
      end
    end
    object ValueListEditor1: TValueListEditor
      Left = 5
      Top = 344
      Width = 236
      Height = 162
      Strings.Strings = (
        'Weigths='
        'weigthStreets=0,5'
        'weigthHouses=1,0'
        'Thresholds='
        'leavePlace=0,33'
        'settleDown=0,33')
      TabOrder = 4
      TitleCaptions.Strings = (
        'Control Parameter'
        'Wert')
      OnStringsChange = ValueListEditor1StringsChange
      ColWidths = (
        116
        114)
    end
    object B_setupStruct: TButton
      Left = 5
      Top = 303
      Width = 108
      Height = 25
      Caption = 'Setup Structure'
      TabOrder = 5
      OnClick = B_setupStructClick
    end
    object B_oneStep: TButton
      Left = 135
      Top = 644
      Width = 106
      Height = 25
      Caption = 'Single Step'
      TabOrder = 6
      OnClick = B_oneStepClick
    end
    object Button2: TButton
      Left = 119
      Top = 521
      Width = 122
      Height = 25
      Caption = 'New Weigths'
      TabOrder = 7
      OnClick = Button2Click
    end
    object B_newAgents: TButton
      Left = 133
      Top = 303
      Width = 106
      Height = 25
      Caption = 'New Agents'
      TabOrder = 8
      OnClick = B_newAgentsClick
    end
    object Button3: TButton
      Left = 5
      Top = 720
      Width = 105
      Height = 25
      Caption = 'Delete Connections'
      TabOrder = 9
      OnClick = Button3Click
    end
    object E_Delete: TEdit
      Left = 116
      Top = 722
      Width = 28
      Height = 21
      TabOrder = 10
      Text = '5'
    end
    object UpD_delete: TUpDown
      Left = 144
      Top = 722
      Width = 16
      Height = 21
      Associate = E_Delete
      Min = 1
      Max = 20
      Position = 5
      TabOrder = 11
    end
    object B_advAna: TButton
      Left = 5
      Top = 564
      Width = 108
      Height = 25
      Caption = 'Advanced Analysis'
      TabOrder = 12
      OnClick = B_advAnaClick
    end
    object B_phaseAna: TButton
      Left = 119
      Top = 564
      Width = 124
      Height = 25
      Caption = 'Phasetranition Analysis'
      TabOrder = 13
      OnClick = B_phaseAnaClick
    end
    object Button4: TButton
      Left = 119
      Top = 595
      Width = 122
      Height = 25
      Caption = 'Spatial Effects'
      TabOrder = 14
      OnClick = Button4Click
    end
  end
  object Panel_PBar: TPanel
    Left = 272
    Top = 328
    Width = 217
    Height = 81
    TabOrder = 1
    Visible = False
    object Lbl_ct: TLabel
      Left = 75
      Top = 60
      Width = 66
      Height = 13
      Caption = 'Pathes_count'
    end
    object Lbl_pathOut: TLabel
      Left = 74
      Top = 41
      Width = 69
      Height = 13
      Caption = 'Pathes_real...'
    end
    object ProgressBar1: TProgressBar
      Left = 32
      Top = 18
      Width = 153
      Height = 17
      TabOrder = 0
    end
  end
  object Timer1: TTimer
    Enabled = False
    Interval = 1
    OnTimer = Timer1Timer
    Left = 728
    Top = 8
  end
end

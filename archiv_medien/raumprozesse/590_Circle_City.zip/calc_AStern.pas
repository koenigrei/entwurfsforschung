// *****************************************************************************
// ****************          Pathfinding with A-Stern           ****************
// *****************************************************************************
// --- Programming: Reinhard K�nig                                           ---
// --- Date       : 04.Jan.2007                                              ---
// -----------------------------------------------------------------------------
// --- Find the shortest path in the NodeList                                ---
// --- the findPath procedure returns the found path in the pfadList         ---
// --- beside the NodeList you have to define the startNode and zielNode     ---
// -----------------------------------------------------------------------------

unit calc_AStern;

interface

uses
  Math, SysUtils, Types, Classes, Node;


const                        
  DegToRadX  = 3.141592654/180;
  RadToDegX  = 180/3.141592654;
  Pi        = 3.141592654;

var
  foundPath : Boolean;
  openList  : TList;

procedure setup;
procedure checkNeighbour (parAgent, zielNode : TNode);
procedure calcF          (vorg, me, zielNode : TNode);
procedure findPath       (var pfadList: TList; startNode, zielNode : TNode);
procedure deletePath;
function  compareByF     (Item1 : Pointer; Item2 : Pointer) : Integer;
function  distance       (pX1: Integer; pY1: Integer; pX2: Integer; pY2: Integer): Integer;

implementation

uses Main;

// *****************************************************************************
// ****************             A-Stern Berechnungen            ****************
// *****************************************************************************
//
procedure setup;
begin
  openList := TList.Create;
end;
//==========================================================geht die Nodes durch
procedure findPath (var pfadList: TList; startNode, zielNode : TNode);
var
  explNode : TNode;
  parAgent : TNode;
begin
  foundPath := false;
  deletePath;
  openList.Add(startNode);
  //---------------Wdh. bis openList vollst�ndig �berpr�ft => kein Pfad m�glich!
  //---------------oder bis zielNode erreicht -------------=> pfad gefunden.
  While ((openList.count > 0) And (foundPath = false)) Do
  begin
    explNode := openList.Items[openList.count -1];
    explNode.closed := true;
    checkNeighbour (explNode, zielNode);
    openList.Sort(compareByF);
    openList.Remove(explNode);
  end;
  //----------------------------------------------------------speichere den Pfad
  explNode := zielNode;
  If foundPath = true Then begin
    repeat
      pfadList.Add (explNode);
      explNode := explNode.Vorg;
    Until (explNode = startNode);
    pfadList.Add (startNode);
  end;
  openList.Free;
end;

//=======================Node wird expandiert -&- die neuen Nodes werden gepr�ft
procedure checkNeighbour (parAgent, zielNode : TNode);
var
  I, U      : Integer;
  altG      : Integer;
  altH      : Integer;
  altF      : Integer;
  inOpen    : Boolean;
  cildAgent : TNode;
begin
  for I := 0 To length(parAgent.NachbList)-1 Do
  begin
    cildAgent := NodeList.Items[parAgent.NachbList[I].Nr];
    //If ((cildAgent.State < 999) and (cildAgent.Closed = false)) then
    If (cildAgent.Closed = false) then                  // -- nicht untersucht werden W�nde und closed Nodes
    begin
      inOpen := false;
      for U := 0 To openList.count -1 do                // -- pr�ft, ob Knoten bereits in openList
      begin
        If (openList.Items[U] = cildAgent) then begin
          inOpen := true;
        end;
      end;
      If inOpen = false then                            // -- wenn Node noch nicht in open List
      begin
        calcF (parAgent, cildAgent, zielNode);          // -- berechnet die Sch�tzwerte (Heuristik)
        cildAgent.Vorg := parAgent;                     // -- bestimmt den Vog�nger-VerweisNode
        openList.Add(cildAgent);                        // -- nimmt Node in Openlist auf
        If (cildAgent = zielNode) Then begin
          foundPath := true;                            // -- Ziel erreicht!
        end;
      end else begin                                    // -- wenn wenn Node bereits in open List
                                                        // -- pr�fe, ob G g�nstiger => ver�ndere Vorg
        altG := cildAgent.G;                            // +
        altH := cildAgent.H;                            // + speichert Werte vor der neuBerechnung
        altF := cildAgent.F;                            // +
        calcF (parAgent, cildAgent, zielNode);
        If (altG < cildAgent.G) Then begin              // -- setze alte Werte wieder ein
          cildAgent.G := altG;
          cildAgent.H := altH;
          cildAgent.F := altF;
        end else begin
          cildAgent.Vorg := parAgent;                   // -- falls neuer G-Wert g�nstiger, neuer Verweis auf Vorg�nger-Node
        end;
      end;
    end;
  end;
end;

//===========================================Berechnung der Heuristik: F = G + H
procedure calcF (vorg, me, zielNode : TNode);
var
  dist     : Integer;
begin
  // ----- Berechne G -----
  dist := distance(vorg.FPos.X, vorg.FPos.Y, me.FPos.X, me.FPos.Y);
  me.G := vorg.G + dist;
  // ----- Berechne H -----
  me.H := distance(zielNode.FPos.X, zielNode.FPos.Y, me.FPos.X, me.FPos.Y);
  // ----- Berechne F -----
  me.F := me.G + me.H;
end;

//================================TList sort routine : compare customers by name
//--------------------------------The returned integer has the following value :
//--------------------------------   > 0 : (positive) Item1 is less than Item2
//--------------------------------     0 : Item1 is equal to Item2
//--------------------------------   < 0 : (negative) Item1 is greater than Item2
function compareByF(Item1 : Pointer; Item2 : Pointer) : Integer;
var
  customer1, customer2 : TNode;
begin
  //-------------------We start by viewing the object pointers as TNode objects
  customer1 := TNode(Item1);
  customer2 := TNode(Item2);
  //-------------------------------------------Now compare by F - complete Kosts
  if   customer1.F < customer2.F
    then Result := 1
  else if customer1.F = customer2.F
    then Result := 0
  else   Result := -1;
end;

//=================================================================Pfade l�schen
procedure deletePath;
var
  I : Integer;
  AShape : TNode;
begin
  openList := TList.Create;
  for I := 0 to NodeList.Count - 1 do
  begin
    AShape := NodeList.Items [I];
    AShape.F:= 0;
    AShape.G:= 0;
    AShape.H:= 0;
    AShape.closed:= false;
  end;
end;

//===================================================funktion zur Distanzmessung
function distance(pX1: Integer; pY1: Integer; pX2: Integer; pY2: Integer): Integer;
  var temp: double;
  begin
  temp := sqrt(Power((pX1 - pX2), 2) + Power((pY1 - pY2), 2));
  distance := Round(temp);
end;

end.

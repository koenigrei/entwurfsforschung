unit Agent;

interface

uses
  Windows, Graphics;

type
  colList = Array of TColor;

type
  TAgent = class
  private

  public
    Stopped   : Boolean;
    onCell    : TPoint;
    satisf    : Double;
    FState    : Integer;
    FColor    : TColor;
    FPos      : TPoint;
    FSize     : Integer;
    //Same      : Real;                                                         // Fraction of same kinded agents
    //Others    : Real;                                                         // Fraction of different agents
    NrFlat    : Integer;
    NeighFract: Real;
    procedure Paint (Canvas: TCanvas);
  published

  end;

implementation

procedure TAgent.Paint (Canvas: TCanvas);
begin
  Canvas.Pen.Width := 1;
  Canvas.Pen.Color := FColor; 
  Canvas.Brush.Color := FColor;
  Canvas.Ellipse (FPos.X - FSize , FPos.Y - (FSize), FPos.X + (FSize), FPos.Y + (FSize));
end;

end.

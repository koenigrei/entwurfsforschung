unit phaseTransAna;

interface

uses
  Windows, Messages, SysUtils, Variants, Classes, Graphics, Controls, Forms, Math,
  Dialogs, ExtCtrls, StdCtrls, TeEngine, TeeFunci, TeeTools, TeePageNumTool, 
  Series, TeeProcs, Chart, TeeSVGCanvas, TeeEdit;

type
  TForm6 = class(TForm)
    Chart_Stability: TChart;
    ser_segVal: TPointSeries;
    ser_segAvg: TLineSeries;
    PageNumTool1    : TPageNumTool;
    TeeFunction1    : TAverageTeeFunction;
    GroupBox1       : TGroupBox;
    Label1          : TLabel;
    Label2          : TLabel;
    Label3          : TLabel;
    Label4          : TLabel;
    Label5          : TLabel;
    E_valFrom       : TEdit;
    E_valTo         : TEdit;
    E_toSteps       : TEdit;
    E_calcRds       : TEdit;
    E_incre         : TEdit;
    lbl_pSteps      : TLabel;
    lbl_timesteps   : TLabel;
    Label8          : TLabel;
    Lbl_proceed     : TLabel;
    Timer5          : TTimer;
    B_undoZ         : TButton;
    Chart_Change    : TChart;
    ser_avgVal: TLineSeries;
    PageNumTool3    : TPageNumTool;
    ser_avgChange: TLineSeries;
    GroupBox2       : TGroupBox;
    Label6          : TLabel;
    E_thirdFrom     : TEdit;
    Label7          : TLabel;
    E_thirdTo       : TEdit;
    Label9          : TLabel;
    E_thirdIncre    : TEdit;
    S_start         : TButton;
    S_break         : TButton;
    Button1         : TButton;
    Cb_acti3d       : TCheckBox;
    CB_param: TComboBox;
    ser_ConnVal: TPointSeries;
    ser_ConnAvg: TLineSeries;
    TeeFunction2: TAverageTeeFunction;
    cB_showTicks: TCheckBox;
    Button2: TButton;
    Button3: TButton;
    ChartEditor1: TChartEditor;
    Lbl_akt: TLabel;
    Button4: TButton;
    Button5: TButton;
    ChartEditor2: TChartEditor;
    ser_Change: TPointSeries;
    ser_Val: TPointSeries;
    TeeFunction3: TAverageTeeFunction;
    TeeFunction4: TAverageTeeFunction;
    cB_showTicks2: TCheckBox;
    procedure FormCreate      (Sender: TObject);
    procedure S_breakClick    (Sender: TObject);
    procedure S_startClick    (Sender: TObject);
    procedure B_undoZClick    (Sender: TObject);
    procedure Timer5Timer     (Sender: TObject);
    procedure cB_showTicksClick(Sender: TObject);
    procedure Button2Click(Sender: TObject);
    procedure Button3Click(Sender: TObject);
    procedure Button4Click(Sender: TObject);
    procedure Button5Click(Sender: TObject);
    procedure cB_showTicks2Click(Sender: TObject);
  private
    procedure resetGraphs;
    procedure newRound;
    procedure plotVals;
    procedure writeParameter;
  public
    { Public declarations }
  end;

var
  Form6    : TForm6;
  pSteps   : Integer;    // -- local step counter
  rounds   : Cardinal;
  thirdRds : Cardinal;
  aktVal   : Real;       // -- holds the actual tolerance value
  thirdVal : Integer;    // -- holds the actual third value
  thirdActi: Boolean;    // -- if the calculation of a third parameter is activated
  toCalc   : Cardinal;   // -- how many values have to be calculated
  noChange : Integer;
  oldChange: Integer;
  ctUp     : Boolean;    // -- indicates if the aktVal have to increased or decreased

implementation

{$R *.dfm}
uses Main, CreateStructure, basicAnalysis,
     TeeStore, TeExport, TeeAbout, TeePNG, TeeJPEG;

procedure TForm6.FormCreate(Sender: TObject);
begin
  Timer5.enabled     := false;
  lbl_pSteps.Caption := '0';
  pSteps := 0;
  globCount  := 0;
  toCalc := 0;
  Lbl_akt.Caption := IntToStr(toCalc);
  Chart_Stability.Title.Text.Clear;
  Chart_Stability.Title.Text.Add('phase transitions || '+IntToStr(NGroups)+' groups');
  resetGraphs;
  thirdActi := false;
  CB_param.AddItem(' thresh leavePlace', Sender);  //- 0
  CB_param.AddItem(' thresh settleDown', Sender);  //- 1
  CB_param.AddItem(' both thresholds', Sender);    //- 2
  CB_param.AddItem(' weightStreets', Sender);      //- 3
  CB_param.AddItem(' weightHouses', Sender);       //- 4
  CB_param.AddItem(' connections', Sender);        //- 5
end;


procedure TForm6.Button2Click(Sender: TObject);
begin
  TeeExport(Self,Chart_Stability)
end;


procedure TForm6.Button3Click(Sender: TObject);
begin
  ChartEditor1.Execute
end;

procedure TForm6.Button4Click(Sender: TObject);
begin
  ChartEditor2.Execute
end;

procedure TForm6.Button5Click(Sender: TObject);
begin
  TeeExport(Self, Chart_Change)
end;

procedure TForm6.S_breakClick(Sender: TObject);
begin
  Timer5.enabled := not(Timer5.enabled);
end;

procedure TForm6.resetGraphs;
begin
  ser_segVal.clear;
  ser_segVal.VertAxis := aLeftAxis;
  ser_segAvg.Clear;
  ser_segAvg.VertAxis := aLeftAxis;
  ser_ConnVal.Clear;
  ser_ConnVal.VertAxis := aRightAxis;
  ser_ConnAvg.Clear;
  ser_ConnAvg.VertAxis := aRightAxis;
  ser_Val.clear;
  ser_Val.VertAxis := aLeftAxis;
  ser_avgVal.Clear;
  ser_avgVal.VertAxis := aLeftAxis;
  ser_change.clear;
  ser_change.VertAxis := aRightAxis;
  ser_avgChange.Clear;
  ser_avgChange.VertAxis := aRightAxis;
  ser_avgChange.Color := clGreen;
end;

procedure TForm6.Timer5Timer(Sender: TObject);
var valFrom, valTo : Real;
    testRds : Integer;
begin
  If noChange >= StrToInt(E_toSteps.Text) Then                                // -- increase tolerance if nothing changes
  begin
    plotVals;
    noChange := 0;
    writeParameter;
    inc(toCalc);
    Lbl_akt.Caption := IntToStr(toCalc);
    If ctUp = true Then
    begin
      valTo := StrToFloat(E_valTo.Text)-0.0001;
      valFrom := aktVal;
    end else begin
      valTo := aktVal-0.0001;
      valFrom := StrToFloat(E_valTo.Text);
    end;
    If valFrom >= valTo Then                                   // -- one round is finished
    begin
      ser_segAvg.FunctionType.Period := rounds;
      ser_segAvg.CheckDataSource;                                          // -- print the average
      ser_ConnAvg.FunctionType.Period := rounds;
      ser_ConnAvg.CheckDataSource;

      ser_avgVal.FunctionType.Period := rounds;
      ser_avgVal.CheckDataSource;                                             // -- print the average
      ser_avgChange.FunctionType.Period := rounds;
      ser_avgChange.CheckDataSource;
      testRds := StrToInt(E_calcRds.Text);
      If rounds >= testRds Then                                               // -- calculated rounds
      begin                                                                   // -- in the 2D case exit the examination
        Timer5.enabled := false;                                            // -- the end of the analysis
        exit;
      end;

      pSteps := 1;
      inc(rounds);
      newRound;                                                               // -- start again from the beginning
      If CB_param.ItemIndex = 5 Then
      begin
        Form1.Deleter;
        Form1.SetupStruct;
        //rounds := 0;
      end;
      Form1.CreateNewAgents;
    end;
    If pSteps > 0 Then
    begin
      If CB_param.ItemIndex = 5 Then Form1.ConnectionDeleteAuto;              // Delete a connection
      If ctUp=true Then begin
        aktVal := aktVal + StrToFloat(E_incre.Text);                          // increase the aktVal
      end else begin
        aktVal := aktVal - StrToFloat(E_incre.Text);                          // decrease the aktVal
      end;
    end;
  end;
  If UnHappyList.Count = oldChange Then inc(noChange) Else noChange := 0;     // -- if there is no change increase the noChange counter
  oldChange := UnHappyList.Count;
  Form1.Execute;                                                              // -- run the process at Form1
  lbl_pSteps.Caption := IntToStr (pSteps);
  inc(pSteps);
end;

procedure TForm6.newRound;
begin
  pSteps    := 0;
  globCount := 0;
  noChange  := 0;
  Lbl_akt.Caption := IntToStr(toCalc);
  aktVal := StrToFloat(E_valFrom.Text);
  writeParameter;
  Lbl_proceed.Caption := IntToStr(rounds);
end;

procedure TForm6.writeParameter;
begin
  case CB_param.ItemIndex of                                                  // -- raise aktual value by increment
    0: Form1.ValueListEditor1.Values['leavePlace'] := FloatToStr(aktVal);
    1: Form1.ValueListEditor1.Values['settleDown'] := FloatToStr(aktVal);
    2: begin Form1.ValueListEditor1.Values['leavePlace'] := FloatToStr(aktVal);
             Form1.ValueListEditor1.Values['settleDown'] := FloatToStr(aktVal);
       end;
    3: begin Form1.ValueListEditor1.Values['weigthStreets'] := FloatToStr(aktVal);
             Form1.CalcWeightsNew;
       end;
    4: begin Form1.ValueListEditor1.Values['weigthHouses'] := FloatToStr(aktVal);
             Form1.CalcWeightsNew;
       end;
    5: begin Form1.UpD_delete.Position  := round(StrToFloat(E_incre.Text));

       end;
  end;
end;

procedure TForm6.plotVals;
var
  I : Integer;
  sumIS   : Extended;
begin
  sumIS   := 0;
  For I := 0 To NGroups-1 Do
  begin
    sumIS   := sumIS + isSer[I].YValues[pSteps-1];
  end;
  sumIS := sumIS / NGroups;
  If CB_param.ItemIndex = 5 Then begin
    ser_SegVal.AddXY(aktVal, sumIS);
    ser_ConnVal.AddXY(aktVal, globML);
  end else begin
    ser_SegVal.AddXY(aktVal*100, sumIS);                                   // -- average of the segregation indices
  end;
  ser_Val.AddXY(globCount, aktVal);
end;

//******************************************************************************
procedure TForm6.S_startClick(Sender: TObject);
begin
  If StrToFloat(E_valFrom.Text) < StrToFloat(E_valTo.Text) Then
  begin
    ctUp := true;
  end else begin
    ctUp := false;
  end;
  Form1.Deleter;
  Form1.SetupStruct;
  rounds := 1;
  Lbl_proceed.Caption := IntToStr(rounds);
  If CB_param.ItemIndex = -1 Then
  begin
    MessageBox(MB_Ok, 'please select a parameter', 'missing value', MB_Ok);
    exit;
  end;
  pSteps   := 0;
  toCalc   := 0;
  rounds   := 1;
  thirdRds := 1;
  resetGraphs;
  newRound;
  Timer5.Enabled := true;
  Chart_Stability.Title.Text.Clear;
  Chart_Stability.Title.Text.Add('phase transitions || '+IntToStr(NGroups)+' groups');
  Form3.resetCharts;
end;

procedure TForm6.B_undoZClick(Sender: TObject);
begin
  Chart_Stability.UndoZoom;
  Chart_Change.UndoZoom;
end;

procedure TForm6.cB_showTicksClick(Sender: TObject);
begin
  ser_ConnVal.Visible := cB_showTicks.Checked;
  ser_segVal.Visible := cB_showTicks.Checked;
end;

procedure TForm6.cB_showTicks2Click(Sender: TObject);
begin
  ser_Change.Visible := cB_showTicks2.Checked;
  ser_Val.Visible := cB_showTicks2.Checked;
end;

end.

unit Node;

interface

uses
  Windows, Graphics, Classes, Math;

type TStateWeight = record    // --- list of the other flats
      State  : Array of Integer; //^Integer;      // --- with the state
      Path   : TList;         // --- shortest path to the considered neighbour
      Weight : Real;          // --- and the weigth = relative distance
      //FromNode, ToNode  : Integer; // --- NodeList Idices
      //SelfInd, OtherInd : Integer; // --- Indices of the StaWgList Array
end;

type TNachb = record       // --- f�r A* Heuristik
      nr    : Integer;     // --- = NeigborList
      EStat : Integer;     // --- indicates the type of edge
end;

type TNbArray = Array of TNachb;

type
  TNode = class
  private
    //
  public
    F  : Integer;
    G  : Integer;
    H  : Integer;
    Vorg   : Pointer;
    closed : Boolean;                                                        // Array of states and weigths
    StaWgList : Array of TStateWeight;
    ConnList  : TNbArray;                                                    // List of connected neighbours
    NachbList : TNbArray;                                                    // Street neighbours for a*-calculation
    FFree     : Boolean;
    FPos      : TPoint;
    FSize     : Integer;
    FFillCol  : Integer;
    FLineCol  : Integer;
    NStat     : Integer;                                                      // Type of the node
    FState    : Integer;                                                      // Status of the agent on the node

    HouseList : TList;                                                        // Houses in a street
    FlatList  : TList;                                                        // Flats in a house
    toStreet  : Integer;                                                      // Index of the street a house of flat are part of
    toHouse   : Integer;                                                      // Indes of the house a flat is part of
    typeRatio : Array of Integer;                                             // number of agents from different groups in a house or in a street
    NachbStr  : Array of TList;

    procedure Paint (Canvas: TCanvas);

  published

  end;

implementation

// ********* Zeichnungseinstellungen f�r die Agentenrepr�sentation **********//
procedure TNode.Paint(Canvas: TCanvas);
begin
  Canvas.Pen.Color := FLineCol;
  Canvas.Pen.Style := psSolid;                                                 // (psSolid, psDash, psDot, psClear)
  Canvas.Pen.Width := 1;
  Canvas.Brush.Color := FFillCol;
  Canvas.Ellipse (FPos.X - FSize , FPos.Y - (FSize), FPos.X + (FSize), FPos.Y + (FSize));
end;

end.

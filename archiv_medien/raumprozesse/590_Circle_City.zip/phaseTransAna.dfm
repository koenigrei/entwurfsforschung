object Form6: TForm6
  Left = 0
  Top = 0
  Caption = 'Analyse Stability & Phasetransitions'
  ClientHeight = 690
  ClientWidth = 1016
  Color = clBtnFace
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -11
  Font.Name = 'Tahoma'
  Font.Style = []
  OldCreateOrder = False
  OnCreate = FormCreate
  PixelsPerInch = 96
  TextHeight = 13
  object lbl_pSteps: TLabel
    Left = 892
    Top = 599
    Width = 49
    Height = 13
    Alignment = taRightJustify
    Caption = 'lbl_pSteps'
  end
  object lbl_timesteps: TLabel
    Left = 947
    Top = 599
    Width = 53
    Height = 13
    Caption = ': timesteps'
  end
  object Label8: TLabel
    Left = 947
    Top = 618
    Width = 40
    Height = 13
    Caption = ': rounds'
  end
  object Lbl_proceed: TLabel
    Left = 919
    Top = 618
    Width = 19
    Height = 13
    Alignment = taRightJustify
    Caption = 'sum'
  end
  object Lbl_akt: TLabel
    Left = 882
    Top = 618
    Width = 19
    Height = 13
    Alignment = taRightJustify
    Caption = 'sum'
  end
  object Chart_Stability: TChart
    Left = 8
    Top = 8
    Width = 801
    Height = 340
    BackWall.Brush.Color = clWhite
    BackWall.Brush.Style = bsClear
    Border.Visible = True
    Gradient.Balance = 99
    Gradient.Direction = gdFromTopLeft
    Gradient.EndColor = 753908
    Gradient.MidColor = 16059031
    Gradient.StartColor = 14540754
    Legend.CheckBoxesStyle = cbsRadio
    Legend.Visible = False
    Title.Text.Strings = (
      'phase transitions || ')
    BottomAxis.ExactDateTime = False
    BottomAxis.Increment = 1.000000000000000000
    BottomAxis.Title.Caption = 'value'
    DepthAxis.Automatic = False
    DepthAxis.AutomaticMaximum = False
    DepthAxis.AutomaticMinimum = False
    DepthAxis.Maximum = 0.500000000000005700
    DepthAxis.Minimum = -0.499999999999991600
    DepthTopAxis.Automatic = False
    DepthTopAxis.AutomaticMaximum = False
    DepthTopAxis.AutomaticMinimum = False
    DepthTopAxis.Maximum = 0.500000000000005700
    DepthTopAxis.Minimum = -0.499999999999991600
    LeftAxis.ExactDateTime = False
    LeftAxis.Grid.ZPosition = 100.000000000000000000
    LeftAxis.Inverted = True
    LeftAxis.MaximumOffset = 5
    LeftAxis.MinimumOffset = 5
    LeftAxis.Title.Caption = 'average segregation index'
    RightAxis.Grid.Visible = False
    RightAxis.Inverted = True
    RightAxis.MaximumOffset = 5
    RightAxis.MinimumOffset = 5
    RightAxis.Title.Caption = 'average connectivity'
    TopAxis.Automatic = False
    TopAxis.AutomaticMaximum = False
    TopAxis.AutomaticMinimum = False
    TopAxis.Visible = False
    View3D = False
    Zoom.UpLeftZooms = True
    Color = clWhite
    TabOrder = 0
    object ser_segAvg: TLineSeries
      Marks.Callout.Brush.Color = clBlack
      Marks.Visible = False
      DataSource = ser_segVal
      SeriesColor = clGreen
      LinePen.Color = clGreen
      LinePen.Width = 3
      Pointer.InflateMargins = True
      Pointer.Style = psRectangle
      Pointer.Visible = False
      XValues.Name = 'X'
      XValues.Order = loAscending
      YValues.Name = 'Y'
      YValues.Order = loNone
      object TeeFunction1: TAverageTeeFunction
      end
    end
    object ser_ConnAvg: TLineSeries
      Marks.Callout.Brush.Color = clBlack
      Marks.Visible = False
      DataSource = ser_ConnVal
      LinePen.Color = clBlue
      LinePen.Style = psDashDot
      LinePen.Width = 3
      Pointer.InflateMargins = True
      Pointer.Style = psRectangle
      Pointer.Visible = False
      XValues.Name = 'X'
      XValues.Order = loAscending
      YValues.Name = 'Y'
      YValues.Order = loNone
      object TeeFunction2: TAverageTeeFunction
      end
    end
    object ser_ConnVal: TPointSeries
      Marks.Callout.Brush.Color = clBlack
      Marks.Visible = False
      VertAxis = aRightAxis
      ClickableLine = False
      Pointer.HorizSize = 2
      Pointer.InflateMargins = True
      Pointer.Style = psDiagCross
      Pointer.VertSize = 2
      Pointer.Visible = True
      XValues.Name = 'X'
      XValues.Order = loAscending
      YValues.Name = 'Y'
      YValues.Order = loNone
    end
    object ser_segVal: TPointSeries
      Marks.Callout.Brush.Color = clBlack
      Marks.Visible = False
      ClickableLine = False
      Pointer.HorizSize = 2
      Pointer.InflateMargins = True
      Pointer.Style = psCross
      Pointer.VertSize = 2
      Pointer.Visible = True
      XValues.Name = 'X'
      XValues.Order = loAscending
      YValues.Name = 'Y'
      YValues.Order = loNone
    end
    object PageNumTool1: TPageNumTool
      Active = False
      Callout.Brush.Color = clBlack
      Callout.Arrow.Visible = False
      Text = 'Page %d of %d'
      Format = 'Page %d of %d'
    end
  end
  object GroupBox1: TGroupBox
    Left = 815
    Top = 8
    Width = 192
    Height = 178
    Caption = 'settings'
    TabOrder = 1
    object Label1: TLabel
      Left = 12
      Top = 64
      Width = 74
      Height = 13
      Caption = 'tolerance from:'
    end
    object Label2: TLabel
      Left = 126
      Top = 65
      Width = 14
      Height = 13
      Caption = 'to:'
    end
    object Label3: TLabel
      Left = 20
      Top = 125
      Width = 107
      Height = 13
      Caption = 'steps until next value:'
    end
    object Label4: TLabel
      Left = 90
      Top = 152
      Width = 37
      Height = 13
      Caption = 'rounds:'
    end
    object Label5: TLabel
      Left = 76
      Top = 97
      Width = 51
      Height = 13
      Caption = 'increment:'
    end
    object E_valFrom: TEdit
      Left = 88
      Top = 61
      Width = 32
      Height = 21
      TabOrder = 0
      Text = '0,1'
    end
    object E_valTo: TEdit
      Left = 146
      Top = 61
      Width = 32
      Height = 21
      TabOrder = 1
      Text = '0,9'
    end
    object E_toSteps: TEdit
      Left = 133
      Top = 121
      Width = 32
      Height = 21
      TabOrder = 2
      Text = '3'
    end
    object E_calcRds: TEdit
      Left = 133
      Top = 148
      Width = 32
      Height = 21
      TabOrder = 3
      Text = '10'
    end
    object E_incre: TEdit
      Left = 133
      Top = 93
      Width = 32
      Height = 21
      TabOrder = 4
      Text = '0,01'
    end
    object CB_param: TComboBox
      Left = 16
      Top = 24
      Width = 158
      Height = 21
      ItemHeight = 13
      TabOrder = 5
      Text = ' choose parameter'
    end
  end
  object B_undoZ: TButton
    Left = 920
    Top = 652
    Width = 75
    Height = 25
    Caption = 'undoZoom'
    TabOrder = 2
    OnClick = B_undoZClick
  end
  object Chart_Change: TChart
    Left = 8
    Top = 356
    Width = 801
    Height = 326
    BackWall.Brush.Color = clWhite
    BackWall.Brush.Style = bsClear
    Border.Visible = True
    Gradient.Balance = 99
    Gradient.Direction = gdFromTopLeft
    Gradient.EndColor = 753908
    Gradient.MidColor = 16059031
    Gradient.StartColor = 14540754
    Legend.Visible = False
    Title.Text.Strings = (
      'changes')
    BottomAxis.Title.Caption = 'timesteps'
    DepthAxis.Automatic = False
    DepthAxis.AutomaticMaximum = False
    DepthAxis.AutomaticMinimum = False
    DepthAxis.Maximum = 0.500000000000000000
    DepthAxis.Minimum = -0.500000000000000000
    DepthTopAxis.Automatic = False
    DepthTopAxis.AutomaticMaximum = False
    DepthTopAxis.AutomaticMinimum = False
    DepthTopAxis.Maximum = 0.500000000000000000
    DepthTopAxis.Minimum = -0.500000000000000000
    LeftAxis.Grid.Visible = False
    LeftAxis.MaximumOffset = 5
    LeftAxis.MinimumOffset = 5
    LeftAxis.Title.Caption = 'tolerance value'
    RightAxis.MaximumOffset = 5
    RightAxis.MinimumOffset = 5
    RightAxis.Title.Caption = 'number of changing agents'
    TopAxis.Automatic = False
    TopAxis.AutomaticMaximum = False
    TopAxis.AutomaticMinimum = False
    TopAxis.Visible = False
    View3D = False
    Zoom.UpLeftZooms = True
    Color = clWhite
    TabOrder = 3
    object ser_avgVal: TLineSeries
      Marks.Callout.Brush.Color = clBlack
      Marks.Visible = False
      DataSource = ser_Val
      SeriesColor = clBlack
      LinePen.Width = 2
      Pointer.InflateMargins = True
      Pointer.Style = psRectangle
      Pointer.Visible = False
      XValues.Name = 'X'
      XValues.Order = loAscending
      YValues.Name = 'Y'
      YValues.Order = loNone
      object TeeFunction3: TAverageTeeFunction
      end
    end
    object ser_avgChange: TLineSeries
      Marks.Callout.Brush.Color = clBlack
      Marks.Visible = False
      DataSource = ser_Change
      SeriesColor = clGreen
      VertAxis = aRightAxis
      LinePen.Color = clGreen
      LinePen.Width = 3
      Pointer.InflateMargins = True
      Pointer.Style = psRectangle
      Pointer.Visible = False
      XValues.Name = 'X'
      XValues.Order = loAscending
      YValues.Name = 'Y'
      YValues.Order = loNone
      object TeeFunction4: TAverageTeeFunction
      end
    end
    object ser_Change: TPointSeries
      Marks.Callout.Brush.Color = clBlack
      Marks.Visible = False
      VertAxis = aRightAxis
      ClickableLine = False
      Pointer.HorizSize = 2
      Pointer.InflateMargins = True
      Pointer.Style = psCross
      Pointer.VertSize = 2
      Pointer.Visible = True
      XValues.Name = 'X'
      XValues.Order = loAscending
      YValues.Name = 'Y'
      YValues.Order = loNone
    end
    object ser_Val: TPointSeries
      Marks.Callout.Brush.Color = clBlack
      Marks.Visible = False
      ClickableLine = False
      Pointer.HorizSize = 2
      Pointer.InflateMargins = True
      Pointer.Style = psDiagCross
      Pointer.VertSize = 2
      Pointer.Visible = True
      XValues.Name = 'X'
      XValues.Order = loAscending
      YValues.Name = 'Y'
      YValues.Order = loNone
    end
    object PageNumTool3: TPageNumTool
      Active = False
      Callout.Brush.Color = clBlack
      Callout.Arrow.Visible = False
      Text = 'Page %d of %d'
      Format = 'Page %d of %d'
    end
  end
  object GroupBox2: TGroupBox
    Left = 815
    Top = 192
    Width = 193
    Height = 105
    Caption = 'analyse with a third paramter:'
    TabOrder = 4
    object Label6: TLabel
      Left = 12
      Top = 48
      Width = 55
      Height = 13
      Caption = 'value from:'
    end
    object Label7: TLabel
      Left = 117
      Top = 49
      Width = 14
      Height = 13
      Caption = 'to:'
    end
    object Label9: TLabel
      Left = 80
      Top = 78
      Width = 51
      Height = 13
      Caption = 'increment:'
    end
    object E_thirdFrom: TEdit
      Left = 79
      Top = 45
      Width = 32
      Height = 21
      TabOrder = 0
      Text = '25'
    end
    object E_thirdTo: TEdit
      Left = 137
      Top = 45
      Width = 32
      Height = 21
      TabOrder = 1
      Text = '45'
    end
    object E_thirdIncre: TEdit
      Left = 137
      Top = 74
      Width = 32
      Height = 21
      TabOrder = 2
      Text = '1'
    end
    object Cb_acti3d: TCheckBox
      Left = 42
      Top = 25
      Width = 71
      Height = 17
      Caption = 'activate'
      TabOrder = 3
    end
  end
  object S_start: TButton
    Left = 851
    Top = 476
    Width = 75
    Height = 25
    Caption = 'new start'
    TabOrder = 5
    OnClick = S_startClick
  end
  object S_break: TButton
    Left = 929
    Top = 476
    Width = 75
    Height = 25
    Caption = 'start / stop'
    TabOrder = 6
    OnClick = S_breakClick
  end
  object Button1: TButton
    Left = 855
    Top = 529
    Width = 153
    Height = 25
    Caption = 'show 3D surface'
    TabOrder = 7
    Visible = False
  end
  object cB_showTicks: TCheckBox
    Left = 815
    Top = 312
    Width = 74
    Height = 17
    Caption = 'show ticks'
    Checked = True
    State = cbChecked
    TabOrder = 8
    OnClick = cB_showTicksClick
  end
  object Button2: TButton
    Left = 902
    Top = 308
    Width = 50
    Height = 25
    Caption = 'save'
    TabOrder = 9
    OnClick = Button2Click
  end
  object Button3: TButton
    Left = 958
    Top = 308
    Width = 50
    Height = 25
    Caption = 'edit'
    TabOrder = 10
    OnClick = Button3Click
  end
  object Button4: TButton
    Left = 958
    Top = 364
    Width = 50
    Height = 25
    Caption = 'edit'
    TabOrder = 11
    OnClick = Button4Click
  end
  object Button5: TButton
    Left = 902
    Top = 364
    Width = 50
    Height = 25
    Caption = 'save'
    TabOrder = 12
    OnClick = Button5Click
  end
  object cB_showTicks2: TCheckBox
    Left = 815
    Top = 368
    Width = 74
    Height = 17
    Caption = 'show ticks'
    Checked = True
    State = cbChecked
    TabOrder = 13
    OnClick = cB_showTicks2Click
  end
  object Timer5: TTimer
    Interval = 1
    OnTimer = Timer5Timer
    Left = 886
    Top = 650
  end
  object ChartEditor1: TChartEditor
    Chart = Chart_Stability
    Left = 968
    Top = 560
  end
  object ChartEditor2: TChartEditor
    Chart = Chart_Change
    Left = 920
    Top = 560
  end
end

object Form4: TForm4
  Left = 0
  Top = 0
  Caption = 'Spatial Analysis'
  ClientHeight = 792
  ClientWidth = 1001
  Color = clBtnFace
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -11
  Font.Name = 'Tahoma'
  Font.Style = []
  OldCreateOrder = False
  OnCreate = FormCreate
  PixelsPerInch = 96
  TextHeight = 13
  object lbl_pSteps: TLabel
    Left = 860
    Top = 191
    Width = 49
    Height = 13
    Alignment = taRightJustify
    Caption = 'lbl_pSteps'
  end
  object lbl_timesteps: TLabel
    Left = 915
    Top = 191
    Width = 53
    Height = 13
    Caption = ': timesteps'
  end
  object Label8: TLabel
    Left = 915
    Top = 210
    Width = 62
    Height = 13
    Caption = ': calculations'
  end
  object Lbl_proceed: TLabel
    Left = 890
    Top = 210
    Width = 19
    Height = 13
    Alignment = taRightJustify
    Caption = 'sum'
  end
  object Lbl_akt: TLabel
    Left = 852
    Top = 210
    Width = 19
    Height = 13
    Alignment = taRightJustify
    Caption = 'sum'
  end
  object Label3: TLabel
    Left = 800
    Top = 241
    Width = 106
    Height = 13
    Caption = 'subcharts save name:'
  end
  object Chart_Slope: TChart
    Left = 8
    Top = 14
    Width = 786
    Height = 377
    BackWall.Brush.Color = clWhite
    BackWall.Brush.Style = bsClear
    Border.Visible = True
    Gradient.Balance = 99
    Gradient.Direction = gdFromTopLeft
    Gradient.EndColor = 753908
    Gradient.MidColor = 16059031
    Gradient.StartColor = 14540754
    Title.Text.Strings = (
      'TChart')
    BottomAxis.ExactDateTime = False
    BottomAxis.Increment = 1.000000000000000000
    BottomAxis.Title.Caption = 'values'
    DepthAxis.Automatic = False
    DepthAxis.AutomaticMaximum = False
    DepthAxis.AutomaticMinimum = False
    DepthAxis.Maximum = 0.500000000000000000
    DepthAxis.Minimum = -0.500000000000000000
    DepthTopAxis.Automatic = False
    DepthTopAxis.AutomaticMaximum = False
    DepthTopAxis.AutomaticMinimum = False
    DepthTopAxis.Maximum = 0.500000000000000000
    DepthTopAxis.Minimum = -0.500000000000000000
    LeftAxis.Title.Caption = 'delta IS | r'#178
    RightAxis.Grid.Visible = False
    RightAxis.Title.Caption = 'StDv |  S_error'
    TopAxis.Automatic = False
    TopAxis.AutomaticMaximum = False
    TopAxis.AutomaticMinimum = False
    TopAxis.Visible = False
    View3D = False
    Zoom.UpLeftZooms = True
    Color = clWhite
    TabOrder = 0
    PrintMargins = (
      15
      26
      15
      26)
    object ser_slopeTrend: TLineSeries
      Marks.Callout.Brush.Color = clBlack
      Marks.Callout.Length = 0
      Marks.Visible = False
      Title = 'deltaIS'
      ClickableLine = False
      LinePen.Color = clRed
      LinePen.Width = 2
      Pointer.HorizSize = 3
      Pointer.InflateMargins = True
      Pointer.Style = psCircle
      Pointer.VertSize = 3
      Pointer.Visible = True
      XValues.Name = 'X'
      XValues.Order = loAscending
      YValues.Name = 'Y'
      YValues.Order = loNone
    end
    object ser_StDv: TLineSeries
      Marks.Callout.Brush.Color = clBlack
      Marks.Visible = False
      Title = 'StDv'
      VertAxis = aRightAxis
      LinePen.Color = clGreen
      LinePen.Style = psDash
      LinePen.Width = 2
      Pointer.HorizSize = 2
      Pointer.InflateMargins = True
      Pointer.Style = psRectangle
      Pointer.VertSize = 2
      Pointer.Visible = True
      XValues.Name = 'X'
      XValues.Order = loAscending
      YValues.Name = 'Y'
      YValues.Order = loNone
    end
    object ser_corr: TLineSeries
      Marks.Callout.Brush.Color = clBlack
      Marks.Visible = False
      SeriesColor = clBlue
      Title = 'r'#178
      LinePen.Color = clBlue
      LinePen.Style = psDot
      LinePen.Width = 2
      Pointer.HorizSize = 3
      Pointer.InflateMargins = True
      Pointer.Style = psTriangle
      Pointer.VertSize = 3
      Pointer.Visible = True
      XValues.Name = 'X'
      XValues.Order = loAscending
      YValues.Name = 'Y'
      YValues.Order = loNone
    end
    object ser_SErr: TLineSeries
      Marks.Callout.Brush.Color = clBlack
      Marks.Visible = False
      SeriesColor = clAqua
      Title = 'S_error'
      VertAxis = aRightAxis
      LinePen.Color = clAqua
      LinePen.Style = psDashDot
      LinePen.Width = 2
      Pointer.HorizSize = 3
      Pointer.InflateMargins = True
      Pointer.Style = psDownTriangle
      Pointer.VertSize = 3
      Pointer.Visible = True
      XValues.Name = 'X'
      XValues.Order = loAscending
      YValues.Name = 'Y'
      YValues.Order = loNone
    end
    object PageNumTool2: TPageNumTool
      Active = False
      Callout.Brush.Color = clBlack
      Callout.Arrow.Visible = False
      Text = 'Page %d of %d'
      Format = 'Page %d of %d'
    end
  end
  object GroupBox1: TGroupBox
    Left = 800
    Top = 8
    Width = 192
    Height = 177
    Caption = 'settings'
    TabOrder = 1
    object Label1: TLabel
      Left = 11
      Top = 64
      Width = 60
      Height = 13
      Caption = 'values from:'
    end
    object Label2: TLabel
      Left = 115
      Top = 64
      Width = 14
      Height = 13
      Caption = 'to:'
    end
    object Label5: TLabel
      Left = 76
      Top = 105
      Width = 51
      Height = 13
      Caption = 'increment:'
    end
    object CB_param: TComboBox
      Left = 11
      Top = 24
      Width = 158
      Height = 21
      ItemHeight = 13
      TabOrder = 0
      Text = ' choose parameter'
    end
    object E_valFrom: TEdit
      Left = 77
      Top = 60
      Width = 32
      Height = 21
      TabOrder = 1
      Text = '0,2'
      OnChange = E_valFromChange
    end
    object E_valTo: TEdit
      Left = 135
      Top = 60
      Width = 32
      Height = 21
      TabOrder = 2
      Text = '0,5'
      OnChange = E_valFromChange
    end
    object B_start: TButton
      Left = 11
      Top = 135
      Width = 75
      Height = 25
      Caption = 'new start'
      TabOrder = 3
      OnClick = B_startClick
    end
    object B_break: TButton
      Left = 92
      Top = 135
      Width = 75
      Height = 25
      Caption = 'start / stop'
      TabOrder = 4
      OnClick = B_breakClick
    end
    object E_incre: TEdit
      Left = 133
      Top = 101
      Width = 32
      Height = 21
      TabOrder = 5
      Text = '0,01'
      OnChange = E_valFromChange
    end
  end
  object B_undoZ: TButton
    Left = 811
    Top = 366
    Width = 75
    Height = 25
    Caption = 'undoZoom'
    TabOrder = 2
  end
  object Button1: TButton
    Left = 811
    Top = 311
    Width = 75
    Height = 49
    Caption = 'edit'
    TabOrder = 3
    OnClick = Button1Click
  end
  object chart_absCh: TChart
    Left = 8
    Top = 397
    Width = 786
    Height = 377
    BackWall.Brush.Color = clWhite
    BackWall.Brush.Style = bsClear
    Border.Visible = True
    Gradient.Balance = 99
    Gradient.Direction = gdFromTopLeft
    Gradient.EndColor = 753908
    Gradient.MidColor = 16059031
    Gradient.StartColor = 14540754
    Title.Text.Strings = (
      'absolut change')
    BottomAxis.ExactDateTime = False
    BottomAxis.Increment = 1.000000000000000000
    BottomAxis.Title.Caption = 'values'
    DepthAxis.Automatic = False
    DepthAxis.AutomaticMaximum = False
    DepthAxis.AutomaticMinimum = False
    DepthAxis.Maximum = 0.500000000000000000
    DepthAxis.Minimum = -0.500000000000000000
    DepthTopAxis.Automatic = False
    DepthTopAxis.AutomaticMaximum = False
    DepthTopAxis.AutomaticMinimum = False
    DepthTopAxis.Maximum = 0.500000000000000000
    DepthTopAxis.Minimum = -0.500000000000000000
    LeftAxis.Title.Caption = 'b_yx | mean'
    RightAxis.Grid.Visible = False
    RightAxis.Title.Caption = 'correlation r'
    TopAxis.Automatic = False
    TopAxis.AutomaticMaximum = False
    TopAxis.AutomaticMinimum = False
    TopAxis.Visible = False
    View3D = False
    Zoom.UpLeftZooms = True
    Color = clWhite
    TabOrder = 4
    PrintMargins = (
      15
      26
      15
      26)
    object ser_b: TLineSeries
      Marks.Callout.Brush.Color = clBlack
      Marks.Callout.Length = 0
      Marks.Visible = False
      SeriesColor = 33023
      Title = 'b_yx'
      ClickableLine = False
      LinePen.Color = 33023
      LinePen.Width = 2
      Pointer.HorizSize = 3
      Pointer.InflateMargins = True
      Pointer.Style = psCircle
      Pointer.VertSize = 3
      Pointer.Visible = True
      XValues.Name = 'X'
      XValues.Order = loAscending
      YValues.Name = 'Y'
      YValues.Order = loNone
    end
    object ser_corr_R: TLineSeries
      Marks.Callout.Brush.Color = clBlack
      Marks.Visible = False
      SeriesColor = 16744448
      Title = 'r'
      VertAxis = aRightAxis
      LinePen.Color = clGreen
      LinePen.Style = psDash
      LinePen.Width = 2
      Pointer.HorizSize = 2
      Pointer.InflateMargins = True
      Pointer.Style = psRectangle
      Pointer.VertSize = 2
      Pointer.Visible = True
      XValues.Name = 'X'
      XValues.Order = loAscending
      YValues.Name = 'Y'
      YValues.Order = loNone
    end
    object ser_mean: TLineSeries
      Marks.Callout.Brush.Color = clBlack
      Marks.Visible = False
      SeriesColor = clLime
      Title = 'mean'
      LinePen.Color = clLime
      LinePen.Style = psDot
      LinePen.Width = 3
      Pointer.HorizSize = 3
      Pointer.InflateMargins = True
      Pointer.Style = psTriangle
      Pointer.VertSize = 3
      Pointer.Visible = True
      XValues.Name = 'X'
      XValues.Order = loAscending
      YValues.Name = 'Y'
      YValues.Order = loNone
    end
    object PageNumTool1: TPageNumTool
      Active = False
      Callout.Brush.Color = clBlack
      Callout.Arrow.Visible = False
      Text = 'Page %d of %d'
      Format = 'Page %d of %d'
    end
  end
  object Button2: TButton
    Left = 811
    Top = 562
    Width = 75
    Height = 49
    Caption = 'edit'
    TabOrder = 5
    OnClick = Button2Click
  end
  object E_saveName: TEdit
    Left = 800
    Top = 260
    Width = 193
    Height = 21
    TabOrder = 6
    Text = 'enter name!'
    OnChange = E_valFromChange
  end
  object Timer4: TTimer
    Interval = 1
    OnTimer = Timer4Timer
    Left = 896
    Top = 362
  end
  object ChartEditor1: TChartEditor
    Chart = Chart_Slope
    Left = 896
    Top = 320
  end
  object ChartEditor2: TChartEditor
    Chart = chart_absCh
    Left = 896
    Top = 576
  end
end

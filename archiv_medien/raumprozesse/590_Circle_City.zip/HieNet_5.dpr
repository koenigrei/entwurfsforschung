program HieNet_5;

uses
  Forms,
  Main in 'Main.pas' {Form1},
  Node in 'Node.pas',
  CreateStructure in 'CreateStructure.pas',
  Agent in 'Agent.pas',
  ColourSelect in 'ColourSelect.pas',
  calc_AStern in 'calc_AStern.pas',
  basicAnalysis in 'basicAnalysis.pas' {Form3},
  advancedAnalysis in 'advancedAnalysis.pas' {Form2},
  phaseTransAna in 'phaseTransAna.pas' {Form6},
  spatialAnalysis in 'spatialAnalysis.pas' {Form4};

{$R *.res}

begin
  Application.Initialize;
  Application.CreateForm(TForm1, Form1);
  Application.CreateForm(TForm3, Form3);
  Application.CreateForm(TForm2, Form2);
  Application.CreateForm(TForm6, Form6);
  Application.CreateForm(TForm4, Form4);
  Application.Run;
end.

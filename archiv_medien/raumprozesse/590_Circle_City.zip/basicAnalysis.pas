unit basicAnalysis;

interface

uses
  Windows, Messages, SysUtils, Variants, Classes, Graphics, Controls, Forms, Node,
  Dialogs, TeEngine, TeeTools, TeePageNumTool, Series, ExtCtrls, TeeProcs, Chart,
  Math, Grids;

type
  TForm3 = class(TForm)
    Ch_basic: TChart;
    PageNumTool1: TPageNumTool;
    Ch_IS: TChart;
    PageNumTool2: TPageNumTool;
    ser_Connect: TFastLineSeries;
    Ser_happy: TFastLineSeries;
    Ser_moving: TFastLineSeries;
    Ser_settleTh: TFastLineSeries;
    Ser_moveTh: TFastLineSeries;
    StringGrid1: TStringGrid;
    procedure StringGrid1Click(Sender: TObject);
  private
    { Private-Deklarationen }
 public
    { Public-Deklarationen }
    procedure resetCharts;
    //procedure setMinMax;
    procedure IDissimilar;
    Procedure GraphConnectivity;
  end;

var
  Form3: TForm3;
  isSer : Array of TLineSeries;    // -- Segregation Index
  oldMax, oldMin : Real;
  globML    : Real;                // -- global mean length of the street-network

implementation

uses CreateStructure, Main, phaseTransAna;

{$R *.dfm}

{procedure TForm3.setMinMax;
var threshA, threshB : Real;
begin
  threshA := StrToFloat(Form1.ValueListEditor1.Values['settleDown']);
  threshB := StrToFloat(Form1.ValueListEditor1.Values['leavePlace']);
  If (threshA > threshB) Then
  begin
    If (threshA > oldMax) Then begin
      Form3.Ch_basic.RightAxis.Maximum := threshA;
      oldMax := threshA;
    end;
    If (threshB < oldMin) Then begin
      Form3.Ch_basic.RightAxis.Minimum := threshB;
      oldMin := threshB;
    end;
  end else begin
    If (threshB > oldMax) Then begin
      Form3.Ch_basic.RightAxis.Maximum := threshB;
      oldMax := threshB;
    end;
    If (threshA < oldMin) Then begin
      Form3.Ch_basic.RightAxis.Minimum := threshA;
      oldMin := threshA;
    end;
  end;
end; }

//==============================================================reset the charts
procedure TForm3.resetCharts;
var
 I, K : Integer;
begin
  Ser_happy.Clear;
  Ser_moving.Clear;
  Ser_moveTh.Clear;
  Ser_settleTh.Clear;
  Ser_Connect.Clear;
  //Form3.setMinMax;

  If length(isSer) > 0 Then
  For I := 0 To length(isSer)-1 Do
  begin
    Ch_IS.RemoveSeries(isSer[I]);
  end;
  SetLength (isSer, 0);
  SetLength (isSer, NGroups);
  with Ch_IS do
  begin
    For I := 0 To NGroups-1 Do
    begin
      isSer[I] := TLineSeries.Create(self);                                   // -- Create first Series
      isSer[I].Clear;                                                         // -- Clear it
      isSer[I].ParentChart := Ch_IS;                                          // -- determine the chart, this series belongs to
      isSer[I].VertAxis := aRightAxis;
      isSer[I].Color := ColList[I];
      isSer[I].LinePen.Width := 2;
    end;
  end;
  For I:=0 To StringGrid1.RowCount Do
  begin
    For K:=0 To StringGrid1.ColCount Do
    begin
      StringGrid1.Cells[I, K] := '';
    end;
  end;
  StringGrid1.RowCount := StreetList.Count +2;
  StringGrid1.ColCount := StreetList.Count +3;
  GraphConnectivity;
end;

// *** calculate dissimilar index **********************************************
procedure TForm3.IDissimilar;
var
  I, V, W : Integer;
  sumTyp     : Array of Array of Extended;                                   // Dissimilarit�tsindex
  segIdx     : Array of Extended;                                            // Segregationsindex
  sumGes     : Extended;                                                     // Sum of the population without the current group
  CurStreet, CurHouse  : TNode;
begin
  SetLength (sumTyp, 0, 0);
  SetLength (sumTyp, NGroups, NGroups);
  SetLength (segIdx, 0);
  SetLength (segIdx, NGroups);
  // --- Street Level ----------------------------------------------------------
  For I:=0 To StreetList.Count-1 Do
  begin
    CurStreet := StreetList.Items[I];
    For V:= 0 To NGroups -1 Do
    begin
      For W := V+1 To NGroups -1 Do
      begin
        sumTyp[W, V] := sumTyp[W, V] + abs(
        (CurStreet.typeRatio[V]/groupSz[V] * 100)-(CurStreet.typeRatio[W]/groupSz[W] * 100));
      end;
      sumGes := 0;
      For W := 0 To NGroups -1 Do
      begin
        If not (W=V) Then
          sumGes := sumGes + (CurStreet.typeRatio[W]);
      end;
      segIdx[V] := segIdx[V] + abs(
      (CurStreet.typeRatio[V]/groupSz[V] * 100)-(sumGes/(Form1.UpD_nrAgents.Position-groupSz[V]) * 100));
    end;
  end;
  // --- House Level -----------------------------------------------------------
  {For I:=0 To HouseList.Count-1 Do
  begin
    CurHouse := HouseList.Items[I];
    For V:= 0 To NGroups -1 Do
    begin
      For W := V+1 To NGroups -1 Do
      begin
        sumTyp[W, V] := sumTyp[W, V] + abs(
        (CurHouse.typeRatio[V]/groupSz[V] * 100)-(CurHouse.typeRatio[W]/groupSz[W] * 100));
      end;
      sumGes := 0;
      For W := 0 To NGroups -1 Do
      begin
        If not (W=V) Then
          sumGes := sumGes + (CurHouse.typeRatio[W]);
      end;
      segIdx[V] := segIdx[V] + abs(
      (CurHouse.typeRatio[V]/groupSz[V] * 100)-(sumGes/(Form1.UpD_nrAgents.Position-groupSz[V]) * 100));
    end;
  end;  }
  For V:= 0 To NGroups-1  Do
  begin
    For W := V To NGroups-1  Do
    begin
      sumTyp[W, V] := 0.5 * sumTyp[W, V];
    end;
    segIdx[V] := 0.5 * segIdx[V];
    isSer[V].AddXY(globCount, segIdx[V]);                                    // Segregation Index
    Ser_Connect.AddXY(globCount, globML);                                    // The mean length of the network
  end;
end;

//=======================================Calculate the connectivity of the graph
Procedure TForm3.GraphConnectivity;
var I, K, length: Integer;
    CurStreet : TNode;
    ConnMatr  : Array of Array of Integer;                                   // Connectivity Matrix of the graph
    MeanLength: Array of Real;                                               // the mean length of a node to all others
    Diameter, RowSum : Integer;                                              // Diameter or "Streuwert" of the graph
begin
  SetLength(ConnMatr, StreetList.Count, StreetList.Count);
  SetLength(MeanLength, StreetList.Count);
  Diameter := 0;
  globML   := 0;
  For I:=0 To StreetList.Count-1 Do
  begin
    StringGrid1.Cells[0, I+1]:= IntToStr(I);
    CurStreet := StreetList.Items[I];
    RowSum := 0;
    For K:=0 To StreetList.Count-1 Do
    begin
      StringGrid1.Cells[K+1, 0]:= IntToStr(K);
      If K=I Then begin length := 0;                                         // length to a node itself is zero
      end else begin length := CurStreet.NachbStr[K].Count-1;                // substract the start-node itsef
      end;
      ConnMatr[I, K] := length;
      RowSum := RowSum + length;
      StringGrid1.Cells[K+1, I+1]:= IntToStr(length);
    end;
    Diameter := Diameter + RowSum;
    MeanLength[I] := roundTo(RowSum / (StreetList.Count-1), -2);
    globML := globML + MeanLength[I];
    StringGrid1.Cells[StreetList.Count+1, I+1]:= IntToStr(RowSum);
    StringGrid1.Cells[StreetList.Count+2, I+1]:= FloatToStr(MeanLength[I]);
  end;
  globML := roundTo(globML / StreetList.Count, -2);
  StringGrid1.Cells[StreetList.Count+1, StreetList.Count+1]:= IntToStr(Diameter);
  StringGrid1.Cells[StreetList.Count+2, StreetList.Count+1]:= FloatToStr(globML);
end;

end.

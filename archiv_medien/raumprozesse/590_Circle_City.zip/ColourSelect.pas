unit ColourSelect;

interface

uses
 Graphics, GraphUtil, Windows;

type
  ColourList = Array of TColor;

Procedure ColoSelec(NCol: Word; var ColList: ColourList);
Procedure ChooseCol(NCol: Word; var ColList: ColourList);
Procedure ColPalet (NCol: Word; var ColList: ColourList);

implementation

Procedure ColoSelec(NCol: Word; var ColList: ColourList);
var I, Lum, Sat : Word;
begin
  Lum := 100;
  Sat := 240;
  SetLength (ColList, NCol);
  ColList[0] := ColorHLSToRGB(0, Lum, Sat);
  For I:=1 To NCol Do begin
    ColList[I] := ColorHLSToRGB(round(220/I), Lum, Sat)                       // Hue = Farbton , Luminance = Helligkeit , Saturation = S�ttigung
  end;                                                                        // H = 0: rot / H = 40: gelb / H = 80: gr�n / H = 120: blaugr�n / H = 160: blau / H = 200: violett / H = 240: rot 
end;

Procedure ChooseCol(NCol: Word; var ColList: ColourList);
var
  Number,Red,Green,Blue,I, Num : Integer;
  Step                         : Real;
begin
  If NCol <3 Then Num := 3 Else Num := NCol;
  Setlength (ColList, Num);
  Step:=1275/(Num-1);
  For I:=0 to Num-1 do
  Begin
    Number:=round(I*Step);
    Red:=0;
    Green:=0;
    Blue:=0;
    case Number of
    0..255:
      begin
        Red:=255;
        Green:=Number;
      end;
    256..510:
      begin
        Red:=510-Number;
        Green:=255;
      end;
    511..765:
      begin
        Green:=255;
        Blue:=Number-510;
      end;
    766..1020:
      begin
        Green:=1020-Number;
        Blue:=255;
      end;  
    1021..1275:  
      begin
        Red:=Number-1020;
        Blue:=255;  
      end;
    1276:  
      begin
        Red:=255;  
        Blue:=255;
      end;
    end;
    ColList[I] := RGB(Red,Green,Blue);
  end;
end;

Procedure ColPalet (NCol: Word; var ColList: ColourList);
var I : Integer;
begin
  SetLength (ColList, NCol);
  For I := 0 To NCol Do begin
    case I of
      0:  ColList[I] := clRed;        // Rot
      1:  ColList[I] := clLime;       // Gelbgr�n
      2:  ColList[I] := clBlue;       // Blau
      3:  ColList[I] := clYellow;     // Yellow
      4:  ColList[I] := clPurple;     // Purpur
      5:  ColList[I] := clAqua;       // Hellblau
      6:  ColList[I] := clFuchsia;    // Lila
      7:  ColList[I] := clTeal;       // Blaugr�n
      8:  ColList[I] := clMaroon;     // Braun
      9:  ColList[I] := clNavy;       // Marineblau
      10: ColList[I] := clOlive;      // Olivgr�n
      11: ColList[I] := clSkyBlue;    // Himmelblau
      12: ColList[I] := clGreen;      // Gr�n
      13: ColList[I] := clMoneyGreen; // Minzgr�n
      // for more colours see: http://www.wackerart.de/rgbfarben.html 
    end;
  end;
end;

end.

unit spatialAnalysis;

interface

uses
  Windows, Messages, SysUtils, Variants, Classes, Graphics, Controls, Forms,
  Dialogs, TeeEdit, ExtCtrls, ComCtrls, StdCtrls, TeEngine, TeeTools, teestore,
  TeePageNumTool, Series, TeeProcs, Chart, Math, CurvFitt;

type
  TForm4 = class(TForm)
    Chart_Slope: TChart;
    PageNumTool2: TPageNumTool;
    GroupBox1: TGroupBox;
    Label1: TLabel;
    Label2: TLabel;
    Label5: TLabel;
    CB_param: TComboBox;
    E_valFrom: TEdit;
    E_valTo: TEdit;
    B_start: TButton;
    B_break: TButton;
    E_incre: TEdit;
    lbl_pSteps: TLabel;
    lbl_timesteps: TLabel;
    Label8: TLabel;
    Lbl_proceed: TLabel;
    Lbl_akt: TLabel;
    B_undoZ: TButton;
    Timer4: TTimer;
    ChartEditor1: TChartEditor;
    ser_slopeTrend: TLineSeries;
    Button1: TButton;
    ser_StDv: TLineSeries;
    ser_corr: TLineSeries;
    ser_SErr: TLineSeries;
    chart_absCh: TChart;
    ser_b: TLineSeries;
    ser_corr_R: TLineSeries;
    ser_mean: TLineSeries;
    PageNumTool1: TPageNumTool;
    Button2: TButton;
    Label3: TLabel;
    E_saveName: TEdit;
    ChartEditor2: TChartEditor;
    procedure FormCreate(Sender: TObject);
    procedure B_startClick(Sender: TObject);
    procedure Timer4Timer(Sender: TObject);
    procedure B_breakClick(Sender: TObject);
    procedure Button1Click(Sender: TObject);
    procedure E_valFromChange(Sender: TObject);
    procedure Button2Click(Sender: TObject);
  private
    rds : Integer;
    curVal : Real;
    procedure resetGraphs;
    procedure newRoundS;
    procedure addDeltaIS;
    procedure sumCalculations;
    procedure saveSubChart;
  public
    { Public-Deklarationen }
  end;

var
  Form4: TForm4;
  trendFunct : TCustomTrendFunction;
  teilS : Integer;                                                            // Teilschritte der Erh�hung der Stra�en

implementation

{$R *.dfm}
uses Main, advancedAnalysis;

procedure TForm4.FormCreate(Sender: TObject);
begin
  Timer4.enabled := false;
  lbl_pSteps.Caption := '0';
  CB_param.AddItem(' weightStreets', Sender);    // 0
  CB_param.AddItem(' weightsHouses', Sender);    // 1
  CB_param.AddItem(' both thresholds', Sender);  // 2
  rds := 0;
  Lbl_akt.Caption := IntToStr(rds);
  sumCalculations;
  trendFunct := TCustomTrendFunction.Create(self);
end;

procedure TForm4.sumCalculations;
var sumCalc : Real;
begin
  sumCalc := abs((StrToFloat(E_valTo.Text) - StrToFloat(E_valFrom.Text))*10)/(StrToFloat(E_incre.Text)*10)+1;
  Lbl_proceed.Caption := '/ ' + IntToStr(ceil(sumCalc));
end;

procedure TForm4.Button1Click(Sender: TObject);
begin
  ChartEditor1.Execute;
end;

procedure TForm4.Button2Click(Sender: TObject);
begin
  ChartEditor2.Execute;
end;

procedure TForm4.B_breakClick(Sender: TObject);
begin
  Timer4.Enabled := Not Timer4.Enabled;
end;

procedure TForm4.B_startClick(Sender: TObject);
begin
  Form1.Timer1.enabled := false;
  Form2.Timer2.enabled := false;
  Form2.Steps := 0;
  globCount := 0;
  If CB_param.ItemIndex = -1 Then
  begin
    MessageBox(MB_Ok, 'please select a parameter', 'missing value', MB_Ok);
    exit;
  end;
  resetGraphs;
  rds := 1;
  Lbl_akt.Caption := IntToStr(rds);
  curVal := StrToFloat(E_valFrom.Text);
  newRoundS;
  Timer4.Enabled := true;
  sumCalculations;
end;

procedure TForm4.E_valFromChange(Sender: TObject);
begin
  sumCalculations;
end;

procedure TForm4.resetGraphs;
begin
  teilS := (StrToInt(Form2.E_valTo.Text)-StrToInt(Form2.E_valFrom.Text)+2);
  with Chart_Slope do
  begin
    Title.Text.Clear;                                                         // -- Title of the Chart
    Title.Text.Add('deslta IS / thresholds or weights || steps:'+IntToStr(teilS));
  end;
  ser_slopeTrend.Clear;
  ser_StDv.Clear;
  ser_corr.Clear;
  ser_serr.Clear;
  ser_b.Clear;
  ser_corr_R.Clear;
  ser_mean.Clear;
end;

procedure TForm4.newRoundS;
begin
  case CB_param.ItemIndex of
    0: begin Form1.ValueListEditor1.Values['weigthStreets'] := FloatToStr(roundTo(curVal, -2));
             Form1.CalcWeightsNew;
       end;
    1: begin Form1.ValueListEditor1.Values['weigthHouses'] := FloatToStr(roundTo(curVal, -2));
             Form1.CalcWeightsNew;
       end;
    2: begin Form1.ValueListEditor1.Values['leavePlace'] := FloatToStr(roundTo(curVal, -2));
             Form1.ValueListEditor1.Values['settleDown'] := FloatToStr(roundTo(curVal, -2));
       end;
  end;
  Form2.Series_IS_Avg.FunctionType.Period := (StrToInt(Form2.E_calcVals.Text));
  Form2.NewStart;
end;

procedure TForm4.Timer4Timer(Sender: TObject);
begin
  If (Form2.noChange >= StrToInt(Form2.E_toSteps.Text)) Or (Form2.Steps > 50) Then
  begin
    Form2.plotVals;
    inc(Form2.rounds);
    inc(Form2.toCalc);
    Form2.Lbl_akt.Caption := IntToStr(Form2.toCalc);
    If Form2.rounds > StrToInt(Form2.E_calcVals.Text) Then                          // -- calculations per value
    begin
      Form2.aktVal := Form2.aktVal + StrToInt(Form2.E_incre.Text);                  // -- raise aktual value by increment
      If Form2.aktVal > StrToInt(Form2.E_valTo.Text) Then                           // -- iterate the range from start value to end value
      begin
        //Form2.Series_IS_Fit.CheckDataSource;
        //Form2.Timer2.enabled := false;
        //exit;                                                              // plot the slope
        addDeltaIS;
        inc(rds);
        Lbl_akt.Caption := IntToStr(rds);
        If curVal > StrToFloat(E_valTo.Text) Then                            // check if spatial analysis is finished
        begin
          Timer4.Enabled := false;
          exit;
        end;
        curVal := curVal + StrToFloat(E_incre.Text);
        newRoundS;
      end;
      Form2.rounds := 1;
    end;
    Form2.Steps := 0;
    Form2.newRound(Form2.aktVal);
    If Form2.rounds =1 Then
    begin
      Form1.Deleter;
      Form1.SetupStruct;
    end;
    Form1.CreateNewAgents;
  end;
  If UnHappyList.Count = Form2.oldChange Then inc(Form2.noChange) Else Form2.noChange := 0;             // -- if there is no change increase the noChange counter
  Form2.oldChange := UnHappyList.Count;
  Form1.Execute;
  lbl_pSteps.Caption := IntToStr (Form2.Steps);
  inc(Form2.Steps);
end;

procedure TForm4.addDeltaIS;
var DeltaIS1, DeltaIS2, DeltaIS, StDV, r2, Se : Real;
begin
  Form2.Series_IS_Trend.CheckDataSource;
  Form2.Series_StDv.CheckDataSource;
  Form2.Series_Correlation.CheckDataSource;
  Form2.Series_Mean.CheckDataSource;
  DeltaIS1 := Form2.Series_IS_Trend.YValues[0];
  DeltaIS2 := Form2.Series_IS_Trend.YValues[1];
  StDV     := Form2.Series_StDv.YValues[0];
  DeltaIS  := (DeltaIS2 - DeltaIS1)/teilS;
  r2       := Power(Form2.Series_Correlation.YValues[1], 2);
  Se       := StDV * sqrt(1-r2);
  ser_slopeTrend.AddXY(curVal*100, DeltaIS);                                 // plot the slope ot the trend line - Regressionsgerade
  ser_StDv.AddXY(curVal*100, StDV);                                          // plot the standard deviation
  ser_Corr.AddXY(curVal*100, r2);                                            // plot the detereminationskoeffizeint r^2
  ser_SErr.AddXY(curVal*100, Se);                                            // plot the standard error - Standardsch�tzfehler

  ser_b.AddXY(curVal*100, DeltaIS1);
  ser_corr_R.AddXY(curVal*100, Form2.Series_Correlation.YValues[1]);
  ser_mean.AddXY(curVal*100, Form2.Series_Mean.YValues[1]);

  saveSubChart;
end;

procedure TForm4.saveSubChart;
var
  path    : String;
  Filename: String;
begin
  path := ExtractFilePath(Application.ExeName);
  Filename := path+'data\'+E_saveName.Text+ FloatToStr(curVal*100);
  SaveChartToFile(Form2.Chart_IS, Filename, true);
end;

end.

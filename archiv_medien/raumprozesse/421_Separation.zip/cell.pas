unit cell;

interface

uses
  Windows, Graphics;

type
  TBaseCell = class
  private
  public
    FPositionX: Integer;
    FPositionY: Integer;
    FSize     : Integer;
    FStepX    : Double;
    FStepY    : Double;
    FFillColor: Integer;
    FState    : Integer;
    FPassed   : Integer;
    procedure Paint (Canvas: TCanvas); virtual;
    procedure SetPositionX(const Value: Integer);
    procedure SetPositionY(const Value: Integer);
    procedure SetStepX(const Value: Double);
    procedure SetStepY(const Value: Double);
    procedure SetSize(const Value: Integer);
    procedure SetFillColor(const Value: Integer);
    procedure SetState(const Value: Integer);
    procedure SetPassed(const Value: Integer);
  published
    property PositionX: Integer read FPositionX write SetPositionX;
    property PositionY: Integer read FPositionY write SetPositionY;
    property StepX    : Double  read FStepX     write SetStepX;
    property StepY    : Double  read FStepY     write SetStepY;
    property Size     : Integer read FSize      write SetSize;
    property FillColor: Integer read FFillColor write SetFillColor;
    property State    : Integer read FState     write SetState;
    property Passed   : Integer read FPassed    write SetPassed;
  end;

type
  TCell = class (TBaseCell)
    procedure Paint (Canvas: TCanvas); override;
  end;
  
// ---------------------------------------------------------------------------//
implementation

procedure TBaseCell.Paint (Canvas: TCanvas);
begin
  Canvas.Pen.Width := 1;
end;

procedure TBaseCell.SetStepX(const Value: Double);
begin
  FStepX := Value;
end;

procedure TBaseCell.SetPassed(const Value: Integer);
begin
  FPassed := Value;
end;

procedure TBaseCell.SetStepY(const Value: Double);
begin
  FStepY := Value;
end;

procedure TBaseCell.SetPositionX(const Value: Integer);
begin
  FPositionX := Value;
end;

procedure TBaseCell.SetPositionY(const Value: Integer);
begin
  FPositionY := Value;
end;

procedure TBaseCell.SetSize(const Value: Integer);
begin
  FSize := Value;
end;

procedure TBaseCell.SetFillColor(const Value: Integer);
begin
  FFillColor := Value;
end;

procedure TBaseCell.SetState(const Value: Integer);
begin
  FState := Value;
end;

procedure TCell.Paint(Canvas: TCanvas);
begin
  inherited Paint (Canvas);
  Canvas.Pen.Color := FFillColor; //clBlack;
  Canvas.Brush.Color := FFillColor;
  Canvas.Rectangle (FPositionX - FSize , FPositionY - (FSize), FPositionX + (FSize), FPositionY + (FSize));
end;

end.

object MovePlate: TMovePlate
  Left = 0
  Top = 0
  Width = 800
  Height = 629
  Caption = 'MovePlate'
  Color = clSilver
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -10
  Font.Name = 'Tahoma'
  Font.Style = []
  OldCreateOrder = False
  OnCreate = FormCreate
  OnDestroy = FormDestroy
  PixelsPerInch = 96
  TextHeight = 12
  object ImagePaint: TImage
    Left = 8
    Top = 8
    Width = 777
    Height = 450
    OnClick = ImagePaintClick
    OnMouseMove = ImagePaintMouseMove
  end
  object Label1: TLabel
    Left = 6
    Top = 468
    Width = 106
    Height = 13
    Caption = 'Anzahl Knotenpunkte:'
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clWhite
    Font.Height = -11
    Font.Name = 'Tahoma'
    Font.Style = []
    ParentFont = False
  end
  object Label2: TLabel
    Left = 116
    Top = 468
    Width = 24
    Height = 13
    Caption = '0000'
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clWhite
    Font.Height = -11
    Font.Name = 'Tahoma'
    Font.Style = []
    ParentFont = False
  end
  object Label3: TLabel
    Left = 420
    Top = 473
    Width = 61
    Height = 13
    Caption = 'MausRadius:'
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clWhite
    Font.Height = -11
    Font.Name = 'Tahoma'
    Font.Style = []
    ParentFont = False
  end
  object Label_Radius: TLabel
    Left = 480
    Top = 473
    Width = 24
    Height = 13
    Caption = '____'
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clWhite
    Font.Height = -11
    Font.Name = 'Tahoma'
    Font.Style = []
    ParentFont = False
  end
  object Label4: TLabel
    Left = 17
    Top = 575
    Width = 90
    Height = 13
    Caption = 'Anlager Dist. Gelb:'
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clWhite
    Font.Height = -11
    Font.Name = 'Tahoma'
    Font.Style = []
    ParentFont = False
  end
  object LabelInterakt: TLabel
    Left = 114
    Top = 575
    Width = 24
    Height = 13
    Caption = '____'
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clWhite
    Font.Height = -11
    Font.Name = 'Tahoma'
    Font.Style = []
    ParentFont = False
  end
  object Label5: TLabel
    Left = 27
    Top = 539
    Width = 80
    Height = 13
    Caption = 'Mindestabstand:'
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clWhite
    Font.Height = -11
    Font.Name = 'Tahoma'
    Font.Style = []
    ParentFont = False
  end
  object Label_MinDist: TLabel
    Left = 114
    Top = 539
    Width = 24
    Height = 13
    Caption = '____'
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clWhite
    Font.Height = -11
    Font.Name = 'Tahoma'
    Font.Style = []
    ParentFont = False
  end
  object Label6: TLabel
    Left = 18
    Top = 557
    Width = 89
    Height = 13
    Caption = 'Anlager Dist. Blau:'
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clWhite
    Font.Height = -11
    Font.Name = 'Tahoma'
    Font.Style = []
    ParentFont = False
  end
  object Label_Sichtfeld: TLabel
    Left = 114
    Top = 557
    Width = 24
    Height = 13
    Caption = '____'
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clWhite
    Font.Height = -11
    Font.Name = 'Tahoma'
    Font.Style = []
    ParentFont = False
  end
  object ScrollBar1: TScrollBar
    Left = 512
    Top = 469
    Width = 97
    Height = 15
    Max = 200
    PageSize = 0
    TabOrder = 0
    OnChange = ScrollBar1Change
  end
  object Button_Delete: TButton
    Left = 216
    Top = 469
    Width = 68
    Height = 15
    Caption = 'Delete 100 Pts'
    TabOrder = 1
    OnClick = Button_DeleteClick
  end
  object Button2: TButton
    Left = 342
    Top = 469
    Width = 67
    Height = 15
    Caption = 'Attract/Repel'
    TabOrder = 2
    OnMouseUp = Button2MouseUp
  end
  object CheckB_Zellen: TCheckBox
    Left = 6
    Top = 492
    Width = 97
    Height = 13
    Caption = 'Zellen markieren'
    Checked = True
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clWhite
    Font.Height = -11
    Font.Name = 'Tahoma'
    Font.Style = []
    ParentFont = False
    State = cbChecked
    TabOrder = 3
  end
  object Button_Create: TButton
    Left = 144
    Top = 469
    Width = 68
    Height = 15
    Caption = 'Create Pts'
    TabOrder = 4
    OnClick = Button_CreateClick
  end
  object ScrollBar_DistGelb: TScrollBar
    Left = 144
    Top = 571
    Width = 97
    Height = 15
    LargeChange = 5
    Min = 5
    PageSize = 0
    Position = 30
    TabOrder = 5
    OnChange = ScrollBar_DistGelbChange
  end
  object ScrollBar_MinDist: TScrollBar
    Left = 144
    Top = 535
    Width = 97
    Height = 15
    Max = 50
    Min = 1
    PageSize = 0
    Position = 10
    TabOrder = 6
    OnChange = ScrollBar_MinDistChange
  end
  object ScrollBar_DistBlau: TScrollBar
    Left = 144
    Top = 553
    Width = 97
    Height = 15
    LargeChange = 5
    Min = 5
    PageSize = 0
    Position = 30
    TabOrder = 7
    OnChange = ScrollBar_DistBlauChange
  end
  object ButtonPause: TButton
    Left = 216
    Top = 491
    Width = 68
    Height = 15
    Caption = 'Pause'
    TabOrder = 8
    OnClick = ButtonPauseClick
  end
  object ButtonCreateB: TButton
    Left = 144
    Top = 491
    Width = 68
    Height = 15
    Caption = 'Create Blues'
    TabOrder = 9
    OnClick = ButtonCreateBClick
  end
  object ButtonCreateY: TButton
    Left = 144
    Top = 509
    Width = 68
    Height = 15
    Caption = 'Create Yellows'
    TabOrder = 10
    OnClick = ButtonCreateYClick
  end
  object ApplicationEvents1: TApplicationEvents
    OnIdle = ApplicationEvents1Idle
    Left = 120
    Top = 72
  end
end

unit cell_P;

interface

uses
  Windows, Graphics, Classes, node, Math;

type
  TCell = class
  private
  public
    AgNr       : Integer;            // -- Nummer der Agenten auf einer Zelle
    cent       : Boolean;            // -- in the cell is a market cell.
    Dist       : Integer;            // -- Distance to nexgt market
    distM      : Array [0..9] of Integer;  // -- distances to all markets
    indM       : Integer;            // -- index of the next market
    besetzt    : Boolean;            // -- in an agent is on the cell
    colr       : Integer;            // -- Farbwert der Zelle
    mark       : Integer;            // -- marking where the agents are gone
    FPos       : TPoint;
    FSize      : Integer;
    FFillColor : Integer;
    FState     : Integer;            // -- Status speichert die Anzahl der Agenten auf Zelle
    procedure Paint         (Canvas: TCanvas);
    procedure SetPositionX  (const Value: Integer);
    procedure SetPositionY  (const Value: Integer);
    procedure SetSize       (const Value: Integer);
    procedure SetFillColor  (const Value: Integer);
    procedure SetState      (const Value: Integer);
    constructor create      (xPos, yPos, size, colr: Integer);
  published
    property PositionX: Integer read FPos.X     write SetPositionX;
    property PositionY: Integer read FPos.Y     write SetPositionY;
    property Size     : Integer read FSize      write SetSize;
    property FillColor: Integer read FFillColor write SetFillColor;
    property State    : Integer read FState     write SetState;
  end;

// ---------------------------------------------------------------------------//

implementation

constructor TCell.create(xPos, yPos, size, colr: Integer);
begin
  inherited create;
  FPos.X := xPos;
  FPos.Y := yPos;
  FSize  := size;
  FFillColor := colr;
end;

//------------------------------------------------------------------------------

procedure TCell.SetPositionX(const Value: Integer);
begin
  FPos.X := Value;
end;

procedure TCell.SetPositionY(const Value: Integer);
begin
  FPos.Y := Value;
end;

procedure TCell.SetSize(const Value: Integer);
begin
  FSize := Value;
end;

procedure TCell.SetFillColor(const Value: Integer);
begin
  FFillColor := Value;
end;

procedure TCell.SetState(const Value: Integer);
begin
  FState := Value;
end;

procedure TCell.Paint(Canvas: TCanvas);

begin
  Canvas.Pen.Width := 0;
  //Canvas.Pen.Color := clWhite; //clgray; //clgreen;
  If mark > 255 then mark := 255;
  colr := 255 - mark;
  Canvas.Pen.Color   := RGB (colr, colr, colr);
  Canvas.Brush.Color := RGB (colr, colr, colr);
  If cent = true then Canvas.Brush.Color := clgreen;
  //Canvas.Pen.Color   := RGB (colr, colr, colr);
  Canvas.Rectangle (FPos.X - FSize , FPos.Y - FSize, FPos.X + FSize, FPos.Y + FSize);
end;

end.

object Form6: TForm6
  Left = 0
  Top = 0
  Caption = 'Analyse Stability'
  ClientHeight = 690
  ClientWidth = 1016
  Color = clBtnFace
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -11
  Font.Name = 'Tahoma'
  Font.Style = []
  OldCreateOrder = False
  OnCreate = FormCreate
  PixelsPerInch = 96
  TextHeight = 13
  object lbl_pSteps: TLabel
    Left = 873
    Top = 599
    Width = 49
    Height = 13
    Alignment = taRightJustify
    Caption = 'lbl_pSteps'
  end
  object lbl_timesteps: TLabel
    Left = 928
    Top = 599
    Width = 53
    Height = 13
    Caption = ': timesteps'
  end
  object Label8: TLabel
    Left = 928
    Top = 618
    Width = 62
    Height = 13
    Caption = ': calculations'
  end
  object Lbl_proceed: TLabel
    Left = 900
    Top = 618
    Width = 19
    Height = 13
    Alignment = taRightJustify
    Caption = 'sum'
  end
  object Lbl_akt: TLabel
    Left = 862
    Top = 618
    Width = 19
    Height = 13
    Alignment = taRightJustify
    Caption = 'sum'
  end
  object Chart_Stability: TChart
    Left = 8
    Top = 8
    Width = 801
    Height = 340
    BackWall.Brush.Color = clWhite
    BackWall.Brush.Style = bsClear
    Border.Visible = True
    Gradient.Balance = 99
    Gradient.Direction = gdFromTopLeft
    Gradient.EndColor = 753908
    Gradient.MidColor = 16059031
    Gradient.StartColor = 14540754
    Legend.CheckBoxesStyle = cbsRadio
    Legend.Visible = False
    Title.Text.Strings = (
      'phase transitions || ')
    BottomAxis.ExactDateTime = False
    BottomAxis.Increment = 1.000000000000000000
    BottomAxis.Title.Caption = 'tolerance value'
    DepthAxis.Automatic = False
    DepthAxis.AutomaticMaximum = False
    DepthAxis.AutomaticMinimum = False
    DepthAxis.Maximum = 0.500000000000000000
    DepthAxis.Minimum = -0.500000000000000000
    DepthTopAxis.Automatic = False
    DepthTopAxis.AutomaticMaximum = False
    DepthTopAxis.AutomaticMinimum = False
    DepthTopAxis.Maximum = 0.500000000000000000
    DepthTopAxis.Minimum = -0.500000000000000000
    LeftAxis.ExactDateTime = False
    LeftAxis.Grid.ZPosition = 100.000000000000000000
    LeftAxis.Inverted = True
    LeftAxis.Title.Caption = 'average segregation index'
    RightAxis.Title.Caption = 'segregation index'
    TopAxis.Automatic = False
    TopAxis.AutomaticMaximum = False
    TopAxis.AutomaticMinimum = False
    TopAxis.Visible = False
    View3D = False
    Zoom.UpLeftZooms = True
    Color = clWhite
    TabOrder = 0
    object Series_segVal: TPointSeries
      Marks.Callout.Brush.Color = clBlack
      Marks.Visible = False
      ClickableLine = False
      Pointer.HorizSize = 2
      Pointer.InflateMargins = True
      Pointer.Style = psCross
      Pointer.VertSize = 2
      Pointer.Visible = True
      XValues.Name = 'X'
      XValues.Order = loAscending
      YValues.Name = 'Y'
      YValues.Order = loNone
    end
    object Series_segAvg: TLineSeries
      Marks.Callout.Brush.Color = clBlack
      Marks.Visible = False
      DataSource = Series_segVal
      LinePen.Width = 2
      Pointer.InflateMargins = True
      Pointer.Style = psRectangle
      Pointer.Visible = False
      XValues.Name = 'X'
      XValues.Order = loAscending
      YValues.Name = 'Y'
      YValues.Order = loNone
      object TeeFunction1: TAverageTeeFunction
      end
    end
    object PageNumTool1: TPageNumTool
      Active = False
      Callout.Brush.Color = clBlack
      Callout.Arrow.Visible = False
      Text = 'Page %d of %d'
    end
  end
  object GroupBox1: TGroupBox
    Left = 815
    Top = 8
    Width = 192
    Height = 137
    Caption = 'settings'
    TabOrder = 1
    object Label1: TLabel
      Left = 12
      Top = 22
      Width = 74
      Height = 13
      Caption = 'tolerance from:'
    end
    object Label2: TLabel
      Left = 126
      Top = 23
      Width = 14
      Height = 13
      Caption = 'to:'
    end
    object Label3: TLabel
      Left = 20
      Top = 83
      Width = 107
      Height = 13
      Caption = 'steps until next value:'
    end
    object Label4: TLabel
      Left = 90
      Top = 110
      Width = 37
      Height = 13
      Caption = 'rounds:'
    end
    object Label5: TLabel
      Left = 76
      Top = 55
      Width = 51
      Height = 13
      Caption = 'increment:'
    end
    object E_valFrom: TEdit
      Left = 88
      Top = 19
      Width = 32
      Height = 21
      TabOrder = 0
      Text = '25'
      OnChange = E_valFromChange
    end
    object E_valTo: TEdit
      Left = 146
      Top = 19
      Width = 32
      Height = 21
      TabOrder = 1
      Text = '45'
      OnChange = E_valFromChange
    end
    object E_toSteps: TEdit
      Left = 133
      Top = 79
      Width = 32
      Height = 21
      TabOrder = 2
      Text = '5'
    end
    object E_calcRds: TEdit
      Left = 133
      Top = 106
      Width = 32
      Height = 21
      TabOrder = 3
      Text = '5'
      OnChange = E_valFromChange
    end
    object E_incre: TEdit
      Left = 133
      Top = 51
      Width = 32
      Height = 21
      TabOrder = 4
      Text = '1'
      OnChange = E_valFromChange
    end
  end
  object B_undoZ: TButton
    Left = 920
    Top = 652
    Width = 75
    Height = 25
    Caption = 'undoZoom'
    TabOrder = 2
    OnClick = B_undoZClick
  end
  object Chart_Change: TChart
    Left = 8
    Top = 356
    Width = 841
    Height = 326
    BackWall.Brush.Color = clWhite
    BackWall.Brush.Style = bsClear
    Border.Visible = True
    Gradient.Balance = 99
    Gradient.Direction = gdFromTopLeft
    Gradient.EndColor = 753908
    Gradient.MidColor = 16059031
    Gradient.StartColor = 14540754
    Legend.Visible = False
    Title.Text.Strings = (
      'changes')
    BottomAxis.Title.Caption = 'timesteps'
    DepthAxis.Automatic = False
    DepthAxis.AutomaticMaximum = False
    DepthAxis.AutomaticMinimum = False
    DepthAxis.Maximum = 0.500000000000000000
    DepthAxis.Minimum = -0.500000000000000000
    DepthTopAxis.Automatic = False
    DepthTopAxis.AutomaticMaximum = False
    DepthTopAxis.AutomaticMinimum = False
    DepthTopAxis.Maximum = 0.500000000000000000
    DepthTopAxis.Minimum = -0.500000000000000000
    LeftAxis.Grid.Visible = False
    LeftAxis.Title.Caption = 'tolerance value'
    RightAxis.Title.Caption = 'number of changing agents'
    TopAxis.Automatic = False
    TopAxis.AutomaticMaximum = False
    TopAxis.AutomaticMinimum = False
    TopAxis.Visible = False
    View3D = False
    Zoom.UpLeftZooms = True
    Color = clWhite
    TabOrder = 3
    object ser_tol: TLineSeries
      Marks.Callout.Brush.Color = clBlack
      Marks.Visible = False
      Pointer.InflateMargins = True
      Pointer.Style = psRectangle
      Pointer.Visible = False
      XValues.Name = 'X'
      XValues.Order = loAscending
      YValues.Name = 'Y'
      YValues.Order = loNone
    end
    object ser_change: TLineSeries
      Marks.Callout.Brush.Color = clBlack
      Marks.Visible = False
      Pointer.InflateMargins = True
      Pointer.Style = psRectangle
      Pointer.Visible = False
      XValues.Name = 'X'
      XValues.Order = loAscending
      YValues.Name = 'Y'
      YValues.Order = loNone
    end
    object PageNumTool3: TPageNumTool
      Active = False
      Callout.Brush.Color = clBlack
      Callout.Arrow.Visible = False
      Text = 'Page %d of %d'
    end
  end
  object GroupBox2: TGroupBox
    Left = 815
    Top = 151
    Width = 193
    Height = 146
    Caption = 'analyse with a third paramter:'
    TabOrder = 4
    object Label6: TLabel
      Left = 12
      Top = 86
      Width = 55
      Height = 13
      Caption = 'value from:'
    end
    object Label7: TLabel
      Left = 117
      Top = 87
      Width = 14
      Height = 13
      Caption = 'to:'
    end
    object Label9: TLabel
      Left = 80
      Top = 116
      Width = 51
      Height = 13
      Caption = 'increment:'
    end
    object CB_param: TComboBox
      Left = 11
      Top = 48
      Width = 158
      Height = 21
      ItemHeight = 13
      TabOrder = 0
      Text = ' choose parameter'
      OnChange = CB_paramChange
    end
    object E_thirdFrom: TEdit
      Left = 79
      Top = 83
      Width = 32
      Height = 21
      TabOrder = 1
      Text = '25'
      OnChange = E_valFromChange
    end
    object E_thirdTo: TEdit
      Left = 137
      Top = 83
      Width = 32
      Height = 21
      TabOrder = 2
      Text = '45'
      OnChange = E_valFromChange
    end
    object E_thirdIncre: TEdit
      Left = 137
      Top = 112
      Width = 32
      Height = 21
      TabOrder = 3
      Text = '1'
      OnChange = E_valFromChange
    end
    object Cb_acti3d: TCheckBox
      Left = 42
      Top = 25
      Width = 71
      Height = 17
      Caption = 'activate'
      TabOrder = 4
    end
  end
  object S_start: TButton
    Left = 855
    Top = 316
    Width = 75
    Height = 25
    Caption = 'new start'
    TabOrder = 5
    OnClick = S_startClick
  end
  object S_break: TButton
    Left = 933
    Top = 316
    Width = 75
    Height = 25
    Caption = 'start / stop'
    TabOrder = 6
    OnClick = S_breakClick
  end
  object Button1: TButton
    Left = 855
    Top = 356
    Width = 153
    Height = 25
    Caption = 'show 3D surface'
    TabOrder = 7
    OnClick = Button1Click
  end
  object B_saveSnap: TButton
    Left = 855
    Top = 408
    Width = 153
    Height = 25
    Caption = 'save snapshots'
    TabOrder = 8
    OnClick = B_saveSnapClick
  end
  object Timer5: TTimer
    Interval = 1
    OnTimer = Timer5Timer
    Left = 886
    Top = 650
  end
end

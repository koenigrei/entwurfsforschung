unit AnaStability;

interface

uses
  Windows, Messages, SysUtils, Variants, Classes, Graphics, Controls, Forms, Math,
  Dialogs, ExtCtrls, StdCtrls, TeEngine, TeeFunci, TeeTools, TeePageNumTool,
  Series, TeeProcs, Chart;

type
  TForm6 = class(TForm)
    Chart_Stability : TChart;
    Series_segVal   : TPointSeries;
    Series_segAvg   : TLineSeries;
    PageNumTool1    : TPageNumTool;
    TeeFunction1    : TAverageTeeFunction;
    GroupBox1       : TGroupBox;
    Label1          : TLabel;
    Label2          : TLabel;
    Label3          : TLabel;
    Label4          : TLabel;
    Label5          : TLabel;
    E_valFrom       : TEdit;
    E_valTo         : TEdit;
    E_toSteps       : TEdit;
    E_calcRds       : TEdit;
    E_incre         : TEdit;
    lbl_pSteps      : TLabel;
    lbl_timesteps   : TLabel;
    Label8          : TLabel;
    Lbl_proceed     : TLabel;
    Lbl_akt         : TLabel;
    Timer5          : TTimer;
    B_undoZ         : TButton;
    Chart_Change    : TChart;
    ser_tol         : TLineSeries;
    PageNumTool3    : TPageNumTool;
    ser_change      : TLineSeries;
    GroupBox2       : TGroupBox;
    CB_param        : TComboBox;
    Label6          : TLabel;
    E_thirdFrom     : TEdit;
    Label7          : TLabel;
    E_thirdTo       : TEdit;
    Label9          : TLabel;
    E_thirdIncre    : TEdit;
    S_start         : TButton;
    S_break         : TButton;
    Button1         : TButton;
    Cb_acti3d       : TCheckBox;
    B_saveSnap: TButton;
    procedure FormCreate      (Sender: TObject);
    procedure S_breakClick    (Sender: TObject);
    procedure S_startClick    (Sender: TObject);
    procedure B_undoZClick    (Sender: TObject);
    procedure E_valFromChange (Sender: TObject);
    procedure Timer5Timer     (Sender: TObject);
    procedure Button1Click    (Sender: TObject);
    procedure CB_paramChange(Sender: TObject);
    procedure B_saveSnapClick(Sender: TObject);
  private
    procedure resetGraphs;
    procedure updProc;
    procedure newRound;
    procedure plotVals;
    procedure plotToSurface;
  public
    { Public declarations }
  end;

var
  Form6    : TForm6;
  pSteps   : Integer;    // -- local step counter
  rounds   : Cardinal;
  thirdRds : Cardinal;
  aktVal   : Integer;    // -- holds the actual tolerance value
  thirdVal : Integer;    // -- holds the actual third value
  thirdActi: Boolean;    // -- if the calculation of a third parameter is activated
  toCalc   : Cardinal;   // -- how many values have to be calculated
  noChange : Integer;
  oldChange: Integer;

implementation

{$R *.dfm}
uses CellForm, Analyse, AnaLandsc3D;

procedure TForm6.FormCreate(Sender: TObject);
begin
  Timer5.enabled     := false;
  lbl_pSteps.Caption := '0';
  pSteps := 0;
  Steps  := 0;
  toCalc := 0;
  Lbl_akt.Caption := IntToStr(toCalc);
  updProc;
  Chart_Stability.Title.Text.Clear;
  Chart_Stability.Title.Text.Add('phase transitions || '+IntToStr(ngGroups)+' groups');
  resetGraphs;
  thirdActi := false;
  CB_param.AddItem(' number of agents', Sender);
  CB_param.AddItem(' number of groups', Sender);
  CB_param.AddItem(' radius neighbourhood', Sender);
  CB_param.AddItem(' move distance', Sender);
end;

procedure TForm6.S_breakClick(Sender: TObject);
begin
  Timer5.enabled := not(Timer5.enabled);
end;

procedure TForm6.resetGraphs;
begin
  Series_segVal.clear;
  ser_change.clear;
  ser_change.VertAxis := aRightAxis;
  ser_tol.clear;
  ser_tol.VertAxis := aLeftAxis;
end;

procedure TForm6.Timer5Timer(Sender: TObject);
begin
  If noChange >= StrToInt(E_toSteps.Text) Then                                // -- increase tolerance if nothing changes
  begin
    plotVals;
    noChange := 0;
    inc(aktVal);
    Form1.TrB_thresh.Position := aktVal;                                      // -- raise aktual value by increment
    Form1.UpD_thresh.Position := aktVal;                                      // --  ""                 "
    satiThr := aktVal;                                                        // --  ""                 "
    inc(toCalc);
    Lbl_akt.Caption := IntToStr(toCalc);
    If aktVal > StrToInt(E_valTo.Text) Then                                   // -- one round is finished
    begin
      Series_segAvg.FunctionType.Period := rounds;
      Series_segAvg.CheckDataSource;                                          // -- print the average
      inc(rounds);
      Series_segAvg.CheckDataSource;
      If rounds > StrToInt(E_calcRds.Text) Then                               // -- calculated rounds
      begin
        Form1.cb_save_3DSurf.Checked := false;                                // -- save the 3D surface only once at the end
        Form1.saveBmp (IntToStr(thirdRds));
        If Cb_acti3d.Checked Then                                             // -- if a third parameter should be investigated
        begin
          plotToSurface;
          thirdVal := thirdVal + StrToInt(E_thirdIncre.Text);
          If thirdVal > StrToInt(E_thirdTo.Text) Then                         // -- third parameter examination finished?
          begin                                                               // -- in the 3D case exit the examination
            Form1.cb_save_3DSurf.Checked := true;                             // -- save the 3D surface only once at the end
            Form1.saveBmp (IntToStr(thirdRds));
            Timer5.enabled := false;                                          // -- the end of the analysis
            exit;
          end;
          case CB_param.ItemIndex of                                          // -- set the third parameter
            0: Form1.Edit_anzAg.Text       := IntToStr(thirdVal);
            1: Form1.UpD_nrGroups.Position := thirdVal;
            2: Form1.UpD_radNb.Position    := thirdVal;
            3: Form1.UpD_moveDist.Position := thirdVal;
          end;
          rounds := 1;
          inc(thirdRds);                                                      // -- count the rounds of the third parameter
          resetGraphs;
          newRound;
          Chart_Stability.Title.Text.Clear;
          Chart_Stability.Title.Text.Add('phase transitions || '+IntToStr(ngGroups)+' groups');
        end else
        begin                                                                 // -- in the 2D case exit the examination
          Timer5.enabled := false;                                            // -- the end of the analysis
          exit;
        end;
      end;
      ser_change.clear;
      ser_tol.clear;
      pSteps := 0;
      newRound;                                                               // -- start again from the beginning
    end;
  end;
  If posChange = oldChange Then inc(noChange) Else noChange := 0;             // -- if there is no change increase the noChange counter
  oldChange := posChange;
  Form1.actions;                                                              // -- run the process at Form1
  lbl_pSteps.Caption := IntToStr (pSteps);
  inc(pSteps);
end;

procedure TForm6.plotToSurface;
var
  I, counter : Integer;
begin
  counter := StrToInt(E_valTo.Text) - StrToInt(E_valFrom.Text);
  For I := 0 To counter Do
  begin
    Form7.ser_landsc.AddXYZ(Series_segAvg.XValues[I], Series_segAvg.YValues[I], thirdVal);
    Form7.Chart_3DLand.Update;
  end;
end;

procedure TForm6.plotVals;
var
  I : Integer;
  sumIS   : Extended;
begin
  sumIS   := 0;
  For I := 0 To ngGroups-1 Do
  begin
    sumIS   := sumIS + isSer[I].YValues[pSteps-1];
  end;
  sumIS := sumIS / ngGroups;
  Series_SegVal.AddXY(aktVal, sumIS);                                         // -- average of the segregation indices
end;

procedure TForm6.S_startClick(Sender: TObject);
begin
  If Cb_acti3d.Checked Then                                                   // -- if a third parameter should be investigated,
  begin
    If CB_param.ItemIndex = -1 Then                                           // -- but no parameter is selected,
    begin
      MessageBox(MB_Ok, 'please select a parameter', 'missing value', MB_Ok); // -- then show thies message box.
      exit;
    end;
    thirdActi:= true;
    thirdVal := StrToInt(E_thirdFrom.Text);
    Form7.reset3DGraph;
    case CB_param.ItemIndex of                                                // -- set the third parameter
      0: begin Form1.Edit_anzAg.Text       := IntToStr(thirdVal);
         Form7.Chart_3DLand.Title.Text.Clear;
         Form7.Chart_3DLand.Title.Text.Add('Stability Landscape for '+'"number of agents"');
      end;
      1: begin Form1.UpD_nrGroups.Position := thirdVal;
         Form7.Chart_3DLand.Title.Text.Clear;
         Form7.Chart_3DLand.Title.Text.Add('Stability Landscape for '+'"number of groups"');
      end;
      2: begin Form1.UpD_radNb.Position    := thirdVal;
         Form7.Chart_3DLand.Title.Text.Clear;
         Form7.Chart_3DLand.Title.Text.Add('Stability Landscape for '+'"radius neighbourhood"');
      end;
      3: begin Form1.UpD_moveDist.Position := thirdVal;
         Form7.Chart_3DLand.Title.Text.Clear;
         Form7.Chart_3DLand.Title.Text.Add('Stability Landscape for '+'"move distance"');
      end;
    end;
  end;
  toCalc   := 0;
  rounds   := 1;
  thirdRds := 1;
  resetGraphs;
  newRound;
  Timer5.Enabled := true;
  Chart_Stability.Title.Text.Clear;
  Chart_Stability.Title.Text.Add('phase transitions || '+IntToStr(ngGroups)+' groups');
end;

procedure TForm6.Button1Click(Sender: TObject);
begin
  Form7.show;
end;

procedure TForm6.B_saveSnapClick(Sender: TObject);
begin
  Form1.saveBmp (IntToStr(thirdRds));
end;

procedure TForm6.B_undoZClick(Sender: TObject);
begin
  Chart_Stability.UndoZoom;
  Chart_Change.UndoZoom;
end;

procedure TForm6.CB_paramChange(Sender: TObject);
begin
  updProc;
end;

procedure TForm6.E_valFromChange(Sender: TObject);
begin
  updProc;
end;

procedure TForm6.newRound;
begin
  pSteps   := 0;
  Steps    := 0;
  noChange := 0;
  Lbl_akt.Caption := IntToStr(toCalc);
  aktVal := StrToInt(E_valFrom.Text);
  Form1.E_stopT.Text := E_toSteps.Text;
  Form1.deleter;
  Form1.TrB_thresh.Position := aktVal;                                      // -- raise aktual value by increment
  Form1.UpD_thresh.Position := aktVal;                                      // --  ""                 "
  satiThr := aktVal;                                                        // --  ""                 "
end;

procedure TForm6.updProc;
var
  firstSum, secSum : Cardinal;
begin
  If (StrToInt(E_thirdIncre.Text)<1) OR (StrToInt(E_incre.Text)<1) Then
  begin
    MessageBox(MB_Ok, 'increments have to be > 0', 'missing value', MB_Ok);   // -- then show thies message box.
    exit;
  end;
  If (StrToInt(E_valTo.Text)  -StrToInt(E_valFrom.Text)+1   < 0) OR
     (StrToInt(E_thirdTo.Text)-StrToInt(E_thirdFrom.Text)+1 < 0) Then
  begin
    Lbl_proceed.Caption := '0';
    exit;
  end;
  firstSum := Ceil((StrToInt(E_valTo.Text) -  StrToInt(E_valFrom.Text)+1)/
                    StrToInt(E_incre.Text)) * StrToInt(E_calcRds.Text);
  If Cb_acti3d.Checked Then begin
    secSum :=  Ceil((StrToInt(E_thirdTo.Text) - StrToInt(E_thirdFrom.Text)+1)/
                     StrToInt(E_thirdIncre.Text));
    Lbl_proceed.Caption := '/ ' + IntToStr(firstSum * secSum);
  end else begin
    Lbl_proceed.Caption := '/ ' + IntToStr(firstSum);
  end;
end;

end.

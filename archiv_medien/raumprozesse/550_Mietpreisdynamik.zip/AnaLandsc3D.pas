unit AnaLandsc3D;

interface

uses
  Windows, Messages, SysUtils, Variants, Classes, Graphics, Controls, Forms,
  Dialogs, TeEngine, TeeSurfa, TeeTools, TeePageNumTool, ExtCtrls, TeeProcs,
  Chart;

type
  TForm7 = class(TForm)
    Chart_3DLand: TChart;
    PageNumTool3: TPageNumTool;
    ser_landsc: TSurfaceSeries;
    procedure FormCreate(Sender: TObject);
  private
  public
    procedure reset3DGraph;
  end;

var
  Form7: TForm7;

implementation

{$R *.dfm}

procedure TForm7.FormCreate(Sender: TObject);
begin
  reset3DGraph;
end;

procedure TForm7.reset3DGraph;
begin
  ser_Landsc.clear;
end;

end.

object Form9: TForm9
  Left = 0
  Top = 0
  Width = 336
  Height = 440
  AutoScroll = True
  Caption = 'Group Sizes'
  Color = clBtnFace
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -11
  Font.Name = 'Tahoma'
  Font.Style = []
  OldCreateOrder = False
  OnCreate = FormCreate
  PixelsPerInch = 96
  TextHeight = 13
  object B_reset: TButton
    Left = 32
    Top = 8
    Width = 75
    Height = 25
    Caption = 'reset values'
    TabOrder = 0
    OnClick = B_resetClick
  end
end

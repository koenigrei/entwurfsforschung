object Form3: TForm3
  Left = 0
  Top = 0
  Caption = 'Analyse Parameterspace'
  ClientHeight = 700
  ClientWidth = 1000
  Color = clBtnFace
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -11
  Font.Name = 'Tahoma'
  Font.Style = []
  OldCreateOrder = False
  OnCreate = FormCreate
  PixelsPerInch = 96
  TextHeight = 13
  object lbl_pSteps: TLabel
    Left = 860
    Top = 268
    Width = 49
    Height = 13
    Alignment = taRightJustify
    Caption = 'lbl_pSteps'
  end
  object lbl_timesteps: TLabel
    Left = 915
    Top = 268
    Width = 53
    Height = 13
    Caption = ': timesteps'
  end
  object Label8: TLabel
    Left = 915
    Top = 300
    Width = 62
    Height = 13
    Caption = ': calculations'
  end
  object Lbl_proceed: TLabel
    Left = 890
    Top = 300
    Width = 19
    Height = 13
    Alignment = taRightJustify
    Caption = 'sum'
  end
  object Lbl_akt: TLabel
    Left = 852
    Top = 300
    Width = 19
    Height = 13
    Alignment = taRightJustify
    Caption = 'sum'
  end
  object GroupBox1: TGroupBox
    Left = 800
    Top = 8
    Width = 192
    Height = 241
    Caption = 'settings'
    TabOrder = 0
    object Label1: TLabel
      Left = 11
      Top = 64
      Width = 60
      Height = 13
      Caption = 'values from:'
    end
    object Label2: TLabel
      Left = 115
      Top = 64
      Width = 14
      Height = 13
      Caption = 'to:'
    end
    object Label3: TLabel
      Left = 29
      Top = 132
      Width = 98
      Height = 13
      Caption = 'timesteps per value:'
    end
    object Label4: TLabel
      Left = 20
      Top = 159
      Width = 107
      Height = 13
      Caption = 'calculations per value:'
    end
    object Label5: TLabel
      Left = 76
      Top = 110
      Width = 51
      Height = 13
      Caption = 'increment:'
    end
    object CB_param: TComboBox
      Left = 11
      Top = 24
      Width = 158
      Height = 21
      ItemHeight = 13
      TabOrder = 0
      Text = ' choose parameter'
    end
    object E_valFrom: TEdit
      Left = 77
      Top = 60
      Width = 32
      Height = 21
      TabOrder = 1
      Text = '2'
      OnChange = E_calcValsChange
    end
    object E_valTo: TEdit
      Left = 135
      Top = 60
      Width = 32
      Height = 21
      TabOrder = 2
      Text = '4'
      OnChange = E_calcValsChange
    end
    object E_toSteps: TEdit
      Left = 133
      Top = 129
      Width = 32
      Height = 21
      TabOrder = 3
      Text = '30'
    end
    object E_calcVals: TEdit
      Left = 133
      Top = 156
      Width = 32
      Height = 21
      TabOrder = 4
      Text = '3'
      OnChange = E_calcValsChange
    end
    object B_start: TButton
      Left = 11
      Top = 200
      Width = 75
      Height = 25
      Caption = 'new start'
      TabOrder = 5
      OnClick = B_startClick
    end
    object B_break: TButton
      Left = 92
      Top = 200
      Width = 75
      Height = 25
      Caption = 'start / stop'
      TabOrder = 6
      OnClick = B_breakClick
    end
    object E_incre: TEdit
      Left = 133
      Top = 101
      Width = 32
      Height = 21
      TabOrder = 7
      Text = '1'
      OnChange = E_calcValsChange
    end
  end
  object Chart_Cluster: TChart
    Left = 8
    Top = 8
    Width = 786
    Height = 340
    BackWall.Brush.Color = clWhite
    BackWall.Brush.Style = bsClear
    Border.Visible = True
    Gradient.Balance = 99
    Gradient.Direction = gdFromTopLeft
    Gradient.EndColor = 753908
    Gradient.MidColor = 16059031
    Gradient.StartColor = 14540754
    Legend.Visible = False
    Title.Text.Strings = (
      'TChart')
    BottomAxis.ExactDateTime = False
    BottomAxis.Increment = 1.000000000000000000
    BottomAxis.Title.Caption = 'values'
    DepthAxis.Automatic = False
    DepthAxis.AutomaticMaximum = False
    DepthAxis.AutomaticMinimum = False
    DepthAxis.Maximum = 0.500000000000000000
    DepthAxis.Minimum = -0.500000000000000000
    DepthTopAxis.Automatic = False
    DepthTopAxis.AutomaticMaximum = False
    DepthTopAxis.AutomaticMinimum = False
    DepthTopAxis.Maximum = 0.500000000000000000
    DepthTopAxis.Minimum = -0.500000000000000000
    LeftAxis.ExactDateTime = False
    LeftAxis.Increment = 1.000000000000000000
    LeftAxis.Title.Caption = 'clusters'
    RightAxis.Automatic = False
    RightAxis.AutomaticMaximum = False
    RightAxis.AutomaticMinimum = False
    RightAxis.Title.Caption = 'segregation index'
    RightAxis.Visible = False
    TopAxis.Automatic = False
    TopAxis.AutomaticMaximum = False
    TopAxis.AutomaticMinimum = False
    TopAxis.Visible = False
    View3D = False
    Zoom.UpLeftZooms = True
    Color = clWhite
    TabOrder = 1
    object Series_Avg: TPointSeries
      Marks.Callout.Brush.Color = clBlack
      Marks.Visible = False
      Title = 'Series_Avg'
      ClickableLine = False
      Pointer.HorizSize = 3
      Pointer.InflateMargins = True
      Pointer.Style = psCircle
      Pointer.VertSize = 3
      Pointer.Visible = True
      XValues.Name = 'X'
      XValues.Order = loAscending
      YValues.Name = 'Y'
      YValues.Order = loNone
    end
    object Series_AvgClust: TLineSeries
      Marks.Callout.Brush.Color = clBlack
      Marks.Visible = True
      DataSource = Series_Avg
      Title = 'Series_AvgClust'
      ValueFormat = '#,##0.#'
      Pointer.HorizSize = 2
      Pointer.InflateMargins = True
      Pointer.Style = psRectangle
      Pointer.VertSize = 2
      Pointer.Visible = True
      XValues.Name = 'X'
      XValues.Order = loAscending
      YValues.Name = 'Y'
      YValues.Order = loNone
      object TeeFunction1: TAverageTeeFunction
      end
    end
    object Series_AvgFit: TLineSeries
      Marks.Callout.Brush.Color = clBlack
      Marks.Visible = False
      DataSource = Series_Avg
      SeriesColor = 16744448
      LinePen.Width = 2
      Pointer.InflateMargins = True
      Pointer.Style = psRectangle
      Pointer.Visible = False
      XValues.Name = 'X'
      XValues.Order = loAscending
      YValues.Name = 'Y'
      YValues.Order = loNone
      object TeeFunction4: TCurveFittingFunction
        Period = 1.000000000000000000
      end
    end
    object Series_AvgTrend: TLineSeries
      Marks.Callout.Brush.Color = clBlack
      Marks.Visible = False
      DataSource = Series_Avg
      SeriesColor = 33023
      Pointer.InflateMargins = True
      Pointer.Style = psRectangle
      Pointer.Visible = False
      XValues.Name = 'X'
      XValues.Order = loAscending
      YValues.Name = 'Y'
      YValues.Order = loNone
      object TeeFunction5: TTrendFunction
      end
    end
    object PageNumTool1: TPageNumTool
      Active = False
      Callout.Brush.Color = clBlack
      Callout.Arrow.Visible = False
      Text = 'Page %d of %d'
      Format = 'Page %d of %d'
    end
  end
  object Chart_IS: TChart
    Left = 8
    Top = 354
    Width = 786
    Height = 340
    BackWall.Brush.Color = clWhite
    BackWall.Brush.Style = bsClear
    Border.Visible = True
    Gradient.Balance = 99
    Gradient.Direction = gdFromTopLeft
    Gradient.EndColor = 753908
    Gradient.MidColor = 16059031
    Gradient.StartColor = 14540754
    Legend.Visible = False
    Title.Text.Strings = (
      'TChart')
    BottomAxis.ExactDateTime = False
    BottomAxis.Increment = 1.000000000000000000
    BottomAxis.Title.Caption = 'values'
    DepthAxis.Automatic = False
    DepthAxis.AutomaticMaximum = False
    DepthAxis.AutomaticMinimum = False
    DepthAxis.Maximum = 0.500000000000000000
    DepthAxis.Minimum = -0.500000000000000000
    DepthTopAxis.Automatic = False
    DepthTopAxis.AutomaticMaximum = False
    DepthTopAxis.AutomaticMinimum = False
    DepthTopAxis.Maximum = 0.500000000000000000
    DepthTopAxis.Minimum = -0.500000000000000000
    LeftAxis.Title.Caption = 'segregation index (IS)'
    RightAxis.Automatic = False
    RightAxis.AutomaticMaximum = False
    RightAxis.AutomaticMinimum = False
    RightAxis.Title.Caption = 'segregation index'
    RightAxis.Visible = False
    TopAxis.Automatic = False
    TopAxis.AutomaticMaximum = False
    TopAxis.AutomaticMinimum = False
    TopAxis.Visible = False
    View3D = False
    Zoom.UpLeftZooms = True
    Color = clWhite
    TabOrder = 2
    PrintMargins = (
      15
      26
      15
      26)
    object Series_IS: TPointSeries
      Marks.Callout.Brush.Color = clBlack
      Marks.Visible = False
      ClickableLine = False
      Pointer.HorizSize = 3
      Pointer.InflateMargins = True
      Pointer.Style = psCircle
      Pointer.VertSize = 3
      Pointer.Visible = True
      XValues.Name = 'X'
      XValues.Order = loAscending
      YValues.Name = 'Y'
      YValues.Order = loNone
    end
    object Series_IS_Avg: TLineSeries
      Marks.Callout.Brush.Color = clBlack
      Marks.Visible = True
      DataSource = Series_IS
      Title = 'Series_IS_Avg'
      ValueFormat = '#,##0.#'
      Pointer.HorizSize = 2
      Pointer.InflateMargins = True
      Pointer.Style = psRectangle
      Pointer.VertSize = 2
      Pointer.Visible = True
      XValues.Name = 'X'
      XValues.Order = loAscending
      YValues.Name = 'Y'
      YValues.Order = loNone
      object TeeFunction2: TAverageTeeFunction
      end
    end
    object Series_IS_Fit: TLineSeries
      Marks.Callout.Brush.Color = clBlack
      Marks.Visible = False
      DataSource = Series_IS
      SeriesColor = 16744448
      LinePen.Color = 16744448
      LinePen.Width = 2
      Pointer.InflateMargins = True
      Pointer.Style = psRectangle
      Pointer.Visible = False
      XValues.Name = 'X'
      XValues.Order = loAscending
      YValues.Name = 'Y'
      YValues.Order = loNone
      object TeeFunction3: TCurveFittingFunction
        Period = 1.000000000000000000
      end
    end
    object Series_IS_Trend: TLineSeries
      Marks.Callout.Brush.Color = clBlack
      Marks.Visible = False
      DataSource = Series_IS
      SeriesColor = 33023
      Pointer.InflateMargins = True
      Pointer.Style = psRectangle
      Pointer.Visible = False
      XValues.Name = 'X'
      XValues.Order = loAscending
      YValues.Name = 'Y'
      YValues.Order = loNone
      object TeeFunction6: TTrendFunction
      end
    end
    object PageNumTool2: TPageNumTool
      Active = False
      Callout.Brush.Color = clBlack
      Callout.Arrow.Visible = False
      Text = 'Page %d of %d'
      Format = 'Page %d of %d'
    end
  end
  object GroupBox2: TGroupBox
    Left = 800
    Top = 354
    Width = 192
    Height = 153
    Caption = 'cluster chart'
    TabOrder = 3
    object Label6: TLabel
      Left = 31
      Top = 121
      Width = 61
      Height = 13
      Caption = 'poly degree:'
    end
    object CB_data_Clust: TCheckBox
      Left = 10
      Top = 24
      Width = 97
      Height = 17
      Caption = 'show data'
      Checked = True
      State = cbChecked
      TabOrder = 0
      OnClick = CB_data_ClustClick
    end
    object CB_avg_Clust: TCheckBox
      Left = 10
      Top = 47
      Width = 97
      Height = 17
      Caption = 'show average'
      Checked = True
      State = cbChecked
      TabOrder = 1
      OnClick = CB_avg_ClustClick
    end
    object CB_trend_Clust: TCheckBox
      Left = 10
      Top = 70
      Width = 97
      Height = 17
      Caption = 'show trend'
      Checked = True
      State = cbChecked
      TabOrder = 2
      OnClick = CB_trend_ClustClick
    end
    object CB_cFit_Clust: TCheckBox
      Left = 10
      Top = 93
      Width = 97
      Height = 17
      Caption = 'show curve fitting'
      Checked = True
      State = cbChecked
      TabOrder = 3
      OnClick = CB_cFit_ClustCli
    end
    object UpD_polyDegClust: TUpDown
      Left = 123
      Top = 117
      Width = 16
      Height = 21
      Associate = E_polyDegClust
      Min = 2
      Max = 20
      Position = 3
      TabOrder = 4
      OnClick = UpD_polyDegClustClick
    end
    object E_polyDegClust: TEdit
      Left = 98
      Top = 117
      Width = 25
      Height = 21
      TabOrder = 5
      Text = '3'
    end
  end
  object GroupBox3: TGroupBox
    Left = 800
    Top = 539
    Width = 192
    Height = 153
    Caption = 'segregation chart'
    TabOrder = 4
    object Label7: TLabel
      Left = 31
      Top = 121
      Width = 61
      Height = 13
      Caption = 'poly degree:'
    end
    object CB_data_Seg: TCheckBox
      Left = 10
      Top = 24
      Width = 97
      Height = 17
      Caption = 'show data'
      Checked = True
      State = cbChecked
      TabOrder = 0
      OnClick = CB_data_SegClick
    end
    object CB_avg_Seg: TCheckBox
      Left = 10
      Top = 47
      Width = 97
      Height = 17
      Caption = 'show average'
      Checked = True
      State = cbChecked
      TabOrder = 1
      OnClick = CB_avg_SegClick
    end
    object CB_trend_Seg: TCheckBox
      Left = 10
      Top = 70
      Width = 97
      Height = 17
      Caption = 'show trend'
      Checked = True
      State = cbChecked
      TabOrder = 2
      OnClick = CB_trend_SegClick
    end
    object CB_cFit_Seg: TCheckBox
      Left = 10
      Top = 93
      Width = 97
      Height = 17
      Caption = 'show curve fitting'
      Checked = True
      State = cbChecked
      TabOrder = 3
      OnClick = CB_cFit_SegClick
    end
    object UpD_polyDegSeg: TUpDown
      Left = 123
      Top = 116
      Width = 16
      Height = 21
      Associate = E_polyDegSeg
      Min = 2
      Max = 20
      Position = 3
      TabOrder = 4
      OnClick = UpD_polyDegSegClick
    end
    object E_polyDegSeg: TEdit
      Left = 98
      Top = 116
      Width = 25
      Height = 21
      TabOrder = 5
      Text = '3'
    end
  end
  object B_undoZ: TButton
    Left = 892
    Top = 323
    Width = 75
    Height = 25
    Caption = 'undoZoom'
    TabOrder = 5
    OnClick = B_undoZClick
  end
  object Timer2: TTimer
    Interval = 1
    OnTimer = Timer2Timer
    Left = 816
    Top = 258
  end
end

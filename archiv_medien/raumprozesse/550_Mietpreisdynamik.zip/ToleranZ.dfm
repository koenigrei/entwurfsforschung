object Form8: TForm8
  Left = 0
  Top = 0
  Width = 940
  Height = 600
  AutoScroll = True
  Caption = 'Individual Tolerance'
  Color = clBtnFace
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -11
  Font.Name = 'Tahoma'
  Font.Style = []
  OldCreateOrder = False
  OnClose = FormClose
  OnShow = FormShow
  PixelsPerInch = 96
  TextHeight = 13
end

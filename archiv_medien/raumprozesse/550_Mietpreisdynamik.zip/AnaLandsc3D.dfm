object Form7: TForm7
  Left = 0
  Top = 0
  Caption = '3D Prozess-Analyse-Landscape'
  ClientHeight = 666
  ClientWidth = 1016
  Color = clBtnFace
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -11
  Font.Name = 'Tahoma'
  Font.Style = []
  OldCreateOrder = False
  OnCreate = FormCreate
  PixelsPerInch = 96
  TextHeight = 13
  object Chart_3DLand: TChart
    Left = 8
    Top = 8
    Width = 1000
    Height = 650
    BackWall.Brush.Color = clWhite
    BackWall.Brush.Style = bsClear
    BackWall.Color = clWhite
    BackWall.Transparent = False
    Border.Visible = True
    Gradient.Balance = 99
    Gradient.Direction = gdFromTopLeft
    Gradient.EndColor = 753908
    Gradient.MidColor = 16059031
    Gradient.StartColor = 14540754
    LeftWall.Color = clWhite
    LeftWall.Gradient.EndColor = clWhite
    LeftWall.Gradient.StartColor = clYellow
    Legend.Visible = False
    Title.Text.Strings = (
      'Stability Surface')
    BottomAxis.Title.Caption = 'tolerance values'
    Chart3DPercent = 45
    DepthAxis.Inverted = True
    DepthAxis.Title.Angle = 45
    DepthAxis.Title.Caption = 'choosen third param.'
    DepthAxis.Visible = True
    DepthTopAxis.Automatic = False
    DepthTopAxis.AutomaticMaximum = False
    DepthTopAxis.AutomaticMinimum = False
    DepthTopAxis.Inverted = True
    DepthTopAxis.Maximum = 0.500000000000000000
    DepthTopAxis.Minimum = -0.500000000000000000
    LeftAxis.Inverted = True
    LeftAxis.Title.Caption = 'average segregation indices'
    RightAxis.Title.Caption = 'number of changing agents'
    TopAxis.Automatic = False
    TopAxis.AutomaticMaximum = False
    TopAxis.AutomaticMinimum = False
    TopAxis.Visible = False
    Zoom.UpLeftZooms = True
    Color = clWhite
    TabOrder = 0
    object ser_landsc: TSurfaceSeries
      Marks.Callout.Brush.Color = clBlack
      Marks.Visible = False
      IrregularGrid = True
      SideBrush.Color = clWhite
      SideBrush.Style = bsClear
      XValues.Name = 'X'
      XValues.Order = loNone
      YValues.Name = 'Y'
      YValues.Order = loNone
      ZValues.Name = 'Z'
      ZValues.Order = loNone
    end
    object PageNumTool3: TPageNumTool
      Active = False
      Callout.Brush.Color = clBlack
      Callout.Arrow.Visible = False
      Text = 'Page %d of %d'
    end
  end
end

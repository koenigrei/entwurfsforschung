object Form1: TForm1
  Left = 600
  Top = 0
  Caption = 'Segregation by Move '
  ClientHeight = 711
  ClientWidth = 924
  Color = clBtnFace
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -10
  Font.Name = 'Tahoma'
  Font.Style = []
  OldCreateOrder = False
  Position = poDesigned
  OnCreate = FormCreate
  OnDestroy = FormDestroy
  OnShow = FormShow
  PixelsPerInch = 96
  TextHeight = 12
  object lbl_Steps: TLabel
    Left = 767
    Top = 527
    Width = 39
    Height = 12
    Alignment = taRightJustify
    Caption = 'lbl_Steps'
  end
  object lbl_timesteps: TLabel
    Left = 812
    Top = 527
    Width = 47
    Height = 12
    Caption = ': timesteps'
  end
  object Label5: TLabel
    Left = 835
    Top = 680
    Width = 76
    Height = 12
    Caption = ': stop at timestep'
  end
  object Lbl_cellS: TLabel
    Left = 791
    Top = 635
    Width = 39
    Height = 12
    Alignment = taRightJustify
    Caption = 'lbl_Steps'
  end
  object Label10: TLabel
    Left = 836
    Top = 635
    Width = 50
    Height = 12
    Caption = ': cell-space'
  end
  object Lbl_strCell: TLabel
    Left = 791
    Top = 653
    Width = 39
    Height = 12
    Alignment = taRightJustify
    Caption = 'lbl_Steps'
  end
  object Label19: TLabel
    Left = 836
    Top = 653
    Width = 52
    Height = 12
    Caption = ': street cells'
  end
  object ZeichenPanel: TPanel
    Left = 8
    Top = 9
    Width = 694
    Height = 694
    BorderStyle = bsSingle
    DockSite = True
    TabOrder = 0
    OnMouseDown = ZeichenPanelMouseDown
    OnMouseMove = ZeichenPanelMouseMove
    OnMouseUp = ZeichenPanelMouseUp
  end
  object PageControl1: TPageControl
    Left = 708
    Top = 8
    Width = 205
    Height = 505
    ActivePage = TabSheet3
    MultiLine = True
    TabOrder = 1
    object TabSheet1: TTabSheet
      Caption = 'setup'
      object GroupBox1: TGroupBox
        Left = 3
        Top = 0
        Width = 191
        Height = 254
        Caption = 'setup settings'
        TabOrder = 0
        object Lbl_TextAnzahl: TLabel
          Left = 72
          Top = 24
          Width = 86
          Height = 12
          Caption = ': number of agents'
        end
        object Label2: TLabel
          Left = 72
          Top = 74
          Width = 39
          Height = 12
          Caption = ': cell size'
        end
        object Label3: TLabel
          Left = 72
          Top = 100
          Width = 89
          Height = 12
          Caption = ': number of groups'
        end
        object Label1: TLabel
          Left = 72
          Top = 126
          Width = 93
          Height = 12
          Caption = ': radius neighbourh.'
        end
        object Label4: TLabel
          Left = 72
          Top = 152
          Width = 71
          Height = 12
          Caption = ': move distance'
        end
        object Label27: TLabel
          Left = 72
          Top = 50
          Width = 50
          Height = 12
          Caption = ': agent size'
        end
        object Edit_anzAg: TEdit
          Left = 9
          Top = 21
          Width = 41
          Height = 20
          TabOrder = 0
          Text = '12000'
          OnChange = Edit_anzAgChange
        end
        object Edit_cellSiz: TEdit
          Left = 26
          Top = 71
          Width = 24
          Height = 20
          TabOrder = 1
          Text = '6'
          OnChange = Edit_cellSizChange
        end
        object Edit_anzGr: TEdit
          Left = 26
          Top = 97
          Width = 24
          Height = 20
          TabOrder = 2
          Text = '6'
          OnChange = Edit_anzGrChange
        end
        object Edit_nRad: TEdit
          Left = 26
          Top = 123
          Width = 24
          Height = 20
          TabOrder = 3
          Text = '2'
          OnChange = Edit_nRadChange
        end
        object Edit_mDist: TEdit
          Left = 26
          Top = 149
          Width = 24
          Height = 20
          TabOrder = 4
          Text = '54'
          OnChange = Edit_mDistChange
        end
        object CB_graphicUpd: TCheckBox
          Left = 9
          Top = 175
          Width = 133
          Height = 17
          Caption = 'run with graphic (slower)'
          Checked = True
          State = cbChecked
          TabOrder = 5
        end
        object UpD_moveDist: TUpDown
          Left = 50
          Top = 149
          Width = 16
          Height = 20
          Associate = Edit_mDist
          Min = 2
          Max = 1000
          Position = 54
          TabOrder = 6
        end
        object UpD_radNb: TUpDown
          Left = 50
          Top = 123
          Width = 16
          Height = 20
          Associate = Edit_nRad
          Min = 1
          Max = 1000
          Position = 2
          TabOrder = 7
        end
        object UpD_nrGroups: TUpDown
          Left = 50
          Top = 97
          Width = 16
          Height = 20
          Associate = Edit_anzGr
          Min = 2
          Max = 1000
          Position = 6
          TabOrder = 8
        end
        object UpD_sellSz: TUpDown
          Left = 50
          Top = 71
          Width = 16
          Height = 20
          Associate = Edit_cellSiz
          Min = 1
          Max = 50
          Position = 6
          TabOrder = 9
        end
        object CB_strOcc: TCheckBox
          Left = 9
          Top = 198
          Width = 166
          Height = 17
          Caption = 'allow street occupation'
          TabOrder = 10
        end
        object B_adjGroupSz: TButton
          Left = 9
          Top = 221
          Width = 94
          Height = 25
          Caption = 'adjust group size'
          TabOrder = 11
          OnClick = B_adjGroupSzClick
        end
        object cb_indiGroups: TCheckBox
          Left = 109
          Top = 225
          Width = 68
          Height = 17
          Caption = 'activate'
          TabOrder = 12
        end
        object Edit_agentSize: TEdit
          Left = 26
          Top = 47
          Width = 24
          Height = 20
          TabOrder = 13
          Text = '6'
          OnChange = Edit_cellSizChange
        end
        object UpD_agentSz: TUpDown
          Left = 50
          Top = 47
          Width = 16
          Height = 20
          Associate = Edit_agentSize
          Min = 1
          Max = 50
          Position = 6
          TabOrder = 14
          OnClick = UpD_agentSzClick
        end
      end
      object GroupBox3: TGroupBox
        Left = 3
        Top = 271
        Width = 191
        Height = 118
        Caption = 'growth'
        TabOrder = 1
        object Label11: TLabel
          Left = 43
          Top = 64
          Width = 77
          Height = 12
          Caption = 'start with agents:'
        end
        object Label12: TLabel
          Left = 10
          Top = 90
          Width = 110
          Height = 12
          Caption = 'add agents per timestep:'
        end
        object Lbl_nrAgents: TLabel
          Left = 39
          Top = 40
          Width = 42
          Height = 12
          Alignment = taRightJustify
          Caption = 'nr agents'
        end
        object Label6: TLabel
          Left = 87
          Top = 40
          Width = 29
          Height = 12
          Caption = 'agents'
        end
        object E_startGrowWith: TEdit
          Left = 126
          Top = 60
          Width = 33
          Height = 20
          TabOrder = 0
          Text = '100'
          OnChange = Edit_anzAgChange
        end
        object E_growRate: TEdit
          Left = 126
          Top = 86
          Width = 33
          Height = 20
          TabOrder = 1
          Text = '10'
          OnChange = Edit_anzAgChange
        end
        object CB_actiGrow: TCheckBox
          Left = 25
          Top = 17
          Width = 56
          Height = 17
          Caption = 'activate'
          TabOrder = 2
        end
        object UpDown6: TUpDown
          Left = 159
          Top = 60
          Width = 16
          Height = 20
          Associate = E_startGrowWith
          Min = 1
          Max = 32000
          Increment = 10
          Position = 100
          TabOrder = 3
        end
        object UpDown7: TUpDown
          Left = 159
          Top = 86
          Width = 16
          Height = 20
          Associate = E_growRate
          Min = 1
          Max = 32000
          Increment = 5
          Position = 10
          TabOrder = 4
        end
      end
      object CB_showRentSc: TCheckBox
        Left = 3
        Top = 441
        Width = 97
        Height = 17
        Caption = 'show rent landscape'
        Checked = True
        State = cbChecked
        TabOrder = 2
      end
      object CB_showAgs: TCheckBox
        Left = 3
        Top = 418
        Width = 97
        Height = 17
        Caption = 'show agents'
        Checked = True
        State = cbChecked
        TabOrder = 3
      end
    end
    object TabSheet2: TTabSheet
      Caption = 'parameter'
      ImageIndex = 1
      object GroupBox2: TGroupBox
        Left = 3
        Top = 16
        Width = 191
        Height = 305
        Caption = 'tolerance settings'
        TabOrder = 0
        object Label8: TLabel
          Left = 16
          Top = 28
          Width = 49
          Height = 12
          Caption = 'threshold :'
        end
        object Lbl_P: TLabel
          Left = 71
          Top = 28
          Width = 15
          Height = 12
          Caption = '___'
        end
        object Label9: TLabel
          Left = 92
          Top = 28
          Width = 10
          Height = 12
          Caption = '%'
        end
        object TrB_thresh: TTrackBar
          Left = 3
          Top = 46
          Width = 158
          Height = 41
          Max = 100
          PageSize = 5
          Frequency = 10
          Position = 100
          TabOrder = 0
          OnChange = TrB_threshChange
        end
        object UpD_thresh: TUpDown
          Left = 155
          Top = 46
          Width = 17
          Height = 27
          TabOrder = 1
          OnClick = UpD_threshClick
        end
        object cb_individTol: TCheckBox
          Left = 12
          Top = 93
          Width = 163
          Height = 17
          Caption = 'activate individual thresholds'
          Checked = True
          State = cbChecked
          TabOrder = 2
        end
        object Button3: TButton
          Left = 12
          Top = 116
          Width = 157
          Height = 25
          Caption = 'show indivdual thresholds'
          TabOrder = 3
          OnClick = Button3Click
        end
        object GroupBox7: TGroupBox
          Left = 9
          Top = 147
          Width = 179
          Height = 142
          Caption = 'group thresholds'
          TabOrder = 4
          object Label23: TLabel
            Left = 11
            Top = 27
            Width = 67
            Height = 12
            Caption = 'to itself (basis):'
          end
          object Label24: TLabel
            Left = 11
            Top = 49
            Width = 101
            Height = 12
            Caption = 'to superior: distance *'
          end
          object Label25: TLabel
            Left = 11
            Top = 71
            Width = 102
            Height = 12
            Caption = 'to inferior  : distance *'
          end
          object Label26: TLabel
            Left = 11
            Top = 93
            Width = 44
            Height = 12
            Caption = 'to empty:'
          end
          object E_toItself: TEdit
            Left = 119
            Top = 23
            Width = 24
            Height = 20
            TabOrder = 0
            Text = '0'
            OnChange = Edit_cellSizChange
          end
          object UpD_toItself: TUpDown
            Left = 143
            Top = 23
            Width = 16
            Height = 20
            Associate = E_toItself
            TabOrder = 1
          end
          object E_toSuper: TEdit
            Left = 119
            Top = 45
            Width = 24
            Height = 20
            TabOrder = 2
            Text = '0'
            OnChange = Edit_cellSizChange
          end
          object UpD_toSuper: TUpDown
            Left = 143
            Top = 45
            Width = 16
            Height = 20
            Associate = E_toSuper
            Min = -100
            TabOrder = 3
          end
          object E_toInfer: TEdit
            Left = 119
            Top = 67
            Width = 24
            Height = 20
            TabOrder = 4
            Text = '-20'
            OnChange = Edit_cellSizChange
          end
          object UpD_toInfer: TUpDown
            Left = 143
            Top = 67
            Width = 16
            Height = 20
            Associate = E_toInfer
            Min = -100
            Position = -20
            TabOrder = 5
          end
          object E_toEmpty: TEdit
            Left = 119
            Top = 89
            Width = 24
            Height = 20
            TabOrder = 6
            Text = '0'
            OnChange = Edit_cellSizChange
          end
          object UpD_toEmpty: TUpDown
            Left = 143
            Top = 89
            Width = 16
            Height = 20
            Associate = E_toEmpty
            TabOrder = 7
          end
          object B_setTols: TButton
            Left = 12
            Top = 111
            Width = 71
            Height = 25
            Caption = 'set'
            TabOrder = 8
            OnClick = B_setTolsClick
          end
        end
      end
      object RadioGroup1: TRadioGroup
        Left = 3
        Top = 335
        Width = 191
        Height = 105
        Caption = 'handle free cells (deactivated individ.)'
        TabOrder = 1
      end
      object RB_count_no: TRadioButton
        Left = 16
        Top = 360
        Width = 137
        Height = 17
        Caption = 'do not count empty cells'
        Checked = True
        TabOrder = 2
        TabStop = True
      end
      object RB_count_diff: TRadioButton
        Left = 16
        Top = 383
        Width = 157
        Height = 17
        Caption = 'count empty cells as different'
        TabOrder = 3
      end
      object RB_count_simi: TRadioButton
        Left = 16
        Top = 406
        Width = 157
        Height = 17
        Caption = 'count empty cells as similar'
        TabOrder = 4
      end
    end
    object TabSheet3: TTabSheet
      Caption = 'analysis'
      ImageIndex = 2
      object Label7: TLabel
        Left = 130
        Top = 55
        Width = 55
        Height = 12
        Caption = ': cluster thr.'
      end
      object Label14: TLabel
        Left = 131
        Top = 83
        Width = 43
        Height = 12
        Caption = ': grid size'
      end
      object Button1: TButton
        Left = 3
        Top = 15
        Width = 75
        Height = 25
        Caption = 'show charts'
        TabOrder = 0
        OnClick = Button1Click
      end
      object B_cluster: TBitBtn
        Left = 3
        Top = 46
        Width = 75
        Height = 26
        Caption = 'cluster analysis'
        Font.Charset = DEFAULT_CHARSET
        Font.Color = clWindowText
        Font.Height = -10
        Font.Name = 'Tahoma'
        Font.Style = []
        ParentFont = False
        TabOrder = 1
        OnClick = B_clusterClick
      end
      object Button2: TButton
        Left = 3
        Top = 78
        Width = 75
        Height = 25
        Caption = 'dissimilar'
        TabOrder = 2
        OnClick = Button2Click
      end
      object E_clusterT: TEdit
        Left = 84
        Top = 51
        Width = 25
        Height = 20
        TabOrder = 3
        Text = '10'
      end
      object E_nbSize: TEdit
        Left = 84
        Top = 79
        Width = 25
        Height = 20
        TabOrder = 4
        Text = '20'
        OnChange = E_nbSizeChange
      end
      object ana_ps: TButton
        Left = 12
        Top = 142
        Width = 80
        Height = 25
        Caption = 'analyse ps'
        TabOrder = 5
        OnClick = ana_psClick
      end
      object ana_growth: TButton
        Left = 98
        Top = 142
        Width = 80
        Height = 25
        Caption = 'analyse growth'
        TabOrder = 6
        OnClick = ana_growthClick
      end
      object UpD_clS: TUpDown
        Left = 109
        Top = 51
        Width = 16
        Height = 20
        Associate = E_clusterT
        Min = 1
        Max = 10000
        Position = 10
        TabOrder = 7
      end
      object UpDown5: TUpDown
        Left = 109
        Top = 79
        Width = 16
        Height = 20
        Associate = E_nbSize
        Min = 1
        Max = 10000
        Position = 20
        TabOrder = 8
      end
      object B_anaStr: TButton
        Left = 98
        Top = 173
        Width = 80
        Height = 25
        Caption = 'analyse streets'
        TabOrder = 9
        OnClick = B_anaStrClick
      end
      object B_stabili: TButton
        Left = 12
        Top = 173
        Width = 80
        Height = 25
        Caption = 'analyse stability'
        TabOrder = 10
        OnClick = B_stabiliClick
      end
      object GroupBox6: TGroupBox
        Left = 3
        Top = 204
        Width = 191
        Height = 237
        Caption = 'save windows '
        TabOrder = 11
        DesignSize = (
          191
          237)
        object Label18: TLabel
          Left = 8
          Top = 159
          Width = 32
          Height = 12
          Caption = 'round:'
        end
        object Label20: TLabel
          Left = 63
          Top = 159
          Width = 84
          Height = 12
          Caption = 'examination name:'
        end
        object Label21: TLabel
          Left = 8
          Top = 203
          Width = 159
          Height = 12
          Caption = 'if you don'#39't change round or name'
        end
        object Label22: TLabel
          Left = 8
          Top = 217
          Width = 135
          Height = 12
          Caption = 'the old pictures will be deleted'
        end
        object cb_save_basic: TCheckBox
          Left = 8
          Top = 38
          Width = 173
          Height = 17
          Caption = 'basic process recording charts'
          TabOrder = 0
        end
        object cb_save_main: TCheckBox
          Left = 8
          Top = 21
          Width = 173
          Height = 17
          Caption = 'main window with cells and agents'
          Checked = True
          State = cbChecked
          TabOrder = 1
        end
        object cb_save_paraSp: TCheckBox
          Left = 8
          Top = 56
          Width = 173
          Height = 17
          Caption = 'parameterspace (ps) charts'
          TabOrder = 2
        end
        object cb_save_growth: TCheckBox
          Left = 8
          Top = 74
          Width = 173
          Height = 17
          Caption = 'analyse growth charts'
          TabOrder = 3
        end
        object cb_save_streets: TCheckBox
          Left = 8
          Top = 91
          Width = 173
          Height = 17
          Caption = 'analyse streets charts'
          TabOrder = 4
        end
        object cb_save_stability: TCheckBox
          Left = 8
          Top = 109
          Width = 173
          Height = 17
          Caption = 'analyse stability charts'
          Checked = True
          State = cbChecked
          TabOrder = 5
        end
        object E_sRound: TEdit
          Left = 8
          Top = 177
          Width = 49
          Height = 20
          Anchors = [akLeft, akBottom]
          BevelEdges = [beLeft, beBottom]
          BevelInner = bvLowered
          BiDiMode = bdLeftToRight
          ParentBiDiMode = False
          TabOrder = 6
          Text = '01'
        end
        object E_sName: TEdit
          Left = 63
          Top = 177
          Width = 114
          Height = 20
          Anchors = [akLeft, akBottom]
          BevelEdges = [beLeft, beBottom]
          BevelInner = bvLowered
          BiDiMode = bdLeftToRight
          ParentBiDiMode = False
          TabOrder = 7
          Text = 'please enter name'
        end
        object cb_save_3DSurf: TCheckBox
          Left = 26
          Top = 125
          Width = 114
          Height = 17
          Caption = '3D stability surface'
          Checked = True
          State = cbChecked
          TabOrder = 8
        end
      end
    end
    object TabSheet4: TTabSheet
      Caption = 'streets'
      ImageIndex = 3
      ExplicitLeft = 0
      ExplicitTop = 0
      ExplicitWidth = 0
      ExplicitHeight = 0
      object colCode1: TLabel
        Left = 151
        Top = 112
        Width = 21
        Height = 12
        Caption = '       '
        Color = clWhite
        Font.Charset = DEFAULT_CHARSET
        Font.Color = clMaroon
        Font.Height = -10
        Font.Name = 'Tahoma'
        Font.Style = []
        ParentColor = False
        ParentFont = False
      end
      object colCode2: TLabel
        Left = 151
        Top = 133
        Width = 21
        Height = 12
        Caption = '       '
        Color = clWhite
        Font.Charset = DEFAULT_CHARSET
        Font.Color = clMaroon
        Font.Height = -10
        Font.Name = 'Tahoma'
        Font.Style = []
        ParentColor = False
        ParentFont = False
      end
      object colCode3: TLabel
        Left = 151
        Top = 154
        Width = 21
        Height = 12
        Caption = '       '
        Color = clWhite
        Font.Charset = DEFAULT_CHARSET
        Font.Color = clMaroon
        Font.Height = -10
        Font.Name = 'Tahoma'
        Font.Style = []
        ParentColor = False
        ParentFont = False
      end
      object colCode4: TLabel
        Left = 151
        Top = 176
        Width = 21
        Height = 12
        Caption = '       '
        Color = clWhite
        Font.Charset = DEFAULT_CHARSET
        Font.Color = clMaroon
        Font.Height = -10
        Font.Name = 'Tahoma'
        Font.Style = []
        ParentColor = False
        ParentFont = False
      end
      object colCode5: TLabel
        Left = 151
        Top = 197
        Width = 21
        Height = 12
        Caption = '       '
        Color = clWhite
        Font.Charset = DEFAULT_CHARSET
        Font.Color = clMaroon
        Font.Height = -10
        Font.Name = 'Tahoma'
        Font.Style = []
        ParentColor = False
        ParentFont = False
      end
      object colCode6: TLabel
        Left = 151
        Top = 218
        Width = 21
        Height = 12
        Caption = '       '
        Color = clWhite
        Font.Charset = DEFAULT_CHARSET
        Font.Color = clMaroon
        Font.Height = -10
        Font.Name = 'Tahoma'
        Font.Style = []
        ParentColor = False
        ParentFont = False
      end
      object colCode7: TLabel
        Left = 151
        Top = 240
        Width = 21
        Height = 12
        Caption = '       '
        Color = clWhite
        Font.Charset = DEFAULT_CHARSET
        Font.Color = clMaroon
        Font.Height = -10
        Font.Name = 'Tahoma'
        Font.Style = []
        ParentColor = False
        ParentFont = False
      end
      object b_delStr: TButton
        Left = 3
        Top = 423
        Width = 75
        Height = 25
        Caption = 'delete streets'
        TabOrder = 0
        OnClick = b_delStrClick
      end
      object GroupBox4: TGroupBox
        Left = 3
        Top = 3
        Width = 191
        Height = 54
        Caption = 'draw streets'
        TabOrder = 1
        object CB_strType: TComboBox
          Left = 11
          Top = 24
          Width = 158
          Height = 20
          ItemHeight = 0
          TabOrder = 0
          Text = ' choose street type'
        end
      end
      object SG_weight: TStringGrid
        Left = 16
        Top = 86
        Width = 129
        Height = 173
        BevelEdges = [beRight, beBottom]
        BevelInner = bvSpace
        BevelOuter = bvSpace
        BiDiMode = bdLeftToRight
        ColCount = 2
        DefaultColWidth = 60
        DefaultRowHeight = 20
        RowCount = 8
        Font.Charset = DEFAULT_CHARSET
        Font.Color = clWindowText
        Font.Height = -11
        Font.Name = 'Tahoma'
        Font.Orientation = 1
        Font.Style = []
        Options = [goFixedVertLine, goFixedHorzLine, goVertLine, goHorzLine, goRangeSelect, goEditing]
        ParentBiDiMode = False
        ParentFont = False
        ScrollBars = ssNone
        TabOrder = 2
        RowHeights = (
          20
          20
          20
          20
          20
          20
          20
          20)
      end
      object GroupBox5: TGroupBox
        Left = 3
        Top = 265
        Width = 191
        Height = 152
        Caption = 'predefined layouts'
        TabOrder = 3
        object Label13: TLabel
          Left = 119
          Top = 23
          Width = 29
          Height = 12
          Caption = ': rows'
        end
        object Label15: TLabel
          Left = 119
          Top = 109
          Width = 54
          Height = 12
          Caption = ': street type'
        end
        object Label16: TLabel
          Left = 119
          Top = 77
          Width = 35
          Height = 12
          Caption = ': streets'
        end
        object Label17: TLabel
          Left = 119
          Top = 49
          Width = 44
          Height = 12
          Caption = ': columns'
        end
        object B_randStr: TButton
          Left = 11
          Top = 71
          Width = 56
          Height = 24
          Caption = 'random'
          TabOrder = 0
          OnClick = B_randStrClick
        end
        object B_drawGrid: TButton
          Left = 11
          Top = 20
          Width = 56
          Height = 45
          Caption = 'draw grid'
          TabOrder = 1
          OnClick = B_drawGridClick
        end
        object Ed_rows: TEdit
          Left = 73
          Top = 19
          Width = 25
          Height = 20
          TabOrder = 2
          Text = '5'
        end
        object UpD_rows: TUpDown
          Left = 98
          Top = 19
          Width = 16
          Height = 20
          Associate = Ed_rows
          Min = 1
          Max = 10000
          Position = 5
          TabOrder = 3
        end
        object Ed_strType: TEdit
          Left = 73
          Top = 105
          Width = 25
          Height = 20
          TabOrder = 4
          Text = '3'
        end
        object UpD_strType: TUpDown
          Left = 98
          Top = 105
          Width = 16
          Height = 20
          Associate = Ed_strType
          Min = -3
          Max = 3
          Position = 3
          TabOrder = 5
        end
        object Ed_nrStr: TEdit
          Left = 73
          Top = 73
          Width = 25
          Height = 20
          TabOrder = 6
          Text = '20'
        end
        object UpD_nrStr: TUpDown
          Left = 98
          Top = 73
          Width = 16
          Height = 20
          Associate = Ed_nrStr
          Min = 1
          Max = 10000
          Increment = 5
          Position = 20
          TabOrder = 7
        end
        object Ed_cols: TEdit
          Left = 73
          Top = 45
          Width = 25
          Height = 20
          TabOrder = 8
          Text = '5'
        end
        object UpD_cols: TUpDown
          Left = 98
          Top = 45
          Width = 16
          Height = 20
          Associate = Ed_cols
          Min = 1
          Max = 10000
          Position = 5
          TabOrder = 9
        end
        object CB_rndTyp: TCheckBox
          Left = 72
          Top = 127
          Width = 116
          Height = 17
          Caption = 'random street types'
          Checked = True
          State = cbChecked
          TabOrder = 10
        end
      end
      object CB_hideAgs: TCheckBox
        Left = 16
        Top = 63
        Width = 129
        Height = 17
        Caption = 'draw without agents'
        Checked = True
        State = cbChecked
        TabOrder = 4
      end
      object B_imprint: TButton
        Left = 144
        Top = 423
        Width = 50
        Height = 25
        Caption = 'imprint'
        TabOrder = 5
        OnClick = B_imprintClick
      end
    end
    object TabSheet5: TTabSheet
      Caption = 'rent'
      ImageIndex = 4
      object GroupBox8: TGroupBox
        Left = 19
        Top = 127
        Width = 158
        Height = 254
        Caption = 'changes by moves'
        TabOrder = 0
      end
      object cb_actiRentLand: TCheckBox
        Left = 24
        Top = 9
        Width = 141
        Height = 17
        Caption = 'activate rent landscape'
        Checked = True
        State = cbChecked
        TabOrder = 1
      end
      object GroupBox9: TGroupBox
        Left = 19
        Top = 32
        Width = 157
        Height = 89
        Caption = 'basic settings'
        TabOrder = 2
        object Label28: TLabel
          Left = 32
          Top = 20
          Width = 41
          Height = 12
          Caption = 'min rent:'
        end
        object Label29: TLabel
          Left = 32
          Top = 46
          Width = 43
          Height = 12
          Caption = 'max rent:'
        end
        object Label30: TLabel
          Left = 10
          Top = 68
          Width = 65
          Height = 12
          Caption = 'budget range:'
        end
        object lbl_budgetR: TLabel
          Left = 81
          Top = 68
          Width = 20
          Height = 12
          Caption = '____'
        end
        object E_rentMin: TEdit
          Left = 80
          Top = 16
          Width = 41
          Height = 20
          TabOrder = 0
          Text = '-1,00'
        end
        object E_rentMax: TEdit
          Left = 80
          Top = 42
          Width = 41
          Height = 20
          TabOrder = 1
          Text = '+1,00'
        end
      end
    end
  end
  object B_setup: TButton
    Left = 812
    Top = 551
    Width = 74
    Height = 25
    Caption = 'new Setup'
    TabOrder = 2
    OnClick = B_setupClick
  end
  object B_repaint: TButton
    Left = 724
    Top = 590
    Width = 82
    Height = 25
    Caption = 'repaint all'
    TabOrder = 3
    OnClick = B_repaintClick
  end
  object E_stopT: TEdit
    Left = 788
    Top = 677
    Width = 41
    Height = 20
    TabOrder = 4
    Text = '500'
    OnChange = E_stopTChange
  end
  object B_stop: TBitBtn
    Left = 724
    Top = 551
    Width = 82
    Height = 25
    Caption = 'start / stop'
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clGreen
    Font.Height = -10
    Font.Name = 'Tahoma'
    Font.Style = []
    ParentFont = False
    TabOrder = 5
    OnClick = B_stopClick
  end
  object Timer1: TTimer
    Interval = 1
    OnTimer = Timer1Timer
    Left = 720
    Top = 672
  end
end

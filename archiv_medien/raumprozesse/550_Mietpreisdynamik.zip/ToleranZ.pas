unit ToleranZ;

interface

uses
  Windows, Messages, SysUtils, Variants, Classes, Graphics, Controls, Forms, math,
  Dialogs, TeEngine, Series, ExtCtrls, TeeProcs, Chart, TeeDragPoint, StdCtrls;

type
  TForm8 = class(TForm)
    procedure FormClose(Sender: TObject; var Action: TCloseAction);
    procedure FormShow(Sender: TObject);
  private
    procedure DragPointEvent(Sender:TDragPointTool; Index:Integer);
    procedure DragMouseUp(Sender: TObject; Button: TMouseButton; Shift: TShiftState; X, Y: Integer);
  public
    procedure setTolGroup;
    procedure setValues;
  end;

var
  Form8    : TForm8;
  tolChart : Array of TChart;
  tolSer   : Array of TPointSeries;
  DragPoint: Array of TDragPointTool;

implementation

{$R *.dfm}
uses CellForm;

// *****************************************************************************
procedure TForm8.setTolGroup;
var
  I, K : Integer;
begin
  for I := 0 to ngGroups do
  begin
    for K := 0 to ngGroups-1 do
    begin
      If Form1.cb_individTol.Checked Then
      begin
        tolGroup[K,I] := nbSize - round((tolSer[K+1].YValues[I]/100)*nbSize);
      end;
    end;
  end;
end;

// *****************************************************************************
procedure TForm8.FormClose(Sender: TObject; var Action: TCloseAction);
var I : Integer;
begin
  For I := 1 To length(DragPoint) Do
  begin
    DragPoint[I].Free;
    tolSer[I].Free;
    tolChart[I].Free;
  end;
  SetLength (tolChart, 0);
  SetLength (tolSer, 0);
  SetLength (DragPoint, 0);
end;

procedure TForm8.DragMouseUp(Sender: TObject; Button: TMouseButton; Shift: TShiftState; X, Y: Integer);
begin
  setTolGroup;
end;

// *****************************************************************************
procedure TForm8.FormShow(Sender: TObject);
var I, K: Integer;
    links, oben : Integer;
    counter : Integer;
begin
  SetLength (tolChart, ngGroups);
  SetLength (tolSer, ngGroups);
  SetLength (DragPoint, ngGroups);
  links  := 5;
  oben   := 5;
  counter:= 0;
  For I := 1 To ngGroups Do
  begin
    IF counter >= 3 Then
    begin
      oben   := oben + 255;
      counter:= 0;
      links  := 5;
    end;
    inc (counter);
    // -- Create the Chart --------------
    tolChart[I] := TChart.Create(self);
    tolChart[I].Legend.Visible:= False;
    tolChart[I].Parent        := Form8;
    tolChart[I].Height        := 250;
    tolChart[I].Width         := 300;
    tolChart[I].Left          := links;
    tolChart[I].Top           := oben;
    tolChart[I].View3D        := False;
    tolChart[I].BackColor     := ClWhite;
    tolChart[I].Color         := ClWhite;
    tolChart[I].Title.Font.Color  := farbList[I-1];
    tolChart[I].Title.Caption     := 'Group'+IntToStr(I);
    tolChart[I].Name              := 'Chart'+IntToStr(I);
    tolChart[I].Border.visible    := true;
    tolChart[I].Border.Color      := clBlack;
    tolChart[I].LeftAxis.Automatic:= False;
    tolChart[I].LeftAxis.Maximum  := 100;
    tolChart[I].LeftAxis.Minimum  := 0;
    tolChart[I].LeftAxis.Increment:= 1;
    tolChart[I].BottomAxis.Title.Caption := 'to Group';
    tolChart[I].OnMouseUp :=  DragMouseUp;
    // -- Create the Series -------------
    tolSer[I] := TPointSeries.Create(self);                                   // -- Create first Series
    tolSer[I].Clear;                                                          // -- Clear it
    tolSer[I].Pointer.HorizSize := 5;
    tolSer[I].Pointer.VertSize  := 14;
    tolSer[I].ParentChart       := tolChart[I];                               // -- determine the chart, this series belongs to
    tolSer[I].VertAxis          := aLeftAxis;
    tolSer[I].Color             := farbList[I-1];
    tolSer[I].Cursor            := crTeeHand;
    tolSer[I].Marks.Visible     := True;
    tolSer[I].Marks.ArrowLength := -7;
    // -- Create Darag Tool -------------
    DragPoint[I]:=TDragPointTool.Create(Self);
    DragPoint[I].ParentChart :=tolChart[I];
    DragPoint[I].Series      :=tolSer[I];
    DragPoint[I].DragStyle   :=dsY;
    DragPoint[I].Active      := True;
    DragPoint[I].OnDragPoint :=DragPointEvent;
    links := links + 305;
    // -- add the values --
    For K := 1 To ngGroups Do
    begin
      tolSer[I].AddXY(K, 0)
    end;
    tolSer[I].AddXY(0, 0);                                                    // -- Tolerance to empty cells
  end;
  setValues;
  Form8.Width  := 3*305 + 10;
  Form8.Height := oben + 290;
end;

// *****************************************************************************
procedure TForm8.setValues;
var I, K, diff : Integer;
begin
  For I := 1 To ngGroups Do
  begin
    For K := 1 To ngGroups Do
    begin
    //diff := 3 -abs(I-K);        // -- version 1
      diff := (I-K);              // -- version 2
      If diff > 0 Then begin
        diff := Form1.UpD_toItself.Position - diff * Form1.UpD_toInfer.Position;
      end else begin
        If diff <= 0 Then diff := Form1.UpD_toItself.Position + diff * Form1.UpD_toSuper.Position;
      end;
      If diff > 100 Then diff := 100;
      If diff < 0 Then diff := 0;
      tolSer[I].YValues[K] := diff;
    end;
    tolSer[I].YValues[0] := Form1.UpD_toEmpty.Position;
    tolSer[I].Repaint;
  end;
  setTolGroup;
end;

// *****************************************************************************
procedure TForm8.DragPointEvent(Sender:TDragPointTool; Index:Integer);
var I, K : Integer;
begin
  For I := 1 To ngGroups Do
  begin
    For K := 0 To ngGroups Do
    begin
      tolSer[I].YValues[K] := round(tolSer[I].YValues[K]);
      If tolSer[I].YValues[K] > 100  then tolSer[I].YValues[K] := 100;
      If tolSer[I].YValues[K] < 0 then tolSer[I].YValues[K] := 0;
    end;
  tolSer[I].Repaint;  { repaint the grid to show the new values... }
  end;
end;

end.

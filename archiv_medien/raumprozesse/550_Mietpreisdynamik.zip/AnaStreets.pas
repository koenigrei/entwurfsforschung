unit AnaStreets;

interface

uses
  Windows, Messages, SysUtils, Variants, Classes, Graphics, Controls, Forms,
  Dialogs, ExtCtrls, StdCtrls, TeEngine, TeeTools, TeePageNumTool, Series, Math,
  TeeProcs, Chart, CurvFitt;

type
  TForm5 = class(TForm)
    Chart_Streets   : TChart;
    Series_street   : TPointSeries;
    PageNumTool1    : TPageNumTool;
    GroupBox1       : TGroupBox;
    Label1          : TLabel;
    Label2          : TLabel;
    Label3          : TLabel;
    Label4          : TLabel;
    Label5          : TLabel;
    E_valFrom       : TEdit;
    E_valTo         : TEdit;
    E_toSteps       : TEdit;
    E_calcVals      : TEdit;
    S_start         : TButton;
    S_break         : TButton;
    E_incre         : TEdit;
    lbl_pSteps      : TLabel;
    lbl_timesteps   : TLabel;
    Label8          : TLabel;
    Lbl_akt         : TLabel;
    Lbl_proceed     : TLabel;
    B_undoZ         : TButton;
    Timer4          : TTimer;
    Label6          : TLabel;
    RadioGroup1     : TRadioGroup;
    RB_grid         : TRadioButton;
    RB_rnd          : TRadioButton;
    Series_strTrend : TLineSeries;
    TeeFunction1    : TTrendFunction;
    procedure S_breakClick(Sender: TObject);
    procedure S_startClick(Sender: TObject);
    procedure Timer4Timer(Sender: TObject);
    procedure E_valFromChange(Sender: TObject);
    procedure FormCreate(Sender: TObject);
    procedure B_undoZClick(Sender: TObject);
  private
    procedure resetGraphs;
    procedure updProc;
    procedure newRound(aktVal: Integer);
  public
    { Public declarations }
  end;

var
  Form5: TForm5;
  pSteps  : Integer;
  rounds  : Cardinal;
  aktVal  : Integer;
  toCalc  : Cardinal;

implementation

{$R *.dfm}
uses CellForm, Analyse;

procedure TForm5.FormCreate(Sender: TObject);
begin
  Timer4.enabled := false;
  lbl_pSteps.Caption := '0';
  pSteps := 0;
  Steps  := 0;
  toCalc := 0;
  Lbl_akt.Caption := IntToStr(toCalc);
  updProc;
end;

procedure TForm5.S_breakClick(Sender: TObject);
begin
  Timer4.enabled := not(Timer4.enabled);
end;

procedure TForm5.resetGraphs;
begin
  Series_street.clear;
end;

procedure TForm5.Timer4Timer(Sender: TObject);
begin
  If pSteps >= StrToInt(E_toSteps.Text) Then                                  // -- timesteps per value
  begin
    Form1.startCAna;
    Series_Street.AddXY(StrToInt(Form1.Lbl_strCell.Caption), tmpBarSeries.XValues.Count);// -- all clusters over threshold from the barSeries
    inc(rounds);
    inc(toCalc);
    {inc(subrds);
    If subrds = StrToInt(E_calcVals.Text) Then
    begin
      plotVals;
      inc(mesrds);
      For I := 0 To high(growSer) Do                                          // -- delete the temporary series
      begin
        growSer[I].Clear;
        colSer[I].Clear;
      end;
      subrds := 0;
    end; }
    //
    Lbl_akt.Caption := IntToStr(toCalc);
    If rounds > StrToInt(E_calcVals.Text) Then                                // -- calculations per value
    begin
      aktVal := aktVal + StrToInt(E_incre.Text);                              // -- raise aktual value by increment
      Series_strTrend.CheckDataSource;
      If aktVal > StrToInt(E_valTo.Text) Then                                 // -- iterate the range from start value to end value
      begin
        //Form1.startCAna;
        Timer4.enabled := false;
        exit;
      end;
      rounds := 1;
    end;
    pSteps := 0;
    newRound(aktVal);
  end;
  Form1.actions;
  lbl_pSteps.Caption := IntToStr (pSteps);
  inc(pSteps);
end;

procedure TForm5.S_startClick(Sender: TObject);
begin
  pSteps := 0;
  Steps  := 0;
  rounds := 1;
  toCalc := 0;
  resetGraphs;
  Lbl_akt.Caption := IntToStr(toCalc);
  aktVal := StrToInt(E_valFrom.Text);
  Form1.E_stopT.Text := E_toSteps.Text;
  newRound(aktVal);
  Timer4.Enabled := true;
end;

procedure TForm5.B_undoZClick(Sender: TObject);
begin
  Chart_Streets.UndoZoom;
end;

procedure TForm5.E_valFromChange(Sender: TObject);
begin
  updProc;
end;

procedure TForm5.newRound(aktVal: Integer);
begin
  Form1.deleteStreets;
  If RB_grid.Checked Then begin                                               // -- change the values at Form1
    Form1.UpD_rows.Position := aktVal;
    Form1.UpD_cols.Position := aktVal;
    Form1.rasterStreets;
  end;
  IF RB_rnd.Checked Then begin
    Form1.UpD_nrStr.Position := aktVal;
    Form1.randStreets;
  end;
  Form1.deleter;
end;

procedure TForm5.updProc;
begin
  Lbl_proceed.Caption := '/ ' + IntToStr( Ceil((StrToInt(E_valTo.Text) - StrToInt(E_valFrom.Text)+1)/
                         StrToInt(E_incre.Text)) * StrToInt(E_calcVals.Text));
end;

end.

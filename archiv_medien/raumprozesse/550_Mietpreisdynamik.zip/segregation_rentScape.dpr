program segregation_rentScape;

uses
  Forms,
  CellForm in 'CellForm.pas' {Form1},
  cell_P in 'cell_P.pas',
  agenten in 'agenten.pas',
  Analyse in 'Analyse.pas' {Form2},
  Parameterspace in 'Parameterspace.pas' {Form3},
  AnalyseGrowth in 'AnalyseGrowth.pas' {Form4},
  AnaStreets in 'AnaStreets.pas' {Form5},
  AnaStability in 'AnaStability.pas' {Form6},
  AnaLandsc3D in 'AnaLandsc3D.pas' {Form7},
  ToleranZ in 'ToleranZ.pas' {Form8},
  GroupSizes in 'GroupSizes.pas' {Form9};

{$R *.res}

begin
  Application.Initialize;
  Application.CreateForm(TForm1, Form1);
  Application.CreateForm(TForm2, Form2);
  Application.CreateForm(TForm3, Form3);
  Application.CreateForm(TForm4, Form4);
  Application.CreateForm(TForm5, Form5);
  Application.CreateForm(TForm6, Form6);
  Application.CreateForm(TForm7, Form7);
  Application.CreateForm(TForm8, Form8);
  Application.CreateForm(TForm9, Form9);
  Application.Run;
end.

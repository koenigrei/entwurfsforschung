(********************************************************************)
(*                                                                  *) 
(*                                                                  *)
(*                      Segregation - Streets                       *)
(*                          Version 1.0                             *)
(*                                                                  *)
(*                                                                  *)
(*     Programmierer: Reinhard K�nig                   Oktober 2006 *)
(*                    http://www.entwurfsforschung.de               *)
(*                                                                  *)
(*     Last Update: Okt-20, 2006                                    *)
(*                                                                  *)
(********************************************************************) 
{revision history:

1.0     [Okt-20, 2006]
        paint the streets in the grig
        and examine different effects of these streets
}

unit CellForm;

interface

uses
  Windows, Messages, SysUtils, Classes, Graphics, Controls, Forms, ValEdit, jpeg, TeeStore,
  Dialogs, StdCtrls, cell_P, Math, agenten, ExtCtrls, ComCtrls, Buttons, Grids;

type
  TDreierArray = Array of Array of Array of Cardinal;
type
  nachbarArray = Array[0..3]of TPoint;
type
  TLine = Record
    startP : TPoint;
    endP   : TPoint;
    lType  : Integer;
  end;

type
  TForm1 = class(TForm)
    ZeichenPanel      : TPanel;
    Timer1            : TTimer;
    PageControl1      : TPageControl;
    TabSheet1         : TTabSheet;
    GroupBox1         : TGroupBox;
    Lbl_TextAnzahl    : TLabel;
    Label2            : TLabel;
    Label3            : TLabel;
    Label1            : TLabel;
    Label4            : TLabel;
    Edit_anzAg        : TEdit;
    Edit_cellSiz      : TEdit;
    Edit_anzGr        : TEdit;
    Edit_nRad         : TEdit;
    Edit_mDist        : TEdit;
    CB_graphicUpd     : TCheckBox;
    TabSheet2         : TTabSheet;
    GroupBox2         : TGroupBox;
    Label8            : TLabel;
    Lbl_P             : TLabel;
    Label9            : TLabel;
    TrB_thresh        : TTrackBar;
    TabSheet3         : TTabSheet;
    Button1           : TButton;
    B_cluster         : TBitBtn;
    Button2           : TButton;
    Label7            : TLabel;
    E_clusterT        : TEdit;
    E_nbSize          : TEdit;
    GroupBox3         : TGroupBox;
    Label11           : TLabel;
    Label12           : TLabel;
    Lbl_nrAgents      : TLabel;
    E_startGrowWith   : TEdit;
    E_growRate        : TEdit;
    CB_actiGrow       : TCheckBox;
    ana_ps            : TButton;
    ana_growth        : TButton;
    Label6            : TLabel;
    TabSheet4         : TTabSheet;
    b_delStr          : TButton;
    lbl_Steps         : TLabel;
    lbl_timesteps     : TLabel;
    GroupBox4         : TGroupBox;
    CB_strType        : TComboBox;
    UpD_moveDist      : TUpDown;
    UpD_radNb         : TUpDown;
    UpD_nrGroups      : TUpDown;
    UpD_sellSz        : TUpDown;
    SG_weight         : TStringGrid;
    GroupBox5         : TGroupBox;
    colCode1          : TLabel;
    RadioGroup1       : TRadioGroup;
    RB_count_no       : TRadioButton;
    RB_count_diff     : TRadioButton;
    RB_count_simi     : TRadioButton;
    CB_hideAgs        : TCheckBox;
    B_setup           : TButton;
    Label14           : TLabel;
    UpD_clS           : TUpDown;
    UpDown5           : TUpDown;
    colCode2          : TLabel;
    colCode3          : TLabel;
    colCode4          : TLabel;
    colCode5          : TLabel;
    colCode6          : TLabel;
    colCode7          : TLabel;
    B_repaint         : TButton;
    UpDown6           : TUpDown;
    UpDown7           : TUpDown;
    E_stopT           : TEdit;
    Label5            : TLabel;
    B_stop            : TBitBtn;
    B_randStr         : TButton;
    B_drawGrid        : TButton;
    Ed_rows           : TEdit;
    UpD_rows          : TUpDown;
    Label13           : TLabel;
    Ed_strType        : TEdit;
    UpD_strType       : TUpDown;
    Label15           : TLabel;
    Ed_nrStr          : TEdit;
    UpD_nrStr         : TUpDown;
    Label16           : TLabel;
    Ed_cols           : TEdit;
    UpD_cols          : TUpDown;
    Label17           : TLabel;
    Lbl_cellS         : TLabel;
    Label10           : TLabel;
    Lbl_strCell       : TLabel;
    Label19           : TLabel;
    B_imprint         : TButton;
    CB_strOcc         : TCheckBox;
    B_anaStr          : TButton;
    CB_rndTyp         : TCheckBox;
    UpD_thresh        : TUpDown;
    B_stabili         : TButton;
    GroupBox6         : TGroupBox;
    cb_save_basic     : TCheckBox;
    cb_save_main      : TCheckBox;
    cb_save_paraSp    : TCheckBox;
    cb_save_growth    : TCheckBox;
    cb_save_streets   : TCheckBox;
    cb_save_stability : TCheckBox;
    E_sRound          : TEdit;
    E_sName           : TEdit;
    Label18           : TLabel;
    Label20           : TLabel;
    cb_save_3DSurf    : TCheckBox;
    Label21           : TLabel;
    Label22           : TLabel;
    cb_individTol     : TCheckBox;
    Button3           : TButton;
    GroupBox7         : TGroupBox;
    Label23           : TLabel;
    Label24           : TLabel;
    Label25           : TLabel;
    Label26           : TLabel;
    E_toItself        : TEdit;
    UpD_toItself      : TUpDown;
    E_toSuper         : TEdit;
    UpD_toSuper       : TUpDown;
    E_toInfer         : TEdit;
    UpD_toInfer       : TUpDown;
    E_toEmpty         : TEdit;
    UpD_toEmpty       : TUpDown;
    B_setTols         : TButton;
    B_adjGroupSz      : TButton;
    TabSheet5         : TTabSheet;
    cb_indiGroups     : TCheckBox;
    Edit_agentSize    : TEdit;
    UpD_agentSz       : TUpDown;
    Label27           : TLabel;
    GroupBox8: TGroupBox;
    cb_actiRentLand: TCheckBox;
    GroupBox9: TGroupBox;
    Label28: TLabel;
    Label29: TLabel;
    Label30: TLabel;
    lbl_budgetR: TLabel;
    E_rentMin: TEdit;
    E_rentMax: TEdit;
    CB_showRentSc: TCheckBox;
    CB_showAgs: TCheckBox;
    procedure B_stopClick          (Sender: TObject);
    procedure B_setupClick         (Sender: TObject);
    procedure Timer1Timer          (Sender: TObject);
    procedure FormDestroy          (Sender: TObject);
    procedure FormCreate           (Sender: TObject);
    procedure Edit_anzAgChange     (Sender: TObject);
    procedure Edit_nRadChange      (Sender: TObject);
    procedure Edit_mDistChange     (Sender: TObject);
    procedure B_clusterClick       (Sender: TObject);
    procedure Button1Click         (Sender: TObject);
    procedure Button2Click         (Sender: TObject);
    procedure E_nbSizeChange       (Sender: TObject);
    procedure E_stopTChange        (Sender: TObject);
    procedure Edit_anzGrChange     (Sender: TObject);
    procedure Edit_cellSizChange   (Sender: TObject);
    procedure ana_psClick          (Sender: TObject);
    procedure B_repaintClick       (Sender: TObject);
    procedure TrB_threshChange     (Sender: TObject);
    procedure ana_growthClick      (Sender: TObject);
    procedure ZeichenPanelMouseDown(Sender: TObject; Button: TMouseButton; Shift: TShiftState; X, Y: Integer);
    procedure ZeichenPanelMouseMove(Sender: TObject; Shift: TShiftState; X, Y: Integer);
    procedure ZeichenPanelMouseUp  (Sender: TObject; Button: TMouseButton; Shift: TShiftState; X, Y: Integer);
    procedure b_delStrClick        (Sender: TObject);
    procedure B_repaintAllClick    (Sender: TObject);
    procedure B_drawGridClick      (Sender: TObject);
    procedure B_randStrClick       (Sender: TObject);
    procedure B_imprintClick       (Sender: TObject);
    procedure B_anaStrClick        (Sender: TObject);
    procedure UpD_threshClick      (Sender: TObject; Button: TUDBtnType);
    procedure B_stabiliClick       (Sender: TObject);
    procedure Button3Click         (Sender: TObject);
    procedure FormShow             (Sender: TObject);
    procedure B_setTolsClick       (Sender: TObject);
    procedure B_adjGroupSzClick    (Sender: TObject);
    procedure UpD_agentSzClick(Sender: TObject; Button: TUDBtnType);
  private
    cellList  : Array of Array of TCell;
    limboWorld: Array of Array of Real;
    streetList: Array of Array of Integer;
    lineList  : Array of TLine;
    procedure checkNei      (K, I: Integer);
    procedure torus         (var Xp: Integer; var Yp: Integer);
    function  wrap          (var Xp: Integer; var Yp: Integer):Boolean;
    procedure testLocation  (K, I: Integer; var similar : Double);
    procedure moveAgent     (oldPos: TPoint; newPos: TPoint; curAgent: TAgent);
    procedure chooseCol     (anzahl:integer; var farbListe: colList);
    procedure createPaintImg;
    procedure createRaster;
    procedure createAgents;
    procedure setupCells;
    procedure setupAgents (I: Integer);
    procedure calcAgents;
    procedure repaintAgents;
    procedure repaintCells;
    procedure checkMoore  (K, I: Integer);
    procedure findCluster (K, I : Integer; clustNr :Integer);
    procedure resetCluster;
    procedure speedMeasure;
    procedure calcChart;
    procedure countInTiles;
    procedure IDissimilar (ctInTiles: TDreierArray; tiles: Cardinal);
    procedure growth;
    procedure neumNb      (K, I: Integer; var nbDirect: nachbarArray);
    procedure transLine   (p1X, p1Y, strType: Integer);
    procedure setStreetList;
    procedure preserveStreets;
    procedure lookForStreets;
    procedure checkStreets   (K, I: Integer);
    procedure tempPaintImg;
    procedure setupFields    (Sender: TObject);
    function  testLines      (AX1,AY1,AX2,AY2: Integer):Real;
    procedure setStreetPara  (stPos, taPos: TPoint; strType: Integer);
    function  Intersect      (const A1, A2, B1, B2: TPoint): Boolean;
    Procedure BmpToJpg       (const Filename: String; Quality: TJPEGQualityRange=100);
    procedure saveXLS        (step: String);
    procedure diffuseCheckNei(K, I : Integer);
    procedure diffuseField;
    procedure diffuseIn (curCell: TCell);
    procedure rentGroupsCreate;
  public
    AgentList : TList;
    procedure startCAna;
    procedure actions;
    procedure Setup;
    procedure deleter;
    procedure randStreets;
    procedure rasterStreets;
    procedure deleteStreets;
    procedure saveBmp       (step: String);
end;

var
  Form1    : TForm1;
  paintImg : TImage;
  tempImg  : TImage;
  cellScal : Integer;                     //-- Zellen  gr��e
  AgSize   : Integer;                     //-- Agenten gr��e
  halfScal : Integer;
  reih     : Integer;                     //-- Zellen-Reihen gesamt
  spalt    : Integer;                     //-- Zellen-Spalten gesamt
  steps    : Cardinal;
  nbRad    : Integer;
  moveDist : Integer;
  stopT    : Cardinal;                    // -- stop Time-step
  nbS      : Cardinal;                    // -- tile size for the segregation index
  farbList : colList;                     // -- the agent's colors
  ngGroups : Integer;                     // -- number of Groups
  Frames, StartTick : Cardinal;           // -- for the fps measure
  clustCount: Array of Array of Integer;  // -- count the members of each cluster
  groupSz   : Array of Integer;           // -- number of agents in each group (color)
  tolGroup  : Array of Array of Integer;  // -- the tolerance-values from each group to each other
  grapUpd   : Boolean;
  satiThr   : Cardinal;
  posChange : Cardinal;                   // -- how many agents change their position in each step
  targetCell: TCell;
  startCell : TCell;
  targWink  : Double;                     // -- richtungsvektor f�r linien�bertragung in grid
  lDown     : Boolean;                    // -- if the mousebuttons are pressed
  newLines  : Boolean;
  nbSize    : Integer;                    // -- number of cells in the neighbourhood
  XagSum    : Integer;                    // -- created agents;
  Xround    : Integer;
  E_Rents   : Array of TEdit;
  lbl_Rents   : Array of TLabel;
implementation

{$R *.dfm}
uses Analyse, Parameterspace, AnalyseGrowth, AnaStreets, AnaStability,
     AnaLandsc3D, ToleranZ, GroupSizes;

//var

//------------------------------------------------------------------------------
// *** Initialisierung *********************************************************
procedure TForm1.FormCreate(Sender: TObject);
begin
  AgSize    := 2;//Floor (cellScal/2)-1;                                          // -- Agenten gr��e
  setupFields(Sender);
  setup;
  setStreetList;
  UpD_agentSz.Position := AgSize;
end;
procedure TForm1.FormShow(Sender: TObject);
begin
  If Form1.cb_individTol.Checked Then Form8.show;
  Form8.setTolGroup;
end;

// *** Initialisierung *********************************************************
procedure TForm1.Setup;
begin
  Randomize();
  cellScal  := StrToInt(Edit_cellSiz.Text);
  nbRad     := StrToInt(Edit_nRad.Text);
  moveDist  := StrToInt(Edit_mDist.Text);
  halfScal  := Ceil(cellScal/2);
  spalt     := round (ZeichenPanel.Width / cellScal);
  reih      := round (ZeichenPanel.Height / cellScal);
  ngGroups  := StrToInt(Edit_anzGr.Text);
  newLines  := false;
  chooseCol(ngGroups, farbList);
  SetLength(groupSz,  0);
  SetLength(groupSz,  ngGroups);
  SetLength(cellList, spalt, reih);
  SetLength(limboWorld, spalt, reih);
  SetLength(streetList, spalt, reih);
  SetLength(tolGroup, ngGroups, ngGroups+1);
  AgentList := TList.Create;
  createPaintImg;
  CreateRaster;
  CreateAgents;
  ZeichenPanel.Enabled := true;
  steps   := 0;
  nbS     := StrToInt(E_nbSize.Text);
  stopT   := StrToInt(E_stopT.Text);
  satiThr := TrB_thresh.Position;
  grapUpd := CB_graphicUpd.Checked;
  nbSize  := round(Power((Form1.UpD_radNb.Position*2+1), 2));
  Lbl_P.Caption      := FloatToStr(TrB_thresh.Position);
  Lbl_cellS.Caption  := IntToStr(reih) + ' x ' + IntToStr(spalt) +' = ' + IntToStr(reih*spalt);
  UpD_thresh.Position:= TrB_thresh.Position;
  rentGroupsCreate;
end;

// *****************************************************************************
procedure TForm1.rentGroupsCreate;
var
  I           : Integer;
  curLabel    : TLabel;
  curEdit     : TEdit;
  links, oben : Integer;
  inDissiRange: Real;
begin
  inDissiRange := (StrToFloat(E_rentMax.Text) - StrToFloat(E_rentMin.Text))/(ngGroups-1);
  SetLength(E_Rents, ngGroups);
  SetLength(lbl_Rents, ngGroups);
  For I := 1 To ngGroups Do
  begin
    links := 12;
    oben  := i*27;
    lbl_Rents[I-1]         := TLabel.Create(self);
    lbl_Rents[I-1].Parent  := GroupBox8;
    lbl_Rents[I-1].Left    := links;
    lbl_Rents[I-1].Top     := oben;
    lbl_Rents[I-1].Caption := 'group '+IntToStr(I);
    lbl_Rents[I-1].Name    := 'Lbl_Rent'+IntToStr(I);

    E_Rents[I-1]          := TEdit.Create(self);
    E_Rents[I-1].Parent   := GroupBox8;
    E_Rents[I-1].Left     := links+53;
    E_Rents[I-1].Top      := oben-4;
    E_Rents[I-1].Width    := 35;
    E_Rents[I-1].Text     := FloatToStr(StrToFloat(E_rentMin.Text) + inDissiRange*(i-1));
    E_Rents[I-1].Name     := 'E_Rent'+IntToStr(I);
  end;
  GroupBox8.Height  := 27 * (ngGroups+1);
end;

// *****************************************************************************
procedure TForm1.setStreetList;
var
  I, K : Integer;
begin
  for I := 0 to reih -1 do
  begin
    for K := 0 to spalt -1 do
    begin
      streetList[K,I] := 0;
      cellList[K,I].street := 0;
    end;
  end;
  SetLength(lineList, 0);
  lookForStreets;
end;
// *****************************************************************************
procedure TForm1.preserveStreets;
var
  I, K : Integer;
  strCol : TColor;
begin
  for I := 0 to reih -1 do
  begin
    for K := 0 to spalt -1 do
    begin
      cellList[K,I].street := streetList[K,I];
      If Not(cellList[K,I].street = 0) then
      begin
        case cellList[K,I].street of
          -3: strCol := colCode1.Color;
          -2: strCol := colCode2.Color;
          -1: strCol := colCode3.Color;
           1: strCol := colCode5.Color;
           2: strCol := colCode6.Color;
           3: strCol := colCode7.Color;
        end;
        cellList[K,I].colr := strCol ;//RGB(232, 232, 232);
        cellList[K,I].Paint(paintImg.Canvas);
      end else begin
        cellList[K,I].colr := RGB(255,255,255);
      end;
    end;
  end;
  lookForStreets;
end;

// ---------------------------------------------------------------------------//
// ------------------------- Elemente erstellen ------------------------------//
// ---------------------------------------------------------------------------//

// *** Legt eine leere Zeichenfl�che �ber das Zeichenpanel *********************
procedure TForm1.createPaintImg;
begin
  paintImg        := TImage.Create(self);
  paintImg.Parent := ZeichenPanel;
  paintImg.top    := 0;
  paintImg.Left   := 0;
  paintImg.Height := ZeichenPanel.Height;
  paintImg.Width  := ZeichenPanel.Width;
  paintImg.Enabled:= False;                                                   // -- does not reakt on mouseEvents
end;

procedure TForm1.tempPaintImg;
begin
  tempImg        := TImage.Create(self);
  tempImg.Parent := ZeichenPanel;
  tempImg.top    := 0;
  tempImg.Left   := 0;
  tempImg.Height := ZeichenPanel.Height;
  tempImg.Width  := ZeichenPanel.Width;
  tempImg.Transparent := true;
  tempImg.Enabled:= False;
end;

// *** Agenten erstellen *******************************************************
procedure TForm1.CreateAgents;
var
  I        : Integer;
  curAgent : TAgent;
  startNr  : Integer;
begin
  If CB_actiGrow.Checked Then startNr := StrToInt(E_startGrowWith.Text)
                         Else startNr := StrToInt(Edit_anzAg.Text);
  Xround:=0;
  If cb_indiGroups.Checked Then XagSum:=round(realPercent[Xround]*0.01*StrToInt(Edit_anzAg.Text));
  for I := 0 to startNr-1 do
  begin
    curAgent := TAgent.Create;
    AgentList.Add (curAgent);
    setupAgents(I);
  end;
end;

// *** Agenten initialisieren **************************************************
procedure TForm1.setupAgents(I: Integer);
var
  curAgent  : TAgent;
  resc      : Integer;
  strSt, K  : Integer;
  budgetRange : Real;
begin
  budgetRange := (StrToFloat(E_rentMax.Text) - StrToFloat(E_rentMin.Text))/ngGroups;
  lbl_budgetR.Caption := FloatToStr(roundTo(budgetRange, -2));
    curAgent := AgentList.Items [I];
    resc := 0;
    IF CB_strOcc.Checked Then strSt := 0;
    repeat
      resc := resc +1;
      If resc > 1000 then break;                                              // -- break condition
      curAgent.onCell.X := random (spalt);
      curAgent.onCell.Y := random (reih);
      IF Not(CB_strOcc.Checked) Then strSt := cellList[curAgent.onCell.X, curAgent.onCell.Y].street;
    until (cellList[curAgent.onCell.X, curAgent.onCell.Y].besetzt = false)
      And (strSt  = 0);
    curAgent.PosX     := curAgent.onCell.X * cellScal + halfScal;
    curAgent.PosY     := curAgent.onCell.Y * cellScal + halfScal;
    curAgent.Size     := AgSize;
    curAgent.Stopped  := False;
    If cb_indiGroups.Checked Then
    begin
      If AgentList.count <= XagSum Then
      begin
        curAgent.State := Xround+1;
        curAgent.Color := farbList[(curAgent.State-1)];
      end else begin
        inc(Xround);
        If Xround > ngGroups-1 Then Xround := ngGroups-1;
        XagSum := XagSum + round(realPercent[Xround]*0.01*StrToInt(Edit_anzAg.Text));
        curAgent.State := Xround+1;
        curAgent.Color := farbList[(curAgent.State-1)];
      end;
    end else begin
      curAgent.State := random(ngGroups)+1;
      curAgent.Color := farbList[(curAgent.State-1)];
    end;
    If cb_actiRentLand.Checked Then begin
      curAgent.budget := StrToFloat(E_rentMin.Text) + (curAgent.state*budgetRange);
    end else begin
      curAgent.budget := StrToFloat(E_rentMax.Text)
    end;
    curAgent.Paint   (paintImg.Canvas);
    cellList[curAgent.onCell.X, curAgent.onCell.Y].besetzt := true;
    cellList[curAgent.onCell.X, curAgent.onCell.Y].state := curAgent.State;
    inc(groupSz[(curAgent.State-1)]);
end;

// *** Zellen erstellen ********************************************************
procedure TForm1.CreateRaster;
var
  curCell : TCell;
  I       : Integer;
  K       : Integer;
  creaPt  : TPoint;
begin
  for I := 0 to reih -1 do
  begin
    for K := 0 to spalt -1 do
    begin
      creaPt.X := halfScal + K * cellScal;
      creaPt.Y := halfScal + I * cellScal;
      curCell  := TCell.Create(creaPt.X, creaPt.Y, halfScal, 0);
      cellList[K,I] := curCell;
    end;
  end;
  setupCells;
end;

// *** Zellen initialisieren ***************************************************
procedure TForm1.setupCells;
var
  curCell : TCell;
  I, K    : Integer;
begin
  for I := 0 to reih -1 do
  begin
    for K := 0 to spalt -1 do
    begin
      curCell         := cellList[K,I];
      curCell.besetzt := false;
      curCell.colr    := RGB(255, 255, 255);
      curCell.state   := 0;
      curCell.street  := 0;
      curCell.sWeight := 1;
      curCell.rent    := 0;
      curCell.clCeck  := false;
      curCell.Paint(paintImg.Canvas);
      SetLength(curCell.wghtList, 0);
    end;
  end;
  preserveStreets;
end;

// ########################################################################## //
// ---------------------------- Berechnungen -------------------------------- //
// ########################################################################## //

// *** Diffusionsfeld **********************************************************
procedure TForm1.diffuseIn (curCell: TCell);
begin
  If cb_actiRentLand.Checked Then
  case curCell.State of
  1 : curCell.rent := StrToFloat(E_Rents[0].Text);
  2 : curCell.rent := StrToFloat(E_Rents[1].Text);
  3 : curCell.rent := StrToFloat(E_Rents[2].Text);
  4 : curCell.rent := StrToFloat(E_Rents[3].Text);
  5 : curCell.rent := StrToFloat(E_Rents[4].Text);
  6 : curCell.rent := StrToFloat(E_Rents[5].Text);
  end;
end;
// *** diffuse the rent-values *************************************************
procedure TForm1.diffuseField;
var
  curCell  : TCell;
  I, K     : Integer;
begin
  for I := 0 to reih -1 do
  begin
    for K := 0 to spalt -1 do
    begin
      diffuseCheckNei (K, I);
    end;
  end;
  for I := 0 to reih -1 do
  begin
    for K := 0 to spalt -1 do
    begin
      curCell := cellList[K,I];
      curCell.rent := limboWorld[K, I];
      //curCell.Paint(paintImg.Canvas);
      //curCell.potent[1] := 0.39*(curCell.potent[1] + limboWorld[1, K, I] + 0.5*limboWorld[0, K, I]) + (random() * dVal/5);   // -- dVal is here the stregth of the error term
    end;
  end;
end;

// *** check the moore-neighbourhood *******************************************
procedure TForm1.diffuseCheckNei (K, I : Integer);
var
  u, v   : Integer;
  Xp, Yp : Integer;
  M      : Integer;
begin
  // --- Summe berechnen ---
  For M := 0 to 2 do
  begin
    limboWorld[K, I] := 0;
    for u := -1 to 1 do
    begin
      for v := -1 to 1 do
      begin
        Xp := K + v;
        Yp := I + u;
        torus(Xp, Yp);  // -- Torus
        limboWorld[K, I] := limboWorld[K, I] + cellList[Xp, Yp].rent;
      end;
    end;
    limboWorld[K, I] := limboWorld[K, I] - cellList[K, I].rent;
    limboWorld[K, I] := limboWorld[K, I]/ 8;
  end;
end;
// *****************************************************************************

// *** Iterativ Befehle ausf�hren **********************************************
procedure TForm1.Timer1Timer(Sender: TObject);
begin
  actions;
  If steps = stopT Then Timer1.Enabled:= false;
end;
// *****************************************************************************
procedure TForm1.actions;
begin
  growth;
  calcAgents;                                                                 // -- ver�ndert die Position der Agenten                                                                 // -- �bertr�gt die cell-states in das feld
  If cb_actiRentLand.Checked Then diffuseField;                                                               // -- calculates the diffusion field
  inc(steps);
  lbl_Steps.Caption := IntToStr (steps);
  calcChart;
  speedMeasure;
  If steps = stopT Then begin
    Timer1.Enabled    := false;
    B_stop.Font.Color := clRed;
  end;
  IF CB_showRentSc.Checked=true Then repaintCells;      
  If CB_showAgs.Checked Then repaintAgents;
end;

// *****************************************************************************
procedure TForm1.transLine(p1X, p1Y, strType: Integer);
var
  curCell               : TCell;
  I, bestP              : Word;
  min, tmpDiff, tmpWink : Double;
  strCol                : TColor;
  nbDirect              : nachbarArray;                                       // -- 4 direct neighbours
begin
  case strType of
    -3: strCol := colCode1.Color;
    -2: strCol := colCode2.Color;
    -1: strCol := colCode3.Color;
    1:  strCol := colCode5.Color;
    2:  strCol := colCode6.Color;
    3:  strCol := colCode7.Color;
  end;
  curCell := cellList[p1X, p1Y];
  curCell.colr    := strCol;
  curCell.street  := strType;
  streetList[p1X, p1Y] := curCell.street;
  curCell.Paint(paintImg.Canvas);
  neumNb (p1X, p1Y, nbDirect);
  min := 999999999;
  For I := 0 To 3 Do
  begin
    tmpWink := ArcTan2 ((targetCell.reiSpa.Y - nbDirect[I].Y), (targetCell.reiSpa.X - nbDirect[I].X));
    tmpDiff := abs(targWink-tmpWink);
    If (abs(targetCell.reiSpa.Y - nbDirect[I].Y) <= abs(targetCell.reiSpa.Y - p1Y)) And
       (abs(targetCell.reiSpa.X - nbDirect[I].X) <= abs(targetCell.reiSpa.X - p1X)) Then
    If tmpDiff < min Then
    begin
      min := tmpDiff;
      bestP := I;
    end;
  end;
  If Not (curCell = targetCell) Then transLine(nbDirect[bestP].X, nbDirect[bestP].Y, strType); // --  recursive call!!
end;

// _____________________________________________________________________________
// *****************************************************************************
procedure TForm1.lookForStreets;
var
  I,K, v,u, Xp,Yp : Integer;
  sumStreets      : Cardinal;
  tmpWght         : Real;
  curCell,tmpCell : TCell;
begin                                   // --- look for the POSITIVE streets ---
  sumStreets := 0;
  for I := 0 to reih -1 do
  begin
    for K := 0 to spalt -1 do
    begin
      checkStreets (K, I);
      If not (cellList[K, I].street = 0) Then inc(sumStreets);
    end;
  end;
  Lbl_strCell.Caption := IntToStr(sumStreets);
  for I := 0 to reih -1 do              // --- look for the NEGATIVE streets ---
  begin
    for K := 0 to spalt -1 do
    begin
      for v := -nbRad to nbRad do
      begin
        for u := -nbRad to nbRad do
        begin
          Xp := K + u;
          Yp := I + v;
          If wrap(Xp, Yp)= false Then
          begin
            curCell := cellList[K, I];
            tmpCell := cellList[Xp, Yp];
            If high(lineList)>0 Then tmpWght := testLines(K, I, Xp, Yp)       // -- test, if a street is between the current cell an the neighbour
                                Else tmpWght := StrToFloat(SG_weight.Cells[1,4]);
            If tmpWght = StrToFloat(SG_weight.Cells[1,4]) Then                // -- If no negative street is in between,
               tmpWght := tmpCell.sWeight;                                    // -- take the positive weight
            SetLength(curCell.wghtList, length(curCell.wghtList)+1);          // -- save the negative weight values in a list at each cell
            curCell.wghtList[high(curCell.wghtList)] := tmpWght;
          end;
        end;
      end;
    end;
  end;
  newLines := false;
end;

function TForm1.testLines(AX1,AY1,AX2,AY2: Integer):Real;
var
  I          : Integer;
  tPt1, tPt2 : TPoint;
  isCrosP    : Boolean;
  lineType   : Integer;
begin
  lineType := 0;
  For I := 0 To high(lineList) Do
  begin
    tPt1.X := AX1;
    tPt1.Y := AY1;
    tPt2.X := AX2;
    tPt2.Y := AY2;
    isCrosP := Intersect(tPt1, tPt2, lineList[I].startP, lineList[I].endP);
    If isCrosP = true Then begin
      If lineList[I].lType < lineType Then lineType := lineList[I].lType;
    end;
  end;
  case lineType of
     0: Result := StrToFloat(SG_weight.Cells[1,4]);
    -1: Result := StrToFloat(SG_weight.Cells[1,3]);
    -2: Result := StrToFloat(SG_weight.Cells[1,2]);
    -3: Result := StrToFloat(SG_weight.Cells[1,1]);
  end;
end;

function TForm1.Intersect(const A1, A2, B1, B2: TPoint): Boolean;
 Var
  I, J, K1, K2, K3: integer;
  E, D: Extended;
 begin
  D := 0;
  K1 := B2.Y-B1.Y;
  K2 := A1.Y-A2.Y;
  K3 := A2.Y-B2.Y;
  J := A1.X*(B1.Y-B2.Y)+A2.X*K1+B1.X*(A2.Y-A1.Y)+B2.X*K2;
  if J=0 then exit;
  I := A1.X*K3+A2.X*(B2.Y-A1.Y)+B2.X*K2;
  if J > 0 then
  begin
    if (I <= 0) or (I >= J) then exit;
  end else
    if (I >= 0) or (I <= J) then exit;
  I := B1.X*K3+B2.X*(B1.Y-A2.Y)+A2.X*K1;
  if J > 0 then
  begin
    if (I <= 0) or (I >= J) then exit;
  end else
    if (I >= 0) or (I <= J) then exit;
  E := I/J;
  if E>D then
    Result:=true;
end;

// -----------------------------------------------------------------------------
procedure TForm1.checkStreets (K, I: Integer);
var
  u,v     : Integer;
  Xp, Yp  : Integer;
  sVal    : Integer;      // -- street value
  curCell : TCell;
begin
  curCell := cellList[K,I];
  If (curCell.street < 0) then
  begin
    case curCell.street of
      -1: curCell.sWeight:= StrToFloat(SG_weight.Cells[1,3]);
      -2: curCell.sWeight:= StrToFloat(SG_weight.Cells[1,2]);
      -3: curCell.sWeight:= StrToFloat(SG_weight.Cells[1,1]);
    end;
  end;
  for v := -1 to 1 do
  begin
    for u := -1 to 1 do
    begin
      Xp := K + u;
      Yp := I + v;
      torus(Xp, Yp);
      sVal := cellList[Xp, Yp].street;
      If (sVal > 0) and (curCell.street = 0) then                             // -- increase the weights of the cells around a kommunicative street
      begin
        cellList[K,I].colr := RGB(232, 232, 232);
        curCell.Paint(paintImg.Canvas);
        case sVal of
          1: curCell.sWeight:= StrToFloat(SG_weight.Cells[1,5]);
          2: curCell.sWeight:= StrToFloat(SG_weight.Cells[1,6]);
          3: curCell.sWeight:= StrToFloat(SG_weight.Cells[1,7]);
        end;
      end;
    end;
  end;
end;

// *****************************************************************************
procedure TForm1.neumNb (K, I: Integer; var nbDirect: nachbarArray);
var
  v      : Integer;
  Xp, Yp : Integer;
  koNei  : Array [0..3] of TPoint;
  neib   : TPoint;
begin
  // --- Summe berechnen ---
  koNei[0].X := K;    koNei[0].Y := I + 1;
  koNei[1].X := K;    koNei[1].Y := I - 1;
  koNei[2].X := K+1;  koNei[2].Y := I;
  koNei[3].X := K-1;  koNei[3].Y := I;

  for v := 0 to 3 do
  begin
    Xp := koNei[v].X;
    Yp := koNei[v].Y;
    torus(Xp, Yp);                                                            // -- Torus check
    neib.X := Xp;
    neib.Y := Yp;
    nbDirect[v]:= neib;
  end;
end;

// *****************************************************************************
// *** increase population per step ********************************************
procedure TForm1.growth;
var
  I        : Integer;
  CurAgent : TAgent;
begin
  If CB_actiGrow.Checked Then
  If AgentList.Count < StrToInt(Edit_anzAg.Text) Then
    For I := 0 to StrToInt(E_growRate.Text)-1 do
    begin
      curAgent := TAgent.Create;
      AgentList.Add (curAgent);
      setupAgents(AgentList.Count-1);
    end;
  Lbl_nrAgents.Caption := IntToStr(AgentList.Count-1);
end;

// *** fps measure *************************************************************
procedure TForm1.speedMeasure;
var
  Framespersecond   : Cardinal;
begin
  Inc(Frames);
  if GetTickCount - StartTick >=1000 then
  begin  
    Framespersecond:= round(Frames/(GetTickCount - StartTick)*1000);
    StartTick := GetTickCount;
    Frames := 0;
    Form1.Caption := 'Group seperation || ' + 'fps= ' + IntToStr(Framespersecond);
  end;
end;

// *****************************************************************************
// *** Clusterparameter zur�cksetzen *******************************************
procedure TForm1.resetCluster;
var
  curCell : TCell;
  I, K    : Integer;
begin
  for I := 0 to reih -1 do
  begin
    for K := 0 to spalt -1 do
    begin
      curCell   := cellList[K,I];
      setLength (curCell.sameNB, 0);
      curCell.clCeck := false;
    end;
  end;
end;

// *** calculate dissimilar index **********************************************
procedure TForm1.countInTiles;
var
  curCell    : TCell;
  I, K, L, M : Integer;
  tiles            : Cardinal;
  inReih, inSpalt  : Cardinal;
  nbSizeR, nbSizeS : Cardinal;
  ctInTiles        : TDreierArray;                                            // -- count the group members in each tile
begin
  nbSizeR := nbS;
  nbSizeS := nbS;
  inSpalt := 0;
  inReih  := 0;
  tiles   := ceil((reih) / nbS);
  setlength (ctInTiles, tiles, tiles, ngGroups);
  resetCluster;
  For L := 0 to tiles-1 Do
  begin
    For M := 0 to tiles-1 Do
    begin
      // --- one tile ------------------------
      for I := inReih to inReih + nbSizeR-1 do                                // -- reihe
      begin
        for K := inSpalt to inSpalt + nbSizeS-1 do                            // -- spalte
        begin
          curCell := cellList[K,I];
          IF curCell.state > 0 Then begin
            inc(ctInTiles[M, L, curCell.state-1]);                            // -- z�hlt Zellen mit anderem Status
          end;
        end;
      end;
      // -------------------------------------
      inSpalt := inSpalt + nbSizeS;
      If (inSpalt + nbSizeS) > spalt-1 Then nbSizeS := (spalt - inSpalt);
    end;
    inReih  := inReih + nbSizeR;
    inSpalt := 0;
    nbSizeS := nbS;
    If (inReih + nbSizeR) > reih-1 Then nbSizeR := (reih - inReih);
  end;
  IDissimilar (ctInTiles, tiles);
end;

// *** calculate dissimilar index **********************************************
procedure TForm1.IDissimilar (ctInTiles: TDreierArray; tiles: Cardinal);
var
  L, M, V, W : Integer;
  sumTyp     : Array of Array of Extended;                                    // -- Dissimilarit�tsindex
  segIdx     : Array of Extended;                                             // -- Segregationsindex
  sumGes     : Extended;                                                      // -- Sum of the population without the current group
  relChange  : Double;
  pDense     : Double;
begin
  SetLength (sumTyp, 0, 0);
  SetLength (sumTyp, ngGroups, ngGroups);
  SetLength (segIdx, 0);
  SetLength (segIdx, ngGroups);
  setlength (ctInTiles, tiles, tiles, ngGroups);
  resetCluster;
  For L := 0 to tiles-1 Do
  begin
    For M := 0 to tiles-1 Do
    begin
      For V:= 0 To ngGroups -1 Do
      begin
        For W := V+1 To ngGroups -1 Do
        begin
          sumTyp[W, V] := sumTyp[W, V] + abs(
          (ctInTiles[M, L, V]/groupSz[V] * 100)-(ctInTiles[M, L, W]/groupSz[W] * 100));
        end;
        sumGes := 0;
        For W := 0 To ngGroups -1 Do
        begin
          If not (W=V) Then
            sumGes := sumGes + (ctInTiles[M, L, W]);
        end;
        segIdx[V] := segIdx[V] + abs(
        (ctInTiles[M, L, V]/groupSz[V] * 100)-(sumGes/(StrToInt(Edit_anzAg.Text)-groupSz[V]) * 100));
      end;
    end;
  end;
  For V:= 0 To ngGroups-1  Do
  begin
    For W := V To ngGroups-1  Do
    begin
      sumTyp[W, V] := 0.5 * sumTyp[W, V];
      Form2.DissimiGrid.Cells[W+1, V+1] := FloatToStr(roundTo(sumTyp[W, V], -2));
    end;
    segIdx[V] := 0.5 * segIdx[V];
    Form2.DissimiGrid.Cells[V+1, ngGroups+1] := FloatToStr(roundTo(segIdx[V],-2));
    isSer[V].AddXY(steps, segIdx[V]);                                         // -- Segregation Index
    dsSer[V].AddXY(AgentList.Count-1, segIdx[V]);                             // -- Segregation / density
  end;
  csSer[0].AddXY(steps, posChange);                                           // -- plot the absolute change = number of moving agents at t
  relChange := posChange/(AgentList.Count-1)*100;
  csSer[1].AddXY(steps, relChange);                                           // -- plot the relative change = percentage of moving agents at t
  If Form6.Timer5.Enabled Then Form6.ser_change.AddXY(steps, posChange);      // -- plot the absolute change again to the stability analysis form
  If Form6.Timer5.Enabled Then Form6.ser_tol.AddXY(steps, satiThr);           // -- plot the satisfaction threshold to the stability analysis form
  pDense := (AgentList.Count-1)/(reih*spalt)*100;
  csSer[2].AddXY((AgentList.Count-1), pDense) ;                               // -- plot density-agents
  csSer[3].AddXY(steps, pDense) ;                                             // -- plot density-time
end;

// *** Cluster Analyse *********************************************************
procedure TForm1.startCAna;
var
  curCell    : TCell;
  I, K       : Integer;
  clustNr    : Integer;
begin
  SetLength (clustCount, 0, 0);
  setLength (clustCount, ngGroups);
  resetCluster;
  clustNr := 1;
  for I := 0 to reih -1 do
  begin
    for K := 0 to spalt -1 do
    begin
      curCell := cellList[K,I];
      If (curCell.state > 0) and ( curCell.clCeck = false) Then
      begin
        CellList[K,I].clCeck := true;
        setLength(clustCount[CellList[K,I].state-1], length(clustCount[CellList[K,I].state-1])+1);
        inc(clustCount[curCell.state-1, High(clustCount[curCell.state-1])]);
        findCluster (K,I, clustNr);
        inc (clustNr);
      end;
    end;
  end;
  Form2.setClusterGraph;
end;

// *** Cluster Analysieren *****************************************************
procedure TForm1.findCluster (K, I :Integer; clustNr :Integer);
var
  curCell  : TCell;
  M        : Integer;
begin
  curCell  := CellList[K, I];
  checkMoore (K,I);
  for M := 0 to High(curCell.sameNB) do
  begin
    findCluster(curCell.sameNB[M].X, curCell.sameNB[M].Y, clustNr)            // -- Rekursion
  end;
end;

// *** Neumann Nachbarschaft, mit den Abstand 1 �berpr�fen *********************
procedure TForm1.checkMoore (K, I: Integer);
var
  v        : Integer;
  Xp, Yp   : Integer;
  koNei    : Array [0..3] of TPoint;
  curCell  : TCell;
begin
  koNei[0].X := K;    koNei[0].Y := I + 1;
  koNei[1].X := K;    koNei[1].Y := I - 1;
  koNei[2].X := K+1;  koNei[2].Y := I;
  koNei[3].X := K-1;  koNei[3].Y := I;
  for v := 0 to 3 do
  begin
    Xp := koNei[v].X;
    Yp := koNei[v].Y;
    torus(Xp, Yp);                                                            // -- Torus check
    curCell := cellList[K, I];                                                   
    If ((cellList[Xp, Yp].state = curCell.state) AND (cellList[Xp, Yp].clCeck = false)) then
    begin
      setLength(curCell.sameNB, length(curCell.sameNB)+1);
      curCell.sameNB[high(curCell.sameNB)].X := Xp;
      curCell.sameNB[high(curCell.sameNB)].Y := Yp;
      cellList[Xp, Yp].clCeck := true;
      inc(clustCount[curCell.state-1, High(clustCount[curCell.state-1])]);
    end;
  end;
end;

// *****************************************************************************
// *** Ver�ndert die Position der Agenten **************************************
procedure TForm1.calcAgents;
var
  curCell          : TCell;
  curAgent         : TAgent;
  I, strSt, resc   : Integer;
  tempPos          : TPoint;
  similar, tmpSati : Double;
  oldRent, newRent : Real;
begin
  posChange := 0;
  for I := 0 to AgentList.Count - 1 do
  begin
    curAgent := AgentList.Items [I];
    resc := 0;
    curCell := cellList[curAgent.onCell.X, curAgent.onCell.Y];
    If steps = 0 Then testLocation (curAgent.onCell.X, curAgent.onCell.Y, tmpSati);
    If (curCell.satisfied >= satiThr) AND (curCell.rent < curAgent.budget) Then //And (curCell.street = 0) Then            // -- if the neighbours are statisfying,
    begin
      curAgent.Stopped := true;                                               // -- stop the agent
      IF Not(CB_strOcc.Checked) And not (curCell.street = 0) Then curAgent.Stopped := false;
    end else begin
      curAgent.Stopped := false;                                              // -- otherwise look for a better location
      oldRent := curCell.rent;
    end;

    If curAgent.Stopped = false then                                          // -- Wenn Agent noch nicht angelagert,
    begin                                                                     // -- suche nach einem besseren Ort.
      IF CB_strOcc.Checked Then strSt := 0;                
      repeat                                                                  // -- look for a unoccupied cell
        resc := resc +1;
        If resc > 1000 then begin
          tempPos.X := curAgent.onCell.X;                                     // -- don't change position
          tempPos.Y := curAgent.onCell.Y;
          break;                                                              // -- break condition
        end;
        curAgent.ChangeHeading(180, moveDist);                                // -- Richtungsspektrum und Distanz
        tempPos.X := curAgent.onCell.X + curAgent.stepX;
        tempPos.Y := curAgent.onCell.Y + curAgent.stepY;
        torus (tempPos.X, tempPos.Y);                                         // -- Torus
        curCell := cellList[tempPos.X, tempPos.Y];
        IF Not(CB_strOcc.Checked) Then strSt := curCell.street;
      until (curCell.besetzt = false) and (strSt = 0);                        // -- wiederholen, bis freie Zelle gefunden

      newRent := curCell.rent;
      testLocation (curAgent.onCell.X, curAgent.onCell.Y, tmpSati);           // -- test new location
      cellList[curAgent.onCell.X, curAgent.onCell.Y].state   := 0;            // -- set a temporarily new state
      curCell := cellList[tempPos.X, tempPos.Y];
      curCell.State     := curAgent.State;
      testLocation (tempPos.X, tempPos.Y, similar);
      curCell.State     := 0;                                                 // -- and reset the temporarily state
      cellList[curAgent.onCell.X, curAgent.onCell.Y].state   := curAgent.State;;

      If (tmpSati < similar)// Then begin                                         // -- move, if the new place is more satisfying
        or (newRent < oldRent) Then begin
        moveAgent (curAgent.onCell, tempPos, curAgent);
      end;
      inc(posChange);                                                         // -- these are the agents, which WANTS to change their locaton
      If grapUpd Then curAgent.Paint (paintImg.Canvas);

    end else begin
      testLocation (curAgent.onCell.X, curAgent.onCell.Y, tmpSati);
    end;
  end;
end;

// *** test if location is more satisfiying ************************************
procedure TForm1.moveAgent (oldPos: TPoint; newPos: TPoint; curAgent: TAgent);
var
  curCell : TCell;
begin
  curCell := cellList[newPos.X, newPos.Y];
  cellList[oldPos.X, oldPos.Y].besetzt := false;                              // -- alte Zelle wieder leer
  cellList[oldPos.X, oldPos.Y].state   := 0;
  If grapUpd Then cellList[oldPos.X, oldPos.Y].Paint (paintImg.Canvas);       // -- und neu zeichnen
  curAgent.onCell.X := newPos.X;
  curAgent.onCell.Y := newPos.Y;
  curAgent.PosX     := curAgent.onCell.X * cellScal + halfScal;               // -- Wenn Zelle frei, Agent bewegen ---
  curAgent.PosY     := curAgent.onCell.Y * cellScal + halfScal;
  curCell.Besetzt   := true;                                                  // -- Zelle unter Agent als besetzt markieren.
  curCell.State     := curAgent.State;
  diffuseIn (curCell);
end;

// *** test if location is more satisfiying ************************************
procedure TForm1.testLocation (K, I: Integer; var similar : Double);
var
  curCell : TCell;
  nSum1    : Cardinal;
  nSum2    : Real;
  happy, unhappy : Cardinal;
  J : Integer;
begin
  curCell := cellList[K, I];
  checkNei (K, I);
  nSum2    := 0;//curCell.neighSimi + curCell.neighDiff;
  happy   := 0;
  unhappy := 0;
  If Not cb_individTol.Checked Then begin                                     // -- keine individuellen toleranzwerte
    nSum2 := curCell.neighSimi + curCell.neighDiff;
    If nSum2 > 0 then begin
      similar := (curCell.neighSimi/nSum2) * 100;
      curCell.satisfied := similar;
    end else begin
      similar := 0;
      curCell.satisfied := 0;
    end;
  end else begin  // ---------------------------------------------------------------------------
  For J:=0 To length(curCell.neighGroup)-1 Do
  begin
    If not (curCell.state = 0) Then begin                                     // -- leere zellen nicht pr�fen
    If curCell.neighGroup[J] <= tolGroup[curCell.state-1,J] Then begin
      //happy   := happy + 1;//curCell.neighGroup[J];                               // -- zufrieden mit (allen) X zellen
      happy   := happy + curCell.neighGroup[J];
    end else begin
      //unhappy := unhappy + 1;//curCell.neighGroup[J] -tolGroup[curCell.state-1,J]; // - unzufrieden mit Y zellen
      unhappy := unhappy + curCell.neighGroup[J] -tolGroup[curCell.state-1,J];
      happy   := happy + tolGroup[curCell.state-1,J];
    end;
    end;
  end;
  nSum1 := happy+unhappy;
  If nSum1 >0 then begin
    similar := (nSum1-unhappy)/nSum1 * 100;
  end else begin
    similar := 0;
  end;
  curCell.satisfied := similar;
  end;
end;

// *** Moorsche Nachbarschaft, mit den Abstand nbRad �berpr�fen ****************
procedure TForm1.checkNei (K, I: Integer);
var
  u,v, Xp,Yp, idx  : Integer;
  curCell, tmpCell : TCell;
  tmpWght          : Real;
  tolWght          : Integer;
begin
  idx := 0;
  curCell := cellList[K,I];
  curCell.neighSimi := 0;
  curCell.neighDiff := 0;
  SetLength(curCell.neighGroup, 0);                                           // -- delete the group-counter
  SetLength(curCell.neighGroup, ngGroups+1);                                    // -- reseize the group-counter
  for v := -nbRad to nbRad do                                                 // -- Summen berechnen
  begin
    for u := -nbRad to nbRad do
    begin
      Xp := K + u;
      Yp := I + v;
      If wrap(Xp, Yp)= false Then
      begin
        tmpCell := cellList[Xp, Yp];
        tmpWght := curCell.wghtList[idx];                                     // -- take the weight from the list
        inc(idx);
        If Not cb_individTol.Checked Then begin                               // -- keine individuellen toleranzwerte
        // --- for equal tolerances ------------------------
        If (tmpCell.state = curCell.state) then begin
           curCell.neighSimi := curCell.neighSimi +1*tmpWght;                 // -- z�hlt Zellen mit gleichem Status
        end else begin
          IF cellList[Xp, Yp].besetzt = true Then begin
             curCell.neighDiff := curCell.neighDiff +1*tmpWght;               // -- z�hlt Zellen mit anderem Status
          end else begin                                                      // -- how to handle empty cells
            If RB_count_diff.Checked Then
              curCell.neighDiff := curCell.neighDiff +1;                      // -- count empty cells as different
            If RB_count_simi.Checked Then
              curCell.neighSimi := curCell.neighSimi +1;                      // -- count empty cells as similar
          end;
        end;
        end else begin                                                        // -- mit individuellen toleranzwerte
          // --- for individual tolerances -----------------
          inc(curCell.neighGroup[tmpCell.state]);                             // -- erh�ht den jeweiligen gruppen-counter
        end;
      end;
    end;
  end;
end;

// *** calculate the values for the chart **************************************
procedure TForm1.calcChart;
var
  curCell : TCell;
  I, K, M : Integer;
  sumSati : Array of Double;
  sumAgs  : Array of Integer;
  rest    : Word;
begin
  If steps = 1 Then Form2.resetGraph;
  setLength(sumSati, ngGroups);
  setLength(sumAgs,  ngGroups);
  for I := 0 to reih -1 do
  begin
    for K := 0 to spalt -1 do
    begin
      curCell := cellList[K, I];
      If curCell.besetzt then
      begin
        //sumSati[curCell.State-1] := sumSati[curCell.State-1] + curCell.satisfied;
        If curCell.satisfied >= 100 Then sumSati[curCell.State-1] := sumSati[curCell.State-1] + 100;
        sumAgs [curCell.State-1] := sumAgs [curCell.State-1] + 1;
      end;
    end;
  end;
  For M :=0 to ngGroups-1 Do
  begin
    If sumAgs[M] > 0 Then begin
      sSer[M].AddXY(steps, sumSati[M]/sumAgs[M]);
    end else sSer[M].AddXY(steps, 0);
  end;
  DivMod(steps-1, 30, rest, rest);
  If rest = 0 Then begin
    startCAna;                                                                // -- cluster analysis
  end;
  countInTiles;
end;
// -----------------------------------------------------------------------------
// -----------------------------------------------------------------------------
procedure TForm1.repaintAgents;
var
  curAgent : TAgent;
  I        : Integer;
begin
  repaintCells;
  for I := 0 to AgentList.Count - 1 do
  begin
    curAgent := AgentList.Items [I];
    curAgent.Paint (paintImg.Canvas);
  end;
end;

procedure TForm1.repaintCells;
var
  curCell  : TCell;
  I, K : Integer;
begin
  for I := 0 to reih -1 do
  begin
    for K := 0 to spalt -1 do
    begin
      curCell := cellList[K, I];
      curCell.Paint (paintImg.Canvas);
    end;
  end;
end;
// ---------------------------------------------------------------------------//
// -------------------------- Funktionen -------------------------------------//
// ---------------------------------------------------------------------------//
// --- Select a Color ---
procedure TForm1.chooseCol(anzahl:integer; var farbListe: colList);
var
  number,red,green,blue,i : integer;
  step                    : real;
begin
  setlength (farbListe,anzahl);
  step:=1275/(anzahl-1);
  for i:=0 to anzahl-1 do
  begin
    number:=round(i*step);
    red:=0;
    green:=0;
    blue:=0;
    case number of
    0..255:
      begin
        red:=255;
        green:=number;
      end;
    256..510:
      begin
        red:=510-number;
        green:=255;
      end;
    511..765:
      begin
        green:=255;
        blue:=number-510;
      end;
    766..1020:
      begin
        green:=1020-number;  
        blue:=255;  
      end;  
    1021..1275:  
      begin
        red:=number-1020;  
        blue:=255;  
      end;  
    1276:  
      begin
        red:=255;  
        blue:=255;
      end;  
    end;
    farbListe[i] := rgb(red,green,blue);
  end;  
end;

// *** Torusfunktion ***********************************************************
procedure TForm1.torus (var Xp: Integer; var Yp: Integer);
begin
  if Xp < 0 then begin
     while Xp < 0 do
     Xp := spalt + Xp;
  end else
  if Xp > spalt-1 then begin
     while Xp > spalt-1 do
     Xp := 0 + (Xp - spalt) ;
  end;
  if Yp < 0 then begin
     while Yp < 0 do
     Yp := reih + Yp;
  end else
  if Yp > reih-1 then begin
     while Yp > reih-1  do
     Yp := 0 + (Yp - reih) ;
  end;
end;
// *** wrap funktion ***********************************************************
function TForm1.wrap (var Xp: Integer; var Yp: Integer):Boolean;
begin
  Result := false;
  if Xp < 0 then begin
     Result := true;
     Exit;
  end else
  if Xp > spalt-1 then begin
     Result := true;
     Exit;
  end;
  if Yp < 0 then begin
     Result := true;
     Exit;
  end else
  if Yp > reih-1 then begin
     Result := true;
     Exit;
  end;
end;
// -----------------------------------------------------------------------------
procedure TForm1.TrB_threshChange(Sender: TObject);
begin
  UpD_thresh.Position := TrB_thresh.Position;
  Lbl_P.Caption := FloatToStr(TrB_thresh.Position);
  satiThr       := TrB_thresh.Position;
end;

procedure TForm1.UpD_agentSzClick(Sender: TObject; Button: TUDBtnType);
begin
  AgSize := UpD_agentSz.Position;
end;

procedure TForm1.UpD_threshClick(Sender: TObject; Button: TUDBtnType);
begin
  TrB_thresh.Position := UpD_thresh.Position;
  satiThr             := UpD_thresh.Position;
end;

// *****************************************************************************
// *** the mouse interactions **************************************************
// *****************************************************************************
procedure TForm1.ZeichenPanelMouseDown(Sender: TObject; Button: TMouseButton;
  Shift: TShiftState; X, Y: Integer);
var
  cPos : TPoint;
begin
  If CB_strType.ItemIndex = -1 Then
  begin
    MessageBox(MB_Ok, 'please select a street type', 'missing value', MB_Ok);
    exit;
  end;
  If CB_hideAgs.Checked Then begin
    timer1.Enabled    := false;
    B_stop.Font.Color := clRed;
    repaintCells
  end Else repaintAgents;
  If Button = mbLeft  then  lDown := true;
  cPos.X  := round((X- halfScal) / cellScal);
  cPos.Y  := round((Y- halfScal) / cellScal);
  targetCell := cellList[cPos.X, cPos.Y];
  targetCell.reiSpa.X := cPos.X;
  targetCell.reiSpa.Y := cPos.Y;
  SetLength(lineList, length(lineList)+1);
  lineList[high(lineList)].startP := cPos;
  tempPaintImg;                                                               // -- create a temporary paintImage
end;
// -----------------------------------------------------------------------------
procedure TForm1.ZeichenPanelMouseMove(Sender: TObject; Shift: TShiftState; X,
  Y: Integer);
var
  lineFPt : TPoint;
  strCol  : TColor;
begin
  If (lDown = true) Then
  begin
    tempImg.Canvas.brush.Color := clWhite;
    tempImg.Canvas.pen.Color   := clWhite;
    tempImg.Canvas.Rectangle(0,0,ZeichenPanel.Height,ZeichenPanel.Width);
    lineFPt.X := halfScal + targetCell.reiSpa.X * cellScal;
    lineFPt.Y := halfScal + targetCell.reiSpa.Y * cellScal;
    case CB_strType.ItemIndex of
      0: strCol := colCode1.Color;
      1: strCol := colCode2.Color;
      2: strCol := colCode3.Color;
      3: strCol := colCode5.Color;
      4: strCol := colCode6.Color;
      5: strCol := colCode7.Color;
    end;
    tempImg.Canvas.Pen.Width := 3;
    tempImg.Canvas.Pen.Color := strCol;
    tempImg.Canvas.MoveTo(lineFPt.X, lineFPt.Y);
    tempImg.Canvas.LineTo(X, Y);
  end;
end;
// -----------------------------------------------------------------------------
procedure TForm1.ZeichenPanelMouseUp(Sender: TObject; Button: TMouseButton;
  Shift: TShiftState; X, Y: Integer);
var
  cPos    : TPoint;
  strType : Integer;
begin
  If Not (CB_strType.ItemIndex = -1) Then
  begin
    cPos.X  := round((X- halfScal) / cellScal);
    cPos.Y  := round((Y- halfScal) / cellScal);
    lDown := false;
    startCell := cellList[cPos.X, cPos.Y];
    targWink := ArcTan2((targetCell.reiSpa.Y - cPos.Y),(targetCell.reiSpa.X - cPos.X));
    case CB_strType.ItemIndex of                                              // -- save the type of the new line in the list below
      0: strType := -3;
      1: strType := -2;
      2: strType := -1;
      3: strType := 1;
      4: strType := 2;
      5: strType := 3;
    end;
    lineList[high(lineList)].endP := cPos;
    lineList[high(lineList)].lType:= strType;
    transLine (cPos.X, cPos.Y, strType);                                      // -- transfer the line into the grid
    newLines := true;
    If Not CB_hideAgs.Checked Then lookForStreets;
    If CB_hideAgs.Checked Then repaintCells Else repaintAgents;
    tempImg.Free;
  end;
end;
// -----------------------------------------------------------------------------
procedure TForm1.B_drawGridClick(Sender: TObject);
begin
  rasterStreets;
end;
procedure TForm1.rasterStreets;
var
  stPos, taPos    : TPoint;
  dist,strType, I : Integer;
begin
  If UpD_strType.Position = 0 Then
  begin
    MessageBox(MB_Ok, '0 is not a valid street type', 'missing value', MB_Ok);
    exit;
  end;
  dist := round(reih / UpD_rows.Position);
  For I := 1 to UpD_rows.Position-1 Do
  begin
    If CB_rndTyp.Checked Then begin
      strType := random (6)+1;
      If strType > 3 Then strType:= strType-7;
    end else begin
      strType := UpD_strType.Position;
    end;
    stPos.X  := I * dist-1;
    stPos.Y  := 0;
    taPos.X  := I * dist-1;
    taPos.Y  := reih    -1;
    setStreetPara(stPos, taPos, strType)
  end;
  dist := round(reih / UpD_cols.Position);
  For I := 1 to UpD_cols.Position-1 Do
  begin
    If CB_rndTyp.Checked Then begin
      strType := random (6)+1;
      If strType > 3 Then strType:= strType-7;
    end else begin
      strType := UpD_strType.Position;
    end;
    stPos.X  := 0;
    stPos.Y  := I * dist-1;
    taPos.X  := spalt   -1;
    taPos.Y  := I * dist-1;
    setStreetPara(stPos, taPos, strType)
  end;
  newLines := true;
  lookForStreets;
  tempImg.Free;
  repaintAgents;
end;

procedure TForm1.B_randStrClick(Sender: TObject);
begin
  randStreets;
end;

procedure TForm1.randStreets;
var
  stPos, taPos : TPoint;
  strType, I   : Integer;
begin
  If UpD_strType.Position = 0 Then
  begin
    MessageBox(MB_Ok, '0 is not a valid street type', 'missing value', MB_Ok);
    exit;
  end;
  For I := 1 to UpD_nrStr.Position-1 Do
  begin
    If CB_rndTyp.Checked Then begin
      strType := random (6)+1;
      If strType > 3 Then strType:= strType-7;
    end else begin
      strType := UpD_strType.Position;
    end;
    stPos.X  := random(reih);
    stPos.Y  := random(spalt);
    taPos.X  := random(reih);
    taPos.Y  := random(spalt);
    setStreetPara(stPos, taPos, strType)
  end;
  newLines := true;
  lookForStreets;
  tempImg.Free;
  repaintAgents;
end;

procedure TForm1.setStreetPara(stPos, taPos: TPoint; strType: Integer);
begin
  If (stPos.X > spalt) or (stPos.Y > reih) or (taPos.X > spalt) or (taPos.Y > reih) Then Exit;
  startCell := cellList[stPos.X, stPos.Y];
  SetLength(lineList, length(lineList)+1);
  lineList[high(lineList)].endP := stPos;
  lineList[high(lineList)].lType:= strType;
  targetCell := cellList[taPos.X, taPos.Y];
  targetCell.reiSpa.X := taPos.X;
  targetCell.reiSpa.Y := taPos.Y;
  lineList[high(lineList)].startP := taPos;
  targWink := ArcTan2((taPos.Y - stPos.Y),(taPos.X - stPos.X));
  transLine (stPos.X, stPos.Y, strType);
end;
// ---------------------------------------------------------------------------//
// ------------------------------- Schalter ----------------------------------//
// ---------------------------------------------------------------------------//
procedure TForm1.setupFields(Sender: TObject);
var
  Style: DWord;
begin
  // --- Beschr�nkt die Eingabe auf Zahlenwerte -------------------
  Style:=GetWindowLong(Edit_anzAg.Handle, GWL_STYLE);
  SetWindowLong(Edit_anzAg.Handle, GWL_STYLE, Style or ES_NUMBER);
  SetWindowLong(Edit_cellSiz.Handle, GWL_STYLE, Style or ES_NUMBER);
  SetWindowLong(Edit_anzGr.Handle, GWL_STYLE, Style or ES_NUMBER);
  SetWindowLong(Edit_nRad.Handle, GWL_STYLE, Style or ES_NUMBER);
  SetWindowLong(Edit_mDist.Handle, GWL_STYLE, Style or ES_NUMBER);
  SetWindowLong(E_stopT.Handle, GWL_STYLE, Style or ES_NUMBER);
  SetWindowLong(E_clusterT.Handle, GWL_STYLE, Style or ES_NUMBER);
  SetWindowLong(E_nbSize.Handle, GWL_STYLE, Style or ES_NUMBER);
  // ---
  CB_strType.AddItem(' street type -3', Sender);
  CB_strType.AddItem(' street type -2', Sender);
  CB_strType.AddItem(' street type -1', Sender);
  CB_strType.AddItem(' street type +1', Sender);
  CB_strType.AddItem(' street type +2', Sender);
  CB_strType.AddItem(' street type +3', Sender);
  // --- Werte f�r die weight liste --------------------------------
  SG_weight.Cells[0,0] := 'Type';
  SG_weight.Cells[1,0] := 'Weight';
  SG_weight.Cells[0,1] := '-3';
  SG_weight.Cells[1,1] := '0';
  SG_weight.Cells[0,2] := '-2';
  SG_weight.Cells[1,2] := '0,33';
  SG_weight.Cells[0,3] := '-1';
  SG_weight.Cells[1,3] := '0,67';
  SG_weight.Cells[0,4] := '0';
  SG_weight.Cells[1,4] := '1';
  SG_weight.Cells[0,5] := '+1';
  SG_weight.Cells[1,5] := '2';
  SG_weight.Cells[0,6] := '+2';
  SG_weight.Cells[1,6] := '4';
  SG_weight.Cells[0,7] := '+3';
  SG_weight.Cells[1,7] := '8';
  // ---
  colCode1.Color := RGB(125, 38, 205);
  colCode2.Color := RGB(171, 130, 255);
  colCode3.Color := RGB(224, 102, 255);
  colCode5.Color := RGB(255, 127, 0);
  colCode6.Color := RGB(205, 102, 0);
  colCode7.Color := RGB(205, 0, 0);
end;

procedure TForm1.B_imprintClick(Sender: TObject);
begin
  lookForStreets;
end;

procedure TForm1.Button1Click(Sender: TObject);
begin
  Form2.show;
end;

procedure TForm1.Button2Click(Sender: TObject);
begin
  countInTiles;
end;

procedure TForm1.Button3Click(Sender: TObject);
begin
  TrB_thresh.Position := 100;
  Form8.show;
end;

procedure TForm1.ana_growthClick(Sender: TObject);
begin
  Form4.show;
  Timer1.enabled := false;
end;

procedure TForm1.ana_psClick(Sender: TObject);
begin
  Form3.show;
  Timer1.enabled := false;
end;

procedure TForm1.B_adjGroupSzClick(Sender: TObject);
begin
  Form9.show;
end;

procedure TForm1.B_anaStrClick(Sender: TObject);
begin
  Form5.show;
  Timer1.enabled := false;
end;

procedure TForm1.B_clusterClick(Sender: TObject);
begin
  startCAna
end;

procedure TForm1.b_delStrClick(Sender: TObject);
begin
  deleteStreets;
end;

procedure TForm1.deleteStreets;
begin
  setStreetList;
  preserveStreets;
  repaintAgents;
end;

procedure TForm1.B_repaintAllClick(Sender: TObject);
begin
  repaintAgents;
end;

procedure TForm1.B_repaintClick(Sender: TObject);
begin
  repaintAgents;
end;

procedure TForm1.Edit_anzAgChange(Sender: TObject);
var
  gesamt : Cardinal;
begin
  gesamt := reih * spalt;
  If StrToInt(Edit_anzAg.Text) > (gesamt) Then
     Edit_anzAg.Text := IntToStr (gesamt - round(gesamt*0.05));
  //If StrToInt(Edit_anzAg.Text) < StrToInt(Edit_anzGr.Text) Then
    // Edit_anzAg.Text := IntToStr(StrToInt(Edit_anzGr.Text)*2);
end;

procedure TForm1.Edit_anzGrChange(Sender: TObject);
begin
  If StrToInt(Edit_anzGr.Text) < 1 Then
    Edit_anzGr.Text := IntToStr (1);
end;

procedure TForm1.Edit_cellSizChange(Sender: TObject);
begin
  If StrToInt(Edit_cellSiz.Text) > (ZeichenPanel.Width/20) Then
    Edit_cellSiz.Text := IntToStr (floor (ZeichenPanel.Width / 20));
  If StrToInt(Edit_cellSiz.Text) < 1 Then
    Edit_cellSiz.Text := IntToStr (1);
end;

procedure TForm1.Edit_mDistChange(Sender: TObject);
begin
  If StrToInt(Edit_mDist.Text) > (reih/2) Then
     Edit_mDist.Text := IntToStr (floor (reih)-1);
  If StrToInt(Edit_mDist.Text) < 1 Then
     Edit_mDist.Text := IntToStr (1);
end;

procedure TForm1.Edit_nRadChange(Sender: TObject);
begin
  //If StrToInt(Edit_nRad.Text) > (reih/2) Then
    //Edit_nRad.Text := IntToStr (floor (reih / 2)-1);
  If StrToInt(Edit_nRad.Text) < 1 Then
    Edit_nRad.Text := IntToStr (1);
end;

procedure TForm1.E_nbSizeChange(Sender: TObject);
begin
  nbS := StrToInt(E_nbSize.Text);
  //If StrToInt(E_nbSize.Text) < 2 Then E_nbSize.Text := IntToStr (2);
end;

procedure TForm1.E_stopTChange(Sender: TObject);
begin
  stopT := StrToInt(E_stopT.Text);
end;

procedure TForm1.B_setTolsClick(Sender: TObject);
begin
  Form8.setValues;
end;

procedure TForm1.B_setupClick(Sender: TObject);
begin
  deleter;
  lbl_Steps.Caption := IntToStr (steps);
  If newLines Then lookForStreets;
end;

procedure TForm1.deleter;
var
 I, K     : Integer;
 curCell  : TCell;
 curAgent : TAgent;
begin
  for I := 0 to reih -1 do
  begin
    for K := 0 to spalt -1 do
    begin
      curCell := cellList[K,I];
      curCell.Destroy;
    end;
  end;
  SetLength(cellList, 0, 0);
  for I := 0 to AgentList.Count - 1 do
  begin
    curAgent := AgentList.Items [I];
    curAgent.Destroy;
  end;
  for I := 0 to ngGroups do
  begin
    E_Rents[I].Free;
    lbl_Rents[I].Free;
  end;
  SetLength(E_Rents, 0);
  SetLength(lbl_Rents, 0);
  AgentList.Free;
  SetLength(cellList, 0, 0);
  paintImg.Free;
  Setup;
  Form2.resetGraph;
end;

procedure TForm1.B_stabiliClick(Sender: TObject);
begin
  Form6.show;
  Timer1.enabled := false;
  B_stop.Font.Color := clRed;
end;

procedure TForm1.B_stopClick(Sender: TObject);
begin
  If B_stop.Font.Color = clRed Then B_stop.Font.Color := clGreen
                               Else B_stop.Font.Color := clRed;
  resetCluster;
  If (Timer1.Enabled = false) And newLines Then begin
    lookForStreets;
    repaintAgents;
  end;
  Timer1.enabled := not(Timer1.enabled);
end;

procedure TForm1.FormDestroy(Sender: TObject);
begin
  paintImg.Free;
  ZeichenPanel.Free;
  AgentList.Destroy;
end;

// =============================================================================
// *** save procedures *********************************************************
// =============================================================================
{procedure TForm1.B_saveBmpClick(Sender: TObject);
begin
  saveBmp;
end;
// *****************************************************************************
procedure TForm1.B_saveXMLClick(Sender: TObject);
begin
  saveXLS;
end;}
// *****************************************************************************
procedure TForm1.saveBmp (step: String);
var
  path    : String;
  Filename: String;
  Img     : TBitmap;
begin
  path := ExtractFilePath(Application.ExeName);
  Img := TBitMap.Create;
  If cb_save_main.Checked Then begin                                          // -- save main window
    Img := Form1.GetFormImage;
    Filename := path+'pictures\'+E_sRound.Text+'_0'+step+'_main_'+E_sName.Text;
    Img.SaveToFile(Filename+'.bmp');
    BmpToJpg(Filename, 100);
  end;
  If cb_save_basic.Checked Then begin                                         // -- save bacis process record charts
    Img := Form2.GetFormImage;
    Filename := path+'pictures\'+E_sRound.Text+'_0'+step+'_basic_'+E_sName.Text;
    Img.SaveToFile(Filename+'.bmp');
    BmpToJpg(Filename, 100);
  end;
  If cb_save_paraSp.Checked Then begin                                        // -- save parameter-space window
    Img := Form3.GetFormImage;
    Filename := path+'pictures\'+E_sRound.Text+'_0'+step+'_paraSpace_'+E_sName.Text;
    Img.SaveToFile(Filename+'.bmp');
    BmpToJpg(Filename, 100);
  end;
  If cb_save_growth.Checked Then begin                                        // -- save growth window
    Img := Form4.GetFormImage;
    Filename := path+'pictures\'+E_sRound.Text+'_0'+step+'_growth_'+E_sName.Text;
    Img.SaveToFile(Filename+'.bmp');
    BmpToJpg(Filename, 100);
  end;
  If cb_save_streets.Checked Then begin                                       // -- save streets window
    Img := Form5.GetFormImage;
    Filename := path+'pictures\'+E_sRound.Text+'_0'+step+'_streets_'+E_sName.Text;
    Img.SaveToFile(Filename+'.bmp');
    BmpToJpg(Filename, 100);
  end;
  If cb_save_stability.Checked Then begin                                     // -- save stability window
    Img := Form6.GetFormImage;
    Filename := path+'pictures\'+E_sRound.Text+'_0'+step+'_stability_'+E_sName.Text;
    Img.SaveToFile(Filename+'.bmp');
    BmpToJpg(Filename, 100);
  end;
  If cb_save_3DSurf.Checked Then begin                                        // -- save 3D-stability surface window
    Img := Form7.GetFormImage;
    Filename := path+'pictures\'+E_sRound.Text+'_0'+step+'_stabSurf3D_'+E_sName.Text;
    Img.SaveToFile(Filename+'.bmp');
    BmpToJpg(Filename, 100);
  end;
  Img.Free;
  saveXLS(step);
end;
// *****************************************************************************
procedure TForm1.saveXLS (step: String);
var
  path : String;
begin
  path := ExtractFilePath(Application.ExeName);
  If cb_save_3DSurf.Checked Then begin
    with TSeriesDataXLS.Create(Form7.Chart_3DLand, nil) do
    try
      IncludeHeader:=True;
      SaveToFile(path+'data\'+E_sRound.Text+'_0'+step+'_stabSurf3D_'+E_sName.Text+'.xls');
    finally
      Free;
    end;
  end;
end;
// *****************************************************************************
Procedure TForm1.BmpToJpg(const Filename: String; Quality: TJPEGQualityRange=100);
var
  Bmp: TBitmap;
  Jpg: TJpegImage;
begin
  Bmp:=TBitmap.Create;
  Jpg:=TJpegImage.Create;
  try
    Bmp.LoadFromFile(Filename+'.bmp');
    Jpg.CompressionQuality:=Quality;
    Jpg.Assign(Bmp);
    Jpg.SaveToFile(ChangeFileExt(Filename, '.jpg' ));
  finally
    Jpg.Free;
    Bmp.Free;
  end;
  if FileExists(FileName+'.bmp')then deletefile(FileName+'.bmp');             // -- bitmap l�schen 
end;
// *****************************************************************************

end.



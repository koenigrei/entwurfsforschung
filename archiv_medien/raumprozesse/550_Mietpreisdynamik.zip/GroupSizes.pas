unit GroupSizes;

interface

uses
  Windows, Messages, SysUtils, Variants, Classes, Graphics, Controls, Forms,
  Dialogs, comCtrls, StdCtrls, math;

type
  TForm9 = class(TForm)
    B_reset: TButton;
    procedure FormCreate(Sender: TObject);
    procedure B_resetClick(Sender: TObject);
  private
    procedure TacksCreate;
    procedure TrackBarsChange(Sender: TObject);
    procedure setToNorm;
  public
    { Public declarations }
  end;

var
  Form9: TForm9;
  TrackBars   : Array of TTrackBar;
  TrackLabels : Array of TLabel;
  ColorLabels : Array of TLabel;
  realPercent : Array of Real;
  sumAgents   : Integer;

implementation

{$R *.dfm}
uses CellForm;

procedure TForm9.FormCreate(Sender: TObject);
begin
  TacksCreate;
end;

procedure TForm9.TacksCreate;
var
  I : Integer;
begin
  SetLength (TrackBars, ngGroups);
  SetLength (TrackLabels, ngGroups);
  SetLength (ColorLabels, ngGroups);
  SetLength (realPercent, ngGroups);
  sumAgents := StrToInt(Form1.Edit_anzAg.Text);
  For I:=0 To ngGroups-1 Do
  begin
    // --- Create the track bars ---------------------
    TrackBars[I] := TTrackBar.Create(self);
    TrackBars[I].Parent     := Form9;
    TrackBars[I].Height     := 45;
    TrackBars[I].Width      := 150;
    TrackBars[I].Left       := 5;
    TrackBars[I].Top        := 20 + I*60;
    TrackBars[I].Min        := 1;
    TrackBars[I].Max        := 99;
    TrackBars[I].Frequency  := 10;
    TrackBars[I].PageSize   := 1;
    TrackBars[I].Position   := floor(100/ngGroups);
    realPercent[I]          := 100/ngGroups;
    TrackBars[I].Name       := 't'+IntToStr(I);
    TrackBars[I].OnChange   := TrackBarsChange;
    //TrackBars[I].InheritsFrom(TControl);
    //TrackBars[I].onMouseUp := TrackBarsChange;
    // --- Create the track labels -------------------
    TrackLabels[I] := TLabel.Create(self);
    TrackLabels[I].Parent   := Form9;
    TrackLabels[I].Left     := 20;
    TrackLabels[I].Top      := 5 + I*60;
    TrackLabels[I].Caption  := 'Size of Group '+IntToStr(I+1)+' = '+
                               IntToStr(round(realPercent[I] *0.01 *sumAgents));
    TrackLabels[I].Name     := 'TrackLabel'+IntToStr(I+1);
    // --- Create the color labels -------------------
    ColorLabels[I] := TLabel.Create(self);
    ColorLabels[I].Parent   := Form9;
    ColorLabels[I].Left     := 155;
    ColorLabels[I].Top      := 10 + I*60;
    ColorLabels[I].Height   := 40;
    ColorLabels[I].Width    := 40;
    ColorLabels[I].Color    := farbList[I];
  end;
  B_reset.Top   := 5 + ngGroups*60;
  Form9.Width   := 210;
  Form9.Height  := 70 + ngGroups*60;;
end;

procedure TForm9.TrackBarsChange(Sender: TObject);
var
  curTrackBar        : TTrackBar;
  curSize, sumOthers : Integer;
  allDiff, oneDiff, minAgs   : Integer;
  agsPerG, curPos    : Array of Integer;
  I, ind, bigGroups  : Integer;
  tmpInd             : String;
  bigEnough          : Boolean;
begin
try
  For I:=0 To ngGroups-1 Do
  begin
    TrackBars[I].OnChange   := nil;         // -- onChange deaktivieren, damit nicht endlos ausgel�st wird wenn unten positionen der trackbars ge�ndert werden.
  end;

  SetLength (agsPerG, ngGroups);
  SetLength (curPos, ngGroups);
  curTrackBar := Sender as TTrackBar;
  tmpInd := '0000';
  sumOthers := 0;
  For I:=1 to length(curTrackBar.Name)-1 Do
  begin
    tmpInd[5-I] := curTrackBar.Name[I+1];
  end;
  ind := StrToInt(tmpInd);                  // -- convert the index...

  realPercent[ind] := curTrackBar.Position;
  For I:=0 To ngGroups-1 Do                 // -- sum all group sizes without the current one
  begin
    If not (I = ind) Then begin
      agsPerG[I] := round(realPercent[I] *0.01 *sumAgents);
      sumOthers  := sumOthers + agsPerG[I];
    end;
  end;
  curSize := round(realPercent[ind]*0.01*sumAgents);
  agsPerG[ind] := curSize;

  allDiff := sumAgents - (sumOthers + curSize);
  minAgs  := round(0.01*sumAgents);
  Repeat
    bigGroups := 0;
    For I:=0 To ngGroups-1 Do                 // -- count the groups larger than 0
    begin
      If not (I = ind) Then begin
        If agsPerG[I] > minAgs Then inc(bigGroups);
      end;
    end;
    If bigGroups=0 then abort;

    oneDiff   := round (allDiff/bigGroups);
    sumOthers := 0;
    bigEnough := true;
    For I:=0 To ngGroups-1 Do                 // -- check if the group sizes are large enough for a substraction
    begin
      If not (I = ind) Then begin
        If (agsPerG[I] <= (oneDiff*-1) +minAgs) AND (agsPerG[I] > minAgs) Then begin
          allDiff   := allDiff - (agsPerG[I] - minAgs); // -- vorhandenen rest abziehen...
          agsPerG[I]:= minAgs;
          //allDiff   := allDiff - (agsPerG[I]-curPos[I]);
          dec(bigGroups);
          bigEnough := false;
        end;
        sumOthers  := sumOthers + agsPerG[I];
      end;
    end;
    If bigGroups<1 then begin
      oneDiff := 0;
    end else begin
      oneDiff := round (allDiff/bigGroups);
    end;
  until bigEnough = true;

  For I:=0 To ngGroups-1 Do                 // -- set the new trackbar positions
  begin
    If (oneDiff < 0) Then begin
      If (agsPerG[I] > minAgs) Then agsPerG[I] := round(agsPerG[I] + oneDiff);
    end else begin
      agsPerG[I] := round(agsPerG[I] + oneDiff);
    end;
    realPercent[I] := agsPerG[I]/(0.01 *sumAgents);
    If not (I = ind) Then begin
      TrackBars[I].Position := round((agsPerG[I])/sumAgents * 100);
    end;
    TrackLabels[I].Caption:= 'Size of Group '+IntToStr(I+1)+' = '+ IntToStr(round(agsPerG[I]));
  end;
  For I:=0 To ngGroups-1 Do                 // -- now, activate the onChange event again
  begin
    TrackBars[I].OnChange   := TrackBarsChange;
  end;
except
  For I:=0 To ngGroups-1 Do                 // -- now, activate the onChange event again
  begin
    TrackBars[I].OnChange   := TrackBarsChange;
  end;
end;
end;

procedure TForm9.B_resetClick(Sender: TObject);
begin
  setToNorm;
end;

procedure TForm9.setToNorm;
var I, anzAgs:Integer;
begin
  For I:=0 To ngGroups-1 Do                 // -- now, activate the onChange event again
  begin
    TrackBars[I].OnChange   := nil;
    TrackBars[I].Position   := floor(100/ngGroups);
    realPercent[I]          := 100/ngGroups;
    anzAgs := round(realPercent[I] *0.01 *sumAgents);
    TrackLabels[I].Caption  := 'Size of Group '+IntToStr(I+1)+' = '+ IntToStr(anzAgs);
    TrackBars[I].OnChange   := TrackBarsChange;
  end;
end;
end.

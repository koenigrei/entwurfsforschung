object Form1: TForm1
  Left = 600
  Top = 0
  Caption = 'Segregation by Move '
  ClientHeight = 711
  ClientWidth = 882
  Color = clBtnFace
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -10
  Font.Name = 'Tahoma'
  Font.Style = []
  OldCreateOrder = False
  Position = poDesigned
  OnCreate = FormCreate
  OnDestroy = FormDestroy
  PixelsPerInch = 96
  TextHeight = 12
  object lbl_Steps: TLabel
    Left = 737
    Top = 401
    Width = 39
    Height = 12
    Alignment = taRightJustify
    Caption = 'lbl_Steps'
  end
  object lbl_timesteps: TLabel
    Left = 782
    Top = 401
    Width = 47
    Height = 12
    Caption = ': timesteps'
  end
  object Label5: TLabel
    Left = 784
    Top = 433
    Width = 76
    Height = 12
    Caption = ': stop at timestep'
  end
  object Label6: TLabel
    Left = 817
    Top = 349
    Width = 53
    Height = 12
    Caption = ': neigh. size'
    OnClick = Label6Click
  end
  object Label7: TLabel
    Left = 817
    Top = 317
    Width = 55
    Height = 12
    Caption = ': cluster thr.'
  end
  object Label10: TLabel
    Left = 817
    Top = 379
    Width = 50
    Height = 12
    Caption = ': cell-space'
  end
  object Lbl_cellS: TLabel
    Left = 772
    Top = 379
    Width = 39
    Height = 12
    Alignment = taRightJustify
    Caption = 'lbl_Steps'
  end
  object ZeichenPanel: TPanel
    Left = 8
    Top = 8
    Width = 694
    Height = 694
    BorderStyle = bsSingle
    DockSite = True
    TabOrder = 0
  end
  object B_setup: TButton
    Left = 711
    Top = 196
    Width = 74
    Height = 25
    Caption = 'new Setup'
    TabOrder = 1
    OnClick = B_setupClick
  end
  object B_stop: TButton
    Left = 791
    Top = 196
    Width = 82
    Height = 25
    Caption = 'start / stop'
    TabOrder = 2
    OnClick = B_stopClick
  end
  object GroupBox1: TGroupBox
    Left = 711
    Top = 8
    Width = 162
    Height = 182
    Caption = 'setup settings'
    TabOrder = 3
    object Lbl_TextAnzahl: TLabel
      Left = 56
      Top = 25
      Width = 86
      Height = 12
      Caption = ': number of agents'
    end
    object Label2: TLabel
      Left = 56
      Top = 51
      Width = 39
      Height = 12
      Caption = ': cell size'
    end
    object Label3: TLabel
      Left = 56
      Top = 77
      Width = 89
      Height = 12
      Caption = ': number of groups'
    end
    object Label1: TLabel
      Left = 56
      Top = 103
      Width = 93
      Height = 12
      Caption = ': radius neighbourh.'
    end
    object Label4: TLabel
      Left = 56
      Top = 129
      Width = 71
      Height = 12
      Caption = ': move distance'
    end
    object Edit_anzAg: TEdit
      Left = 9
      Top = 21
      Width = 41
      Height = 20
      TabOrder = 0
      Text = '12783'
      OnChange = Edit_anzAgChange
    end
    object Edit_cellSiz: TEdit
      Left = 26
      Top = 47
      Width = 24
      Height = 20
      TabOrder = 1
      Text = '6'
      OnChange = Edit_cellSizChange
    end
    object Edit_anzGr: TEdit
      Left = 26
      Top = 73
      Width = 24
      Height = 20
      TabOrder = 2
      Text = '6'
      OnChange = Edit_anzGrChange
    end
    object Edit_nRad: TEdit
      Left = 26
      Top = 99
      Width = 24
      Height = 20
      TabOrder = 3
      Text = '5'
      OnChange = Edit_nRadChange
    end
    object Edit_mDist: TEdit
      Left = 26
      Top = 125
      Width = 24
      Height = 20
      TabOrder = 4
      Text = '55'
      OnChange = Edit_mDistChange
    end
    object CB_graphicUpd: TCheckBox
      Left = 9
      Top = 151
      Width = 133
      Height = 17
      Caption = 'run with graphic (slower)'
      Checked = True
      State = cbChecked
      TabOrder = 5
    end
  end
  object B_cluster: TBitBtn
    Left = 708
    Top = 310
    Width = 75
    Height = 26
    Caption = 'cluster analysis'
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clWindowText
    Font.Height = -10
    Font.Name = 'Tahoma'
    Font.Style = []
    ParentFont = False
    TabOrder = 4
    OnClick = B_clusterClick
  end
  object Button1: TButton
    Left = 708
    Top = 277
    Width = 75
    Height = 25
    Caption = 'show charts'
    TabOrder = 5
    OnClick = Button1Click
  end
  object E_stopT: TEdit
    Left = 737
    Top = 429
    Width = 41
    Height = 20
    TabOrder = 6
    Text = '500'
    OnChange = E_stopTChange
  end
  object Button2: TButton
    Left = 708
    Top = 344
    Width = 75
    Height = 25
    Caption = 'dissimilar'
    TabOrder = 7
    OnClick = Button2Click
  end
  object E_nbSize: TEdit
    Left = 789
    Top = 346
    Width = 25
    Height = 20
    TabOrder = 8
    Text = '20'
    OnChange = E_nbSizeChange
  end
  object Button3: TButton
    Left = 708
    Top = 590
    Width = 163
    Height = 25
    Caption = 'analyse parameterspace'
    TabOrder = 9
    OnClick = Button3Click
  end
  object B_repaint: TButton
    Left = 792
    Top = 227
    Width = 82
    Height = 25
    Caption = 'repaint all'
    TabOrder = 10
    OnClick = B_repaintClick
  end
  object E_clusterT: TEdit
    Left = 789
    Top = 313
    Width = 25
    Height = 20
    TabOrder = 11
    Text = '1'
  end
  object GroupBox2: TGroupBox
    Left = 708
    Top = 471
    Width = 166
    Height = 90
    Caption = 'tolerance settings'
    TabOrder = 12
    object Label8: TLabel
      Left = 16
      Top = 28
      Width = 49
      Height = 12
      Caption = 'threshold :'
    end
    object Lbl_P: TLabel
      Left = 71
      Top = 28
      Width = 15
      Height = 12
      Caption = '___'
    end
    object Label9: TLabel
      Left = 92
      Top = 28
      Width = 10
      Height = 12
      Caption = '%'
    end
    object TrB_thresh: TTrackBar
      Left = 3
      Top = 46
      Width = 160
      Height = 41
      Max = 100
      PageSize = 5
      Frequency = 10
      Position = 20
      TabOrder = 0
      OnChange = TrB_threshChange
    end
  end
  object Timer1: TTimer
    Interval = 1
    OnTimer = Timer1Timer
    Left = 712
    Top = 232
  end
end

(********************************************************************)
(*                                                                  *) 
(*                                                                  *)
(*                     Segregation - Toleranze                      *)
(*                          Version 1.0                             *)
(*                                                                  *)
(*                                                                  *)
(*     Programmierer: Reinhard K�nig                 September 2006 *)
(*                    http://www.entwurfsforschung.de               *)
(*                                                                  *)
(*     Last Update: Sept-25, 2005                                   *)
(*                                                                  *)
(********************************************************************) 
{revision history:

1.0     [Sept-25, 2005]
        first release to the public
}

unit CellForm;

interface

uses
  Windows, Messages, SysUtils, Classes, Graphics, Controls, Forms,
  Dialogs, StdCtrls, cell_P, Math, agenten, ExtCtrls, ComCtrls, Buttons;

type
  TDreierArray = Array of Array of Array of Cardinal;

type
  TForm1 = class(TForm)
    ZeichenPanel   : TPanel;
    Timer1         : TTimer;
    B_setup        : TButton;
    B_stop         : TButton;
    GroupBox1      : TGroupBox;
    Edit_anzAg     : TEdit;
    Lbl_TextAnzahl : TLabel;
    Edit_cellSiz   : TEdit;
    Label2         : TLabel;
    Edit_anzGr     : TEdit;
    Label3         : TLabel;
    Edit_nRad      : TEdit;
    Label1         : TLabel;
    lbl_Steps      : TLabel;
    lbl_timesteps  : TLabel;
    Label4         : TLabel;
    Edit_mDist     : TEdit;
    B_cluster      : TBitBtn;
    Button1        : TButton;
    Label5         : TLabel;
    E_stopT        : TEdit;
    Button2        : TButton;
    Label6         : TLabel;
    E_nbSize       : TEdit;
    Button3        : TButton;
    CB_graphicUpd  : TCheckBox;
    B_repaint      : TButton;
    Label7         : TLabel;
    E_clusterT     : TEdit;
    GroupBox2      : TGroupBox;
    Label8         : TLabel;
    Lbl_P          : TLabel;
    Label9         : TLabel;
    TrB_thresh     : TTrackBar;
    Label10        : TLabel;
    Lbl_cellS      : TLabel;
    procedure B_stopClick   (Sender: TObject);
    procedure B_setupClick  (Sender: TObject);
    procedure Timer1Timer   (Sender: TObject);
    procedure FormDestroy   (Sender: TObject);
    procedure FormCreate    (Sender: TObject);
    procedure Edit_anzAgChange(Sender: TObject);
    procedure Edit_nRadChange(Sender: TObject);
    procedure Edit_mDistChange(Sender: TObject);
    procedure B_clusterClick(Sender: TObject);
    procedure Button1Click(Sender: TObject);
    procedure Button2Click(Sender: TObject);
    procedure E_nbSizeChange(Sender: TObject);
    procedure E_stopTChange(Sender: TObject);
    procedure Edit_anzGrChange(Sender: TObject);
    procedure Edit_cellSizChange(Sender: TObject);
    procedure Label6Click(Sender: TObject);
    procedure Button3Click(Sender: TObject);
    procedure B_repaintClick(Sender: TObject);
    procedure TrB_threshChange(Sender: TObject);
  private
    AgentList    : TList;
    cellList     : Array of Array of TCell;
    procedure checkNei      (K, I: Integer);
    procedure torus         (var Xp: Integer; var Yp: Integer);
    procedure testLocation  (K, I: Integer; var similar : Double);
    procedure moveAgent     (oldPos: TPoint; newPos: TPoint; curAgent: TAgent);
    procedure chooseCol     (anzahl:integer; var farbListe: colList);
    procedure createPaintImg;
    procedure createRaster;
    procedure createAgents;
    procedure setupCells;
    procedure setupAgents;
    procedure calcAgents;
    procedure repaintAll;
    procedure checkMoore (K, I: Integer);
    procedure findCluster (K, I : Integer; clustNr :Integer);
    procedure resetCluster;
    procedure speedMeasure;
    procedure calcChart;
    procedure countInTiles;
    procedure IDissimilar(ctInTiles: TDreierArray; tiles: Cardinal);
  public
    procedure startCAna;
    procedure actions;
    procedure Setup;
    procedure deleter;
end;

var
  Form1    : TForm1;
  paintImg : TImage;
  cellScal : Integer;                     //-- Zellen  gr��e
  AgSize   : Integer;                     //-- Agenten gr��e
  halfScal : Integer;
  reih     : Integer;                     //-- Zellen-Reihen gesamt
  spalt    : Integer;                     //-- Zellen-Spalten gesamt
  steps    : Cardinal;
  nbRad    : Integer;
  moveDist : Integer;
  stopT    : Cardinal;                    // -- stop Time-step
  nbS      : Cardinal;                    // -- tile size for the segregation index
  farbList : colList;                     // -- the agent's colors
  ngGroups : Integer;                     // -- number of Groups
  Frames, StartTick : Cardinal;           // -- for the fps measure
  clustCount: Array of Array of Integer;  // -- count the members of each cluster
  groupSz  : Array of Integer;            // -- number of agents in each group (color)
  grapUpd  : Boolean;
  satiThr  : Cardinal;

implementation

{$R *.dfm}
uses Analyse, Parameterspace;

//var

// ---------------------------------------------------------------------------//
// *** Initialisierung ***
procedure TForm1.FormCreate(Sender: TObject);
begin
  setup;
end;

// *** Initialisierung ***
procedure TForm1.Setup;
begin
  cellScal  := StrToInt(Edit_cellSiz.Text);
  nbRad     := StrToInt(Edit_nRad.Text);
  moveDist  := StrToInt(Edit_mDist.Text);
  AgSize    := Floor (cellScal/2);               //-- Agenten gr��e
  halfScal  := round(cellScal/2);
  spalt     := round (ZeichenPanel.Width / cellScal);
  reih      := round (ZeichenPanel.Height / cellScal);
  ngGroups  := StrToInt(Edit_anzGr.Text);
  AgentList := TList.Create;
  SetLength(cellList, spalt, reih);
  createPaintImg;
  CreateRaster;
  CreateAgents;
  steps   := 0;
  nbS     := StrToInt(E_nbSize.Text);
  stopT   := StrToInt(E_stopT.Text);
  satiThr := TrB_thresh.Position;
  grapUpd := CB_graphicUpd.Checked;
  Lbl_P.Caption     := FloatToStr(TrB_thresh.Position);
  Lbl_cellS.Caption := IntToStr(reih) + ' x ' + IntToStr(spalt) +' = ' + IntToStr(reih*spalt);
end;

// ---------------------------------------------------------------------------//
// ------------------------- Elemente erstellen ------------------------------//
// ---------------------------------------------------------------------------//

// *** Legt eine leere Zeichenfl�che �ber das Zeichenpanel *********************
procedure TForm1.createPaintImg;
begin
  paintImg        := TImage.Create(self);
  paintImg.Parent := ZeichenPanel;
  paintImg.top    := 0;
  paintImg.Left   := 0;
  paintImg.Height := ZeichenPanel.Height;
  paintImg.Width  := ZeichenPanel.Width;
end;

// *** Agenten erstellen *******************************************************
procedure TForm1.CreateAgents;
var
  I        : Integer;
  curAgent : TAgent;
begin
  for I := 1 to StrToInt(Edit_anzAg.Text) do
  begin
    curAgent := TAgent.Create;
    AgentList.Add (curAgent);
  end;
  setupAgents;
end;

// *** Agenten initialisieren **************************************************
procedure TForm1.setupAgents;
var
  curAgent : TAgent;
  I        : Integer;
  resc     : Integer;
begin
  Randomize();
  chooseCol(ngGroups, farbList);
  SetLength(groupSz,  0);
  SetLength(groupSz,  ngGroups);
  for I := 0 to AgentList.Count - 1 do
  begin
    curAgent := AgentList.Items [I];
    resc := 0;
    repeat
      resc := resc +1;
      If resc > 1000 then break;                                             // -- break condition
      curAgent.onCell.X := random (spalt);
      curAgent.onCell.Y := random (reih);
    until cellList[curAgent.onCell.X, curAgent.onCell.Y].besetzt = false;
    curAgent.PosX     := curAgent.onCell.X * cellScal + halfScal;
    curAgent.PosY     := curAgent.onCell.Y * cellScal + halfScal;
    curAgent.Size     := AgSize;
    curAgent.Stopped  := False;
    curAgent.State    := random(ngGroups)+1;
    curAgent.Color    := farbList[(curAgent.State-1)];
    curAgent.Paint   (paintImg.Canvas);
    cellList[curAgent.onCell.X, curAgent.onCell.Y].besetzt := true;
    cellList[curAgent.onCell.X, curAgent.onCell.Y].state := curAgent.State;
    inc(groupSz[(curAgent.State-1)]);
  end;
end;

// *** Zellen erstellen ********************************************************
procedure TForm1.CreateRaster;
var
  curCell : TCell;
  I       : Integer;
  K       : Integer;
  creaPt  : TPoint;
begin
  for I := 0 to reih -1 do
  begin
    for K := 0 to spalt -1 do
    begin
      creaPt.X := halfScal + K * cellScal;
      creaPt.Y := halfScal + I * cellScal;
      curCell  := TCell.Create(creaPt.X, creaPt.Y, halfScal, 0);
      cellList[K,I] := curCell;
    end;
  end;
  setupCells;
end;

// *** Zellen initialisieren ***************************************************
procedure TForm1.setupCells;
var
  curCell : TCell;
  I, K    : Integer;
begin
  for I := 0 to reih -1 do
  begin
    for K := 0 to spalt -1 do
    begin
      curCell         := cellList[K,I];
      curCell.besetzt := false;
      curCell.colr    := 180;
      curCell.state   := 0;
      curCell.clCeck  := false;
      curCell.Paint(paintImg.Canvas);
    end;
  end;
end;

// ---------------------------------------------------------------------------//
// ---------------------------- Berechnungen ---------------------------------//
// ---------------------------------------------------------------------------//

// *** Iterativ Befehle ausf�hren **********************************************
procedure TForm1.Timer1Timer(Sender: TObject);
begin
  actions;
  If steps = stopT Then Timer1.Enabled:= false;
end;

procedure TForm1.actions;
begin
  calcAgents;
  inc(steps);                                                                // -- ver�ndert die Position der Agenten
  lbl_Steps.Caption := IntToStr (steps);
  calcChart;
  speedMeasure;
  If steps = stopT Then Timer1.Enabled:= false;
end;

// *** fps measure *************************************************************
procedure TForm1.speedMeasure;
var
  Framespersecond   : Cardinal;
begin
  Inc(Frames);
  if GetTickCount - StartTick >=1000 then
  begin  
    Framespersecond:= round(Frames/(GetTickCount - StartTick)*1000);
    StartTick := GetTickCount;
    Frames := 0;
    Form1.Caption := 'Group seperation || ' + 'fps= ' + IntToStr(Framespersecond);
  end;
end;

// *****************************************************************************
// *** Clusterparameter zur�cksetzen *******************************************
procedure TForm1.resetCluster;
var
  curCell : TCell;
  I, K    : Integer;
begin
  for I := 0 to reih -1 do
  begin
    for K := 0 to spalt -1 do
    begin
      curCell    := cellList[K,I];
      setLength (curCell.sameNB, 0);
      curCell.clCeck := false;
    end;
  end;
end;

// *** calculate dissimilar index **********************************************
procedure TForm1.countInTiles;
var
  curCell    : TCell;
  I, K, L, M : Integer;
  tiles            : Cardinal;
  inReih, inSpalt  : Cardinal;
  nbSizeR, nbSizeS : Cardinal;
  ctInTiles        : TDreierArray;                                            // -- count the group members in each tile
begin
  nbSizeR := nbS;
  nbSizeS := nbS;
  inSpalt := 0;
  inReih  := 0;
  tiles   := ceil((reih) / nbS);
  setlength (ctInTiles, tiles, tiles, ngGroups);
  resetCluster;
  For L := 0 to tiles-1 Do
  begin
    For M := 0 to tiles-1 Do
    begin
      // --- one tile ------------------------
      for I := inReih to inReih + nbSizeR-1 do                                // -- reihe
      begin
        for K := inSpalt to inSpalt + nbSizeS-1 do                            // -- spalte
        begin
          curCell := cellList[K,I];
          IF curCell.state > 0 Then begin
            inc(ctInTiles[M, L, curCell.state-1]);                            // -- z�hlt Zellen mit anderem Status
            //curCell.Colr := clWhite;                                        // -- activate to test, if every cell is checked
            //curCell.Paint(paintImg.Canvas)
          end;
        end;
      end;
      // -------------------------------------
      inSpalt := inSpalt + nbSizeS;
      If (inSpalt + nbSizeS) > spalt-1 Then nbSizeS := (spalt - inSpalt);
    end;
    inReih  := inReih + nbSizeR;
    inSpalt := 0;
    nbSizeS := nbS;
    If (inReih + nbSizeR) > reih-1 Then nbSizeR := (reih - inReih);
  end;
  IDissimilar (ctInTiles, tiles);
end;

// *** calculate dissimilar index **********************************************
procedure TForm1.IDissimilar (ctInTiles: TDreierArray; tiles: Cardinal);
var
  L, M, V, W : Integer;
  sumTyp     : Array of Array of Extended;                                    // -- Dissimilarit�tsindex
  segIdx     : Array of Extended;                                             // -- Segregationsindex
  sumGes     : Extended;                                                      // -- Sum of the population without the current group
begin
  SetLength (sumTyp, 0, 0);
  SetLength (sumTyp, ngGroups, ngGroups);
  SetLength (segIdx, 0);
  SetLength (segIdx, ngGroups);
  setlength (ctInTiles, tiles, tiles, ngGroups);
  resetCluster;
  For L := 0 to tiles-1 Do
  begin
    For M := 0 to tiles-1 Do
    begin
      For V:= 0 To ngGroups -1 Do
      begin
        For W := V+1 To ngGroups -1 Do
        begin
          sumTyp[W, V] := sumTyp[W, V] + abs(
          (ctInTiles[M, L, V]/groupSz[V] * 100)-(ctInTiles[M, L, W]/groupSz[W] * 100));
        end;
        sumGes := 0;
        For W := 0 To ngGroups -1 Do
        begin
          If not (W=V) Then
            sumGes := sumGes + (ctInTiles[M, L, W]);
        end;
        segIdx[V] := segIdx[V] + abs(
        (ctInTiles[M, L, V]/groupSz[V] * 100)-(sumGes/(StrToInt(Edit_anzAg.Text)-groupSz[V]) * 100));
      end;
    end;
  end;
  For V:= 0 To ngGroups-1  Do
  begin
    For W := V To ngGroups-1  Do
    begin
      sumTyp[W, V] := 0.5 * sumTyp[W, V];
      Form2.DissimiGrid.Cells[W+1, V+1] := FloatToStr(roundTo(sumTyp[W, V], -2));
    end;
    segIdx[V] := 0.5 * segIdx[V];
    Form2.DissimiGrid.Cells[V+1, ngGroups+1] := FloatToStr(roundTo(segIdx[V],-2));
    isSer[V].AddXY(steps, segIdx[V]);
  end;
end;

procedure TForm1.Label6Click(Sender: TObject);
begin

end;

// *** Cluster Analyse *********************************************************
procedure TForm1.startCAna;
var
  curCell    : TCell;
  I, K       : Integer;
  clustNr    : Integer;
begin
  SetLength (clustCount, 0, 0);
  setLength (clustCount, ngGroups);
  resetCluster;
  clustNr := 1;
  for I := 0 to reih -1 do
  begin
    for K := 0 to spalt -1 do
    begin
      curCell := cellList[K,I];
      If (curCell.state > 0) and ( curCell.clCeck = false) Then
      begin
        CellList[K,I].clCeck := true;
        setLength(clustCount[CellList[K,I].state-1], length(clustCount[CellList[K,I].state-1])+1);
        inc(clustCount[curCell.state-1, High(clustCount[curCell.state-1])]);
        findCluster (K,I, clustNr);
        inc (clustNr);
      end;
    end;
  end;
  Form2.setClusterGraph;
end;

// *** Cluster Analysieren *****************************************************
procedure TForm1.findCluster (K, I :Integer; clustNr :Integer);
var
  curCell  : TCell;
  M        : Integer;
begin
  curCell  := CellList[K, I];
  //createLbl  (K,I, IntToStr(clustNr));
  checkMoore (K,I);
  for M := 0 to High(curCell.sameNB) do
  begin
    findCluster(curCell.sameNB[M].X, curCell.sameNB[M].Y, clustNr)            // -- Rekursion
  end;
  //Form2.show;
end;

// *** Moorsche Nachbarschaft, mit den Abstand 1 �berpr�fen ********************
procedure TForm1.checkMoore (K, I: Integer);
var
  v        : Integer;
  Xp, Yp   : Integer;
  koNei    : Array [0..3] of TPoint;
  curCell  : TCell;
begin
  // --- Summe berechnen ---
  koNei[0].X := K;    koNei[0].Y := I + 1;
  koNei[1].X := K;    koNei[1].Y := I - 1;
  koNei[2].X := K+1;  koNei[2].Y := I;
  koNei[3].X := K-1;  koNei[3].Y := I;

  for v := 0 to 3 do
  begin
    Xp := koNei[v].X;
    Yp := koNei[v].Y;
    torus(Xp, Yp);                                                            // -- Torus check
    curCell := cellList[K, I];                                                   
    If ((cellList[Xp, Yp].state = curCell.state) AND (cellList[Xp, Yp].clCeck = false)) then
    begin
      setLength(curCell.sameNB, length(curCell.sameNB)+1);
      curCell.sameNB[high(curCell.sameNB)].X := Xp;
      curCell.sameNB[high(curCell.sameNB)].Y := Yp;
      cellList[Xp, Yp].clCeck := true;
      inc(clustCount[curCell.state-1, High(clustCount[curCell.state-1])]);
    end;
  end;
end;

// *****************************************************************************
// *** Ver�ndert die Position der Agenten **************************************
procedure TForm1.calcAgents;
var
  curCell     : TCell;
  curAgent    : TAgent;
  I           : Integer;
  tempPos     : TPoint;
  resc        : Integer;
  similar     : Double;
  tmpSati     : Double;
begin
  for I := 0 to AgentList.Count - 1 do
  begin
    curAgent := AgentList.Items [I];
    resc := 0;
    curCell := cellList[curAgent.onCell.X, curAgent.onCell.Y];
    If steps = 0 Then testLocation (curAgent.onCell.X, curAgent.onCell.Y, tmpSati);
    If curCell.satisfied > satiThr Then begin                                 // -- if the neighbours are statisfying,
      curAgent.Stopped := true;                                               // -- stop the agent
    end else begin
      curAgent.Stopped := false;                                              // -- otherwise look for a better location
    end;

    If curAgent.Stopped = false then                                          // -- Wenn Agent noch nicht angelagert,
    begin                                                                     // -- suche nach einem besseren Ort.
      repeat                                                                  // -- look for a unoccupied cell
        resc := resc +1;
        If resc > 1000 then break;                                            // -- break condition
        curAgent.ChangeHeading(moveDist);                                     // -- Richtungsspektrum und Distanz
        tempPos.X := curAgent.onCell.X + curAgent.stepX;
        tempPos.Y := curAgent.onCell.Y + curAgent.stepY;
        torus (tempPos.X, tempPos.Y);                                         // -- Torus
        curCell := cellList[tempPos.X, tempPos.Y];
      until curCell.besetzt = false;                                          // -- wiederholen, bis freie Zelle gefunden

      testLocation (curAgent.onCell.X, curAgent.onCell.Y, tmpSati);           // -- test new location
      cellList[curAgent.onCell.X, curAgent.onCell.Y].state   := 0;            // -- set a temporarily new state
      curCell := cellList[tempPos.X, tempPos.Y];
      curCell.State     := curAgent.State;
      testLocation (tempPos.X, tempPos.Y, similar);
      curCell.State     := 0;                                                 // -- and reset the temporarily state
      cellList[curAgent.onCell.X, curAgent.onCell.Y].state   := curAgent.State;;

      If tmpSati < similar Then                                               // -- move, if the new place is more satisfying
        moveAgent (curAgent.onCell, tempPos, curAgent);
      If grapUpd Then curAgent.Paint (paintImg.Canvas);
    end else begin
      testLocation (curAgent.onCell.X, curAgent.onCell.Y, tmpSati);
    end;
  end;
end;

// *** test if location is more satisfiying ************************************
procedure TForm1.moveAgent (oldPos: TPoint; newPos: TPoint; curAgent: TAgent);
var
  curCell : TCell;
begin
  curCell := cellList[newPos.X, newPos.Y];
  cellList[oldPos.X, oldPos.Y].besetzt := false;                              // -- alte Zelle wieder leer
  cellList[oldPos.X, oldPos.Y].state   := 0;
  If grapUpd Then cellList[oldPos.X, oldPos.Y].Paint (paintImg.Canvas);       // -- und neu zeichnen
  curAgent.onCell.X := newPos.X;
  curAgent.onCell.Y := newPos.Y;
  curAgent.PosX     := curAgent.onCell.X * cellScal + halfScal;               // -- Wenn Zelle frei, Agent bewegen ---
  curAgent.PosY     := curAgent.onCell.Y * cellScal + halfScal;
  curCell.Besetzt   := true;                                                  // -- Zelle unter Agent als besetzt markieren.
  curCell.State     := curAgent.State;      
end;

// *** test if location is more satisfiying ************************************
procedure TForm1.testLocation (K, I: Integer; var similar : Double);
var
  curCell : TCell;
  nSum    : Integer;
begin
  curCell := cellList[K, I];
  checkNei (K, I);
  nSum := curCell.neighSimi + curCell.neighDiff;
  If nSum > 0 then begin
    similar := (curCell.neighSimi/nSum) * 100;
    curCell.satisfied := similar;
  end else begin
    similar := 0;
    curCell.satisfied := 0;
  end;
end;

// *** Moorsche Nachbarschaft, mit den Abstand nbRad �berpr�fen ****************
procedure TForm1.checkNei (K, I: Integer);
var
  u  : Integer;
  v  : Integer;
  Xp : Integer;
  Yp : Integer;
  curCell : TCell;
begin
  curCell := cellList[K,I];
  curCell.neighSimi := 0;
  curCell.neighDiff := 0;
  setLength(curCell.countType, 0);
  setLength(curCell.countType, ngGroups);                                     // -- count the number of different agents in the neighbourhood
  // --- Summen berechnen ---
  for v := -nbRad to nbRad do
  begin
    for u := -nbRad to nbRad do
    begin
      Xp := K + u;
      Yp := I + v;
      torus(Xp, Yp); // -- Torus --
      If (cellList[Xp, Yp].state = curCell.state) then begin
        curCell.neighSimi := cellList[K,I].neighSimi +1;                      // -- z�hlt Zellen mit gleichem Status
      end else begin
        IF cellList[Xp, Yp].besetzt = true Then
          curCell.neighDiff := cellList[K,I].neighDiff +1;                    // -- z�hlt Zellen mit anderem Status
      end;
    end;
  end;
end;

// *** calculate the values for the chart **************************************
procedure TForm1.calcChart;
var
  curCell : TCell;
  I, K, M : Integer;
  sumSati : Array of Double;
  sumAgs  : Array of Integer;
  rest    : Word;
begin
  If steps = 1 Then Form2.resetGraph;
  setLength(sumSati, ngGroups);
  setLength(sumAgs,  ngGroups);
  for I := 0 to reih -1 do
  begin
    for K := 0 to spalt -1 do
    begin
      curCell := cellList[K, I];
      If curCell.besetzt then
      begin
        sumSati[curCell.State-1] := sumSati[curCell.State-1] + curCell.satisfied;
        sumAgs [curCell.State-1] := sumAgs [curCell.State-1] + 1;
      end;
    end;
  end;
  For M :=0 to ngGroups-1 Do
  begin
    sSer[M].AddXY(steps, sumSati[M]/sumAgs[M]);
  end;
  DivMod(steps-1, 30, rest, rest);
  If rest = 0 Then begin
    startCAna;                                                                // -- cluster analysis
  end;
  countInTiles;
end;

procedure TForm1.repaintAll;
var
  curCell  : TCell;
  curAgent : TAgent;
  I, K : Integer;
begin
  for I := 0 to reih -1 do
  begin
    for K := 0 to spalt -1 do
    begin
      curCell := cellList[K, I];
      curCell.Paint (paintImg.Canvas);
    end;
  end;
  for I := 0 to AgentList.Count - 1 do
  begin
    curAgent := AgentList.Items [I];
    curAgent.Paint (paintImg.Canvas);
  end;
end;

// ---------------------------------------------------------------------------//
// -------------------------- Funktionen -------------------------------------//
// ---------------------------------------------------------------------------//
// --- Select a Color ---
procedure TForm1.chooseCol(anzahl:integer; var farbListe: colList);
var
  number,red,green,blue,i : integer;
  step                    : real;
begin
  setlength (farbListe,anzahl);
  step:=1275/(anzahl-1);
  for i:=0 to anzahl-1 do
  begin
    number:=round(i*step);
    red:=0;
    green:=0;
    blue:=0;
    case number of
    0..255:
      begin
        red:=255;
        green:=number;
      end;
    256..510:
      begin
        red:=510-number;
        green:=255;
      end;
    511..765:
      begin
        green:=255;
        blue:=number-510;
      end;
    766..1020:
      begin
        green:=1020-number;  
        blue:=255;  
      end;  
    1021..1275:  
      begin
        red:=number-1020;  
        blue:=255;  
      end;  
    1276:  
      begin
        red:=255;  
        blue:=255;
      end;  
    end;
    farbListe[i] := rgb(red,green,blue);
  end;  
end;

// *** Torusfunktion ***********************************************************
procedure TForm1.torus (var Xp: Integer; var Yp: Integer);
begin
  if Xp < 0     then begin
     Xp := spalt + Xp;
  end else
  if Xp > spalt-1  then begin
     Xp := 0 + (Xp - spalt) ;
  end;
  if Yp < 0     then begin
     Yp := reih + Yp;
  end else
  if Yp > reih-1  then begin
     Yp := 0 + (Yp - reih) ;
  end;
end;

procedure TForm1.TrB_threshChange(Sender: TObject);
begin
  Lbl_P.Caption := FloatToStr(TrB_thresh.Position);
  satiThr       := TrB_thresh.Position;
end;

// ---------------------------------------------------------------------------//
// ------------------------------- Schalter ----------------------------------//
// ---------------------------------------------------------------------------//

procedure TForm1.Button1Click(Sender: TObject);
begin
  Form2.show;
end;

procedure TForm1.Button2Click(Sender: TObject);
begin
  countInTiles;
end;

procedure TForm1.Button3Click(Sender: TObject);
begin
  Form3.show;
  Timer1.enabled := false;
end;

procedure TForm1.B_clusterClick(Sender: TObject);
begin
  startCAna
end;

procedure TForm1.B_repaintClick(Sender: TObject);
begin
  repaintAll;
end;

procedure TForm1.Edit_anzAgChange(Sender: TObject);
var
  gesamt : Cardinal;
begin
  gesamt := reih * spalt;
  If StrToInt(Edit_anzAg.Text) > (gesamt) Then
     Edit_anzAg.Text := IntToStr (gesamt - round(gesamt*0.05));
  If StrToInt(Edit_anzAg.Text) < 2 Then
     Edit_anzAg.Text := IntToStr (2);
end;

procedure TForm1.Edit_anzGrChange(Sender: TObject);
begin
  If StrToInt(Edit_anzGr.Text) < 1 Then
    Edit_anzGr.Text := IntToStr (1);
end;

procedure TForm1.Edit_cellSizChange(Sender: TObject);
begin
  If StrToInt(Edit_cellSiz.Text) > (ZeichenPanel.Width/20) Then
    Edit_cellSiz.Text := IntToStr (floor (ZeichenPanel.Width / 20));
  If StrToInt(Edit_cellSiz.Text) < 1 Then
    Edit_cellSiz.Text := IntToStr (1);
end;

procedure TForm1.Edit_mDistChange(Sender: TObject);
begin
  If StrToInt(Edit_mDist.Text) > (reih/2) Then
     Edit_mDist.Text := IntToStr (floor (reih / 2)-1);
  If StrToInt(Edit_mDist.Text) < 1 Then
     Edit_mDist.Text := IntToStr (1);
end;

procedure TForm1.Edit_nRadChange(Sender: TObject);
begin
  If StrToInt(Edit_nRad.Text) > (reih/2) Then
    Edit_nRad.Text := IntToStr (floor (reih / 3)-1);
  If StrToInt(Edit_nRad.Text) < 1 Then
    Edit_nRad.Text := IntToStr (1);
end;

procedure TForm1.E_nbSizeChange(Sender: TObject);
begin
  nbS := StrToInt(E_nbSize.Text);
  //If StrToInt(E_nbSize.Text) < 2 Then E_nbSize.Text := IntToStr (2);
end;

procedure TForm1.E_stopTChange(Sender: TObject);
begin
  stopT := StrToInt(E_stopT.Text);
end;

procedure TForm1.B_setupClick(Sender: TObject);
begin
  deleter;
  lbl_Steps.Caption := IntToStr (steps);
end;

procedure TForm1.deleter;
var
 I, K     : Integer;
 curCell  : TCell;
 curAgent : TAgent;
begin
  for I := 0 to reih -1 do
  begin
    for K := 0 to spalt -1 do
    begin
      curCell := cellList[K,I];
      curCell.Destroy;
    end;
  end;
  SetLength(cellList, 0, 0);
  for I := 0 to AgentList.Count - 1 do
  begin
    curAgent := AgentList.Items [I];
    curAgent.Destroy;
  end;
  AgentList.Free;
  paintImg.Free;
  Setup;
  Form2.resetGraph;
end;

procedure TForm1.B_stopClick(Sender: TObject);
begin
  resetCluster;
  Timer1.enabled := not(Timer1.enabled);
end;

procedure TForm1.FormDestroy(Sender: TObject);
begin
  paintImg.Free;
  ZeichenPanel.Free;
  AgentList.Destroy;
end;

end.

program segregation_tolerance;

uses
  Forms,
  CellForm in 'CellForm.pas' {Form1},
  cell_P in 'cell_P.pas',
  agenten in 'agenten.pas',
  Analyse in 'Analyse.pas' {Form2},
  Parameterspace in 'Parameterspace.pas' {Form3};

{$R *.res}

begin
  Application.Initialize;
  Application.CreateForm(TForm1, Form1);
  Application.CreateForm(TForm2, Form2);
  Application.CreateForm(TForm3, Form3);
  Application.Run;
end.

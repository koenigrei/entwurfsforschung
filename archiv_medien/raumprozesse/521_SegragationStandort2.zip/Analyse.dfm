object Form2: TForm2
  Left = 0
  Top = 131
  BiDiMode = bdLeftToRight
  Caption = 'Analysis'
  ClientHeight = 750
  ClientWidth = 792
  Color = clBtnFace
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -11
  Font.Name = 'Tahoma'
  Font.Style = []
  OldCreateOrder = False
  ParentBiDiMode = False
  Position = poDesigned
  PixelsPerInch = 96
  TextHeight = 13
  object Chart1: TChart
    Left = 8
    Top = 8
    Width = 649
    Height = 249
    BackWall.Brush.Color = clWhite
    BackWall.Brush.Style = bsClear
    Border.Visible = True
    Gradient.Balance = 99
    Gradient.Direction = gdFromTopLeft
    Gradient.EndColor = 753908
    Gradient.MidColor = 16059031
    Gradient.StartColor = 14540754
    Legend.Visible = False
    Title.Text.Strings = (
      'TChart')
    BottomAxis.Logarithmic = True
    BottomAxis.Title.Caption = 'time in log10'
    DepthAxis.Automatic = False
    DepthAxis.AutomaticMaximum = False
    DepthAxis.AutomaticMinimum = False
    DepthAxis.Maximum = 0.500000000000000000
    DepthAxis.Minimum = -0.500000000000000000
    DepthTopAxis.Automatic = False
    DepthTopAxis.AutomaticMaximum = False
    DepthTopAxis.AutomaticMinimum = False
    DepthTopAxis.Maximum = 0.500000000000000000
    DepthTopAxis.Minimum = -0.500000000000000000
    LeftAxis.Automatic = False
    LeftAxis.AutomaticMaximum = False
    LeftAxis.AutomaticMinimum = False
    LeftAxis.Maximum = 1122.500000000000000000
    LeftAxis.Minimum = 562.500000000000000000
    LeftAxis.Visible = False
    RightAxis.Title.Caption = 'satisfaction'
    TopAxis.Automatic = False
    TopAxis.AutomaticMaximum = False
    TopAxis.AutomaticMinimum = False
    TopAxis.Visible = False
    View3D = False
    Zoom.Animated = True
    Zoom.UpLeftZooms = True
    Color = clWhite
    TabOrder = 0
    object Series1: TLineSeries
      Marks.Callout.Brush.Color = clBlack
      Marks.Visible = False
      Pointer.InflateMargins = True
      Pointer.Style = psRectangle
      Pointer.Visible = False
      XValues.Name = 'X'
      XValues.Order = loAscending
      YValues.Name = 'Y'
      YValues.Order = loNone
    end
    object ChartTool1: TPageNumTool
      Active = False
      Callout.Brush.Color = clBlack
      Callout.Arrow.Visible = False
      Text = 'Page %d of %d'
    end
  end
  object Chart2: TChart
    Left = 279
    Top = 263
    Width = 505
    Height = 234
    Border.Visible = True
    Legend.Visible = False
    Title.Gradient.EndColor = clGray
    Title.Gradient.MidColor = clWhite
    Title.Gradient.StartColor = clSilver
    Title.Text.Strings = (
      'TChart')
    BottomAxis.ExactDateTime = False
    BottomAxis.Increment = 1.000000000000000000
    DepthAxis.Automatic = False
    DepthAxis.AutomaticMaximum = False
    DepthAxis.AutomaticMinimum = False
    DepthAxis.Maximum = 0.500000000000000000
    DepthAxis.Minimum = -0.500000000000000000
    DepthTopAxis.Automatic = False
    DepthTopAxis.AutomaticMaximum = False
    DepthTopAxis.AutomaticMinimum = False
    DepthTopAxis.Maximum = 0.500000000000000000
    DepthTopAxis.Minimum = -0.500000000000000000
    RightAxis.Automatic = False
    RightAxis.AutomaticMaximum = False
    RightAxis.AutomaticMinimum = False
    View3D = False
    Zoom.UpLeftZooms = True
    Color = clWhite
    TabOrder = 1
    PrintMargins = (
      15
      32
      15
      32)
    object Series2: TBarSeries
      Marks.Callout.Brush.Color = clBlack
      Marks.Visible = True
      Gradient.Direction = gdTopBottom
      MultiBar = mbNone
      XValues.Name = 'X'
      XValues.Order = loAscending
      YValues.Name = 'Bar'
      YValues.Order = loNone
    end
  end
  object Chart3: TChart
    Left = 8
    Top = 263
    Width = 265
    Height = 234
    Border.Visible = True
    Legend.Visible = False
    Title.Gradient.EndColor = clGray
    Title.Gradient.MidColor = clWhite
    Title.Gradient.StartColor = clSilver
    Title.Text.Strings = (
      'TChart')
    BottomAxis.ExactDateTime = False
    BottomAxis.Increment = 1.000000000000000000
    View3D = False
    Zoom.UpLeftZooms = True
    Color = clWhite
    TabOrder = 2
    PrintMargins = (
      15
      32
      15
      32)
    object Series3: THorizBarSeries
      Marks.Callout.Brush.Color = clBlack
      Marks.Visible = True
      Gradient.Direction = gdLeftRight
      XValues.Name = 'Bar'
      XValues.Order = loNone
      YValues.Name = 'Y'
      YValues.Order = loAscending
    end
  end
  object B_undoZ: TButton
    Left = 709
    Top = 232
    Width = 75
    Height = 25
    Caption = 'undoZoom'
    TabOrder = 3
    OnClick = B_undoZClick
  end
  object DissimiGrid: TStringGrid
    Left = 456
    Top = 503
    Width = 328
    Height = 234
    BevelEdges = [beRight, beBottom]
    BevelInner = bvSpace
    BevelOuter = bvSpace
    ColCount = 7
    DefaultColWidth = 45
    DefaultRowHeight = 20
    RowCount = 7
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clWindowText
    Font.Height = -11
    Font.Name = 'Tahoma'
    Font.Orientation = 1
    Font.Style = []
    Options = [goFixedVertLine, goFixedHorzLine, goVertLine, goHorzLine, goRangeSelect, goEditing]
    ParentFont = False
    ParentShowHint = False
    ShowHint = True
    TabOrder = 4
  end
  object Chart4: TChart
    Left = 8
    Top = 503
    Width = 442
    Height = 234
    BackWall.Brush.Color = clWhite
    BackWall.Brush.Style = bsClear
    Border.Visible = True
    Gradient.Balance = 99
    Gradient.Direction = gdFromTopLeft
    Gradient.EndColor = 753908
    Gradient.MidColor = 16059031
    Gradient.StartColor = 14540754
    Legend.Visible = False
    Title.Text.Strings = (
      'TChart')
    BottomAxis.Logarithmic = True
    BottomAxis.Title.Caption = 'time in log10'
    DepthAxis.Automatic = False
    DepthAxis.AutomaticMaximum = False
    DepthAxis.AutomaticMinimum = False
    DepthAxis.Maximum = 0.500000000000000000
    DepthAxis.Minimum = -0.500000000000000000
    DepthTopAxis.Automatic = False
    DepthTopAxis.AutomaticMaximum = False
    DepthTopAxis.AutomaticMinimum = False
    DepthTopAxis.Maximum = 0.500000000000000000
    DepthTopAxis.Minimum = -0.500000000000000000
    LeftAxis.Automatic = False
    LeftAxis.AutomaticMaximum = False
    LeftAxis.AutomaticMinimum = False
    LeftAxis.Maximum = 260.000000000000000000
    LeftAxis.Minimum = 7.500000000000000000
    LeftAxis.Visible = False
    RightAxis.Title.Caption = 'segregation index'
    TopAxis.Automatic = False
    TopAxis.AutomaticMaximum = False
    TopAxis.AutomaticMinimum = False
    TopAxis.Visible = False
    View3D = False
    Zoom.UpLeftZooms = True
    Color = clWhite
    TabOrder = 5
    object Series4: TLineSeries
      Marks.Callout.Brush.Color = clBlack
      Marks.Visible = False
      Pointer.InflateMargins = True
      Pointer.Style = psRectangle
      Pointer.Visible = False
      XValues.Name = 'X'
      XValues.Order = loAscending
      YValues.Name = 'Y'
      YValues.Order = loNone
    end
    object PageNumTool1: TPageNumTool
      Active = False
      Callout.Brush.Color = clBlack
      Callout.Arrow.Visible = False
      Text = 'Page %d of %d'
    end
  end
end

unit Analyse;

interface

uses
  Windows, Messages, SysUtils, Variants, Classes, Graphics, Controls, Forms,
  Dialogs, ExtCtrls, TeeProcs, TeEngine, Chart, Series, agenten, TeeTools,
  TeePageNumTool, StdCtrls, Grids;

type
  TForm2 = class(TForm)
    Chart1       : TChart;
    Series1      : TLineSeries;
    ChartTool1   : TPageNumTool;
    Chart2       : TChart;
    Series2      : TBarSeries;
    Chart3       : TChart;
    Series3      : THorizBarSeries;
    B_undoZ      : TButton;
    DissimiGrid  : TStringGrid;
    Chart4       : TChart;
    PageNumTool1 : TPageNumTool;
    Series4      : TLineSeries;
    procedure B_undoZClick(Sender: TObject);
  private
    { Private declarations }
  public
    procedure resetGraph;
    procedure setClusterGraph;
  end;

var
  Form2: TForm2;
  sSer  : Array of TLineSeries;    //-- series for graph-plotting
  isSer : Array of TLineSeries;
  tmpBarSeries : TBarSeries;

implementation

{$R *.dfm}
uses CellForm;

//******************************************************************************
procedure TForm2.B_undoZClick(Sender: TObject);
begin
  Chart1.UndoZoom;
  Chart2.UndoZoom;
  Chart3.UndoZoom;
end;

procedure TForm2.resetGraph;
var
 I, K : Integer;
begin
  SetLength (sSer, 0);
  SetLength (sSer, ngGroups);
  with Chart1 do
  begin
    RemoveAllSeries;
    Title.Text.Clear;                                                         // -- Title of the Chart
    Title.Text.Add('average satisfaction of the agents');
    For I := 0 To ngGroups-1 Do
    begin
      sSer[I] := TLineSeries.Create(self);                                    // -- Create first Series
      sSer[I].Clear;                                                          // -- Clear it
      sSer[I].ParentChart := Chart1;                                          // -- determine the chart, this series belongs to
      sSer[I].VertAxis := aRightAxis;
      sSer[I].Color := farbList[I];
    end;
  end;
  SetLength (isSer, 0);
  SetLength (isSer, ngGroups);
  with Chart4 do
  begin
    RemoveAllSeries;
    Title.Text.Clear;                                                         // -- Title of the Chart
    Title.Text.Add('segregation measure in '+ Form1.E_nbSize.Text+'x' +Form1.E_nbSize.Text+' tiles');
    For I := 0 To ngGroups-1 Do
    begin
      isSer[I] := TLineSeries.Create(self);                                   // -- Create first Series
      isSer[I].Clear;                                                         // -- Clear it
      isSer[I].ParentChart := Chart4;                                         // -- determine the chart, this series belongs to
      isSer[I].VertAxis := aRightAxis;
      isSer[I].Color := farbList[I];
    end;
  end;
  with Chart2 do
  begin
    Title.Text.Clear;                                                         // -- Title of the Chart
    Title.Text.Add('cluster sizes');
  end;
  with Chart3 do
  begin
    Title.Text.Clear;                                                         // -- Title of the Chart
    Title.Text.Add('group sizes');
  end;
  Series3.Clear;                                                              // -- plot the group sizes
  For I:= 0 To ngGroups-1 Do
  begin
    Series3.Add(groupSz[I], '', farbList[I] );
  end;
  with DissimiGrid do
  begin
    ColCount := ngGroups+1;
    RowCount := ngGroups+2;
    Cells[0, 0]:='groups';
    For I := 0 To ngGroups Do                                                 // -- delete old content
    begin
      For K := 0 To ngGroups +1  Do
      begin
        Cells[I, K]:=' ';
      end;
    end;
    For I := 0 To ngGroups -1 Do                                              // -- titles for the rows and colums
    begin
      Cells[I+1, 0]:='group '+ IntToStr(I);
      Cells[0, ngGroups+1]:='IS';
      Cells[0, I+1]:='group '+ IntToStr(I);
    end;
  end;
end;

procedure TForm2.setClusterGraph;
var
  I, M   : Integer;
  clusterThresh : Integer;
begin
  clusterThresh := StrToInt(Form1.E_clusterT.Text);
  Chart2.RemoveAllSeries;
  tmpBarSeries:=TBarSeries.Create(self);
  Chart2.AddSeries(tmpBarSeries);
  with Chart2 do
  begin
    UndoZoom;
    Title.Text.Clear;                                                         // -- Title of the Chart
    Title.Text.Add('cluster sizes at timestep '+ IntToStr(steps));
  end;
  tmpBarSeries.Clear;
  For I := 0 To ngGroups-1 Do
  begin
    For M := 0 To High(clustCount[I]) Do
    begin
      If clustCount[I,M] > clusterThresh Then
        tmpBarSeries.Add( clustCount[I,M] , '', farbList[I] );
    end;
  end;
end;

end.

unit MAIN_win;

interface

uses Windows, SysUtils, Classes, Graphics, Forms, Controls, Menus,
  StdCtrls, Dialogs, Buttons, Messages, ExtCtrls, ComCtrls, StdActns,
  ActnList, ToolWin, ImgList;

type
  TMainForm = class(TForm)
    MainMenu1: TMainMenu;
    File1: TMenuItem;
    FileNewItem: TMenuItem;
    FileOpenItem: TMenuItem;
    FileCloseItem: TMenuItem;
    Window1: TMenuItem;
    Help1: TMenuItem;
    N1: TMenuItem;
    FileExitItem: TMenuItem;
    WindowCascadeItem: TMenuItem;
    WindowTileItem: TMenuItem;
    WindowArrangeItem: TMenuItem;
    HelpAboutItem: TMenuItem;
    OpenDialog: TOpenDialog;
    FileSaveItem: TMenuItem;
    FileSaveAsItem: TMenuItem;
    Edit1: TMenuItem;
    CutItem: TMenuItem;
    CopyItem: TMenuItem;
    PasteItem: TMenuItem;
    WindowMinimizeItem: TMenuItem;
    StatusBar: TStatusBar;
    ActionList1: TActionList;
    EditCut1: TEditCut;
    EditCopy1: TEditCopy;
    EditPaste1: TEditPaste;
    FileNew1: TAction;
    FileSave1: TAction;
    FileExit1: TAction;
    FileOpen1: TAction;
    FileSaveAs1: TAction;
    WindowCascade1: TWindowCascade;
    WindowTileHorizontal1: TWindowTileHorizontal;
    WindowArrangeAll1: TWindowArrange;
    WindowMinimizeAll1: TWindowMinimizeAll;
    HelpAbout1: TAction;
    FileClose1: TWindowClose;
    WindowTileVertical1: TWindowTileVertical;
    WindowTileItem2: TMenuItem;
    ToolBar2: TToolBar;
    ToolButton1: TToolButton;
    ToolButton2: TToolButton;
    ToolButton3: TToolButton;
    ToolButton4: TToolButton;
    ToolButton5: TToolButton;
    ToolButton6: TToolButton;
    ToolButton9: TToolButton;
    ToolButton7: TToolButton;
    ToolButton8: TToolButton;
    ToolButton10: TToolButton;
    ToolButton11: TToolButton;
    ImageList1: TImageList;
    ToolButton12: TToolButton;
    procedure FileNew1Execute(Sender: TObject);
    procedure FileOpen1Execute(Sender: TObject);
    procedure HelpAbout1Execute(Sender: TObject);
    procedure FileExit1Execute(Sender: TObject);
    procedure FormCreate(Sender: TObject);
    procedure ToolButton12Click(Sender: TObject);
  private
    procedure CreateMDIChild(const Name: string);
    { Private-Deklarationen }
  public
    procedure CreateMyMDIChild(frm : TFormClass);
    { Public-Deklarationen }
  end;

var
  MainForm: TMainForm;

implementation

{$R *.dfm}

uses CHILDWIN, about, Main;

procedure TMainForm.CreateMDIChild(const Name: string);
var
  Child: TMDIChild;
begin
  { ein neues untergeordnetes MDI-Fenster erstellen }
  Child := TMDIChild.Create(Application);
  Child.Caption := Name;
  if FileExists(Name) then Child.Memo1.Lines.LoadFromFile(Name);
end;

procedure TMainForm.CreateMyMDIChild(frm : TFormClass);
const
 sMDIChildFormCreated = 'Form "%s" already created. Select OK to switch to it, Yes to create a new form instance.';
var
  i:integer;
  bCreated:boolean;
  f:TForm;
begin
  bCreated:=False;
  for i:= 0 to MainForm.MDIChildCount-1 do
  begin
    if MainForm.MDIChildren[i] is frm then
    begin
      f:=MainForm.MDIChildren[i] as frm ;
      bCreated:=True;
      Break;
    end;
  end;
  if not bCreated then
  begin
    frm.Create(Application);
  end
  else
  begin
    case MessageDlg(Format(sMDIChildFormCreated,[f.caption]), mtConfirmation, [mbOk, mbYes, mbCancel],0) of
     mrOK: f.Show;
     mrYes: frm.Create(Application);
     mrCancel: //do notingg
    end; //case
  end;
end;

procedure TMainForm.FileNew1Execute(Sender: TObject);
begin
  CreateMyMDIChild(TForm1);
end;

procedure TMainForm.FileOpen1Execute(Sender: TObject);
begin
  if OpenDialog.Execute then
    CreateMDIChild(OpenDialog.FileName);
end;

procedure TMainForm.FormCreate(Sender: TObject);
var
  h:HWnd;
begin
  h:=handle;
  postmessage(h,WM_SYSCOMMAND,SC_MAXIMIZE,0);
end;

procedure TMainForm.HelpAbout1Execute(Sender: TObject);
begin
  AboutBox.ShowModal;
end;

procedure TMainForm.ToolButton12Click(Sender: TObject);
begin
  Form1.Timer1.Enabled := Not Form1.Timer1.Enabled;
end;

procedure TMainForm.FileExit1Execute(Sender: TObject);
begin
  Close;
end;

end.

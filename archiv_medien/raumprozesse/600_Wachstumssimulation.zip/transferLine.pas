unit transferLine;

interface

uses
  Windows, Classes, Graphics, cell, math;

type
  nachbarArray = Array[0..3]of TPoint;

procedure transLine(var curCell, targetCell: TCell; var targWink: Double);
procedure neumNb (K, I: Integer; var nbDirect: nachbarArray);
procedure torus (var Xp: Integer; var Yp: Integer);
procedure subdivideEdge(StartCell, EndCell: TCell);
function  CalcDistance(pAX: Integer; pAY: Integer; pBX: Integer; pBY: Integer): Integer;

implementation

uses Main, agent;

//==============================================================================
procedure subdivideEdge(StartCell, EndCell: TCell);
var eLength           : Single;    // length of the edge
    deltaX, deltaY    : Single;
    refLeng, M, I     : Cardinal;  // max length of a edge
    newKoord          : TPoint;    // new Point & new Coordinates
    tSin, tCos        : Extended;  // temporary sin and cos values
    curCell, fromCell : TCell;
    targWink          : Double;
    curNode, fromNode : TAgent;
begin
  targWink := ArcTan2((StartCell.Koord.Y - EndCell.Koord.Y),(StartCell.Koord.X - EndCell.Koord.X));
  eLength  := CalcDistance(StartCell.Pos.X, StartCell.Pos.Y, EndCell.Pos.X, EndCell.Pos.Y);
  refLeng  := cellScal * Form1.SE_strStep.value;
  M        := round(eLength / refLeng);
  fromCell := StartCell;
  SinCos(targWink, tSin, tCos);
  deltaX   := tCos * refLeng;
  deltaY   := tSin * refLeng;
  If NodeList.Count > 0        Then fromNode := NodeList.Items[fromCell.NodeNr];
  If Not (StartCell.State = 1) Then AgentsCreate(StartCell);
  For I:=1 To M-1 Do
  begin
    newKoord.X := StartCell.Koord.X - round(I * deltaX / cellScal);
    newKoord.Y := StartCell.Koord.Y - round(I * deltaY / cellScal);
    curCell := CellList[newKoord.X, newKoord.Y];
    //If Not (curCell.State = 1) Then
    AgentsCreate(curCell);
    fromNode:= NodeList.Items[fromCell.NodeNr];
    curNode := NodeList.Items[curCell.NodeNr];
    If NodeList.Count > 1 Then Form1.Connect(curNode, fromNode);  // connect the last addes nodes of the list
    fromCell := curCell;
    fromNode := curNode;
  end;
  If Not (EndCell.State = 1) Then AgentsCreate(EndCell);
  curNode := NodeList.Items[EndCell.NodeNr];
  Form1.Connect(curNode, fromNode);
end;

//==============================================================================
function CalcDistance(pAX: Integer; pAY: Integer; pBX: Integer; pBY: Integer): Integer;
var
  temp : double;
begin
  temp := sqrt(Power((pAX - pBX), 2) + Power((pAY - pBY), 2));
  Result := Round(temp);
end;

//==============================================================================
procedure transLine(var curCell, targetCell: TCell; var targWink: Double);
var
  tmpCell, primCell     : TCell;
  I, bestP              : Word;
  min, tmpDiff, tmpWink : Double;
  nbDirect              : nachbarArray;                                       // -- 4 direct neighbours
begin
  primCell := CellList[floor(curCell.Koord.X/3), floor(curCell.Koord.Y/3)];
  If curCell.cState = 1 Then dec(primCell.streetDense);                      // if the Cell was in street state, decrease...
  If curCell.cState = 2 Then dec(primCell.buildDense);                       // if the Cell was in build on state, decrease the build on counter
  inc(primCell.streetDense);                                                 // increase the street counter
  curCell.colr    := clYellow;
  curCell.cState  := 1;
  curCell.subState:= 1;
  curCell.Paint(Image_SmalGrid.Canvas);
  neumNb (curCell.Koord.X, curCell.Koord.Y, nbDirect);
  min := 999999999;
  For I := 0 To 3 Do
  begin
    tmpWink := ArcTan2 ((targetCell.Koord.Y - nbDirect[I].Y), (targetCell.Koord.X - nbDirect[I].X));
    tmpDiff := abs(targWink-tmpWink);
    If (abs(targetCell.Koord.Y - nbDirect[I].Y) <= abs(targetCell.Koord.Y - curCell.Koord.Y)) And
       (abs(targetCell.Koord.X - nbDirect[I].X) <= abs(targetCell.Koord.X - curCell.Koord.X)) Then
    If tmpDiff < min Then
    begin
      min := tmpDiff;
      bestP := I;
    end;
  end;
  If Not (curCell = targetCell) Then begin
    tmpCell := smalGridList[nbDirect[bestP].X, nbDirect[bestP].Y];
    transLine(tmpCell, targetCell, targWink);   // recursive call!!
  end;
end;

//==============================================================================
procedure neumNb (K, I: Integer; var nbDirect: nachbarArray);
var
  v      : Integer;
  Xp, Yp : Integer;
  koNei  : Array [0..3] of TPoint;
  neib   : TPoint;
begin
  // --- Summe berechnen ---
  koNei[0].X := K;    koNei[0].Y := I + 1;
  koNei[1].X := K;    koNei[1].Y := I - 1;
  koNei[2].X := K+1;  koNei[2].Y := I;
  koNei[3].X := K-1;  koNei[3].Y := I;

  for v := 0 to 3 do
  begin
    Xp := koNei[v].X;
    Yp := koNei[v].Y;
    torus(Xp, Yp);                                                            // Torus check
    neib.X := Xp;
    neib.Y := Yp;
    nbDirect[v]:= neib;
  end;
end;

//==============================================================================
procedure torus (var Xp: Integer; var Yp: Integer);
begin
  if Xp < 0 then begin
     while Xp < 0 do
     Xp := spalt + Xp;
  end else
  if Xp > spalt*3-1 then begin
     while Xp > spalt-1 do
     Xp := 0 + (Xp - spalt) ;
  end;
  if Yp < 0 then begin
     while Yp < 0 do
     Yp := reih + Yp;
  end else
  if Yp > reih*3-1 then begin
     while Yp > reih-1  do
     Yp := 0 + (Yp - reih) ;
  end;
end;

end.

unit edge;

interface

uses
  Windows, Graphics, Classes, Math, Cell, StdCtrls, SysUtils;

type
  TEdge = class
  private
  public
    fromN   : Cardinal;        // edge from Node
    toN     : Cardinal;        // edge to Node
    Pos     : TPoint;          // center coordinates of the edge
    length  : Single;          // lenth of the edge
    procedure Paint(Canvas: TCanvas);
  published

  end;

implementation

procedure TEdge.Paint(Canvas: TCanvas);
var
  Size : Integer;
begin
  Size := 3;
  Canvas.Pen.Color := clGreen;
  Canvas.Pen.Style := psSolid;                                                 // (psSolid, psDash, psDot, psClear)
  Canvas.Brush.Color := clAqua;
  Canvas.Ellipse (Pos.X - Size , Pos.Y - (Size), Pos.X + (Size), Pos.Y + (Size));
end;

end.

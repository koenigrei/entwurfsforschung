object ConnectivityTable: TConnectivityTable
  Left = 0
  Top = 0
  Caption = 'Connectivity Table'
  ClientHeight = 427
  ClientWidth = 1037
  Color = clBtnFace
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -11
  Font.Name = 'Tahoma'
  Font.Style = []
  FormStyle = fsMDIChild
  OldCreateOrder = False
  Visible = True
  OnClose = FormClose
  PixelsPerInch = 96
  TextHeight = 13
  object Splitter5: TSplitter
    Left = 706
    Top = 0
    Width = 5
    Height = 427
    Align = alRight
    Beveled = True
    ResizeStyle = rsLine
    ExplicitLeft = 611
    ExplicitTop = -420
    ExplicitHeight = 663
  end
  object StringGrid1: TStringGrid
    Left = 0
    Top = 0
    Width = 706
    Height = 427
    Align = alClient
    ColCount = 15
    DefaultColWidth = 32
    DefaultRowHeight = 16
    RowCount = 14
    Options = [goFixedVertLine, goFixedHorzLine, goVertLine, goHorzLine, goRangeSelect, goRowSizing, goColSizing]
    TabOrder = 0
    ExplicitWidth = 505
    ExplicitHeight = 243
    RowHeights = (
      16
      16
      16
      16
      16
      16
      16
      16
      16
      16
      16
      16
      16
      16)
  end
  object DissimiGrid: TStringGrid
    Left = 711
    Top = 0
    Width = 326
    Height = 427
    Align = alRight
    BevelEdges = [beRight, beBottom]
    BevelInner = bvSpace
    BevelOuter = bvSpace
    ColCount = 7
    DefaultColWidth = 45
    DefaultRowHeight = 20
    RowCount = 7
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clWindowText
    Font.Height = -11
    Font.Name = 'Tahoma'
    Font.Orientation = 1
    Font.Style = []
    Options = [goFixedVertLine, goFixedHorzLine, goVertLine, goHorzLine, goRangeSelect, goEditing]
    ParentFont = False
    ParentShowHint = False
    ShowHint = True
    TabOrder = 1
    ExplicitLeft = 703
    ExplicitHeight = 202
  end
end

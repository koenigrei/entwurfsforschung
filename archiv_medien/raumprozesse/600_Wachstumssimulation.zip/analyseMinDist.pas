unit analyseMinDist;

interface

uses
  Windows, Messages, SysUtils, Variants, Classes, Graphics, Controls, Forms, Math,
  Dialogs, TeEngine, TeeTools, TeePageNumTool, Series, ExtCtrls, TeeProcs, Chart,
  ComCtrls, StdCtrls, CurvFitt, TeeFunci, TeeEdit, StatChar;

type
  TanaMinDist = class(TForm)
    Timer2              : TTimer;
    lbl_pSteps          : TLabel;
    lbl_timesteps       : TLabel;
    Label8              : TLabel;
    Lbl_proceed         : TLabel;
    Lbl_akt             : TLabel;
    B_undoZ             : TButton;
    Chart_IS            : TChart;
    Series_IS           : TPointSeries;
    Series_IS_Avg       : TLineSeries;
    TeeFunction2        : TAverageTeeFunction;
    Series_IS_Fit       : TLineSeries;
    TeeFunction3        : TCurveFittingFunction;
    Series_IS_Trend     : TLineSeries;
    TeeFunction6        : TTrendFunction;
    PageNumTool2        : TPageNumTool;
    GroupBox3           : TGroupBox;
    Label7              : TLabel;
    CB_data_Seg         : TCheckBox;
    CB_avg_Seg          : TCheckBox;
    CB_trend_Seg        : TCheckBox;
    CB_cFit_Seg         : TCheckBox;
    UpD_polyDegSeg      : TUpDown;
    E_polyDegSeg        : TEdit;
    ChartEditor1        : TChartEditor;
    Button1             : TButton;
    Series_StDv         : TLineSeries;
    TeeFunction1        : TStdDeviationFunction;
    Series_Correlation  : TLineSeries;
    TeeFunction4        : TCorrelationFunction;
    Series_mean         : TLineSeries;
    TeeFunction5        : TAverageTeeFunction;
    GroupBox1           : TGroupBox;
    Label1              : TLabel;
    Label2              : TLabel;
    Label4              : TLabel;
    Label5              : TLabel;
    Label3              : TLabel;
    Label6              : TLabel;
    E_valFrom           : TEdit;
    E_valTo             : TEdit;
    E_toSteps           : TEdit;
    E_calcVals          : TEdit;
    B_start             : TButton;
    B_break             : TButton;
    E_incre             : TEdit;
    procedure FormCreate(Sender: TObject);
    procedure B_startClick(Sender: TObject);
    procedure B_undoZClick(Sender: TObject);
    procedure Timer2Timer(Sender: TObject);
    procedure B_breakClick(Sender: TObject);
    procedure CB_data_SegClick(Sender: TObject);
    procedure CB_avg_SegClick(Sender: TObject);
    procedure CB_trend_SegClick(Sender: TObject);
    procedure CB_cFit_SegClick(Sender: TObject);
    procedure UpD_polyDegSegClick(Sender: TObject; Button: TUDBtnType);
    procedure E_calcValsChange(Sender: TObject);
    procedure Button1Click(Sender: TObject);
    procedure FormClose(Sender: TObject; var Action: TCloseAction);
  private
    procedure updProc;
    procedure resetGraphs;
  public
    toCalc : Cardinal;
    Steps  : Integer;
    rounds : Cardinal;
    aktVal : Integer;
    procedure NewStart;
    procedure plotVals;
    procedure newRound(aktVal: Integer);
  end;

var
  anaMinDist  : TanaMinDist;
  segregatFunct : TCurveFittingFunction;

implementation

{$R *.dfm}
uses Main, dijkstra, ConnTable;

procedure TanaMinDist.FormClose(Sender: TObject; var Action: TCloseAction);
begin
  Timer2.enabled := false;
  Action := caFree;
end;

procedure TanaMinDist.FormCreate(Sender: TObject);
begin
  Timer2.enabled := false;
  lbl_pSteps.Caption := '0';
  Steps := 0;
  segregatFunct := TCurveFittingFunction.Create(self);
  segregatFunct.PolyDegree := 3;
  toCalc := 0;
  Lbl_akt.Caption := IntToStr(toCalc);
  Lbl_proceed.Caption := '/ ' + IntToStr( Ceil((StrToInt(E_valTo.Text) - StrToInt(E_valFrom.Text)+1)/
                         StrToInt(E_incre.Text)) * StrToInt(E_calcVals.Text));
end;

procedure TanaMinDist.B_startClick(Sender: TObject);
begin
  NewStart;
  Timer2.Enabled := true;
end;

procedure TanaMinDist.NewStart;
begin
  Form1.RB_netOnly.Checked := true;
  Form1.Timer1.enabled := false;
  Steps := 0;
  resetGraphs;
  rounds := 1;
  toCalc := 0;
  Lbl_akt.Caption := IntToStr(toCalc);
  aktVal := StrToInt(E_valFrom.Text);
  newRound(aktVal);
  Form1.deleteAll;
  Form1.Setup;
  Form1.RB_netOnly.Checked := true;
end;

procedure TanaMinDist.resetGraphs;
begin
  with Chart_IS do
  begin
    Series_IS.Clear;
    Series_IS_Avg.Clear;
    Series_IS_Fit.Clear;
    Series_StDv.Clear;
    Series_Correlation.Clear;
    Series_IS_Avg.FunctionType.Period := (StrToInt(E_calcVals.Text));
    segregatFunct.ParentSeries := Series_IS_Fit;
    Series_IS_Avg.Visible   := CB_avg_Seg.Checked;
    Series_IS_Trend.Visible := CB_trend_Seg.Checked;
    Series_IS_Fit.Visible   := CB_cFit_Seg.Checked;
  end;
end;

procedure TanaMinDist.newRound(aktVal: Integer);
begin
  Form1.SE_minDist.Value := aktVal;
end;

procedure TanaMinDist.Timer2Timer(Sender: TObject);
begin
  If Steps >= StrToInt(E_toSteps.Text) Then                                  // -- timesteps per value
  begin
    plotVals;
    inc(rounds);
    inc(toCalc);
    Lbl_akt.Caption := IntToStr(toCalc);
    If rounds > StrToInt(E_calcVals.Text) Then                                // -- calculations per value
    begin
      aktVal := aktVal + StrToInt(E_incre.Text);                              // -- raise aktual value by increment
      If aktVal > StrToInt(E_valTo.Text) Then                                 // -- iterate the range from start value to end value
      begin
        Series_IS_Fit.CheckDataSource;
        Series_StDv.CheckDataSource;
        Series_Correlation.CheckDataSource;
        Series_mean.CheckDataSource;
        Timer2.enabled := false;
        exit;
      end;
      rounds := 1;
    end;
    Steps := 0;
    newRound(aktVal);
    Form1.DeleteAll;
    Form1.Setup;
  end;
  Form1.ExecuteInterlink;
  lbl_pSteps.Caption := IntToStr (Steps);
  inc(Steps);
end;

procedure TanaMinDist.plotVals;
begin
  CalculatePathes;
  ConnectivityTable.ListKonnVals;
  Form1.EdgesPerNode;
  Series_IS.AddXY(aktVal, globML);
  Series_IS_Avg.CheckDataSource;
  Series_IS_Trend.CheckDataSource;
end;

procedure TanaMinDist.updProc;
begin
  Lbl_proceed.Caption := '/ ' + IntToStr( Ceil((StrToInt(E_valTo.Text) - StrToInt(E_valFrom.Text)+1)/
                         StrToInt(E_incre.Text)) * StrToInt(E_calcVals.Text));
end;

procedure TanaMinDist.B_undoZClick(Sender: TObject);
begin
  Chart_IS.UndoZoom;
end;

procedure TanaMinDist.Button1Click(Sender: TObject);
begin
  ChartEditor1.Execute;
end;

procedure TanaMinDist.B_breakClick(Sender: TObject);
begin
  Timer2.enabled := not(Timer2.enabled);
end;

procedure TanaMinDist.CB_data_SegClick(Sender: TObject);
begin
  If CB_data_Seg.Checked Then begin Series_IS.Visible := true;
  end else begin Series_IS.Visible := false;
  end;
end;

procedure TanaMinDist.CB_avg_SegClick(Sender: TObject);
begin
  If CB_avg_Seg.Checked Then begin Series_IS_Avg.Visible := true;
  end else begin Series_IS_AVG.Visible := false;
  end;
end;

procedure TanaMinDist.CB_trend_SegClick(Sender: TObject);
begin
  If CB_trend_Seg.Checked Then begin Series_IS_Trend.Visible := true;
  end else begin Series_IS_Trend.Visible := false;
  end;
end;

procedure TanaMinDist.E_calcValsChange(Sender: TObject);
begin
  updProc;
end;

procedure TanaMinDist.CB_cFit_SegClick(Sender: TObject);
begin
  If CB_cFit_Seg.Checked Then begin Series_IS_Fit.Visible := true;
  end else begin Series_IS_Fit.Visible := false;
  end;
end;

procedure TanaMinDist.UpD_polyDegSegClick(Sender: TObject; Button: TUDBtnType);
begin
  if UpD_polyDegSeg.Position > 1 then
     segregatFunct.PolyDegree:=UpD_polyDegSeg.Position;
end;


end.

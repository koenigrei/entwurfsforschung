object AnaDev: TAnaDev
  Left = 0
  Top = 0
  Caption = 'AnaDevPara'
  ClientHeight = 568
  ClientWidth = 1048
  Color = clBtnFace
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -11
  Font.Name = 'Tahoma'
  Font.Style = []
  FormStyle = fsMDIChild
  OldCreateOrder = False
  Visible = True
  OnClose = FormClose
  OnCreate = FormCreate
  PixelsPerInch = 96
  TextHeight = 13
  object B_undoZ: TButton
    Left = 800
    Top = 536
    Width = 75
    Height = 25
    Caption = 'undoZoom'
    TabOrder = 0
    OnClick = B_undoZClick
  end
  object Chart_devPara: TChart
    Left = 0
    Top = 0
    Width = 794
    Height = 568
    BackWall.Brush.Color = clWhite
    BackWall.Brush.Style = bsClear
    Border.Visible = True
    Gradient.Balance = 99
    Gradient.Direction = gdFromTopLeft
    Gradient.EndColor = 753908
    Gradient.MidColor = 16059031
    Gradient.StartColor = 14540754
    Title.Text.Strings = (
      'Analyse Development Parameters')
    BottomAxis.ExactDateTime = False
    BottomAxis.Title.Caption = 'analysed development parameters'
    DepthAxis.Automatic = False
    DepthAxis.AutomaticMaximum = False
    DepthAxis.AutomaticMinimum = False
    DepthAxis.Maximum = 0.500000000000000000
    DepthAxis.Minimum = -0.500000000000000000
    DepthTopAxis.Automatic = False
    DepthTopAxis.AutomaticMaximum = False
    DepthTopAxis.AutomaticMinimum = False
    DepthTopAxis.Maximum = 0.500000000000000000
    DepthTopAxis.Minimum = -0.500000000000000000
    LeftAxis.Title.Caption = 'characteristic values'
    RightAxis.Grid.Visible = False
    RightAxis.Title.Caption = 'mean length'
    TopAxis.Automatic = False
    TopAxis.AutomaticMaximum = False
    TopAxis.AutomaticMinimum = False
    TopAxis.Visible = False
    View3D = False
    Zoom.UpLeftZooms = True
    Align = alLeft
    Color = clWhite
    TabOrder = 1
    PrintMargins = (
      15
      26
      15
      26)
    object ser_FractGrid: TPointSeries
      Marks.Callout.Brush.Color = clBlack
      Marks.Visible = False
      Title = 'Fract_D grid'
      ClickableLine = False
      Pointer.Brush.Color = clRed
      Pointer.HorizSize = 2
      Pointer.InflateMargins = True
      Pointer.Style = psRectangle
      Pointer.VertSize = 2
      Pointer.Visible = True
      XValues.Name = 'X'
      XValues.Order = loAscending
      YValues.Name = 'Y'
      YValues.Order = loNone
    end
    object ser_Connect: TPointSeries
      Marks.Callout.Brush.Color = clBlack
      Marks.Visible = False
      Title = 'mean length'
      VertAxis = aRightAxis
      ClickableLine = False
      Pointer.Brush.Color = clLime
      Pointer.HorizSize = 3
      Pointer.InflateMargins = True
      Pointer.Style = psTriangle
      Pointer.VertSize = 2
      Pointer.Visible = True
      XValues.Name = 'X'
      XValues.Order = loAscending
      YValues.Name = 'Y'
      YValues.Order = loNone
    end
    object ser_Rank: TPointSeries
      Marks.Callout.Brush.Color = clBlack
      Marks.Visible = False
      SeriesColor = clBlue
      Title = 'Slope Rank'
      ClickableLine = False
      Pointer.Brush.Color = clBlue
      Pointer.HorizSize = 3
      Pointer.InflateMargins = True
      Pointer.Style = psDownTriangle
      Pointer.VertSize = 2
      Pointer.Visible = True
      XValues.Name = 'X'
      XValues.Order = loAscending
      YValues.Name = 'Y'
      YValues.Order = loNone
    end
    object ser_IS: TPointSeries
      Marks.Callout.Brush.Color = clBlack
      Marks.Visible = False
      SeriesColor = clFuchsia
      Title = 'IS'
      ClickableLine = False
      Pointer.Brush.Color = 16744703
      Pointer.HorizSize = 3
      Pointer.InflateMargins = True
      Pointer.Style = psDiamond
      Pointer.VertSize = 3
      Pointer.Visible = True
      XValues.Name = 'X'
      XValues.Order = loAscending
      YValues.Name = 'Y'
      YValues.Order = loNone
    end
    object ser_potDens: TPointSeries
      Marks.Callout.Brush.Color = clBlack
      Marks.Visible = False
      SeriesColor = clAqua
      Title = 'Pot / Dens'
      ClickableLine = False
      Pointer.Brush.Color = 16777088
      Pointer.HorizSize = 2
      Pointer.InflateMargins = True
      Pointer.Style = psLeftTriangle
      Pointer.VertSize = 3
      Pointer.Visible = True
      XValues.Name = 'X'
      XValues.Order = loAscending
      YValues.Name = 'Y'
      YValues.Order = loNone
    end
    object ser_potConn: TPointSeries
      Depth = 0
      Marks.Callout.Brush.Color = clBlack
      Marks.Visible = False
      Title = 'Pot / Conn'
      ClickableLine = False
      Pointer.Brush.Color = clYellow
      Pointer.HorizSize = 2
      Pointer.InflateMargins = True
      Pointer.Style = psRightTriangle
      Pointer.VertSize = 3
      Pointer.Visible = True
      XValues.Name = 'X'
      XValues.Order = loAscending
      YValues.Name = 'Y'
      YValues.Order = loNone
    end
    object trend_FractGrid: TLineSeries
      Active = False
      ColorEachLine = False
      Marks.Callout.Brush.Color = clBlack
      Marks.Visible = False
      DataSource = ser_FractGrid
      SeriesColor = clRed
      Brush.Color = clRed
      LinePen.Color = clRed
      LinePen.Width = 2
      LinePen.SmallDots = True
      Pointer.InflateMargins = True
      Pointer.Style = psRectangle
      Pointer.Visible = False
      XValues.Name = 'X'
      XValues.Order = loAscending
      YValues.Name = 'Y'
      YValues.Order = loNone
      object TeeFunction6: TTrendFunction
      end
    end
    object trend_Connect: TLineSeries
      Active = False
      Marks.Callout.Brush.Color = clBlack
      Marks.Visible = False
      DataSource = ser_Connect
      SeriesColor = clGreen
      Brush.Color = clGreen
      LinePen.Color = clGreen
      LinePen.SmallDots = True
      Pointer.InflateMargins = True
      Pointer.Style = psRectangle
      Pointer.Visible = False
      XValues.Name = 'X'
      XValues.Order = loAscending
      YValues.Name = 'Y'
      YValues.Order = loNone
      object TeeFunction1: TTrendFunction
      end
    end
    object trend_Rank: TLineSeries
      Active = False
      Marks.Callout.Brush.Color = clBlack
      Marks.Visible = False
      DataSource = ser_Rank
      ValueFormat = '#,##0.#'
      Brush.Color = clBlue
      LinePen.Color = clBlue
      LinePen.Style = psDot
      LinePen.Width = 2
      LinePen.SmallDots = True
      OutLine.Color = clGreen
      Pointer.Brush.Color = clGreen
      Pointer.HorizSize = 2
      Pointer.InflateMargins = True
      Pointer.Style = psRectangle
      Pointer.VertSize = 2
      Pointer.Visible = False
      XValues.Name = 'X'
      XValues.Order = loAscending
      YValues.Name = 'Y'
      YValues.Order = loNone
      object TeeFunction2: TTrendFunction
      end
    end
    object trend_IS: TLineSeries
      Active = False
      ColorEachLine = False
      Marks.Callout.Brush.Color = clBlack
      Marks.Visible = False
      DataSource = ser_IS
      Brush.Color = clFuchsia
      LinePen.Color = clFuchsia
      LinePen.SmallDots = True
      Pointer.InflateMargins = True
      Pointer.Style = psRectangle
      Pointer.Visible = False
      XValues.Name = 'X'
      XValues.Order = loAscending
      YValues.Name = 'Y'
      YValues.Order = loNone
      object TeeFunction4: TTrendFunction
      end
    end
    object trend_potDens: TLineSeries
      Active = False
      Marks.Callout.Brush.Color = clBlack
      Marks.Visible = False
      DataSource = ser_potDens
      SeriesColor = clAqua
      Brush.Color = clAqua
      LinePen.Color = clAqua
      LinePen.SmallDots = True
      Pointer.InflateMargins = True
      Pointer.Style = psRectangle
      Pointer.Visible = False
      XValues.Name = 'X'
      XValues.Order = loAscending
      YValues.Name = 'Y'
      YValues.Order = loNone
      object TeeFunction5: TTrendFunction
      end
    end
    object trend_potConn: TLineSeries
      Active = False
      Marks.Callout.Brush.Color = clBlack
      Marks.Visible = False
      DataSource = ser_potConn
      SeriesColor = clYellow
      Brush.Color = clYellow
      LinePen.Color = clYellow
      LinePen.SmallDots = True
      Pointer.InflateMargins = True
      Pointer.Style = psRectangle
      Pointer.Visible = False
      XValues.Name = 'X'
      XValues.Order = loAscending
      YValues.Name = 'Y'
      YValues.Order = loNone
      object TeeFunction3: TTrendFunction
      end
    end
    object avg_FractGrid: TLineSeries
      ColorEachLine = False
      Marks.Callout.Brush.Color = clBlack
      Marks.Callout.Length = 0
      Marks.Visible = False
      DataSource = ser_FractGrid
      SeriesColor = clRed
      Title = 'avg FGrid'
      Brush.Color = clRed
      ClickableLine = False
      LinePen.Color = clRed
      Pointer.Brush.Color = clRed
      Pointer.HorizSize = 2
      Pointer.InflateMargins = True
      Pointer.Style = psRectangle
      Pointer.VertSize = 2
      Pointer.Visible = False
      XValues.Name = 'X'
      XValues.Order = loAscending
      YValues.Name = 'Y'
      YValues.Order = loNone
      object TeeFunction7: TAverageTeeFunction
      end
    end
    object avg_Connect: TLineSeries
      Marks.Callout.Brush.Color = clBlack
      Marks.Callout.Length = 0
      Marks.Visible = False
      DataSource = ser_Connect
      SeriesColor = clGreen
      Title = 'avg_ML'
      VertAxis = aRightAxis
      Brush.Color = clGreen
      ClickableLine = False
      LinePen.Color = clGreen
      LinePen.SmallDots = True
      Pointer.Brush.Color = clLime
      Pointer.HorizSize = 3
      Pointer.InflateMargins = True
      Pointer.Style = psTriangle
      Pointer.VertSize = 2
      Pointer.Visible = False
      XValues.Name = 'X'
      XValues.Order = loAscending
      YValues.Name = 'Y'
      YValues.Order = loNone
      object TeeFunction8: TAverageTeeFunction
      end
    end
    object avg_Rank: TLineSeries
      Marks.Callout.Brush.Color = clBlack
      Marks.Callout.Length = 0
      Marks.Visible = False
      DataSource = ser_Rank
      SeriesColor = clBlue
      Brush.Color = clBlue
      ClickableLine = False
      LinePen.Color = clBlue
      LinePen.Style = psDashDotDot
      Pointer.Brush.Color = clBlue
      Pointer.HorizSize = 3
      Pointer.InflateMargins = True
      Pointer.Style = psDownTriangle
      Pointer.VertSize = 2
      Pointer.Visible = False
      XValues.Name = 'X'
      XValues.Order = loAscending
      YValues.Name = 'Y'
      YValues.Order = loNone
      object TeeFunction9: TAverageTeeFunction
      end
    end
    object avg_IS: TLineSeries
      Marks.Callout.Brush.Color = clBlack
      Marks.Callout.Length = 0
      Marks.Visible = False
      DataSource = ser_IS
      SeriesColor = clFuchsia
      Brush.Color = clFuchsia
      ClickableLine = False
      LinePen.Color = clFuchsia
      LinePen.Style = psDashDot
      Pointer.Brush.Color = 16744703
      Pointer.HorizSize = 3
      Pointer.InflateMargins = True
      Pointer.Style = psDiamond
      Pointer.VertSize = 3
      Pointer.Visible = False
      XValues.Name = 'X'
      XValues.Order = loAscending
      YValues.Name = 'Y'
      YValues.Order = loNone
      object TeeFunction10: TAverageTeeFunction
      end
    end
    object avg_potDens: TLineSeries
      Marks.Callout.Brush.Color = clBlack
      Marks.Callout.Length = 0
      Marks.Visible = False
      DataSource = ser_potDens
      SeriesColor = clAqua
      Title = 'avg_PotDens'
      Brush.Color = clAqua
      ClickableLine = False
      LinePen.Color = clAqua
      LinePen.Style = psDot
      Pointer.Brush.Color = 16777088
      Pointer.HorizSize = 2
      Pointer.InflateMargins = True
      Pointer.Style = psLeftTriangle
      Pointer.VertSize = 3
      Pointer.Visible = False
      XValues.Name = 'X'
      XValues.Order = loAscending
      YValues.Name = 'Y'
      YValues.Order = loNone
      object TeeFunction11: TAverageTeeFunction
      end
    end
    object avg_potConn: TLineSeries
      Depth = 0
      Marks.Callout.Brush.Color = clBlack
      Marks.Callout.Length = 0
      Marks.Visible = False
      DataSource = ser_potConn
      SeriesColor = clYellow
      Title = 'avg_PotConn'
      Brush.Color = clYellow
      ClickableLine = False
      LinePen.Color = clYellow
      LinePen.Style = psDash
      LinePen.Width = 2
      Pointer.Brush.Color = clYellow
      Pointer.HorizSize = 2
      Pointer.InflateMargins = True
      Pointer.Style = psRightTriangle
      Pointer.VertSize = 3
      Pointer.Visible = False
      XValues.Name = 'X'
      XValues.Order = loAscending
      YValues.Name = 'Y'
      YValues.Order = loNone
      object TeeFunction12: TAverageTeeFunction
      end
    end
    object PageNumTool2: TPageNumTool
      Active = False
      Callout.Brush.Color = clBlack
      Callout.Arrow.Visible = False
      Text = 'Page %d of %d'
      Format = 'Page %d of %d'
    end
  end
  object GroupBox3: TGroupBox
    Left = 800
    Top = 351
    Width = 241
    Height = 100
    Caption = 'chart'
    TabOrder = 2
    object CB_dataShow: TCheckBox
      Left = 10
      Top = 24
      Width = 97
      Height = 17
      Caption = 'show data'
      Checked = True
      State = cbChecked
      TabOrder = 0
      OnClick = CB_dataShowClick
    end
    object CB_avgShow: TCheckBox
      Left = 10
      Top = 47
      Width = 97
      Height = 17
      Caption = 'show average'
      Checked = True
      State = cbChecked
      TabOrder = 1
      OnClick = CB_dataShowClick
    end
    object CB_trendShow: TCheckBox
      Left = 10
      Top = 70
      Width = 97
      Height = 17
      Caption = 'show trend'
      TabOrder = 2
      OnClick = CB_dataShowClick
    end
    object Button1: TButton
      Left = 128
      Top = 16
      Width = 73
      Height = 25
      Caption = 'edit'
      TabOrder = 3
      OnClick = Button1Click
    end
  end
  object GroupBox1: TGroupBox
    Left = 800
    Top = 8
    Width = 241
    Height = 337
    Caption = 'settings / development parameters'
    TabOrder = 3
    object Label4: TLabel
      Left = 16
      Top = 222
      Width = 109
      Height = 13
      Caption = 'calculations per round:'
    end
    object Label3: TLabel
      Left = 29
      Top = 195
      Width = 96
      Height = 13
      Caption = 'time until next step:'
    end
    object Label5: TLabel
      Left = 171
      Top = 55
      Width = 14
      Height = 13
      Caption = 'to:'
    end
    object Label7: TLabel
      Left = 76
      Top = 159
      Width = 51
      Height = 13
      Caption = 'increment:'
    end
    object Label15: TLabel
      Left = 33
      Top = 32
      Width = 93
      Height = 13
      Alignment = taRightJustify
      Caption = 'centripetal weight :'
    end
    object Label1: TLabel
      Left = 34
      Top = 55
      Width = 93
      Height = 13
      Alignment = taRightJustify
      Caption = 'centrifugal weight :'
    end
    object Label2: TLabel
      Left = 170
      Top = 32
      Width = 14
      Height = 13
      Caption = 'to:'
    end
    object Label6: TLabel
      Left = 42
      Top = 105
      Width = 85
      Height = 13
      Alignment = taRightJustify
      Caption = 'centrifugal scale :'
    end
    object Label9: TLabel
      Left = 171
      Top = 105
      Width = 14
      Height = 13
      Caption = 'to:'
    end
    object Label10: TLabel
      Left = 42
      Top = 83
      Width = 85
      Height = 13
      Alignment = taRightJustify
      Caption = 'centripetal scale :'
    end
    object Label11: TLabel
      Left = 171
      Top = 83
      Width = 14
      Height = 13
      Caption = 'to:'
    end
    object lbl_pSteps: TLabel
      Left = 64
      Top = 279
      Width = 49
      Height = 13
      Alignment = taRightJustify
      Caption = 'lbl_pSteps'
    end
    object lbl_timesteps: TLabel
      Left = 119
      Top = 279
      Width = 53
      Height = 13
      Caption = ': timesteps'
    end
    object Lbl_akt: TLabel
      Left = 54
      Top = 314
      Width = 19
      Height = 13
      Alignment = taRightJustify
      Caption = 'sum'
    end
    object Lbl_proceed: TLabel
      Left = 94
      Top = 314
      Width = 19
      Height = 13
      Alignment = taRightJustify
      Caption = 'sum'
    end
    object Label8: TLabel
      Left = 119
      Top = 314
      Width = 62
      Height = 13
      Caption = ': calculations'
    end
    object B_startStop: TSpeedButton
      Left = 126
      Top = 248
      Width = 75
      Height = 25
      AllowAllUp = True
      GroupIndex = 1
      Caption = 'start / stop'
      OnClick = B_startStopClick
    end
    object Label12: TLabel
      Left = 119
      Top = 296
      Width = 67
      Height = 13
      Caption = ': actual round'
    end
    object Lbl_round: TLabel
      Left = 98
      Top = 296
      Width = 15
      Height = 13
      Alignment = taRightJustify
      Caption = 'rds'
    end
    object Lbl_mainRds: TLabel
      Left = 53
      Top = 295
      Width = 35
      Height = 13
      Alignment = taRightJustify
      BiDiMode = bdLeftToRight
      Caption = 'mainRd'
      ParentBiDiMode = False
    end
    object Label14: TLabel
      Left = 57
      Top = 133
      Width = 70
      Height = 13
      Alignment = taRightJustify
      Caption = 'random scale :'
    end
    object Label16: TLabel
      Left = 171
      Top = 133
      Width = 14
      Height = 13
      Caption = 'to:'
    end
    object B_start: TButton
      Left = 43
      Top = 248
      Width = 75
      Height = 25
      Caption = 'new start'
      TabOrder = 0
      OnClick = B_startClick
    end
    object E0_valFrom: TEdit
      Left = 133
      Top = 52
      Width = 32
      Height = 21
      TabOrder = 1
      Text = '1,0'
      OnChange = E0_valFromChange
    end
    object E0_valTo: TEdit
      Left = 191
      Top = 52
      Width = 32
      Height = 21
      TabOrder = 2
      Text = '10,0'
      OnChange = E0_valFromChange
    end
    object E_incre: TEdit
      Left = 133
      Top = 156
      Width = 32
      Height = 21
      TabOrder = 3
      Text = '0,2'
      OnChange = E0_valFromChange
    end
    object E1_valFrom: TEdit
      Left = 132
      Top = 29
      Width = 32
      Height = 21
      TabOrder = 4
      Text = '1,0'
      OnChange = E0_valFromChange
    end
    object E1_valTo: TEdit
      Left = 190
      Top = 29
      Width = 32
      Height = 21
      TabOrder = 5
      Text = '10,0'
      OnChange = E0_valFromChange
    end
    object E2_valFrom: TEdit
      Left = 133
      Top = 102
      Width = 32
      Height = 21
      TabOrder = 6
      Text = '1,0'
      OnChange = E0_valFromChange
    end
    object E2_valTo: TEdit
      Left = 191
      Top = 102
      Width = 32
      Height = 21
      TabOrder = 7
      Text = '3,0'
      OnChange = E0_valFromChange
    end
    object E3_valFrom: TEdit
      Left = 133
      Top = 79
      Width = 32
      Height = 21
      TabOrder = 8
      Text = '1,0'
      OnChange = E0_valFromChange
    end
    object E3_valTo: TEdit
      Left = 191
      Top = 79
      Width = 32
      Height = 21
      TabOrder = 9
      Text = '3,0'
      OnChange = E0_valFromChange
    end
    object SE_toSteps: TSpinEdit
      Left = 133
      Top = 190
      Width = 68
      Height = 22
      Increment = 10
      MaxValue = 10000
      MinValue = 0
      TabOrder = 10
      Value = 300
    end
    object SE_perVal: TSpinEdit
      Left = 133
      Top = 218
      Width = 68
      Height = 22
      MaxValue = 1000
      MinValue = 1
      TabOrder = 11
      Value = 2
      OnChange = E0_valFromChange
    end
    object CB0_acti: TCheckBox
      Left = 10
      Top = 54
      Width = 20
      Height = 17
      TabOrder = 12
      OnClick = CB0_actiClick
    end
    object CB1_acti: TCheckBox
      Left = 9
      Top = 31
      Width = 20
      Height = 17
      TabOrder = 13
      OnClick = CB0_actiClick
    end
    object CB2_acti: TCheckBox
      Left = 10
      Top = 104
      Width = 20
      Height = 17
      TabOrder = 14
      OnClick = CB0_actiClick
    end
    object CB3_acti: TCheckBox
      Left = 10
      Top = 81
      Width = 20
      Height = 17
      TabOrder = 15
      OnClick = CB0_actiClick
    end
    object cb_multiply: TCheckBox
      Left = 171
      Top = 158
      Width = 67
      Height = 17
      Caption = 'multiply'
      TabOrder = 16
    end
    object CB4_acti: TCheckBox
      Left = 10
      Top = 131
      Width = 20
      Height = 17
      TabOrder = 17
      OnClick = CB0_actiClick
    end
    object E4_valFrom: TEdit
      Left = 133
      Top = 129
      Width = 32
      Height = 21
      TabOrder = 18
      Text = '1'
      OnChange = E0_valFromChange
    end
    object E4_valTo: TEdit
      Left = 191
      Top = 129
      Width = 32
      Height = 21
      TabOrder = 19
      Text = '1000'
      OnChange = E0_valFromChange
    end
  end
  object GroupBox2: TGroupBox
    Left = 800
    Top = 457
    Width = 240
    Height = 73
    Caption = 'save snapshot'
    TabOrder = 4
    object Label13: TLabel
      Left = 10
      Top = 47
      Width = 57
      Height = 13
      Caption = 'basic name:'
    end
    object Cb_saveSnap: TCheckBox
      Left = 10
      Top = 16
      Width = 151
      Height = 17
      Caption = 'save snapshot per value'
      TabOrder = 0
      OnClick = CB_dataShowClick
    end
    object E_bName: TEdit
      Left = 73
      Top = 43
      Width = 152
      Height = 21
      TabOrder = 1
      Text = 'xx_GrowingCity'
      OnChange = E_bNameChange
    end
  end
  object Timer4: TTimer
    Enabled = False
    Interval = 1
    OnTimer = Timer4Timer
    Left = 936
    Top = 537
  end
  object ChartEditor_devPara: TChartEditor
    Chart = Chart_devPara
    Left = 904
    Top = 535
  end
end

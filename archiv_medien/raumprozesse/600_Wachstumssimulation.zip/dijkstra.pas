unit dijkstra;

interface

uses
  Windows, Classes, Graphics, agent, math;

Procedure CalculatePathes;
Procedure PathesDijkstra(StartNode: TAgent; idx: Integer);
Procedure ListenReset;
Procedure PathesToGlobalList(I: Integer);

implementation

uses Main, MAIN_win, ConnTable;

//======================================pathes form all nodes to all other nodes
// ------------------------------------ http://www.mcgods.de/fun/1904/node8.html
Procedure CalculatePathes;
var
  I, J               : Integer;
  StartNode, CurNode : TAgent;
begin
  ListenReset;
  Form1.Panel_PBar.Visible := true;
  Form1.lbl_calcer.Update;
  For I := 0 To NodeList.Count -1 Do
  begin
    For J := 0 To NodeList.Count-1 Do begin // reset the Dijkstra-States (or colors)
      CurNode := NodeList.Items[J];
      CurNode.DijS := 0;                    // state: 0=free; 1=open ; 2=closed
      CurNode.DijDist := 0;                 // reset the temporary distance to the start cell
    end;
    StartNode := NodeList.Items[I];         // define the start node
    PathesDijkstra(StartNode, I);           // calculate the shortest pathes from the start node to all others
    PathesToGlobalList(I);                  // transfer the calculated pathes to the global PathList
    IF NodeList.Count > 0 Then Form1.ProgressBar1.Position := round(I/(NodeList.Count)*100);
  end;
  Form1.Panel_PBar.Visible := false;
end;

//============================================================Dijkstra Algorithm
Procedure PathesDijkstra(StartNode: TAgent; idx: Integer);
var
  I, curIdx, minDist : Integer;
  CurNode, FromNode  : TAgent;
  OpenList           : TList;
begin
  OpenList := TList.Create;
  StartNode.DijS := 2;
  For I := 0 To length(StartNode.NachbList)-1 Do
  begin
    CurNode := NodeList.Items[StartNode.NachbList[I].nr];
    CurNode.DijArr[idx].Clear;
    CurNode.DijArr[idx].Add(StartNode);                                      // add the start node
    curIdx  := NodeList.IndexOf(CurNode);
    StartNode.DijArr[curIdx].Assign(CurNode.DijArr[idx]);                    // save the path also at the startNode
    CurNode.DijDist := 1;
    OpenList.Add(CurNode);
  end;
  While OpenList.Count > 0 Do                                                // repeat until all open Nodes are considered
  begin
    minDist := 99999999;
    For I := 0 To OpenList.Count-1 Do
    begin
      CurNode := OpenList.Items[I];
      If CurNode.DijDist < minDist Then                                      // find node with the minDist to start-node
      begin
        curIdx := I;
        minDist := CurNode.DijDist;
      end;
    end;
    FromNode := OpenList.Items[curIdx];                                      // choose node from openList
    FromNode.DijS := 2;                                                      // set state to red
    OpenList.Remove(FromNode);                                               // remove the node from the openList = green = state 2
    For I := 0 To length(FromNode.NachbList)-1 Do
    begin
      CurNode := NodeList.Items[FromNode.NachbList[I].nr];
      curIdx := NodeList.IndexOf(CurNode);
      If CurNode.DijS = 0 Then                                               // consider the first time (white)
      begin
        CurNode.DijS := 1;                                                   // red Node
        CurNode.DijArr[idx].Clear; 
        CurNode.DijArr[idx].Assign(FromNode.DijArr[idx]);                    // copy the path to the startNode from the previous node
        CurNode.DijArr[idx].Add(CurNode);                                    // add the current node
        StartNode.DijArr[curIdx].Assign(CurNode.DijArr[idx]);                // save the path also at the startNode
        CurNode.DijDist := CurNode.DijArr[idx].Count;                        // temp best dist
        OpenList.Add(CurNode);
      end else If CurNode.DijS = 1 Then                                      // consider the red Nodes
      begin
        If CurNode.DijArr[idx].Count > FromNode.DijArr[idx].Count +1 Then    // compare the alredy calculated path-length with the new candidate
        begin
          CurNode.DijArr[idx].Clear;                                         // delete the old path
          CurNode.DijArr[idx].Assign(FromNode.DijArr[idx]);                  // copy the path to the startNode from the previous node
          CurNode.DijArr[idx].Add(CurNode);                                  // add the current node
          StartNode.DijArr[curIdx].Clear;
          StartNode.DijArr[curIdx].Assign(CurNode.DijArr[idx]);              // save the path also at the startNode
          CurNode.DijDist := CurNode.DijArr[idx].Count;                      // temp best dist
        end;
      end;
    end;
  end;
  OpenList.Free;
end;

//=========================================reset the lists required for dijkstra
Procedure ListenReset;
var
  I, K    : Integer;
  CurNode : TAgent;
begin
  try
    ConnectivityTable.StringGrid1.Cells[0,0]:= '';
  except
    MainForm.CreateMyMDIChild(TConnectivityTable);
    ConnectivityTable.StringGrid1.Cells[K+1, I+1]:= '';
    Form1.Show;
  end;
  For I := 0 To NodeList.Count-1 Do
  begin
    CurNode := NodeList.Items[I];
    If length(CurNode.DijArr) > 0 Then
    begin
      For K := 0 To length(CurNode.DijArr)-1 Do
      begin
        CurNode.DijArr[K].Free;
        ConnectivityTable.StringGrid1.Cells[K+1, I+1]:= '';
        PathList[I, K].Free;
      end;
    end;
    SetLength(CurNode.DijArr, 0);
  end;
  SetLength  (PathList, 0, 0);
  SetLength  (PathList, NodeList.Count, NodeList.Count);
  For I := 0 To NodeList.Count-1 Do
  begin
    CurNode := NodeList.Items[I];
    SetLength(CurNode.DijArr, NodeList.Count);
    For K := 0 To NodeList.Count-1 Do
    begin
      CurNode.DijArr[K] := TList.Create;
      PathList[I, K]    := TList.Create;
    end;
  end;
end;

//=========================transfer the calculated pathes to the global PathList
Procedure PathesToGlobalList(I: Integer);
var
  K       : Integer;
  CurNode : TAgent;
begin
  CurNode := NodeList.Items[I];
  For K := 0 To length(CurNode.DijArr)-1 Do
  begin
    PathList[I, K].Assign(CurNode.DijArr[K]);
  end;
end;

end.

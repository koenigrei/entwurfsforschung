unit agent;

interface

uses
  Windows, Graphics, Classes, Math, Cell, StdCtrls, SysUtils;

type TNachb = record       // --- f�r A* Heuristik
      nr     : Integer;    // --- = NeigborList
      dist   : Integer;    // --- entfernung zum Nachbarn
end;

type
  TAgent = class
  private

  public
    F  : Integer;
    G  : Integer;
    H  : Integer;
    Vorg   : Pointer;
    closed : Boolean;
    NachbList : Array of TNachb;
    Usage     : Array of Integer;  //-- z�hlt die Benutzung einer Verindung
    //--------------------------------------------------------------------------
    nullDist      : Single;        //-- distance to the first (central) node
    sML           : Single;        //-- Standardised mean length
    FPositionX    : Integer;       //-- XKoordinate
    FPositionY    : Integer;       //-- YKoordinate
    OnCell        : TPoint;        //-- Coordinate of the cell
    FSize         : Integer;       //-- Gr��e des Agenten
    FStepX        : Double;        //-- X-Anteil des Bewegungsvektors
    FStepY        : Double;        //-- Y-Anteil des Bewegungsvektors
    FFillColor    : Integer;       //-- Farbe des Agenten
    FState        : Integer;       //-- Art des Agenten
    DijS          : SmallInt;      //-- State for the Dijkstra Algo. 0=weiss=leer; 1=rot=grenze; 2=gr�n=abgeschlossen : http://www.mcgods.de/fun/1904/node8.html
    DijArr        : Array of TList;
    DijDist       : Integer;       // -- emporary distance to the start cell
    procedure Paint           (Canvas: TCanvas);
    procedure SetPositionX    (const Value: Integer);
    procedure SetPositionY    (const Value: Integer);
    procedure SetStepX        (const Value: Double);
    procedure SetStepY        (const Value: Double);
    procedure SetSize         (const Value: Integer);
    procedure SetFillColor    (const Value: Integer);
    procedure SetState        (const Value: Integer);
  published
    property PositionX   : Integer read FPositionX    write SetPositionX;
    property PositionY   : Integer read FPositionY    write SetPositionY;
    property StepX       : Double  read FStepX        write SetStepX;
    property StepY       : Double  read FStepY        write SetStepY;
    property Size        : Integer read FSize         write SetSize;
    property FillColor   : Integer read FFillColor    write SetFillColor;
    property State       : Integer read FState        write SetState;
  end;

var LabelList : TList;

procedure AgentsCreate(curCell : TCell);
procedure AgentsPaint;
procedure AgentsPaint_gray;

implementation

uses Main;

//=================================================================create agents
procedure AgentsCreate(curCell : TCell);
var
  Idx      : Integer;
  CurAgent : TAgent;
  NodeLabel: TLabel;
begin
  curCell.State      := 1;
  curCell.NodeNr     := NodeList.Count;
  CurAgent           := TAgent.Create;
  CurAgent.PositionX := curCell.Pos.X;
  CurAgent.PositionY := curCell.Pos.Y;
  CurAgent.OnCell.X  := curCell.Koord.X;
  CurAgent.OnCell.Y  := curCell.Koord.Y;
  CurAgent.FillColor := clGray;
  CurAgent.Size      := Form1.SE_nSz.Value;
  CurAgent.State     := 0;
  CurAgent.Paint (Image_Agents.Canvas);
  NodeList.Add   (CurAgent);
  inc(steps);
  If Form1.CB_nodeLbl.Checked Then
  begin
    NodeLabel             := TLabel.Create(Form1);
    NodeLabel.Parent      := Form1;
    NodeLabel.Enabled     := true;
    NodeLabel.Top         := CurAgent.PositionY-13;
    NodeLabel.Left        := CurAgent.PositionX-5;
    NodeLabel.Font.Color  := clBlack;
    NodeLabel.Height      := 6;
    NodeLabel.Width       := 6;
    NodeLabel.Font.Size   := 6;
    NodeLabel.Font.Color  := clNavy;
    Idx := NodeList.IndexOf(CurAgent);
    NodeLabel.Caption     := IntToStr(Idx);
    NodeLabel.Transparent := True;
    Image_Agents.Canvas.Brush.Color         := clBlack;
    Image_Agents.Picture.Bitmap.Canvas.Font := NodeLabel.Font;
    Image_Agents.Picture.Bitmap.Canvas.TextOut(NodeLabel.Left, NodeLabel.Top, NodeLabel.Caption);
    LabelList.Add(NodeLabel);
  end;
  Form1.testNeighState;
end;

//==============================================================Agenten zeichnen
procedure AgentsPaint;
var
  I        : Integer;
  CurAgent : TAgent;
begin
  Image_Agents.Canvas.Pen.Width := 1;
  for I := 0 to NodeList.Count - 1 do                                       // repaint each agent of the list
  begin
    CurAgent      := NodeList.Items [I];
    CurAgent.Size := Form1.SE_nSz.Value;
    CurAgent.Paint (Image_Agents.Canvas);
  end;
end;

procedure AgentsPaint_gray;
var
  I        : Integer;
  CurAgent : TAgent;
begin
  Image_Agents.Canvas.Pen.Width := 1;
  for I := 0 to NodeList.Count - 1 do                                       // repaint each agent of the list
  begin
    CurAgent      := NodeList.Items [I];
    CurAgent.Size := Form1.SE_nSz.Value;
    CurAgent.FillColor := clGray;
    CurAgent.Paint (Image_Agents.Canvas);
  end;
end;

// ********* Zeichnungseinstellungen f�r die Agentenrepr�sentation **********//
procedure TAgent.Paint(Canvas: TCanvas);
begin
  Canvas.Pen.Color := clGreen;
  Canvas.Pen.Style := psSolid;                                                 // (psSolid, psDash, psDot, psClear)
  Canvas.Brush.Color := FillColor;
  Canvas.Ellipse (FPositionX - FSize , FPositionY - (FSize), FPositionX + (FSize), FPositionY + (FSize));
end;

procedure TAgent.SetStepX(const Value: Double);
begin
  FStepX := Value;
end;

procedure TAgent.SetStepY(const Value: Double);
begin
  FStepY := Value;
end;

procedure TAgent.SetPositionX(const Value: Integer);
begin
  FPositionX := Value;
end;

procedure TAgent.SetPositionY(const Value: Integer);
begin
  FPositionY := Value;
end;

procedure TAgent.SetSize(const Value: Integer);
begin
  FSize := Value;
end;

procedure TAgent.SetFillColor(const Value: Integer);
begin
  FFillColor := Value;
end;

procedure TAgent.SetState(const Value: Integer);
begin
  FState := Value;
end;

end.

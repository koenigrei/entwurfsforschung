unit cluster;

interface

uses
  Windows, Classes, Graphics, cell, agent, math, SysUtils;

procedure DetermineCluster;
procedure PaintCluster;
procedure startCAna;
procedure plotClusterSize(var clustCount: Array of Cardinal);
procedure findCluster (K, I: Integer; clustNr: Integer; var clustCount: Array of Cardinal);
procedure checkClustMoore (K, I: Integer; var clustCount: Array of Cardinal);
procedure resetCluster;
procedure ClusterSort(var clustCount: Array of Cardinal);
procedure centerGravity (var centerK : TPoint);
procedure centerNode (var centerN : Integer);

implementation

uses Main, potentialField, connTable;


//=========================================================find the central node (connectivity)
procedure centerNode (var centerN : Integer);
var
   I               : Integer;
   minVal, curVal  : Single;
begin
   minVal := 999999999;
   For I:= 0 To NodeList.Count - 1 Do
   begin
      curVal := StrToFloat(ConnectivityTable.StringGrid1.Cells[NodeList.Count+2, I+1]);  // mean length per node (row)
      If curVal < minVal Then
      begin
         minVal  := curVal;
         centerN := I;
      end;
   end;
end;

//==============================================calculates the center of gravity (center of mass) of the urban cluster
procedure centerGravity (var centerK : TPoint);
var
   I, K : Integer;
   curCell : TCell;
   counter : Cardinal;
begin
   centerK.X := 0;
   centerK.Y := 0;
   counter   := 0;
   for I := 0 to reih*3 -1 do
   begin
      for K := 0 to spalt*3 -1 do
      begin
         curCell := smalGridList[K, I];
         If curCell.cState = 2 Then
         begin
            centerK.X := centerK.X + curCell.Koord.X;
            centerK.Y := centerK.Y + curCell.Koord.Y;
            inc(counter);
         end;
      end;
   end;
   centerK.X := round(centerK.X / counter);
   centerK.Y := round(centerK.Y / counter);
end;

//==============================================================================
procedure DetermineCluster;
var
  I, K             : Integer;
  curCell, parCell : TCell;
begin
  for I := 0 to reih -1 do
  begin
    for K := 0 to spalt -1 do
    begin
      parCell := cellList[K, I];
      parCell.devDense := 0;                                                 // reset devDense counter
    end;
  end;

  SetLength(groupSz,0);
  SetLength(groupSz,2);
  for I := 0 to reih*3 -1 do
  begin
    for K := 0 to spalt*3 -1 do
    begin
      curCell := smalGridList[K, I];
      If curCell.cState = 2 Then                                             // if cell is in build on state
      begin
        curCell.isDev := true;                                               // define as developed
        inc(groupSz[1]);
      end else If curCell.cState = 1 Then                                    // if cell is in street state
      begin
        If checkDev(K, I) = true Then
        begin                                                                // and a build on cell is in the neighbourhood
          curCell.isDev := true;                                             // then cell is defined as developed
          inc(groupSz[1]);
        end else begin
          curCell.isDev := false;                                            // otherwise it's defined as not developed
          inc(groupSz[0]);
        end;
      end else If curCell.cState = 0 Then                                    // if cell is empty
      begin
        curCell.isDev := false;                                              // define as not developed
        inc(groupSz[0]);
      end;
      //--- count devCells ----------------------
      parCell := cellList[floor(K/3), floor(I/3)];
      IF curCell.isDev Then inc(parCell.devDense);
    end;
  end;
end;

//===============================================================paint the cells
procedure PaintCluster;
var
  I, K    : Integer;
  curCell : TCell;
begin
  for I := 0 to reih*3 -1 do
  begin
    for K := 0 to spalt*3 -1 do
    begin
      curCell := smalGridList[K, I];
      IF curCell.isDev Then
      begin
        curCell.colr := clBlack;
      end else begin
        curCell.colr := clwhite;
      end;
      curCell.Paint (Image_SmalGrid.Canvas);
    end;
  end;
  Image_SmalGrid.Canvas.Refresh;
end;

//===============================================================Cluster Analyse
procedure startCAna;
var
  curCell    : TCell;
  I, K       : Integer;
  clustNr    : Integer;
  clustCount : Array of Cardinal;
begin
  SetLength (clustCount, 0);
  resetCluster;
  clustNr := 1;
  for I := 0 to reih*3 -1 do
  begin
    for K := 0 to spalt*3 -1 do
    begin
      curCell := smalGridList[K,I];
      curCell.toCluster := -1;
    end;
  end;
  for I := 0 to reih*3 -1 do
  begin
    for K := 0 to spalt*3 -1 do
    begin
      curCell := smalGridList[K,I];
      If (curCell.isDev = true) and (curCell.clCeck = false) Then
      begin
        smalGridList[K,I].clCeck := true;
        setLength(clustCount, length(clustCount) +1);
        inc(clustCount[High(clustCount)]);
        findCluster (K,I, clustNr, clustCount);
        inc (clustNr);
      end;
    end;
  end;
  for I := 0 to reih*3 -1 do
  begin
    for K := 0 to spalt*3 -1 do
    begin
      curCell := smalGridList[K,I];
      If not (curCell.toCluster = -1) Then
      curCell.ClustSize := clustCount[curCell.toCluster];
    end;
  end;
  ClusterSort(clustCount);
  plotClusterSize(clustCount);
end;

//========================================================plot the cluster sizes
procedure plotClusterSize(var clustCount: Array of Cardinal);
var
  I, counter        : Integer;
  r2Rank, slopeRank : Single;
  logClustCt        : Array of Single;
begin
  SetLength(logClustCt, length(clustCount));
  Form1.Ch_clusterSize.UndoZoom;
  Form1.Chart_rank.UndoZoom;
  Form1.bar_clusterSize.Clear;
  Form1.ser_rank.Clear;
  Form1.ser_rankTrend.Clear;
  counter := 0;
  For I := length(clustCount)-1 DownTo 0 Do
  begin
    If (clustCount[I] > 10) Then begin
      Form1.bar_clusterSize.AddXY(counter, clustCount[I]);
      inc(counter);
    end;
    logClustCt[I] := log10(clustCount[I]);
    Form1.ser_rank.AddXY(log10(length(clustCount)-I),  logClustCt[I]);
  end;
  Form1.ser_rankCorr.CheckDataSource;
  Form1.ser_rankTrend.CheckDataSource;

  r2Rank := Power(Form1.ser_rankCorr.YValues[1], 2);
  If length(clustCount) > 1 Then
  begin
    slopeRank := Form1.ser_rankTrend.YValues[1] - Form1.ser_rankTrend.YValues[0] / log10(length(clustCount));
  end else slopeRank := 0;
  Form1.ser_RS.AddXY(time, slopeRank * -1);
  Form1.ValueListEditor1.Values['slope_rank'] := FloatToStr((roundTo(slopeRank, -2)));
  Form1.Chart_rank.Title.Text.Clear;
  Form1.Chart_rank.Title.Text.Add('Rank-Size (RS) : r� = ' + FloatToStr(roundTo(r2Rank, -2))
                                + '; slope = ' + FloatToStr(roundTo(slopeRank, -2)));
end;

//===========================================================Cluster Analysieren
procedure findCluster (K, I: Integer; clustNr: Integer; var clustCount: Array of Cardinal);
var
  curCell  : TCell;
  M        : Integer;
begin
  curCell  := smalGridList[K, I];
  checkClustMoore (K,I, clustCount);
  for M := 0 to High(curCell.sameNB) do
  begin
    findCluster(curCell.sameNB[M].X, curCell.sameNB[M].Y, clustNr, clustCount); // -- Rekursion
  end;
end;

//===========================================von Neumann Nachbarschaft, mit den Abstand 1 �berpr�fen
procedure checkClustMoore (K, I: Integer; var clustCount: Array of Cardinal);
var
  v        : Integer;
  Xp, Yp   : Integer;
  koNei    : Array [0..3] of TPoint;
  curCell  : TCell;
begin
  // --- Summe berechnen ---
  koNei[0].X := K;    koNei[0].Y := I + 1;
  koNei[1].X := K;    koNei[1].Y := I - 1;
  koNei[2].X := K+1;  koNei[2].Y := I;
  koNei[3].X := K-1;  koNei[3].Y := I;

  for v := 0 to 3 do
  begin
    Xp := koNei[v].X;
    Yp := koNei[v].Y;
    If Form1.smallGridWrap(Xp, Yp) = true Then
    begin
    curCell := smalGridList[K, I];
    If ((smalGridList[Xp, Yp].isDev = true) AND (smalGridList[Xp, Yp].clCeck = false)) then
    begin
      setLength(curCell.sameNB, length(curCell.sameNB)+1);
      curCell.sameNB[high(curCell.sameNB)].X := Xp;
      curCell.sameNB[high(curCell.sameNB)].Y := Yp;
      smalGridList[Xp, Yp].clCeck := true;
      smalGridList[Xp, Yp].toCluster := High(clustCount);
      inc(clustCount[High(clustCount)]);
    end;
    end;
  end;
end;

//=================================================Clusterparameter zur�cksetzen
procedure resetCluster;
var
  curCell : TCell;
  I, K    : Integer;
begin
  for I := 0 to reih*3 -1 do
  begin
    for K := 0 to spalt*3 -1 do
    begin
      curCell    := smalGridList[K,I];
      setLength (curCell.sameNB, 0);
      curCell.clCeck := false;
    end;
  end;
end;

//==============================================================================
procedure ClusterSort(var clustCount: Array of Cardinal);
  procedure P_DenseSort(var clustCount: Array of Cardinal; iLo, iHi: integer);
  var
    Lo, Hi: integer;
    T, Mid: Cardinal;
  begin
    Lo := iLo;
    Hi := iHi;
    Mid := clustCount[(Lo + Hi) div 2];
    repeat
      while clustCount[Lo] < Mid do
        Inc(Lo);
      while clustCount[Hi] > Mid do
        Dec(Hi);
      if Lo <= Hi then
        begin
          T := clustCount[Lo];
          clustCount[Lo] := clustCount[Hi];
          clustCount[Hi] := T;
          Inc(Lo);
          Dec(Hi);
        end;
    until Lo > Hi;
    if Hi > iLo then
      P_DenseSort(clustCount, iLo, Hi);
    if Lo < iHi then
      P_DenseSort(clustCount, Lo, iHi);
  end;
begin
  if High(clustCount) > 1 then
    P_DenseSort(clustCount, Low(clustCount), High(clustCount));
end;

end.

unit cell;

interface

uses
  Windows, Graphics, Classes, Math, SysUtils;

type
  TCell = class
  private
  public
    // --- for raster_AStern ---
    F  : Integer;
    G  : Integer;
    H  : Integer;
    Vorg   : Pointer;
    closed : Boolean;
    // -------------------------
    basicRnd    : Single;
    colr        : TColor;            // Farbwert der Zelle
    Pot         : Single;            // local potential value
    Pos         : TPoint;
    Koord       : TPoint;
    buildDense  : Cardinal;          // number of build on sub-cells
    streetDense : Cardinal;          // number of build on sub-cells
    devDense    : Cardinal;          // number of developed cells
    isDev       : Boolean;           // is a cell is considered as developed (true) or not (false)
    clCeck      : Boolean;           // indicates it the cell is already considered for the cluster counting
    toCluster   : Integer;           // indicates to which cluster the cell belongs
    ClustSize   : Cardinal;          // indicates the sizes of the cluster the cell belongs to
    sameNB      : Array of TPoint;   // -- neighbours with same state
    NodeNr      : Cardinal;          // Index of the node on the cell
    FSize       : Integer;
    FFillColor  : Integer;
    FState      : Integer;           // state for node development
    cState      : Integer;           // 0=free, 1=street, 2=built on
    subState    : Integer;           // 0=free, 1=street, 2=built on, 3=green :=> states for build on CA
    procedure Paint         (Canvas: TCanvas);
    procedure SetSize       (const Value: Integer);
    procedure SetFillColor  (const Value: Integer);
    procedure SetState      (const Value: Integer);
    constructor create      (xPos, yPos, size, colr: Integer);
  published
    property Size     : Integer read FSize      write SetSize;
    property FillColor: Integer read FFillColor write SetFillColor;
    property State    : Integer read FState     write SetState;
  end;

procedure CellsCreate;
procedure CellsSetup;
procedure CellsPaint;
procedure SmalGridCreate;
procedure PotentialTransfer;
procedure SmallGridPaint;
procedure SmallGrid_SubStatePaint;
procedure paint_candidate;

implementation

uses Main, transferLine;

//==============================================================================
// *** defines the sphere of influence - dependent of the cluster-size *********
procedure paintSmallGrid;
var
  curCell   : TCell;
  K, I, col : Integer;
begin
  for I := 0 to reih*3 -1 do
  begin
    for K := 0 to spalt*3 -1 do
    begin
      curCell := SmalGridList[K,I];
      If curCell.cState = 1 then begin
        curCell.colr  := clYellow;
      end else If curCell.cState = 2 then begin
        curCell.colr  := clBlue; 
      end else curCell.colr  := clWhite;
      curCell.Paint (Image_Cells.Canvas);
    end;
  end;
end;

//========================================potential from smallGrid to parentGrid
procedure PotentialTransfer;
var
  curCell, subCell  : TCell;
  I, K, L, M        : Integer;
  creaPt            : TPoint;
  halfScal, subScal : Integer;
begin
  subScal  := floor (cellScal/2/3);
  for I := 0 to reih -1 do
  begin
    for K := 0 to spalt -1 do
    begin
      curCell := cellList[K,I];
      for L := -1 to 1 do
      begin
        for M := -1 to 1 do
        begin
          subCell     := SmalGridList[K*3+M+1, I*3+L+1];
          subCell.Pot := curCell.Pot;
        end;
      end;
    end;
  end;
end;

//==============================================================Zellen erstellen
procedure SmalGridCreate;
var
  curCell, subCell  : TCell;
  I, K, L, M        : Integer;
  creaPt            : TPoint;
  halfScal, subScal : Integer;
  rdnSize           : Single;
begin
  rdnSize := StrToFloat(Form1.E_rndScale.Text);
  subScal  := floor (cellScal/2/3);
  for I := 0 to reih -1 do
  begin
    for K := 0 to spalt -1 do
    begin
      curCell := cellList[K,I];
      for L := -1 to 1 do
      begin
        for M := -1 to 1 do
        begin
          creaPt.X := curCell.Pos.X + round(M*0.33*cellScal);
          creaPt.Y := curCell.Pos.Y + round(L*0.33*cellScal);
          subCell  := TCell.Create(creaPt.X, creaPt.Y, subScal, 0);
          subCell.colr      := clWhite; //RGB(222, 222, 222);
          subCell.Pot       := curCell.Pot;
          subCell.state     := 0;
          subCell.Koord.X   := K*3+M+1;
          subCell.Koord.Y   := I*3+L+1;
          subCell.cState    := 0;
          subCell.isDev     := false;
          subCell.basicRnd  := random()*rdnSize;
          subCell.Paint(Image_SmalGrid.Canvas);
          SmalGridList[K*3+M+1, I*3+L+1] := subCell;
        end;
      end;
    end;
  end;
end;

//==============================================================Zellen erstellen
procedure CellsCreate;
var
  curCell : TCell;
  I, K    : Integer;
  creaPt  : TPoint;
  halfScal: Integer;
begin
  halfScal    := floor (cellScal/2);
  If cellList[5,5] = nil Then
  begin
    time := 0;
  end;
  for I := 0 to reih -1 do
  begin
    for K := 0 to spalt -1 do
    begin
      creaPt.X := halfScal + K * cellScal;
      creaPt.Y := halfScal + I * cellScal;
      curCell  := TCell.Create(creaPt.X, creaPt.Y, halfScal, 0);
      cellList[K,I] := curCell;
    end;
  end;
end;

//===============================================================Zellen zeichnen
procedure CellsPaint;
var I, K    : Integer;
    curCell : TCell;
begin
  for I := 0 to reih -1 do
  begin
    for K := 0 to spalt -1 do
    begin
      curCell := cellList[K,I];
      curCell.colr := clWhite;
      curCell.Paint(Image_Cells.Canvas);
    end;
  end;
end;

//==============================================================================
procedure SmallGridPaint;
var
  I, K : Integer;
  curCell : TCell;
begin
  for I := 0 to reih*3 -1 do
  begin
    for K := 0 to spalt*3 -1 do
    begin
      curCell := smalGridList[K, I];
      If curCell.cState = 2 Then                                             // if cell is in build on state
      begin
        curCell.colr := clBlue;
      end else If curCell.cState = 1 Then                                    // if cell is in street state
      begin
        curCell.colr := clYellow;
      end else If curCell.cState = 0 Then                                    // if cell is empty
      begin
        curCell.colr := clWhite;//RGB(155, 155, 155);
      end;
      curCell.Paint (Image_SmalGrid.Canvas);
    end;
  end;
end;

//==============================================================================
procedure SmallGrid_SubStatePaint;
var
  I, K : Integer;
  curCell : TCell;
begin
  for I := 0 to reih*3 -1 do
  begin
    for K := 0 to spalt*3 -1 do
    begin
      curCell := smalGridList[K, I];
      If curCell.subState = 3 Then                                           // if cell is in build on state
      begin
        curCell.colr := clLime;
      end else If curCell.subState = 2 Then                                  // if cell is in build on state
      begin
        curCell.colr := clBlue;
      end else If curCell.subState = 0 Then                                  // if cell is empty
      begin
        curCell.colr := clWhite;//RGB(155, 155, 155);
      end;
      If curCell.cState = 1 Then                                             // if cell is in street state
      begin
        curCell.colr := clYellow;
      end;
      curCell.Paint (Image_SmalGrid.Canvas);
    end;
  end;
end;

//=======================================================test neighbouring cells
procedure paint_candidate;
var
  J, I, K : Integer;
  curCell : TCell;
  tVal    : Shortint;  // test value for the neighbourstates
begin
  for I := 0 to reih -1 do
  begin
    for K := 0 to spalt -1 do
    begin
      curCell := cellList[K,I];
      If Not (curCell.State = 1) Then                                        // If there is no node on the cell
      begin
        Form1.testMooreNeigh(K, I, tVal);
        If tVal = 1 Then                                                     // closed for development
        begin
          curCell.State := 2;
          curCell.colr := RGB(229,229,229);
        end Else If tVal = 2 Then
        begin                                                                // for further development
          curCell.State := 3;
          curCell.colr := RGB(255,99,71);
        end;
        curCell.Paint(Image_Cells.Canvas);
      end;
    end;
  end;
end;

//=========================================================Zellen initialisieren
procedure CellsSetup;
var
  curCell, firstBuild : TCell;
  I, K                : Integer;
begin
  firstBuild := cellList[round(spalt/2)+1, round(reih/2)-1];
  for I := 0 to reih -1 do
  begin
    for K := 0 to spalt -1 do
    begin
      curCell             := cellList[K,I];
      curCell.colr        := RGB(255, 255, 255);
      curCell.Pot         := 0;
      curCell.buildDense  := 0;
      curCell.streetDense := 0;
      curCell.state       := 0;
      curCell.Koord.X     := K;
      curCell.Koord.Y     := I;
      curCell.cState      := 0;
      curCell.Paint(Image_Cells.Canvas);
    end;
  end;
end;

//==============================================================================
constructor TCell.create(xPos, yPos, size, colr: Integer);
begin
  inherited create;
  Pos.X := xPos;
  Pos.Y := yPos;
  FSize  := size;
  FFillColor := colr;
end;

//==============================================================================
procedure TCell.SetSize(const Value: Integer);
begin
  FSize := Value;
end;

procedure TCell.SetFillColor(const Value: Integer);
begin
  FFillColor := Value;
end;

procedure TCell.SetState(const Value: Integer);
begin
  FState := Value;
end;

procedure TCell.Paint(Canvas: TCanvas);
var col:Integer;
begin
  Canvas.Pen.Width   := 0;
  Canvas.Pen.Color   := colr;     //RGB(245,245,245);//clSilver; //clgray;
  Canvas.Brush.Color := colr;     //RGB (colr, colr, colr);
  Canvas.Rectangle (Pos.X - FSize , Pos.Y - FSize, Pos.X + FSize, Pos.Y + FSize);
end;

end.

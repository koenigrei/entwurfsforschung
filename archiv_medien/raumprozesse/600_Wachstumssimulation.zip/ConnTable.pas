unit ConnTable;

interface

uses
  Windows, Messages, SysUtils, Variants, Classes, Graphics, Controls, Forms,
  Dialogs, Grids, math, ExtCtrls;

type
  TConnectivityTable = class(TForm)
    StringGrid1: TStringGrid;
    DissimiGrid: TStringGrid;
    Splitter5: TSplitter;
    procedure FormClose(Sender: TObject; var Action: TCloseAction);
  private
    { Private-Deklarationen }
  public
    Procedure ListKonnVals;
    Procedure StandardVal(var MeanLength: Array of Real);
  end;

var
  ConnectivityTable: TConnectivityTable;

implementation

{$R *.dfm}

uses main, agent;

//=====================================print the path-distances in the strinGrid
procedure TConnectivityTable.FormClose(Sender: TObject;
  var Action: TCloseAction);
begin
  Action := caFree;
end;

Procedure TConnectivityTable.ListKonnVals;
var
  I, K, pLength    : Integer;
  CurNode          : TAgent;
  MeanLength       : Array of Real;                                          // the mean length of a node to all others
  locSum           : Array of Real;                                          // count the distances greater than given by locRad
  Diameter, RowSum : Cardinal;                                               // Diameter or "Streuwert" of the graph
  locRad           : Cardinal;                                               // factor for the local measurement
begin
  locRad := Form1.SE_locRad.Value;
  SetLength(MeanLength, 0);
  SetLength(MeanLength, NodeList.Count);
  SetLength(locSum, 0);
  SetLength(locSum, NodeList.Count);
  Diameter := 0;
  globML   := 0;
  StringGrid1.RowCount := NodeList.Count+2;
  StringGrid1.ColCount := NodeList.Count+5;
  StringGrid1.Cells[NodeList.Count+1, 0]:= 'sum';
  StringGrid1.Cells[NodeList.Count+2, 0]:= 'ML';
  StringGrid1.Cells[NodeList.Count+3, 0]:= 'sML';
  StringGrid1.Cells[NodeList.Count+4, 0]:= 'loc';
  For I := 0 To NodeList.Count-1 Do
  begin
    StringGrid1.Cells[0, I+1]:= IntToStr(I);
    CurNode := NodeList.Items[I];
    RowSum  := 0;
    locSum[I]:= 0;
    For K:=0 To length(CurNode.DijArr)-1 Do
    begin
      StringGrid1.Cells[K+1, 0]:= IntToStr(K);
      pLength := PathList[I,K].Count;
      StringGrid1.Cells[K+1, I+1]:= IntToStr(pLength);
      RowSum := RowSum + pLength;
      If pLength <= locRad Then
      begin
        locSum[I] := locSum[I] + (locRad - pLength);
      end;
    end;
    Diameter := Diameter + RowSum;
    MeanLength[I] := roundTo(RowSum / NodeList.Count, -2);
    globML := globML + MeanLength[I];
    StringGrid1.Cells[NodeList.Count+1, I+1]:= IntToStr(RowSum);              // sum of the distances
    StringGrid1.Cells[NodeList.Count+2, I+1]:= FloatToStr(MeanLength[I]);     // mean length per node (row)
    StringGrid1.Cells[NodeList.Count+4, I+1]:= FloatToStr(locSum[I]);
  end;
  globML := roundTo(globML / NodeList.Count, -2);
  StringGrid1.Cells[NodeList.Count+1, NodeList.Count+1]:= IntToStr(Diameter); // average of the distance-sums
  StringGrid1.Cells[NodeList.Count+2, NodeList.Count+1]:= FloatToStr(globML); // average of the mean lengths
  Form1.Lbl_ml.Caption := FloatToStr(globML);
  If Form1.CB_locMeas.Checked Then StandardVal(locSum) Else StandardVal(MeanLength);
end;

//=========================================redimension the mean length to [0, 1]
Procedure TConnectivityTable.StandardVal(var MeanLength: Array of Real);
var
  I, colHight : Integer;
  min, max    : Real;
  NodeCol     : TColor;
  CurNode     : TAgent;
begin
  max := 0;
  min := 99999999;
  For I := 0 To length(MeanLength)-1 Do
  begin
    IF MeanLength[I] > max Then max := MeanLength[I];
    IF MeanLength[I] < min Then min := MeanLength[I];
  end;
  For I := 0 To length(MeanLength)-1 Do
  begin
    If max > min Then begin
      If Form1.CB_locMeas.Checked Then begin
        MeanLength[I] := power(RoundTo((MeanLength[I]- min)/(max-min),-2), colExpo);
      end else begin
        MeanLength[I] := power(1-RoundTo((MeanLength[I]- min)/(max-min),-2), colExpo);
      end;
    end;
    ConnectivityTable.StringGrid1.Cells[NodeList.Count+3, I+1]:= FloatToStr(MeanLength[I]);    // standard mean length per node (row)
    colHight    := round((Form1.ImageGradient.Height-1) * MeanLength[I]);
    NodeCol     := Form1.ImageGradient.Canvas.Pixels[1, colHight];
    CurNode     := NodeList.Items[I];
    CurNode.sMl := MeanLength[I];
    CurNode.FFillColor := NodeCol;
    CurNode.Paint (Image_Agents.Canvas);
  end;
end;

end.

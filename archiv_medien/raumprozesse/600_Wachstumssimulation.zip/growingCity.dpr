program growingCity;

uses
  Forms,
  MAIN_win in 'MAIN_win.PAS' {MainForm},
  about in 'about.pas' {AboutBox},
  Main in 'Main.pas' {Form1},
  agent in 'agent.pas',
  ChildWin in 'ChildWin.pas' {MDIChild},
  analyseMinDist in 'analyseMinDist.pas' {anaMinDist},
  analyseClusterGrowth in 'analyseClusterGrowth.pas' {ana_clusterGrow},
  potentialField in 'potentialField.pas',
  transferLine in 'transferLine.pas',
  calc_AStern in 'calc_AStern.pas',
  cell in 'cell.pas',
  cluster in 'cluster.pas',
  dijkstra in 'dijkstra.pas',
  edge in 'edge.pas',
  ConnTable in 'ConnTable.pas' {ConnectivityTable},
  analyseDevPara in 'analyseDevPara.pas' {AnaDev};

{$R *.RES}

begin
  Application.Initialize;
  Application.CreateForm(TMainForm, MainForm);
  Application.CreateForm(TAboutBox, AboutBox);
  Application.CreateForm(TForm1, Form1);
  Application.CreateForm(TConnectivityTable, ConnectivityTable);
  Application.Run;
end.

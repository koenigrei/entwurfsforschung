(********************************************************************)
(*                                                                  *)
(*                         Growing Network                          *)
(*                          Version 1.0                             *)
(*                                                                  *)
(*     Programmierer: Reinhard K�nig                       May 2007 *)
(*                    http://www.entwurfsforschung.de               *)
(*                                                                  *)
(*     Last Update: May-25, 2007                                    *)
(*                                                                  *)
(********************************************************************) 
{revision history:

1.0     [May-25, 2007]
        start working on the program
}

unit Main;

interface

uses
  Windows, Messages, SysUtils, Variants, Classes, Graphics, Controls, Forms,
  Dialogs, ExtCtrls, ComCtrls, cell, math, ImgList, StdCtrls, agent, calc_AStern,
  Grids, TeEngine, Series, TeeProcs, Chart, Spin, CurvFitt, edge,
  TeeDataTableTool, TeCanvas, TeeEdiGrad, Buttons, ValEdit, TeeEdit, TeeFunci,
  TeeTools, TeePageNumTool;

type TDense = record         // to evaluate the density
      nrBuild  : Integer;    // number of build on cells
      nrStreet : Integer;    // number of street cells
      nrDev    : Integer;    // number of developed cells
      nrSum    : Integer;    // number of street cells and build on cells
      sumPot   : Single;     // sum of the nine potential values
end;

type
  TDreierArray = Array of Array of Array of Cardinal;

type
  TForm1 = class(TForm)
    Panel1: TPanel;
    Panel_PBar: TPanel;
    ProgressBar1: TProgressBar;
    lbl_calcer: TLabel;
    Splitter2: TSplitter;
    Splitter3: TSplitter;
    Panel_Paint: TPanel;
    Timer1: TTimer;
    Chart_denseD: TChart;
    Splitter4: TSplitter;
    ser_buildDense: TAreaSeries;
    ser_streetDense: TAreaSeries;
    Panel2: TPanel;
    PageControl1: TPageControl;
    TabSheet1: TTabSheet;
    Lbl_Sphere: TLabel;
    Label5: TLabel;
    Label15: TLabel;
    Label14: TLabel;
    Label11: TLabel;
    Label2: TLabel;
    Label20: TLabel;
    Label21: TLabel;
    SE_strStep: TSpinEdit;
    E_centriFu: TEdit;
    E_centriPe: TEdit;
    E_devThresh: TEdit;
    SE_HWM_gRate: TSpinEdit;
    SE_stopAt: TSpinEdit;
    E_fuScale: TEdit;
    E_peScale: TEdit;
    TabSheet4: TTabSheet;
    Label3: TLabel;
    Label16: TLabel;
    Label18: TLabel;
    Label12: TLabel;
    Label19: TLabel;
    SE_minDist: TSpinEdit;
    E_fieldW: TEdit;
    E_nodeThresh: TEdit;
    RadioGroup1: TRadioGroup;
    RB_boom: TRadioButton;
    RB_interlink: TRadioButton;
    RB_cluster: TRadioButton;
    TabSheet2: TTabSheet;
    GroupBox4: TGroupBox;
    B_CalcPathes: TButton;
    B_Analyse: TButton;
    Button2: TButton;
    CB_locMeas: TCheckBox;
    SE_locRad: TSpinEdit;
    GroupBox2: TGroupBox;
    ImageGradient: TImage;
    Label4: TLabel;
    Lbl_half: TLabel;
    Label6: TLabel;
    Label8: TLabel;
    Lbl_colScal: TLabel;
    TB_color: TTrackBar;
    GroupBox5: TGroupBox;
    Label9: TLabel;
    Lbl_nrNodes: TLabel;
    Label10: TLabel;
    lbl_nrEdges: TLabel;
    Label17: TLabel;
    Lbl_ml: TLabel;
    Splitter5: TSplitter;
    Splitter1: TSplitter;
    Chart_denseA: TChart;
    ser_devDense: TAreaSeries;
    GroupBox1: TGroupBox;
    Label1: TLabel;
    Label7: TLabel;
    B_setup: TButton;
    SE_nSz: TSpinEdit;
    SE_cellScale: TSpinEdit;
    B_agRepaint: TButton;
    cb_centerNode: TCheckBox;
    CB_nodeLbl: TCheckBox;
    B_ITL_stop: TButton;
    B_ITL_start: TButton;
    CB_agLayer: TCheckBox;
    RB_netOnly: TRadioButton;
    CB_cellLayer: TCheckBox;
    Chart_fractal: TChart;
    ser_fractCorr1: TLineSeries;
    CorrelationFunction2: TCorrelationFunction;
    ser_fractTrend: TLineSeries;
    TrendFunction1: TTrendFunction;
    Splitter9: TSplitter;
    ser_fract: TPointSeries;
    ser_f2: TPointSeries;
    ser_ft2: TLineSeries;
    TeeFunction4: TTrendFunction;
    ser_fractCorr2: TLineSeries;
    TeeFunction5: TCorrelationFunction;
    ser_devFract: TPointSeries;
    ser_devFractTrend: TLineSeries;
    TeeFunction6: TTrendFunction;
    ser_devFractCorr: TLineSeries;
    TeeFunction7: TCorrelationFunction;
    TabSheet3: TTabSheet;
    TabSheet5: TTabSheet;
    Button1: TButton;
    Button4: TButton;
    Button3: TButton;
    Button5: TButton;
    b_autoBuild: TSpeedButton;
    b_rndBuild: TButton;
    se_clusterRds: TSpinEdit;
    Label22: TLabel;
    Label23: TLabel;
    GroupBox3: TGroupBox;
    SE_genA: TSpinEdit;
    SE_genB: TSpinEdit;
    SE_genC: TSpinEdit;
    SE_genD: TSpinEdit;
    Label24: TLabel;
    Label25: TLabel;
    Label26: TLabel;
    Label27: TLabel;
    Chart_FractGrid: TChart;
    ser_DGrid: TPointSeries;
    ser_DGrid_Slope: TLineSeries;
    TrendFunction2: TTrendFunction;
    ser_DGrid_Corr: TLineSeries;
    CorrelationFunction3: TCorrelationFunction;
    Splitter10: TSplitter;
    ValueListEditor1: TValueListEditor;
    cb_centerGrav: TCheckBox;
    Button6: TButton;
    Button7: TButton;
    Button8: TButton;
    Button9: TButton;
    Chart_IS: TChart;
    ser_IS: TLineSeries;
    Splitter11: TSplitter;
    ser_RS: TLineSeries;
    lbl_actTime: TLabel;
    Label13: TLabel;
    ChartEditor_IS: TChartEditor;
    ChartEditor_fractGrid: TChartEditor;
    ChartEditor_fractRad: TChartEditor;
    ChartEditor_rank: TChartEditor;
    Button10: TButton;
    GroupBox6: TGroupBox;
    Label28: TLabel;
    lbl_rat1: TLabel;
    lbl_rat2: TLabel;
    lbl_rat3: TLabel;
    Label29: TLabel;
    E_rndScale: TEdit;
    Chart_resForce: TChart;
    ser_custFkt: TLineSeries;
    TeeFunction8: TCustomTeeFunction;
    cb_plotRnd: TCheckBox;
    ChartEditor_resForce: TChartEditor;
    PageControl2: TPageControl;
    TabSheet6: TTabSheet;
    Panel4: TPanel;
    Splitter12: TSplitter;
    Ch_clusterSize: TChart;
    bar_clusterSize: TBarSeries;
    Chart_nodes: TChart;
    Ser_Edges: TBarSeries;
    Chart_PotDens: TChart;
    ser_PotDense: TPointSeries;
    ser_PotDenseCorr: TLineSeries;
    TeeFunction1: TCorrelationFunction;
    Chart_rank: TChart;
    ser_rank: TLineSeries;
    ser_rankCorr: TLineSeries;
    CorrelationFunction1: TCorrelationFunction;
    ser_rankTrend: TLineSeries;
    TeeFunction3: TTrendFunction;
    Splitter6: TSplitter;
    TabSheet7: TTabSheet;
    Splitter7: TSplitter;
    Splitter8: TSplitter;
    Chart_ConnPot: TChart;
    ser_ConnPot: TPointSeries;
    ser_ConnPotCorr: TLineSeries;
    TeeFunction2: TCorrelationFunction;
    Splitter13: TSplitter;
    Panel5: TPanel;
    Panel3: TPanel;
    Chart1: TChart;
    Splitter14: TSplitter;
    ser_blue_green: TLineSeries;
    ser_green_all: TLineSeries;
    ser_blue_all: TLineSeries;
    GroupBox7: TGroupBox;
    Chart_buildAna: TChart;
    ser_ratBlueGreen: TPointSeries;
    ser_greaterThree: TPointSeries;
    ser_greaterTwo: TPointSeries;
    ser_bML: TPointSeries;
    ser_D_rad: TPointSeries;
    trend_ratBlueGreen: TLineSeries;
    TrendFunction3: TTrendFunction;
    trend_greaterThree: TLineSeries;
    TrendFunction4: TTrendFunction;
    trend_greaterTwo: TLineSeries;
    TrendFunction5: TTrendFunction;
    trend_bML: TLineSeries;
    TrendFunction6: TTrendFunction;
    trend_D_rad: TLineSeries;
    TrendFunction7: TTrendFunction;
    avg_ratBlueGreen: TLineSeries;
    AverageTeeFunction1: TAverageTeeFunction;
    avg_greaterThree: TLineSeries;
    AverageTeeFunction2: TAverageTeeFunction;
    avg_greaterTwo: TLineSeries;
    TeeFunction9: TAverageTeeFunction;
    avg_bML: TLineSeries;
    TeeFunction10: TAverageTeeFunction;
    avg_D_rad: TLineSeries;
    TeeFunction11: TAverageTeeFunction;
    PageNumTool2: TPageNumTool;
    Panel6: TPanel;
    Chart2: TChart;
    ser_white_all: TLineSeries;
    ser_street_all: TLineSeries;
    ser_dev_all: TLineSeries;
    Splitter15: TSplitter;
    Chart_nNb: TChart;
    ser_freeNb: TBarSeries;
    GroupBox8: TGroupBox;
    Label30: TLabel;
    Label31: TLabel;
    Label32: TLabel;
    lbl_grOne: TLabel;
    lbl_grTwo: TLabel;
    lbl_grThree: TLabel;
    cb_r8114: TCheckBox;
    cb_r7013: TCheckBox;
    cb_r5012: TCheckBox;
    cb_r3011: TCheckBox;
    SE_rdsPerVal: TSpinEdit;
    Label33: TLabel;
    ChartEditor_BuildAna: TChartEditor;
    Timer_buildAna: TTimer;
    B_stopBuildAna: TButton;
    B_startBuildAna: TButton;
    SE_stepsPerRd: TSpinEdit;
    Label34: TLabel;
    cb_r3010: TCheckBox;
    Button11: TButton;
    Label35: TLabel;
    Label36: TLabel;
    Label37: TLabel;
    procedure TeeFunction8Calculate(Sender: TCustomTeeFunction; const x: Double; var y: Double);
    procedure FormCreate(Sender: TObject);
    procedure Timer1Timer(Sender: TObject);
    procedure B_deleteAllClick(Sender: TObject);
    procedure FormClose(Sender: TObject; var Action: TCloseAction);
    procedure B_ITL_startClick(Sender: TObject);
    procedure B_CalcPathesClick(Sender: TObject);
    procedure B_setupClick(Sender: TObject);
    procedure B_AnalyseClick(Sender: TObject);
    procedure Button2Click(Sender: TObject);
    procedure TB_colorChange(Sender: TObject);
    procedure SE_nSzChange(Sender: TObject);
    procedure cb_cellStatesClick(Sender: TObject);
    procedure B_agRepaintClick(Sender: TObject);
    procedure B_HWM_startClick(Sender: TObject);
    procedure B_HWM_stopClick(Sender: TObject);
    procedure RB_boomClick(Sender: TObject);
    procedure Panel_PaintMouseUp(Sender: TObject; Button: TMouseButton; Shift: TShiftState; X, Y: Integer);
    procedure Panel_PaintMouseDown(Sender: TObject; Button: TMouseButton; Shift: TShiftState; X, Y: Integer);
    procedure Button1Click(Sender: TObject);
    procedure Button3Click(Sender: TObject);
    procedure CB_agLayerClick(Sender: TObject);
    procedure CB_cellLayerClick(Sender: TObject);
    procedure Button4Click(Sender: TObject);
    procedure Button5Click(Sender: TObject);
    procedure b_rndBuildClick(Sender: TObject);
    procedure Button6Click(Sender: TObject);
    procedure Button7Click(Sender: TObject);
    procedure Button8Click(Sender: TObject);
    procedure Button9Click(Sender: TObject);
    procedure Chart_ISDblClick(Sender: TObject);
    procedure Chart_FractGridDblClick(Sender: TObject);
    procedure Chart_fractalDblClick(Sender: TObject);
    procedure Chart_rankDblClick(Sender: TObject);
    procedure Button10Click(Sender: TObject);
    procedure E_centriFuChange(Sender: TObject);
    procedure cb_plotRndClick(Sender: TObject);
    procedure Chart_resForceDblClick(Sender: TObject);
    procedure Timer_buildAnaTimer(Sender: TObject);
    procedure Chart_buildAnaDblClick(Sender: TObject);
    procedure Button11Click(Sender: TObject);
    procedure B_startBuildAnaClick(Sender: TObject);
    procedure B_stopBuildAnaClick(Sender: TObject);
    procedure SE_rdsPerValChange(Sender: TObject);
  private
    DevList   : TList;        // List the developed-cells
    procedure Ag_clearBack;
    procedure Images_Create;
    procedure DrawConnections;
    procedure Develop;
    procedure InitGadient;
    procedure adjustColScale;
    procedure ExecuteHighwayman;
    procedure ExecuteBoom;
    procedure ExecuteCluster;
    procedure DensitySort(var usages: array of TDense);
    procedure DevDensSort(var usages: array of TDense);
    function  CalcFloatDist(pAX: Integer; pAY: Integer; pBX: Integer; pBY: Integer): Single;
    Procedure DualGrapg_Create;
    procedure buildings_Init;
    procedure buildings_Calc;
    procedure buildings_CounNei(K, I : Integer; var bCounter: Shortint);
    procedure countInTiles(var ctInTiles : TDreierArray; nTiles: Integer);
    procedure IDissimilar (ctInTiles: TDreierArray; tiles: Cardinal);
    procedure singleISCalc;
    procedure calcPropprtions;
    procedure initCustFkt;
    procedure countCellTypes;
    procedure countBuild (K, I: Integer; var nBuild: Cardinal);
    procedure nextRule;
    Procedure plotBuildAna;
    procedure defineRunMode;
    procedure resetGraphs;
    procedure setFktPeriods;
  public
    procedure testNeighState;
    procedure deleteAll;
    procedure Setup;
    procedure EdgesPerNode;
    procedure ExecuteInterlink;
    Procedure Connect(FromNode, ToNode: TAgent);
    function  wrap (var Xp: Integer; var Yp: Integer):Boolean;
    function  smallGridWrap (var Xp: Integer; var Yp: Integer):Boolean;
    procedure lookForOtherNodes(K, I : Integer; var CandList: TList);
    Procedure calcConnections(curCell: TCell; var CandList: TList);
    procedure Interlink(curNode: TAgent; var CandList: TList);
    procedure testMooreNeigh(K, I : Integer; var tVal: Shortint);
    procedure Execute_Step;
    Procedure fractalRad;
    procedure fractalGrid;
    Procedure measureDensity;
  end;

var
  PathList      : Array of Array of TList;    // global list of the shortest pathes
  cellList      : Array of Array of TCell;
  SmalGridList  : Array of Array of TCell;
  NodeList      : TList;
  DualNodeList  : Array of Array of TEdge;
  Form1         : TForm1;
  Image_Cells   : TImage;
  Image_SmalGrid: TImage;
  Image_Agents  : TImage;
  reih          : Integer;                     // Zellen-Reihen gesamt
  spalt         : Integer;                     // Zellen-Spalten gesamt
  cellScal      : Integer;                     // Zellen  gr��e
  steps, conns  : Cardinal;                    // count the nodes and the connections
  globML        : Real;                        // global mean length of all pathes
  colExpo       : Real;                        // scale the color gradient
  runMode       : ShortInt;                    // indicates the field type the program executes
  time, subTime : Cardinal;                    // count the time steps
  usageList     : Array of TDense;
  selfNodeStart : TCell;
  selfNodeEnd   : TCell;
  groupSz       : Array of Cardinal;           // nummber of cels per state
  countRds      : SmallInt;
  curRule       : SmallInt;

implementation

{$R *.dfm}
uses Farbverlauf, analyseMinDist, analyseClusterGrowth, potentialField, transferLine,
      MAIN_win, cluster, dijkstra, ConnTable, analyseDevPara, EditChar;

//==============================================================================
procedure TForm1.B_startBuildAnaClick(Sender: TObject);
begin
   curRule  := 0;
   countRds := 0;
   nextRule;
   resetGraphs;
   defineRunMode;
   DeleteAll;
   Setup;
   Timer_buildAna.enabled := true;
   Timer1.enabled := false;
end;

//==============================================================================
procedure TForm1.resetGraphs;
begin
   ser_ratBlueGreen.Clear;
   ser_greaterThree.Clear;
   ser_greaterTwo.Clear;
   ser_bML.Clear;
   ser_D_rad.Clear;
   trend_ratBlueGreen.Clear;
   trend_greaterThree.Clear;
   trend_greaterTwo.Clear;
   trend_bML.Clear;
   trend_D_rad.Clear;
   avg_ratBlueGreen.Clear;
   avg_greaterThree.Clear;
   avg_greaterTwo.Clear;
   avg_bML.Clear;
   avg_D_rad.Clear;
   setFktPeriods;
end;
//==============================================================================
procedure TForm1.SE_rdsPerValChange(Sender: TObject);
begin
   setFktPeriods;
end;
//==============================================================================
procedure TForm1.setFktPeriods;
begin
   avg_ratBlueGreen.FunctionType.Period := SE_rdsPerVal.Value;
   avg_greaterThree.FunctionType.Period := SE_rdsPerVal.Value;
   avg_greaterTwo.FunctionType.Period   := SE_rdsPerVal.Value;
   avg_bML.FunctionType.Period          := SE_rdsPerVal.Value;
   avg_D_rad.FunctionType.Period        := SE_rdsPerVal.Value;
end;

//==============================================================================
procedure TForm1.Timer_buildAnaTimer(Sender: TObject);
begin
   Execute_Step;
   If time >= SE_stepsPerRd.Value Then
   begin
      plotBuildAna;
      inc(countRds);
      If countRds >= SE_rdsPerVal.Value Then
      begin 
         countRds := 0;
         nextRule;
      end;
      DeleteAll;
      Setup;
   end;
end;
//==============================================================================
procedure TForm1.nextRule;
begin
   inc(curRule);
   case curRule of
      1: If cb_r8114.Checked Then
         begin
            SE_genA.Value:=8; SE_genB.Value:=1; SE_genC.Value:=1; SE_genD.Value:=4;
         end else nextRule;
      2: If cb_r7013.Checked Then
         begin
            SE_genA.Value:=7; SE_genB.Value:=0; SE_genC.Value:=1; SE_genD.Value:=3;
         end else nextRule;
      3: If cb_r5012.Checked Then
         begin
            SE_genA.Value:=5; SE_genB.Value:=0; SE_genC.Value:=1; SE_genD.Value:=2;
         end else nextRule;
      4: If cb_r3011.Checked Then
         begin
            SE_genA.Value:=3; SE_genB.Value:=0; SE_genC.Value:=1; SE_genD.Value:=1;
         end else nextRule;
      5: If cb_r3010.Checked Then
         begin
            SE_genA.Value:=3; SE_genB.Value:=0; SE_genC.Value:=1; SE_genD.Value:=0;
         end else nextRule;
      else Timer_buildAna.enabled := false;  
   end;
end;

//==============================================================================
Procedure TForm1.plotBuildAna;
begin
   countCellTypes;
   CalculatePathes;
   ConnectivityTable.ListKonnVals;
   EdgesPerNode;
   fractalRad;;
   ser_ratBlueGreen.AddXY(curRule, Form1.ser_blue_green.YValues.Last);          // [0, 1] -> linke achse
   ser_greaterThree.AddXY(curRule, StrToInt(Form1.lbl_grThree.Caption)/100);    // [0, 1] -> linke achse
   ser_greaterTwo.AddXY  (curRule, StrToInt(Form1.lbl_grTwo.Caption)/100);      // [0, 1] -> linke achse
   ser_bML.AddXY         (curRule, StrToFloat(Form1.Lbl_ml.Caption));           // rechte achse
   ser_D_rad.AddXY       (curRule, StrToFloat(Form1.ValueListEditor1.Values['slope_edge'])); // rechte achse
   trend_ratBlueGreen.CheckDataSource;
   trend_greaterThree.CheckDataSource;
   trend_greaterTwo.CheckDataSource;
   trend_bML.CheckDataSource;
   trend_D_rad.CheckDataSource;
   avg_ratBlueGreen.CheckDataSource;
   avg_greaterThree.CheckDataSource;
   avg_greaterTwo.CheckDataSource;
   avg_bML.CheckDataSource;
   avg_D_rad.CheckDataSource;
end;

//==============================================================================
procedure TForm1.countCellTypes;
var
   I, K : Integer;
   sumType : Array [0..4] of Cardinal;
   nCells  : Cardinal;
   curCell : TCell;
   sumNb   : Array [0..4] of Cardinal; 
   nBuild  : Cardinal;
begin  
   ser_freeNb.Clear;
   nCells := (reih*3) * (spalt*3);
   For I := 0 To 4 Do sumNb[I] := 0;
   For I := 0 to 4 Do sumType[I] := 0;
   for I := 0 to reih*3 -1 do
   begin
      for K := 0 to spalt*3 -1 do
      begin
         curCell := smalGridList[K, I];
         case curCell.subState of
            0 : inc(sumType[0]);                         // empty cells
            1 : inc(sumType[1]);                         // street cells
            2 : inc(sumType[2]);                         // blue cells - buildings
            3 : inc(sumType[3]);                         // green cells
         end;
         If curCell.cState   = 2 Then inc(sumType[4]);   // developed cells
         If curCell.subState = 2 Then 
         begin
            countBuild(K, I, nBuild);                    // count neighouring build on cells
            inc(sumNb[nBuild]);
         end;
      end;
   end;
   ser_white_all.AddXY (time, sumType[0]/nCells);
   ser_street_all.AddXY(time, sumType[1]/nCells);
   ser_dev_all.AddXY   (time, sumType[4]/nCells);
   ser_blue_all.AddXY  (time, sumType[2]/nCells);
   ser_green_all.AddXY (time, sumType[3]/nCells);
   IF sumType[3] > 0 Then
   begin
      ser_blue_green.AddXY(time, 1-(sumType[3]/sumType[4]));
   end else begin
      ser_blue_green.AddXY(time, 1);
   end;
   For I := 0 To 4 Do 
   begin
      ser_freeNb.AddXY(I, sumNb[I]);                   // histogramm number of build on neighbours
   end;
   lbl_grOne.Caption   := IntToStr(round(((sumNb[2]+sumNb[3]+sumNb[4])/sumType[2])*100));
   lbl_grTwo.Caption   := IntToStr(round(((sumNb[3]+sumNb[4])         /sumType[2])*100));
   lbl_grThree.Caption := IntToStr(round(((sumNb[4])                  /sumType[2])*100));
end;

//============================================count in von Neumann neighbourhood
procedure TForm1.countBuild (K, I: Integer; var nBuild: Cardinal);
var
  v        : Integer;
  Xp, Yp   : Integer;
  koNei    : Array [0..3] of TPoint;
  curCell  : TCell;
begin
   koNei[0].X := K;    koNei[0].Y := I + 1;
   koNei[1].X := K;    koNei[1].Y := I - 1;
   koNei[2].X := K+1;  koNei[2].Y := I;
   koNei[3].X := K-1;  koNei[3].Y := I;
   nBuild := 0;
   for v := 0 to 3 do
   begin
      Xp := koNei[v].X;
      Yp := koNei[v].Y;
      If Form1.smallGridWrap(Xp, Yp) = true Then
      begin
         curCell := smalGridList[Xp, Yp];
         If curCell.subState = 2 then
         begin
            inc(nBuild);
         end;
      end;
   end;
end;

//======================================================plot the resulting force
procedure TForm1.TeeFunction8Calculate(Sender: TCustomTeeFunction; const x: Double; var y: Double);
var
   expoPe, expoFu : Single;
   prScal, fuScal : Single;
   rndScal        : Single;
begin
   Randomize;
   expoPe := StrToFloat(Form1.E_centriPe.Text);       // w1
   expoFu := StrToFloat(Form1.E_centriFu.Text);       // w2
   prScal := StrToFloat(Form1.E_peScale.Text);        // A
   fuScal := StrToFloat(Form1.E_fuScale.Text);        // B
   rndScal := StrToFloat(E_rndScale.Text);
   If cb_plotRnd.Checked Then
   begin
      y:=(prScal*(1-exp(-x*expoPe))+rndScal*random()) - (fuScal*(1-exp(-x*expoFu))+rndScal*random());
   end else begin
      y:=prScal*(1-exp(-x*expoPe)) - fuScal*(1-exp(-x*expoFu));
   end;
end;

//=========================================================================setup
procedure TForm1.Setup;
var
  FirstCell, SecCell : TCell;
begin
  Randomize;
  Images_Create;
  steps   := 0;
  time    := 0;
  SubTime := 0;
  conns   := 0;
  cellScal      := SE_cellScale.Value;
  spalt         := floor (Image_Cells.Width  / cellScal);
  reih          := floor (Image_Cells.Height / cellScal);
  SetLength     (cellList, spalt, reih);
  SetLength     (SmalGridList, spalt*3, reih*3);
  NodeList      := TList.Create;
  DevList       := TList.Create;
  LabelList     := TList.Create;
  PotCandList   := TList.Create;
  ClustCandList := TList.Create;
  CellsCreate;
  CellsSetup;
  SmalGridCreate;
  // --------------------------------- first street
  If cb_centerNode.Checked Then begin
    FirstCell := cellList[round(spalt/2), round(reih/2)];
    AgentsCreate(FirstCell);
  end;
  // ----------------------------------
  Lbl_nrNodes.Caption := '0';
  lbl_nrEdges.Caption := '0';
  Lbl_ml.Caption := 'ML';
  InitGadient;
  Ser_Edges.Clear;
  adjustColScale;
  SetLength(limboPot, spalt, reih);
  ValueListEditor1.Values['D_grid'] := '-';
  ValueListEditor1.Values['slope_grid'] := '-';
  ValueListEditor1.Values['D_rad'] := '-';
  ValueListEditor1.Values['slope_rad'] := '-';
  ValueListEditor1.Values['D_nodes'] := '-';
  ValueListEditor1.Values['slope_nodes'] := '-';
  ValueListEditor1.Values['D_edge'] := '-';
  ValueListEditor1.Values['slope_edge'] := '-';
  ValueListEditor1.Values['IS_developed_cells'] := '-';
  calcPropprtions;
  initCustFkt;
  lbl_grOne.Caption   := '___';
  lbl_grTwo.Caption   := '___';
  lbl_grThree.Caption := '___';
end;

procedure TForm1.initCustFkt;
begin
   with ser_custFkt do
   begin
      clear;
      TeeFunction8.Period := 0.010000000000000000;
      TeeFunction8.NumPoints := 101;
      TeeFunction8.OnCalculate := TeeFunction8Calculate;
   end;
   ser_custFkt.CheckDataSource;
end;

//==============================================================================
//=========================================================================timer
procedure TForm1.Timer1Timer(Sender: TObject); //-------------------timer object
begin
  Execute_Step;
end;

//======================================================================one step
procedure TForm1.Execute_Step;
begin
  Case runMode of
    1: ExecuteInterlink;                                                     // mode 1 = generates only the street network
    2: begin                                                                 // mode 2 = boom
        If time < se_clusterRds.value Then
        begin
          ExecuteCluster;
        end else begin
          ExecuteBoom;
          ExecuteHighwayman;
          //measureDensity;
        end;
    end;
    3: begin
        If time < se_clusterRds.value Then
        begin
          ExecuteCluster;
        end else begin                                                       // mode 3 = interlink
          ExecuteHighwayman;
          ExecuteInterlink;
          //measureDensity;
        end;
    end;
    4: begin
        ExecuteCluster;
        //measureDensity;
    end;
  end;
  If b_autoBuild.Down = true Then 
  begin 
      buildings_Calc;
  end;
  
  lbl_actTime.Caption := IntToStr(time);
  If time >= SE_stopAt.Value Then Timer1.Enabled := false;
  If subTime = 0 Then
  begin
    If runMode > 1 Then
    begin
      measureDensity;
      countCellTypes;
      singleISCalc;
      subTime := 10;
    end;
  end;
  dec(SubTime);
  inc(time);                    // -- increase time steps
end;

procedure TForm1.calcPropprtions;
begin
   lbl_rat1.Caption := '0';
   lbl_rat2.Caption := '0';
   lbl_rat3.Caption := '0';
   If isZero(StrToFloat(E_centriFu.Text)) = false Then
      lbl_rat1.Caption := FloatToStr(roundTo(StrToFloat(E_centriPe.Text) / StrToFloat(E_centriFu.Text), -2));
   If isZero(StrToFloat(E_fuScale.Text))  = false Then
      lbl_rat2.Caption := FloatToStr(roundTo(StrToFloat(E_peScale.Text) / StrToFloat(E_fuScale.Text), -2));
   If isZero(StrToFloat(E_centriPe.Text)) = false Then
      lbl_rat3.Caption := FloatToStr(roundTo(StrToFloat(E_centriFu.Text) / StrToFloat(E_centriPe.Text), -2));
end;

//=======================================================grow the build on cells
procedure TForm1.ExecuteHighwayman;
var
  I, J     : Integer;
begin
  for J:= 0 to 4 do equiPot;                                                 // bring the potential field near equilibrium
  PotentialTransfer;
  For I := 1 To SE_HWM_gRate.value Do
  begin
    findCandidates;
    dev_Cell;                                                                 // one cell per step will develop
    paint_Field;                                                              // paint the cells
  end;
end;

//===================================================execute the boom field type
procedure TForm1.ExecuteBoom;
begin
  Develop;
  Lbl_nrNodes.Caption := IntToStr(steps);
  lbl_nrEdges.Caption := IntToStr(conns);
  If steps >= SE_stopAt.Value Then Timer1.Enabled := false;
end;

//==============================================execute the interlink field type
procedure TForm1.ExecuteInterlink;
begin
  Develop;
  Lbl_nrNodes.Caption := IntToStr(steps);
  lbl_nrEdges.Caption := IntToStr(conns);
  If steps >= SE_stopAt.Value Then Timer1.Enabled := false;
end;

//================================================execute the cluster field type
procedure TForm1.ExecuteCluster;
var
  I, J     : Integer;
begin
  for J:= 0 to 4 do equiPot;                                                 // bring the potential field near equilibrium
  PotentialTransfer;
  For I := 1 To SE_HWM_gRate.value Do
  begin
    findClusterCandidates;
    dev_ClusterCell;                                                         // one cell per step will develop
    paint_Field;                                                             // paint the cells
  end;
end;

//=========================choose the cell where the next node will be developed
procedure TForm1.Develop;
var
  I                   : Integer;
  curCell, devCell    : TCell;
  maxPot              : Real;                                                // maximum Potential
  candiList           : TList;                                               // List of the candidate nodes for a connection
  nodeThresh, fieldWeigth, tmpPot : Single;
begin
  fieldWeigth := StrToFloat(E_fieldW.Text);
  nodeThresh := StrToFloat(E_nodeThresh.Text);
  maxPot := -999999999;
  If DevList.Count = 0 Then begin
    Timer1.Enabled:= false;
    //ana_clusterGrow.Timer3.Enabled:= false;
    //anaMinDist.Timer2.Enabled:= false;
    Exit;
  end;
  For I := 0 To DevList.Count-1 Do
  begin
    curCell := DevList.Items[I];
    If curCell.State = 3 Then
    begin
      tmpPot := curCell.Pot + fieldWeigth * Random();
      If tmpPot > maxPot Then
      begin
        maxPot  := tmpPot;
        devCell := curCell;
      end;
    end;
  end;
  If (runMode > 1) Then
  begin
    If devCell.Pot > nodeThresh Then
    begin
      AgentsCreate(devCell);
      devCell.colr := RGB(229,229,229);                                      // developed Cell
      devCell.Paint(Image_Cells.Canvas);
      candiList := TList.Create;
      If NodeList.Count > 1 Then begin
        lookForOtherNodes(devCell.Koord.X, devCell.Koord.Y, candiList);      // look for other nodes in the neighbourhood
        calcConnections(devCell, candiList);
      end;
      candiList.Free;
    end;
  end else begin
    AgentsCreate(devCell);
    devCell.colr := RGB(229,229,229);                                      // developed Cell
    devCell.Paint(Image_Cells.Canvas);
    candiList := TList.Create;
    If NodeList.Count > 1 Then begin
      lookForOtherNodes(devCell.Koord.X, devCell.Koord.Y, candiList);      // look for other nodes in the neighbourhood
      calcConnections(devCell, candiList);
    end;
    candiList.Free;
  end;
end;

//=====================================================calculate the connections
Procedure TForm1.calcConnections(curCell: TCell; var CandList: TList);
var
  I, minD, sumD             : Integer;
  CurNode, ToNode, testNode : TAgent;
begin
  CurNode := NodeList.Items[curCell.NodeNr];
  If CandList.Count = 1 Then begin                                           // if there is only one node to connect
    ToNode := CandList.Items[0];
    Connect(CurNode, ToNode);
  end else begin                                                             // if there are more nodes to connect
    minD := 9999999;
    For I := 0 To CandList.Count-1 Do                                        // test the distance of the other nodes
    begin
      testNode := CandList.Items[I];
      sumD := abs(testNode.PositionX - CurNode.PositionX) + abs(testNode.PositionY - CurNode.PositionY);
      If sumD < minD Then begin
        minD := sumD;
        ToNode := testNode;
      end;
    end;
    Connect(CurNode, ToNode);
    CandList.Remove(ToNode);
    If (runMode = 1) or (runMode = 3) Then InterLink(CurNode, CandList);
  end;
  DrawConnections;
end;

//======================================================interlink exixting nodes
procedure TForm1.Interlink(curNode: TAgent; var CandList: TList);
var
  PfadList : TList;
  ToNode   : TAgent;
  I        : Integer;
begin
  PfadList := TList.Create;
  For I := 0 To CandList.Count-1 Do                                          // test the distance of the other nodes
  begin
    ToNode := CandList.Items[I];
    findPath (PfadList, CurNode, ToNode);
    If (PfadList.Count > SE_minDist.Value) Or (PfadList.Count = 0) Then
    begin
      Connect(CurNode, ToNode);
    end;
  end;
  PfadList.Free;
end;

//=======================================================test neighbouring cells
procedure TForm1.testNeighState;
var
   J, I, K : Integer;
   curCell : TCell;
   tVal    : Shortint;  // test value for the neighbourstates
begin
   DevList.Clear;
   For J := 0 To 1 Do   // repeat two times
   begin
      for I := 0 to reih -1 do
      begin
         for K := 0 to spalt -1 do
         begin
            curCell := cellList[K,I];
            If Not (curCell.State = 1) Then                                  // If there is no node on the cell
            begin
               testMooreNeigh(K, I, tVal);
               If tVal = 1 Then
               begin
                  curCell.State := 2;                                        // closed for development
               end Else If tVal = 2 Then
               begin
                  curCell.State := 3;                                        // for further development
                  DevList.Add(curCell);
               end;
            end;
         end;
      end;
   end;
end;

//==========================================================save the connections
Procedure TForm1.Connect(FromNode, ToNode: TAgent);
var
  FromCell, ToCell : TCell;
  targWink         : Double;
  tmpDist          : Integer;
begin
  SetLength(FromNode.NachbList, length(FromNode.NachbList)+1);
  SetLength(ToNode.NachbList, length(ToNode.NachbList)+1);
  tmpDist := calcDistance(FromNode.PositionX, FromNode.PositionY, ToNode.PositionX, ToNode.PositionY);
  ToNode.NachbList[high(ToNode.NachbList)].nr := NodeList.IndexOf(FromNode);
  FromNode.NachbList[high(FromNode.NachbList)].nr := NodeList.IndexOf(ToNode);
  ToNode.NachbList[high(ToNode.NachbList)].dist := tmpDist;
  FromNode.NachbList[high(FromNode.NachbList)].dist := tmpDist;
  inc(conns);
  FromCell := smalGridList[FromNode.OnCell.X*3+1, FromNode.OnCell.Y*3+1];
  ToCell   := smalGridList[ToNode.OnCell.X*3+1, ToNode.OnCell.Y*3+1];
  targWink := ArcTan2((FromCell.Koord.Y - ToCell.Koord.Y),(FromCell.Koord.X - ToCell.Koord.X));
  transLine(ToCell, FromCell, targWink);
end;

//=========================================search for nodes in the neighbourhood
procedure TForm1.lookForOtherNodes(K, I : Integer; var CandList: TList);
var
  m, n              : Integer;
  curCell, origCell : TCell;
  curNode           : TAgent;
  Xp, Yp            : Integer;
begin
  candList.Clear;
  origCell := cellList[K, I];
  for n := -2 to 2 do
  begin
    for m := -2 to 2 do
    begin
      Xp := K+n;
      Yp := I+m;
      If wrap(Xp, Yp) = true Then
      begin
        curCell := cellList[Xp, Yp];
        If Not (curCell = origCell) Then                                     // don't count the agent-cell itsef
        If curCell.State = 1 Then begin                                      // if a node is on the cell
          curNode := NodeList.Items[curCell.NodeNr];
          CandList.Add(curNode);                                             // add the corresponding node to the list
        end;
      end;
    end;
  end;
end;

//=============================================coonsider the moore neighbourhood
procedure TForm1.testMooreNeigh(K, I : Integer; var tVal: Shortint);
var
  u, v    : Integer;
  curCell : TCell;
  Xp, Yp  : Integer;
begin
  tVal := 0;
  for u := -1 to 1 do
  begin
    for v := -1 to 1 do
    begin
      Xp := K+v;
      Yp := I+u;
      If wrap(Xp, Yp) = true Then
      begin
        curCell := cellList[Xp, Yp];
        If curCell.State = 1 Then begin                                      // if a node is on the cell
          tVal:=curCell.State;
          Exit;
        end;
        If curCell.State = 2 Then tVal:=curCell.State;                       // if the cell is closed
      end;
    end;
  end;
end;

//##############################################################################
//===================================================start the path calculations
procedure TForm1.B_CalcPathesClick(Sender: TObject);
begin
  CellsPaint;
  CalculatePathes;
  ConnectivityTable.ListKonnVals;
  EdgesPerNode;
  If runMode > 1 Then measureDensity;
end;

//=====================================================change the color gardient
procedure TForm1.TB_colorChange(Sender: TObject);
begin
  adjustColScale;
end;

procedure TForm1.adjustColScale;
begin
  If TB_color.Position <= 5 Then
  begin
    colExpo := 0.5+TB_color.Position*0.1;
  end else begin
    colExpo := 1+((TB_color.Position-5)/2);
  end;
  Lbl_colScal.Caption := FloatToStr(colExpo);
  Lbl_half.Top := round(170-(155*power(0.5, colExpo)));
end;

//======================================================count the edges per node
procedure TForm1.EdgesPerNode;
var
  I        : Integer;
  CurNode  : TAgent;
  sumEdges : Array [0..8] of Cardinal;
begin
  For I := 0 To length(sumEdges)-1 Do
  begin
    sumEdges[I] := 0;
  end;
  Chart_Nodes.UndoZoom;
  Ser_Edges.Clear;
  For I := 0 To NodeList.Count-1 Do
  begin
    CurNode := NodeList.Items[I];
    inc(sumEdges[length(CurNode.NachbList)]);
  end;
  For I := 0 To length(sumEdges)-1 Do
  begin
    If sumEdges[I] > 0 Then begin
      Ser_Edges.AddXY(I, sumEdges[I]);
    end;
  end;
end;

//==========================================================draw the connections
procedure TForm1.DrawConnections;
var
  J, K            : Integer;
  curNode, ToNode : TAgent;
begin
  Image_Agents.Canvas.Pen.Color := clOlive;
  Image_Agents.Canvas.Pen.Style := psSolid;
  Image_Agents.Canvas.Pen.Width := 1;
  for J := 0 to NodeList.Count -1 do
  begin
    curNode := NodeList.Items [J];
    K := 0;
    While  K < length(curNode.NachbList) Do
    Begin
      ToNode := NodeList.Items[curNode.NachbList[K].nr];
      Image_Agents.Canvas.Pen.Width := 2;// 1 + round(AShape.Usage[AShape.NachbList[K].Nr]/10);
      Image_Agents.Canvas.MoveTo(curNode.PositionX, curNode.PositionY);
      Image_Agents.Canvas.LineTo(ToNode.PositionX, ToNode.PositionY);
      K := K + 1;
    end;
  end;
end;

//##############################################################################
//                           2D BUILDING CA
//==========================================initiate a random building structure
procedure TForm1.buildings_Init;
var
   I, K    : Integer;
   curCell : TCell;
begin
   for I := 0 to reih*3 -1 do
   begin
      for K := 0 to spalt*3 -1 do
      begin
         curCell := smalGridList[K, I];
         If curCell.ClustSize > 4 then begin
         If curCell.cState = 2 Then
         begin
            If random() > 0.5 Then
            begin
               curCell.subState := 3;    // random cells to gree state
               curCell.colr   := clLime;
            end else begin
               curCell.subState := 2;    // random cells to build on state
               curCell.colr   := clBlue;
            end;
         end else begin
            curCell.subState := curCell.cState;
         end;
         curCell.Paint(Image_SmalGrid.Canvas);
         end;
      end;
   end;
end;

//================================================================2D building CA
procedure TForm1.buildings_Calc;
var
   I, K    : Integer;
   curCell : TCell;
   bCounter: Shortint;
   genA, genB, genC, genD: Shortint;
begin
   genA := SE_genA.value;
   genB := SE_genB.value;
   genC := SE_genC.value;
   genD := SE_genD.value;
   for I := 0 to reih*3 -1 do
   begin
      for K := 0 to spalt*3 -1 do
      begin
         curCell := smalGridList[K, I];
         If curCell.cState = 2 Then
         begin
            If curCell.ClustSize > 4 then
            begin
               buildings_CounNei(K, I, bCounter);
               If curCell.subState = 2 Then                                 // if cell is in build on state (lives)
               begin
                  If (bCounter >= genA) or (bCounter <= genB) Then
                  begin
                     curCell.subState := 3;                                 // in gets transfered into green
                     curCell.colr     := clLime;
                     curCell.Paint(Image_SmalGrid.Canvas);
                  end;
               end else If curCell.subState = 3 Then                        // if the cell is in green state (death)
               begin
                  If (bCounter >= genC) and (bCounter <= genD) Then
                  begin
                     curCell.subState := 2;                                 // it gets transferd into buid on
                     curCell.colr     := clBlue;
                     curCell.Paint(Image_SmalGrid.Canvas);
                  end;
               end;
            end;
         end;
         // otherwise the cell remains in its old state!
      end;
   end;
end;

//==========================================================count the neighbours
procedure TForm1.buildings_CounNei(K, I : Integer; var bCounter: Shortint);
var
   u, v     : Integer;
   Xp, Yp   : Integer;
   curCell  : TCell;
begin
   bCounter := 0;
   for u := -1 to 1 do
   begin
      for v := -1 to 1 do
      begin
         Xp := K+v;
         Yp := I+u;
         If Form1.smallGridWrap(Xp, Yp) = true Then
         begin
            curCell := smalGridList[Xp, Yp];
            If curCell.subState = 2 then
            begin
               inc(bCounter);
            end;
         end;
      end;
   end;
   If smalGridList[K, I].subState = 2 Then dec(bCounter);  // substract the own built on state
end;

//##############################################################################
//                           FRACTAL ANALYSIS
//=========================================================fractal grid analysis
procedure TForm1.singleISCalc;
var
   ctInTiles  : TDreierArray;     // count the cells (states) in each tile
   nTiles     : Integer;          // number of tiles (to count in)
begin
   nTiles := 8;
   countInTiles(ctInTiles, nTiles);
end;

procedure TForm1.fractalGrid;
var
   L, M : Integer;
   ctInTiles  : TDreierArray;     // count the cells (states) in each tile
   nTiles     : Integer;          // number of tiles (to count in)
   nrDev      : Integer;          // number of tiles with developed cells in it
   DGrid      : Single;
   tileSize   : Integer;
   smalSize   : Integer;
   rds        : Integer;
   r2Grid     : Single;
   slopeGrid  : Single;
begin
   Chart_FractGrid.UndoZoom;
   ser_DGrid.Clear;
   ser_DGrid.AddXY(0, 0);
   smalSize := round(cellScal/6);
   DGrid  := 0;
   rds    := 0;
   nTiles := 2;
   Repeat
      tileSize := round(reih/nTiles);
      If round(spalt/nTiles) < tileSize Then tileSize := round(spalt/nTiles);

      nrDev  := 0;                                                           // number of tiles containing developed cells
      countInTiles(ctInTiles, nTiles);
      For L := 0 to nTiles-1 Do
      begin
         For M := 0 to nTiles-1 Do
         begin
            If ctInTiles[M, L, 1] > 0 Then
            begin
               inc(nrDev);
            end;
         end;
      end;

      ser_DGrid.AddXY(log10(nTiles), log10(nrDev));
      DGrid := DGrid + log10(nrDev) / log10(nTiles);
      inc(rds);
      inc(nTiles);
   Until (tileSize < smalSize);

   DGrid := DGrid / rds;
   ser_DGrid_Slope.CheckDataSource;
   ser_DGrid_Corr.CheckDataSource;
   r2Grid    := Power(Form1.ser_DGrid_Corr.YValues[1], 2);
   slopeGrid := (Form1.ser_DGrid_Slope.YValues[1] - Form1.ser_DGrid_Slope.YValues[0]) /
                (Form1.ser_DGrid_Slope.XValues[1] - Form1.ser_DGrid_Slope.XValues[0]) ;

   ValueListEditor1.Values['D_grid'] := FloatToStr((roundTo(DGrid, -2)));
   ValueListEditor1.Values['slope_grid'] := FloatToStr((roundTo(slopeGrid, -2)));
   Form1.Chart_FractGrid.Title.Text.Clear;
   Form1.Chart_FractGrid.Title.Text.Add('Fractal Grid Analysis, r�_grid = ' + FloatToStr(roundTo(r2Grid, -2)));
end;

//================================================================count in tiles
procedure TForm1.countInTiles(var ctInTiles : TDreierArray; nTiles: Integer);
var
  curCell    : TCell;
  I, K, L, M : Integer;
  subBordX   : Array of Integer; // borders of the tiles in x-direction
  subBordY   : Array of Integer; // borders of the tiles in y-direction
  //rndCol     : TColor;
begin
   DetermineCluster;
   setLength(subBordX, nTiles+1);
   setLength(subBordY, nTiles+1);
   For I:=0 To nTiles Do
   begin
      subBordX[I] := round((spalt*3 -1) / nTiles *I); // define the borders of the tiles
      subBordY[I] := round((reih*3 -1)  / nTiles *I);
   end;
   For I:=0 To nTiles-1 Do
   begin
      subBordX[I] := subBordX[I]-1;  // decrease the lower border with one
      subBordY[I] := subBordY[I]-1;  // to avoid the overlapping of the tiles
   end;

   setlength (ctInTiles, 0, 0, 0);
   setlength (ctInTiles, nTiles, nTiles, 2);//ngGroups);
   For L := 0 to nTiles-1 Do
   begin
      For M := 0 to nTiles-1 Do
      begin
         // --- one tile ------------------------
         //rndCol := RGB(round(random()*255),round(random()*255),round(random()*255));
         for I := subBordY[L]+1 to subBordY[L+1] do                          // sub-reihe
         begin
            for K := subBordX[M]+1 to subBordX[M+1] do                       // sub-spalte
            begin
               curCell := smalGridList[K,I];
               //curCell.colr := rndCol;
               //curCell.Paint(Image_SmalGrid.Canvas);
               IF curCell.isDev = true Then
               begin
                  inc(ctInTiles[M, L, 1]);                                   // count the developed cells
               end else begin
                  inc(ctInTiles[M, L, 0]);
               end;
            end;
         end;
         // -------------------------------------
      end;
   end;
   If nTiles=8 Then begin
      IDissimilar (ctInTiles, nTiles);
   end;
end;

//====================================================calculate dissimilar index
procedure TForm1.IDissimilar (ctInTiles: TDreierArray; tiles: Cardinal);
var
  L, M, V, W : Integer;
  sumTyp     : Array of Array of Extended;                                    // -- Dissimilarit�tsindex
  segIdx     : Array of Extended;                                             // -- Segregationsindex
  sumGes     : Extended;                                                      // -- Sum of the population without the current group
  relChange  : Double;
  pDense     : Double;
  ngGroups   : Integer;
begin
  ngGroups := 2;
  SetLength (sumTyp, 0, 0);
  SetLength (sumTyp, ngGroups, ngGroups);
  SetLength (segIdx, 0);
  SetLength (segIdx, ngGroups);
  setlength (ctInTiles, tiles, tiles, ngGroups);
  resetCluster;
  For L := 0 to tiles-1 Do
  begin
    For M := 0 to tiles-1 Do
    begin
      For V:= 0 To ngGroups -1 Do
      begin
        For W := V+1 To ngGroups -1 Do
        begin
          sumTyp[W, V] := sumTyp[W, V] + abs(
          (ctInTiles[M, L, V]/groupSz[V] * 100)-(ctInTiles[M, L, W]/groupSz[W] * 100));
        end;
        sumGes := 0;
        For W := 0 To ngGroups -1 Do
        begin
          If not (W=V) Then
            sumGes := sumGes + (ctInTiles[M, L, W]);
        end;
        segIdx[V] := segIdx[V] + abs(
        (ctInTiles[M, L, V]/groupSz[V] * 100)-(sumGes/((reih*3*spalt*3)-groupSz[V]) * 100));
      end;
    end;
  end;
  For V:= 0 To ngGroups-1  Do
  begin
    For W := V To ngGroups-1  Do
    begin
      sumTyp[W, V] := 0.5 * sumTyp[W, V];
      ConnectivityTable.DissimiGrid.Cells[W+1, V+1] := FloatToStr(roundTo(sumTyp[W, V], -2));
    end;
    segIdx[V] := (0.5 * segIdx[V])/100;
    ConnectivityTable.DissimiGrid.Cells[V+1, ngGroups+1] := FloatToStr(roundTo(segIdx[V],-2));
  end;
  ValueListEditor1.Values['IS_developed_cells'] := FloatToStr((roundTo(segIdx[1], -2)));
  ser_IS.AddXY(time, segIdx[1]);
end;

//=======================================================fractal radial analysis
Procedure TForm1.fractalRad;
var
  I, K, M                : Integer;
  deltaK                 : TPoint;
  count, devSum, border  : Cardinal;
  nullNode               : TAgent;
  rad, distSum, slopeDev : Single;
  slopeFract, slopeF2    : Single;
  r2fract1, r2fract2     : Single;
  curEdge                : TEdge;
  tmpDist, r2dev         : Single;
  nullCell, curCell      : TCell;
  anyDev, anyEdge        : Boolean;                                          // test if there are developed cells or edges
  centerK                : TPoint;
  centerN                : Integer;
  devRad, nodRad, edgRad : Single;
  ctDev, ctNod, ctEdg    : Cardinal;
begin
  DetermineCluster;
  DualGrapg_Create;
  ser_fract.Clear;
  ser_f2.Clear;
  ser_devFract.Clear;
  devRad := 0;
  nodRad := 0;
  edgRad := 0;
  ctDev  := 0;
  ctNod  := 0;
  ctEdg  := 0;
  anyDev   := false;
  anyEdge  := false;
  If cb_centerGrav.Checked Then
  begin
    centerGravity(centerK);                                                  // calculate the center of gravity
  end else begin
    centerK.X := round((spalt*3)/2);
    centerK.Y := round((reih*3)/2);
  end;
  //smalGridList[centerK.X, centerK.Y].colr := clRed;
  //smalGridList[centerK.X, centerK.Y].paint(Image_SmalGrid.Canvas);
  nullCell := smalGridList[centerK.X, centerK.Y];
  centerN := 0;
  centerNode (centerN);
  nullNode := NodeList.Items[centerN];
  //nullNode.FFillColor := clBlack;
  //nullNode.Paint(Image_Agents.Canvas);

  border := 999999999;
  If centerK.X < border Then border := centerK.X;
  If centerK.Y < border Then border := centerK.Y;
  If spalt*3 - centerK.X < border Then border := spalt*3 - centerK.X;
  If reih*3  - centerK.Y < border Then border := reih*3  - centerK.Y;
  For M := 1 To border Do
  begin
    distSum := 0;
    count   := 0;
    rad := M*(cellScal/3);
    For I := 0 To NodeList.Count-1 Do
    begin
      For K:= 0 To NodeList.Count-1 Do
      begin
        If not (DualNodeList[K,I] = nil) Then
        begin
          curEdge := DualNodeList[K,I];
          tmpDist := CalcFloatDist(nullNode.PositionX, nullNode.PositionY, curEdge.Pos.X, curEdge.Pos.Y);
          If tmpDist <= rad Then
          begin
            inc(count);
            distSum := distSum +curEdge.length;
          end;
        end;
      end;
    end;

    devSum := 0;
    for I := 0 to reih*3 -1 do
    begin
      for K := 0 to spalt*3 -1 do
      begin
        curCell  := smalGridList[K,I];
        //deltaK.X := abs(nullCell.Pos.X - curCell.Pos.X);
        //deltaK.Y := abs(nullCell.Pos.Y - curCell.Pos.Y);
        tmpDist := CalcFloatDist(curCell.Pos.X, curCell.Pos.Y, nullCell.Pos.X, nullCell.Pos.Y);
        //If (deltaK.X <= rad) and (deltaK.Y <= rad) Then //and (curCell.cState = 2) Then
        If (tmpDist <= rad) and (curCell.isDev = true) Then
        begin
          inc(devSum);
        end;
      end;
    end;

    If (count > 0) Then
    begin
      anyEdge := true;
      Form1.ser_fract.AddXY(log10(rad), log10(distSum));
      edgRad := edgRad + (log10(distSum)/log10(rad));
      inc(ctEdg);
      Form1.ser_f2.AddXY(log10(rad), log10(count));
      nodRad := nodRad + (log10(count)/log10(rad));
      inc(ctNod);
    end;
    If (devSum > 0) Then
    begin
      anyDev := true;
      ser_devFract.AddXY(log10(rad), log10(devSum));
      devRad := devRad + (log10(devSum)/log10(rad));
      inc(ctDev);
    end;
  end;

  edgRad := edgRad / ctEdg;
  nodRad := nodRad / ctNod;
  devRad := devRad / ctDev;

  If anyEdge Then
  begin
    Form1.ser_fractCorr1.CheckDataSource;
    Form1.ser_fractCorr2.CheckDataSource;
    Form1.ser_fractTrend.CheckDataSource;
    Form1.ser_fT2.CheckDataSource;
    r2fract1   := Power(Form1.ser_fractCorr1.YValues[1], 2);
    r2fract2   := Power(Form1.ser_fractCorr2.YValues[1], 2);
    slopeFract := (Form1.ser_fractTrend.YValues[1] - Form1.ser_fractTrend.YValues[0]) / log10(border);
    slopeF2    := (Form1.ser_ft2.YValues[1] - Form1.ser_ft2.YValues[0]) / log10(border);
  end;
  If anyDev Then
  begin
    ser_devFractTrend.CheckDataSource;
    ser_devFractCorr.CheckDataSource;
    r2dev    := Power(Form1.ser_devFractCorr.YValues[1], 2);
    slopeDev := (Form1.ser_devFractTrend.YValues[1] - Form1.ser_devFractTrend.YValues[0]) / log10(border);
  end;
  ValueListEditor1.Values['D_rad'] := FloatToStr((roundTo(devRad, -2)));
  ValueListEditor1.Values['slope_rad'] := FloatToStr((roundTo(slopeDev, -2)));

  ValueListEditor1.Values['D_nodes'] := FloatToStr((roundTo(nodRad, -2)));
  ValueListEditor1.Values['slope_nodes'] := FloatToStr((roundTo(slopeF2, -2)));

  ValueListEditor1.Values['D_edge'] := FloatToStr((roundTo(edgRad, -2)));
  ValueListEditor1.Values['slope_edge'] := FloatToStr((roundTo(slopeFract, -2)));

  Form1.Chart_fractal.Title.Text.Clear;
  Form1.Chart_fractal.Title.Text.Add('Fractal Radial Analysis, r�_dev = ' + FloatToStr(roundTo(r2dev, -2))
                                   + ', r�_node = ' + FloatToStr(roundTo(r2fract2, -2))
                                   + ', r�_edge = ' + FloatToStr(roundTo(r2fract1, -2)));
end;

//=========================================================create the dual graph
Procedure TForm1.DualGrapg_Create;
var
  I, K            : Integer;
  curEdge         : TEdge;
  curNode, toNode : TAgent;
  fromN, toN      : Cardinal;
begin
  SetLength (DualNodeList, 0, 0);
  SetLength (DualNodeList, NodeList.Count, NodeList.Count);
  for I := 0 to NodeList.Count -1 do
  begin
    curNode := NodeList.Items[I];
    fromN   := I;
    For K := 0 To length(curNode.NachbList)-1 Do
    begin
      toN := curNode.NachbList[K].nr;
      If (DualNodeList[toN,fromN] = nil) Then
      begin
        toNode  := NodeList.Items[toN];
        curEdge := TEdge.Create;
        curEdge.fromN  := fromN;
        curEdge.toN    := toN;
        curEdge.Pos.X  := curNode.PositionX + round((toNode.PositionX - curNode.PositionX)/2);
        curEdge.Pos.Y  := curNode.PositionY + round((toNode.PositionY - curNode.PositionY)/2);
        curEdge.length := CalcFloatDist(curNode.PositionX, curNode.PositionY, toNode.PositionX, toNode.PositionY);
        DualNodeList[fromN,toN] := curEdge;
        //curEdge.Paint (Image_Agents.Canvas);
      end;
    end;
  end;
end;
//##############################################################################

//=============================================================distance as float
function TForm1.CalcFloatDist(pAX: Integer; pAY: Integer; pBX: Integer; pBY: Integer): Single;
var
  temp : double;
begin
  temp := sqrt(Power((pAX - pBX), 2) + Power((pAY - pBY), 2));
  Result := Round(temp);
end;


//=================================================================wrap funktion
function TForm1.wrap (var Xp: Integer; var Yp: Integer):Boolean;
begin
  Result := true;
  if Xp < 0 then begin
     Result := false;
     Exit;
  end else
  if Xp > spalt-1 then begin
     Result := false;
     Exit;
  end;
  if Yp < 0 then begin
     Result := false;
     Exit;
  end else
  if Yp > reih-1 then begin
     Result := false;
     Exit;
  end;
end;
//=================================================================wrap funktion
function TForm1.smallGridWrap (var Xp: Integer; var Yp: Integer):Boolean;
begin
  Result := true;
  if Xp < 0 then begin
     Result := false;
     Exit;
  end else
  if Xp > spalt*3 -1 then begin
     Result := false;
     Exit;
  end;
  if Yp < 0 then begin
     Result := false;
     Exit;
  end else
  if Yp > reih*3 -1 then begin
     Result := false;
     Exit;
  end;
end;

//==============================================================clear background
procedure TForm1.Ag_clearBack;
begin
  Image_Agents.Canvas.Brush.Color := clBlack;
  Image_Agents.Canvas.Pen.Color   := clBlack;
  Image_Agents.Canvas.Pen.Width   := 1;
  Image_Agents.Canvas.Rectangle (0, 0, Image_Cells.width,Image_Cells.height);
end;

//============================================================Image_AgentsCreate
procedure TForm1.Images_Create;
begin
  Image_Cells := TImage.Create(self);
  Image_Cells.Parent := Panel_Paint;
  Image_Cells.top    := 0;
  Image_Cells.Left   := 0;
  Image_Cells.Width  := Panel_Paint.Width;
  Image_Cells.Height := Panel_Paint.Height;
  Image_Cells.Transparent := false;
  Image_Cells.Enabled:= false;
  Image_Cells.Canvas.Pen.Color := clWhite;
  Image_Cells.Canvas.Brush.Color := clWhite;
  Image_Cells.Canvas.Rectangle (0 , 0, Image_Cells.width, Image_Cells.height);

  Image_SmalGrid := TImage.Create(self);
  Image_SmalGrid.Parent := Panel_Paint;
  Image_SmalGrid.top    := 0;
  Image_SmalGrid.Left   := 0;
  Image_SmalGrid.Width  := Panel_Paint.Width;
  Image_SmalGrid.Height := Panel_Paint.Height;
  Image_SmalGrid.Transparent := false;
  Image_SmalGrid.Enabled:= false;
  Image_SmalGrid.Canvas.Pen.Color := clWhite;
  Image_SmalGrid.Canvas.Brush.Color := clWhite;
  Image_SmalGrid.Canvas.Rectangle (0 , 0, Image_SmalGrid.width, Image_SmalGrid.height);

  Image_Agents := TImage.Create(self);
  Image_Agents.Parent := Panel_Paint;
  Image_Agents.top    := 0;
  Image_Agents.Left   := 0;
  Image_Agents.Width  := Image_Cells.Width;
  Image_Agents.Height := Image_Cells.Height;
  Image_Agents.Transparent := True;
  Image_Agents.Enabled:= False;
  Image_Cells.Canvas.Pen.Color := clBlack;
  Image_Agents.Canvas.Brush.Color := clBlack;
  Image_Agents.Canvas.Rectangle (0 , 0, Image_Cells.width, Image_Cells.height);

  Panel_Paint.DoubleBuffered := True;
  Form1.DoubleBuffered := True;
end;

//##############################################################################
//=============================================================mouse interaction
procedure TForm1.Panel_PaintMouseDown(Sender: TObject; Button: TMouseButton; Shift: TShiftState; X, Y: Integer);
var
  CurCell   : TCell;
  cellKoord : TPoint;
begin
  selfNodeStart := nil;
  cellKoord.X  := floor (X / cellScal);
  cellKoord.Y  := floor (Y / cellScal);
  if wrap(cellKoord.X, cellKoord.Y)=false then Exit;
  CurCell := CellList[cellKoord.X, cellKoord.Y];
  selfNodeStart := CurCell;
end;
//=============================================================mouse interaction
procedure TForm1.Panel_PaintMouseUp(Sender: TObject; Button: TMouseButton; Shift: TShiftState; X, Y: Integer);
var
  CurCell, primCell : TCell;
  cellKoord         : TPoint;
begin
  cellKoord.X  := floor (X / cellScal);
  cellKoord.Y  := floor (Y / cellScal);
  If wrap(cellKoord.X, cellKoord.Y)=false Then Exit;
  If Button = mbLeft Then
  begin
    CurCell := CellList[cellKoord.X, cellKoord.Y];
    selfNodeEnd := CurCell;
    If selfNodeEnd = selfNodeStart Then
    begin
      AgentsCreate(CurCell);
      Exit;
    end;
    subdivideEdge(selfNodeStart, selfNodeEnd);
    DrawConnections;
  end else If Button = mbRight Then
  begin
    primCell := CellList[cellKoord.X, cellKoord.Y];
    cellKoord.X  := floor (X / (cellScal/3));
    cellKoord.Y  := floor (Y / (cellScal/3));
    CurCell := SmalGridList[cellKoord.X, cellKoord.Y];
    CurCell.cState := 2;                                                     // built on state
    CurCell.colr   := clBlue;
    CurCell.Paint(Image_SmalGrid.Canvas);
    inc(primCell.buildDense);
    primCell.cState := 2;
  end;
end;

//==============================paint the color gradient for connectivity coding
procedure TForm1.InitGadient;
var
  myRect : TRect;
begin
  MyRect := rect(0, 0, 35, 40);
  DrawGradient(ImageGradient.Canvas, clBlue, clAqua, MyRect, goVertical);
  MyRect := rect(0, 40, 35, 80);
  DrawGradient(ImageGradient.Canvas, clAqua, clLime, MyRect, goVertical);
  MyRect := rect(0, 80, 35, 120);
  DrawGradient(ImageGradient.Canvas, clLime, clYellow, MyRect, goVertical);
  MyRect := rect(0, 120, 35, 160);
  DrawGradient(ImageGradient.Canvas, clYellow, clRed, MyRect, goVertical);
end;

//##############################################################################
//====================================================================sort array
//===========================================================measure the density
Procedure TForm1.measureDensity;
var
  I, u , v, Xp, Yp : Integer;
  curCell          : TCell;
  curNode          : TAgent;
  idx              : Cardinal;
  r2PotDense, r2ConnPot : Single;
begin
  DetermineCluster;                                                          // distinguish between empty and developed
  startCAna;
  SetLength(usageList, 0);
  SetLength(usageList, NodeList.Count);
  For I := 0 to NodeList.Count-1 Do
  begin
    curNode := NodeList.Items[I];
    usageList[I].nrBuild  := 0;
    usageList[I].nrStreet := 0;
    usageList[I].nrDev    := 0;
    usageList[I].sumPot   := 0;

    for u := -1 to 1 do
    begin
      for v := -1 to 1 do
      begin
        Xp := curNode.onCell.X+v;
        Yp := curNode.onCell.Y+u;
        If wrap(Xp, Yp) = true Then
        begin
          curCell := cellList[Xp, Yp];
          usageList[I].nrStreet := usageList[I].nrStreet + curCell.streetDense;
          usageList[I].nrBuild  := usageList[I].nrBuild  + curCell.buildDense;
          usageList[I].nrDev    := usageList[I].nrDev    + curCell.devDense;
          usageList[I].sumPot   := usageList[I].sumPot   + curCell.pot;
        end;
      end;
    end;
    usageList[I].nrSum := usageList[I].nrBuild + usageList[I].nrStreet;
  end;

  ser_PotDense.Clear;
  ser_ConnPot.Clear;
  For I:=0 To NodeList.Count-1 Do
  begin
    curNode := NodeList.Items[I];
    If usageList[I].nrDev > 0 Then
      ser_PotDense.AddXY(usageList[I].nrDev/81, usageList[I].sumPot/9);
      ser_ConnPot.AddXY(curNode.sMl, usageList[I].sumPot/9);
  end;
  ser_PotDenseCorr.CheckDataSource;
  ser_ConnPotCorr.CheckDataSource;
  r2PotDense := Power(ser_PotDenseCorr.YValues[1], 2);
  r2ConnPot  := Power(ser_ConnPotCorr.YValues[1], 2);
  Chart_PotDens.Title.Text.Clear;
  Chart_PotDens.Title.Text.Add('Potential / Density : r� = ' + FloatToStr(roundTo(r2PotDense, -2)));
  Chart_ConnPot.Title.Text.Clear;
  Chart_ConnPot.Title.Text.Add('Potential / Connectivity : r� = ' + FloatToStr(roundTo(r2ConnPot, -2)));

  DensitySort(usageList); //-----------------------------------------List sorted
  ser_BuildDense.Clear;
  ser_StreetDense.Clear;
  For I:=0 To NodeList.Count-1 Do
  begin
    idx := NodeList.Count-1 -I;
    ser_BuildDense.AddXY(I, usageList[idx].nrBuild/81);
    ser_StreetDense.AddXY(I, usageList[idx].nrStreet/81);
  end;

  DevDensSort(usageList);
  ser_DevDense.Clear;
  For I:=0 To NodeList.Count-1 Do
  begin
    idx := NodeList.Count-1 -I;
    ser_DevDense.AddXY(I, usageList[idx].nrDev/81);
  end;
end;
//==============================================================================
procedure TForm1.DevDensSort(var usages: array of TDense);
  procedure P_DenseSort(var usages: array of TDense; iLo, iHi: integer);
  var
    Lo, Hi: integer;
    T, Mid: Integer;
  begin
    Lo := iLo;
    Hi := iHi;
    Mid := usages[(Lo + Hi) div 2].nrDev;
    repeat
      while usages[Lo].nrDev < Mid do
        Inc(Lo);
      while usages[Hi].nrDev > Mid do
        Dec(Hi);
      if Lo <= Hi then
        begin
          T := usages[Lo].nrDev;
          usages[Lo].nrDev := usages[Hi].nrDev;
          usages[Hi].nrDev := T;
          Inc(Lo);
          Dec(Hi);
        end;
    until
      Lo > Hi;
    if Hi > iLo then
      P_DenseSort(usages, iLo, Hi);
    if Lo < iHi then
      P_DenseSort(usages, Lo, iHi);
  end;
begin
  if High(usages) > 1 then
    P_DenseSort(usages, Low(usages), High(usages));
end;
//==============================================================================
procedure TForm1.DensitySort(var usages: array of TDense);
  procedure P_DenseSort(var usages: array of TDense; iLo, iHi: integer);
  var
    Lo, Hi: integer;
    T, F, B, Mid: Integer;
  begin
    Lo := iLo;
    Hi := iHi;
    Mid := usages[(Lo + Hi) div 2].nrSum;
    repeat
      while usages[Lo].nrSum < Mid do
        Inc(Lo);
      while usages[Hi].nrSum > Mid do
        Dec(Hi);
      if Lo <= Hi then
        begin
          T := usages[Lo].nrSum;
          B := usages[Lo].nrBuild;
          F := usages[Lo].nrStreet;
          usages[Lo].nrSum := usages[Hi].nrSum;
          usages[Lo].nrBuild := usages[Hi].nrBuild;
          usages[Lo].nrStreet := usages[Hi].nrStreet;
          usages[Hi].nrSum := T;
          usages[Hi].nrBuild := B;
          usages[Hi].nrStreet := F;
          Inc(Lo);
          Dec(Hi);
        end;
    until
      Lo > Hi;
    if Hi > iLo then
      P_DenseSort(usages, iLo, Hi);
    if Lo < iHi then
      P_DenseSort(usages, Lo, iHi);
  end;
begin
  if High(usages) > 1 then
    P_DenseSort(usages, Low(usages), High(usages));
end;

//##############################################################################
//######################### interface elements #################################
//##############################################################################
//=========================================================================setup
procedure TForm1.FormCreate(Sender: TObject); //--------------------------------FormCreate
var
  h:HWnd;
begin
  h:=handle;
  postmessage(h,WM_SYSCOMMAND,SC_MAXIMIZE,0);
  Setup;
end;

procedure TForm1.E_centriFuChange(Sender: TObject);
begin
   calcPropprtions;
   //initCustFkt;
   ser_custFkt.CheckDataSource;
end;

procedure TForm1.Chart_buildAnaDblClick(Sender: TObject);
begin
   ChartEditor_BuildAna.Execute;
end;

procedure TForm1.Chart_fractalDblClick(Sender: TObject);
begin
   ChartEditor_fractRad.Execute;
end;

procedure TForm1.Chart_FractGridDblClick(Sender: TObject);
begin
   ChartEditor_fractGrid.Execute;
end;

procedure TForm1.Chart_ISDblClick(Sender: TObject);
begin
   ChartEditor_IS.Execute;
end;

procedure TForm1.Chart_rankDblClick(Sender: TObject);
begin
   ChartEditor_rank.Execute;
end;

procedure TForm1.Chart_resForceDblClick(Sender: TObject);
begin
   ChartEditor_resForce.Execute;
end;

procedure TForm1.SE_nSzChange(Sender: TObject);
begin
  Ag_clearBack;
  DrawConnections;
  AgentsPaint;
end;

procedure TForm1.cb_cellStatesClick(Sender: TObject);
begin
  CellsPaint;
end;

procedure TForm1.cb_plotRndClick(Sender: TObject);
begin
   ser_custFkt.CheckDataSource;
end;

procedure TForm1.CB_agLayerClick(Sender: TObject);
begin
  Image_Agents.Visible := CB_agLayer.Checked;
end;

procedure TForm1.CB_cellLayerClick(Sender: TObject);
begin
  Image_Cells.Visible := CB_cellLayer.Checked;
  Image_SmalGrid.Visible := CB_cellLayer.Checked;
end;

procedure TForm1.RB_boomClick(Sender: TObject);
begin
  If RB_netOnly.Checked Then runMode := 1;
  If RB_boom.Checked Then runMode := 2;
  If RB_interlink.Checked Then runMode := 3;
  If RB_cluster.Checked Then runMode := 4;
end;

procedure TForm1.B_agRepaintClick(Sender: TObject);
begin
  Ag_clearBack;
  DrawConnections;
  AgentsPaint;
end;

procedure TForm1.B_AnalyseClick(Sender: TObject);
begin
  MainForm.CreateMyMDIChild(TanaMinDist);
end;

procedure TForm1.Button10Click(Sender: TObject);
begin
   MainForm.CreateMyMDIChild(TAnaDev);
end;

procedure TForm1.Button11Click(Sender: TObject);
begin
   ChartEditor_BuildAna.Execute;
end;

procedure TForm1.Button1Click(Sender: TObject);
begin
  If (runMode > 1) or (runMode = 0) Then
  begin
    DetermineCluster;
    startCAna;
    PaintCluster;
  end;
end;

procedure TForm1.Button3Click(Sender: TObject);
begin
   Image_SmalGrid.Visible := true;
   SmallGridPaint;
end;

procedure TForm1.Button4Click(Sender: TObject);
begin
   CalculatePathes;
   ConnectivityTable.ListKonnVals;
   EdgesPerNode;
   If runMode > 1 Then measureDensity;
   fractalRad;;
   fractalGrid;
end;

procedure TForm1.Button5Click(Sender: TObject);
begin
  ConnectivityTable.Show;
end;

procedure TForm1.Button6Click(Sender: TObject);
begin
   Image_SmalGrid.Visible := true;
   SmallGrid_SubStatePaint;
end;

procedure TForm1.Button7Click(Sender: TObject);
begin
   Image_SmalGrid.Visible := false;
   paint_Field;
end;

procedure TForm1.Button8Click(Sender: TObject);
begin
   Image_SmalGrid.Visible := false;
   paint_candidate;
end;

procedure TForm1.Button9Click(Sender: TObject);
begin
   AgentsPaint_gray;
end;

procedure TForm1.Button2Click(Sender: TObject);
begin
  MainForm.CreateMyMDIChild(Tana_clusterGrow);
end;

procedure TForm1.B_ITL_startClick(Sender: TObject);
begin
  defineRunMode;
  Timer1.Enabled := true;
end;

procedure TForm1.defineRunMode;
begin
  If RB_netOnly.Checked   Then runMode := 1;
  If RB_boom.Checked      Then runMode := 2;
  If RB_interlink.Checked Then runMode := 3;
  If RB_cluster.Checked   Then runMode := 4;
end;

procedure TForm1.b_rndBuildClick(Sender: TObject);
begin
   buildings_Init;
end;

procedure TForm1.B_HWM_startClick(Sender: TObject);
begin
  Timer1.Enabled := true;
  runMode := 1;
end;

procedure TForm1.B_HWM_stopClick(Sender: TObject);
begin
  Timer1.Enabled := false;
  runMode := 0;
end;

procedure TForm1.B_deleteAllClick(Sender: TObject); //--------------------------delete all
begin
  Timer1.Enabled := false;
  deleteAll;
end;

procedure TForm1.B_setupClick(Sender: TObject);
begin
  deleteAll;
  Setup;
end;

procedure TForm1.B_stopBuildAnaClick(Sender: TObject);
begin
   Timer_buildAna.enabled := not Timer_buildAna.enabled;
end;

//##############################################################################
//===================================================================end program
procedure TForm1.FormClose(Sender: TObject; var Action: TCloseAction); //-------close the form
begin
  deleteAll;
  Action := caFree;
end;

procedure TForm1.deleteAll; //--------------------------------------------------delete all
var
  I, K     : Integer;
  curCell  : TCell;
  curNode  : TAgent;
  curLabel : TLabel;
  curEdge  : TEdge;
begin
  If length(cellList)>0 Then
  begin
    for I := 0 to reih -1 do
    begin
      for K := 0 to spalt -1 do
      begin
        curCell := cellList[K,I];
        curCell.Free;
      end;
    end;
    SetLength  (cellList, 0, 0);
  end;

  If (length(DualNodeList)> 0) Then
  begin
    for I := 0 to length(DualNodeList) -1 do
    begin
      for K := 0 to length(DualNodeList) -1 do
      begin
        If not (DualNodeList[K,I] = nil) Then
        begin
          curEdge := DualNodeList[K,I];
          curEdge.Free;
        end;
      end;
    end;
  end;
  SetLength (DualNodeList, 0, 0);

  If length(SmalGridList)>0 Then
  begin
    for I := 0 to reih*3 -1 do
    begin
      for K := 0 to spalt*3 -1 do
      begin
        curCell := SmalGridList[K,I];
        curCell.Free;
      end;
    end;
  end;
  SetLength (SmalGridList, 0, 0);
  
  If NodeList.Count >0 Then
  begin
    for I := 0 to NodeList.Count -1 do
    begin
      curNode := NodeList.Items[I];
      If length(CurNode.DijArr) > 0 Then
      begin
        For K := 0 To length(CurNode.DijArr)-1 Do
        begin
          CurNode.DijArr[K].Free;
          ConnectivityTable.StringGrid1.Cells[K+1, I+1]:= '';
          PathList[I, K].Free;
        end;
      end;
      SetLength(CurNode.DijArr, 0);
      curNode.Free;
    end;
    NodeList.Free;

    for I := 0 to LabelList.Count -1 do
    begin
      curLabel:= LabelList.Items[I];
      curLabel.Free;
    end;
    LabelList.Free;
  end;
  DevList.Free;
  Image_Cells.Free;
  Image_Agents.Free;
  Image_SmalGrid.Free;

  SetLength(PathList, 0, 0);
  SetLength(limboPot, 0, 0);
  PotCandList.Free;
  ClustCandList.Free;
  panel1.repaint;

  Chart_fractal.UndoZoom;
  ser_fract.Clear;
  ser_f2.Clear;
  ser_devFract.Clear;
  Ch_clusterSize.UndoZoom;
  bar_clusterSize.Clear;
  Chart_rank.UndoZoom;
  ser_rank.Clear;
  ser_rankTrend.Clear;
  Chart_denseA.UndoZoom;
  Chart_denseD.UndoZoom;
  ser_devDense.Clear;
  ser_buildDense.Clear;
  ser_streetDense.Clear;
  Chart_ConnPot.UndoZoom;
  Chart_PotDens.UndoZoom;
  ser_ConnPot.Clear;
  ser_PotDense.Clear;
  Chart_nodes.UndoZoom;
  Ser_Edges.Clear;
  Chart_FractGrid.UndoZoom;
  ser_DGrid.Clear;
  ser_DGrid_Slope.Clear;
  ser_DGrid_Corr.Clear;
  Chart_IS.UndoZoom;
  ser_IS.Clear;
  ser_RS.Clear;
   Chart_nNb.UndoZoom;
   ser_freeNb.Clear;
   ser_white_all.Clear;
   ser_street_all.Clear;
   ser_blue_all.Clear;
   ser_green_all.Clear;
   ser_dev_all.Clear;
   ser_blue_green.Clear;
end;

end.

object Form1: TForm1
  Left = 0
  Top = 0
  Width = 1600
  Height = 960
  AutoScroll = True
  Caption = 'growing network'
  Color = clBtnFace
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -11
  Font.Name = 'Tahoma'
  Font.Style = []
  FormStyle = fsMDIChild
  OldCreateOrder = False
  Visible = True
  OnClose = FormClose
  OnCreate = FormCreate
  PixelsPerInch = 96
  TextHeight = 13
  object Splitter3: TSplitter
    Left = 0
    Top = 689
    Width = 1592
    Height = 3
    Cursor = crVSplit
    Align = alBottom
    ExplicitTop = 0
    ExplicitWidth = 666
  end
  object Splitter5: TSplitter
    Left = 611
    Top = 0
    Width = 5
    Height = 689
    Beveled = True
    ResizeStyle = rsLine
    ExplicitLeft = 851
    ExplicitTop = 6
    ExplicitHeight = 653
  end
  object Splitter1: TSplitter
    Left = 905
    Top = 0
    Width = 5
    Height = 689
    Beveled = True
    ResizeStyle = rsLine
    ExplicitLeft = 624
    ExplicitTop = 8
    ExplicitHeight = 663
  end
  object Panel1: TPanel
    Left = 0
    Top = 692
    Width = 1592
    Height = 234
    Align = alBottom
    Caption = 'Panel1'
    TabOrder = 0
    object Splitter2: TSplitter
      Left = 1586
      Top = 1
      Width = 5
      Height = 232
      Align = alRight
      ExplicitLeft = 702
    end
    object Splitter4: TSplitter
      Left = 230
      Top = 1
      Width = 5
      Height = 232
      ExplicitLeft = 369
    end
    object Splitter9: TSplitter
      Left = 1245
      Top = 1
      Height = 232
      Align = alRight
      ExplicitLeft = 593
    end
    object Splitter10: TSplitter
      Left = 885
      Top = 1
      Height = 232
      Align = alRight
      ExplicitLeft = 593
    end
    object Splitter11: TSplitter
      Left = 473
      Top = 1
      Height = 232
      ExplicitLeft = 593
    end
    object Chart_denseD: TChart
      Left = 1
      Top = 1
      Width = 229
      Height = 232
      Border.Visible = True
      Legend.Visible = False
      Title.Gradient.EndColor = clGray
      Title.Gradient.MidColor = clWhite
      Title.Gradient.StartColor = clSilver
      Title.Text.Strings = (
        'Density Streets and Roads')
      BottomAxis.ExactDateTime = False
      BottomAxis.Increment = 1.000000000000000000
      BottomAxis.Title.Caption = 'region'
      DepthAxis.Automatic = False
      DepthAxis.AutomaticMaximum = False
      DepthAxis.AutomaticMinimum = False
      DepthAxis.Maximum = 0.890000000000000800
      DepthAxis.Minimum = -0.110000000000000100
      DepthTopAxis.Automatic = False
      DepthTopAxis.AutomaticMaximum = False
      DepthTopAxis.AutomaticMinimum = False
      DepthTopAxis.Maximum = 0.890000000000000800
      DepthTopAxis.Minimum = -0.110000000000000100
      LeftAxis.Automatic = False
      LeftAxis.AutomaticMaximum = False
      LeftAxis.AutomaticMinimum = False
      LeftAxis.Maximum = 1.000000000000000000
      LeftAxis.MaximumOffset = 3
      LeftAxis.Title.Caption = 'density'
      RightAxis.Automatic = False
      RightAxis.AutomaticMaximum = False
      RightAxis.AutomaticMinimum = False
      View3D = False
      Zoom.UpLeftZooms = True
      Align = alLeft
      Color = clWhite
      TabOrder = 0
      PrintMargins = (
        15
        32
        15
        32)
      object ser_buildDense: TAreaSeries
        Depth = 0
        Marks.Callout.Brush.Color = clBlack
        Marks.Callout.Length = 20
        Marks.Visible = False
        SeriesColor = clBlue
        AreaChartBrush.Color = clBlue
        AreaLinesPen.Color = clGray
        AreaLinesPen.Style = psDot
        DrawArea = True
        MultiArea = maStacked
        Pointer.InflateMargins = True
        Pointer.Style = psRectangle
        Pointer.Visible = False
        XValues.Name = 'X'
        XValues.Order = loAscending
        YValues.Name = 'Y'
        YValues.Order = loNone
      end
      object ser_streetDense: TAreaSeries
        Marks.Callout.Brush.Color = clBlack
        Marks.Visible = False
        SeriesColor = clYellow
        AreaChartBrush.Color = clYellow
        AreaLinesPen.Color = clGray
        AreaLinesPen.Style = psDot
        DrawArea = True
        MultiArea = maStacked
        Pointer.InflateMargins = True
        Pointer.Style = psRectangle
        Pointer.Visible = False
        XValues.Name = 'X'
        XValues.Order = loAscending
        YValues.Name = 'Y'
        YValues.Order = loNone
      end
    end
    object Chart_denseA: TChart
      Left = 235
      Top = 1
      Width = 238
      Height = 232
      Border.Visible = True
      Legend.Visible = False
      Title.Gradient.EndColor = clGray
      Title.Gradient.MidColor = clWhite
      Title.Gradient.StartColor = clSilver
      Title.Text.Strings = (
        'Density of Developed Cells')
      BottomAxis.ExactDateTime = False
      BottomAxis.Increment = 1.000000000000000000
      BottomAxis.Title.Caption = 'region'
      DepthAxis.Automatic = False
      DepthAxis.AutomaticMaximum = False
      DepthAxis.AutomaticMinimum = False
      DepthAxis.Maximum = 0.890000000000000800
      DepthAxis.Minimum = -0.110000000000000100
      DepthTopAxis.Automatic = False
      DepthTopAxis.AutomaticMaximum = False
      DepthTopAxis.AutomaticMinimum = False
      DepthTopAxis.Maximum = 0.890000000000000800
      DepthTopAxis.Minimum = -0.110000000000000100
      LeftAxis.Automatic = False
      LeftAxis.AutomaticMaximum = False
      LeftAxis.AutomaticMinimum = False
      LeftAxis.Maximum = 1.000000000000000000
      LeftAxis.MaximumOffset = 3
      LeftAxis.Title.Caption = 'density'
      RightAxis.Automatic = False
      RightAxis.AutomaticMaximum = False
      RightAxis.AutomaticMinimum = False
      View3D = False
      Zoom.UpLeftZooms = True
      Align = alLeft
      Color = clWhite
      TabOrder = 1
      PrintMargins = (
        15
        32
        15
        32)
      object ser_devDense: TAreaSeries
        Depth = 0
        Marks.Callout.Brush.Color = clBlack
        Marks.Callout.Length = 20
        Marks.Visible = False
        SeriesColor = clBlack
        AreaChartBrush.Color = clBlue
        AreaLinesPen.Color = clGray
        AreaLinesPen.Style = psDot
        DrawArea = True
        MultiArea = maStacked
        Pointer.InflateMargins = True
        Pointer.Style = psRectangle
        Pointer.Visible = False
        XValues.Name = 'X'
        XValues.Order = loAscending
        YValues.Name = 'Y'
        YValues.Order = loNone
      end
    end
    object Chart_fractal: TChart
      Left = 1248
      Top = 1
      Width = 338
      Height = 232
      Border.Visible = True
      Title.Gradient.EndColor = clGray
      Title.Gradient.MidColor = clWhite
      Title.Gradient.StartColor = clSilver
      Title.Text.Strings = (
        'Fractal Radial Analysis')
      BottomAxis.ExactDateTime = False
      BottomAxis.Increment = 0.200000000000000000
      BottomAxis.MaximumOffset = 3
      BottomAxis.MinimumOffset = 3
      BottomAxis.Title.Caption = 'log (radius)'
      DepthAxis.Automatic = False
      DepthAxis.AutomaticMaximum = False
      DepthAxis.AutomaticMinimum = False
      DepthAxis.Maximum = 1.070000000000001000
      DepthAxis.Minimum = 0.070000000000000080
      DepthTopAxis.Automatic = False
      DepthTopAxis.AutomaticMaximum = False
      DepthTopAxis.AutomaticMinimum = False
      DepthTopAxis.Maximum = 1.070000000000001000
      DepthTopAxis.Minimum = 0.070000000000000080
      LeftAxis.MaximumOffset = 3
      LeftAxis.MinimumOffset = 3
      LeftAxis.Title.Caption = 'log (number developed cells)'
      RightAxis.Automatic = False
      RightAxis.AutomaticMaximum = False
      RightAxis.AutomaticMinimum = False
      View3D = False
      Zoom.UpLeftZooms = True
      Align = alRight
      Color = clWhite
      TabOrder = 2
      OnDblClick = Chart_fractalDblClick
      PrintMargins = (
        15
        32
        15
        32)
      object ser_fract: TPointSeries
        Depth = 0
        Marks.Callout.Brush.Color = clBlack
        Marks.Callout.Length = 20
        Marks.Symbol.Bevel = bvLowered
        Marks.Symbol.ShapeStyle = fosRoundRectangle
        Marks.Visible = False
        SeriesColor = 64
        Title = 'edges'
        ClickableLine = False
        Pointer.Brush.Color = clRed
        Pointer.HorizSize = 2
        Pointer.InflateMargins = True
        Pointer.Style = psDiamond
        Pointer.VertSize = 2
        Pointer.Visible = True
        XValues.Name = 'X'
        XValues.Order = loAscending
        YValues.Name = 'Y'
        YValues.Order = loNone
      end
      object ser_fractTrend: TLineSeries
        Marks.Callout.Brush.Color = clBlack
        Marks.Style = smsXValue
        Marks.Visible = False
        DataSource = ser_fract
        Title = 'edges trend'
        Pointer.InflateMargins = True
        Pointer.Style = psRectangle
        Pointer.Visible = False
        XValues.Name = 'X'
        XValues.Order = loAscending
        YValues.Name = 'Y'
        YValues.Order = loNone
        object TrendFunction1: TTrendFunction
        end
      end
      object ser_fractCorr1: TLineSeries
        Active = False
        Marks.Callout.Brush.Color = clBlack
        Marks.Visible = False
        DataSource = ser_fract
        VertAxis = aRightAxis
        Pointer.InflateMargins = True
        Pointer.Style = psRectangle
        Pointer.Visible = False
        XValues.Name = 'X'
        XValues.Order = loAscending
        YValues.Name = 'Y'
        YValues.Order = loNone
        object CorrelationFunction2: TCorrelationFunction
        end
      end
      object ser_f2: TPointSeries
        Depth = 0
        Marks.Callout.Brush.Color = clBlack
        Marks.Callout.Length = 20
        Marks.Visible = False
        SeriesColor = 64
        Title = 'nodes'
        ClickableLine = False
        Pointer.Brush.Color = clLime
        Pointer.HorizSize = 2
        Pointer.InflateMargins = True
        Pointer.Style = psTriangle
        Pointer.VertSize = 2
        Pointer.Visible = True
        XValues.Name = 'X'
        XValues.Order = loAscending
        YValues.Name = 'Y'
        YValues.Order = loNone
      end
      object ser_ft2: TLineSeries
        Marks.Callout.Brush.Color = clBlack
        Marks.Visible = False
        DataSource = ser_f2
        SeriesColor = clGreen
        Title = 'nodes trend'
        Brush.Color = clGreen
        Pointer.InflateMargins = True
        Pointer.Style = psRectangle
        Pointer.Visible = False
        XValues.Name = 'X'
        XValues.Order = loAscending
        YValues.Name = 'Y'
        YValues.Order = loNone
        object TeeFunction4: TTrendFunction
        end
      end
      object ser_fractCorr2: TLineSeries
        Active = False
        Marks.Callout.Brush.Color = clBlack
        Marks.Visible = False
        DataSource = ser_f2
        VertAxis = aRightAxis
        Pointer.InflateMargins = True
        Pointer.Style = psRectangle
        Pointer.Visible = False
        XValues.Name = 'X'
        XValues.Order = loAscending
        YValues.Name = 'Y'
        YValues.Order = loNone
        object TeeFunction5: TCorrelationFunction
        end
      end
      object ser_devFract: TPointSeries
        Depth = 0
        Marks.Callout.Brush.Color = clBlack
        Marks.Callout.Length = 20
        Marks.Visible = False
        SeriesColor = 64
        Title = 'developed'
        ClickableLine = False
        Pointer.Brush.Color = 16744448
        Pointer.HorizSize = 2
        Pointer.InflateMargins = True
        Pointer.Style = psRectangle
        Pointer.VertSize = 2
        Pointer.Visible = True
        XValues.Name = 'X'
        XValues.Order = loAscending
        YValues.Name = 'Y'
        YValues.Order = loNone
      end
      object ser_devFractTrend: TLineSeries
        Marks.Callout.Brush.Color = clBlack
        Marks.Visible = False
        DataSource = ser_devFract
        Title = 'developed tr.'
        Brush.Color = clBlue
        Pointer.InflateMargins = True
        Pointer.Style = psRectangle
        Pointer.Visible = False
        XValues.Name = 'X'
        XValues.Order = loAscending
        YValues.Name = 'Y'
        YValues.Order = loNone
        object TeeFunction6: TTrendFunction
        end
      end
      object ser_devFractCorr: TLineSeries
        Active = False
        Marks.Callout.Brush.Color = clBlack
        Marks.Visible = False
        DataSource = ser_devFract
        VertAxis = aRightAxis
        Pointer.InflateMargins = True
        Pointer.Style = psRectangle
        Pointer.Visible = False
        XValues.Name = 'X'
        XValues.Order = loAscending
        YValues.Name = 'Y'
        YValues.Order = loNone
        object TeeFunction7: TCorrelationFunction
        end
      end
    end
    object Chart_FractGrid: TChart
      Left = 888
      Top = 1
      Width = 357
      Height = 232
      Border.Visible = True
      Title.Gradient.EndColor = clGray
      Title.Gradient.MidColor = clWhite
      Title.Gradient.StartColor = clSilver
      Title.Text.Strings = (
        'Fractal Grid Analysis')
      BottomAxis.ExactDateTime = False
      BottomAxis.Increment = 0.200000000000000000
      BottomAxis.MaximumOffset = 3
      BottomAxis.MinimumOffset = 3
      BottomAxis.Title.Caption = 'log (number of tiles)'
      DepthAxis.Automatic = False
      DepthAxis.AutomaticMaximum = False
      DepthAxis.AutomaticMinimum = False
      DepthAxis.Maximum = 1.070000000000001000
      DepthAxis.Minimum = 0.070000000000000080
      DepthTopAxis.Automatic = False
      DepthTopAxis.AutomaticMaximum = False
      DepthTopAxis.AutomaticMinimum = False
      DepthTopAxis.Maximum = 1.070000000000001000
      DepthTopAxis.Minimum = 0.070000000000000080
      LeftAxis.MaximumOffset = 3
      LeftAxis.MinimumOffset = 3
      LeftAxis.Title.Caption = 'log (number developed cells)'
      RightAxis.Automatic = False
      RightAxis.AutomaticMaximum = False
      RightAxis.AutomaticMinimum = False
      View3D = False
      Zoom.UpLeftZooms = True
      Align = alRight
      Color = clWhite
      TabOrder = 3
      OnDblClick = Chart_FractGridDblClick
      PrintMargins = (
        15
        32
        15
        32)
      object ser_DGrid: TPointSeries
        Depth = 0
        Marks.Callout.Brush.Color = clBlack
        Marks.Callout.Length = 20
        Marks.Symbol.Bevel = bvLowered
        Marks.Symbol.ShapeStyle = fosRoundRectangle
        Marks.Visible = False
        SeriesColor = 64
        Title = 'grid_ana'
        ClickableLine = False
        Pointer.Brush.Color = clRed
        Pointer.HorizSize = 2
        Pointer.InflateMargins = True
        Pointer.Style = psDiamond
        Pointer.VertSize = 2
        Pointer.Visible = True
        XValues.Name = 'X'
        XValues.Order = loAscending
        YValues.Name = 'Y'
        YValues.Order = loNone
      end
      object ser_DGrid_Slope: TLineSeries
        Marks.Callout.Brush.Color = clBlack
        Marks.Style = smsXValue
        Marks.Visible = False
        DataSource = ser_DGrid
        Title = 'trend'
        Pointer.InflateMargins = True
        Pointer.Style = psRectangle
        Pointer.Visible = False
        XValues.Name = 'X'
        XValues.Order = loAscending
        YValues.Name = 'Y'
        YValues.Order = loNone
        object TrendFunction2: TTrendFunction
        end
      end
      object ser_DGrid_Corr: TLineSeries
        Active = False
        Marks.Callout.Brush.Color = clBlack
        Marks.Visible = False
        DataSource = ser_DGrid
        VertAxis = aRightAxis
        Pointer.InflateMargins = True
        Pointer.Style = psRectangle
        Pointer.Visible = False
        XValues.Name = 'X'
        XValues.Order = loAscending
        YValues.Name = 'Y'
        YValues.Order = loNone
        object CorrelationFunction3: TCorrelationFunction
        end
      end
    end
    object Chart_IS: TChart
      Left = 476
      Top = 1
      Width = 409
      Height = 232
      Border.Visible = True
      Title.Gradient.EndColor = clGray
      Title.Gradient.MidColor = clWhite
      Title.Gradient.StartColor = clSilver
      Title.Text.Strings = (
        'Index of Segregation (IS) and RS')
      BottomAxis.ExactDateTime = False
      BottomAxis.Increment = 1.000000000000000000
      BottomAxis.Title.Caption = 'time'
      DepthAxis.Automatic = False
      DepthAxis.AutomaticMaximum = False
      DepthAxis.AutomaticMinimum = False
      DepthAxis.Maximum = 0.890000000000000800
      DepthAxis.Minimum = -0.110000000000000100
      DepthTopAxis.Automatic = False
      DepthTopAxis.AutomaticMaximum = False
      DepthTopAxis.AutomaticMinimum = False
      DepthTopAxis.Maximum = 0.890000000000000800
      DepthTopAxis.Minimum = -0.110000000000000100
      LeftAxis.MaximumOffset = 3
      LeftAxis.Title.Caption = 'IS & RS'
      RightAxis.Automatic = False
      RightAxis.AutomaticMaximum = False
      RightAxis.AutomaticMinimum = False
      View3D = False
      Zoom.UpLeftZooms = True
      Align = alClient
      Color = clWhite
      TabOrder = 4
      OnDblClick = Chart_ISDblClick
      PrintMargins = (
        15
        32
        15
        32)
      object ser_IS: TLineSeries
        Marks.Callout.Brush.Color = clBlack
        Marks.Visible = False
        Title = 'IS'
        Pointer.HorizSize = 2
        Pointer.InflateMargins = True
        Pointer.Style = psDiamond
        Pointer.VertSize = 2
        Pointer.Visible = True
        XValues.Name = 'X'
        XValues.Order = loAscending
        YValues.Name = 'Y'
        YValues.Order = loNone
      end
      object ser_RS: TLineSeries
        Marks.Callout.Brush.Color = clBlack
        Marks.Visible = False
        SeriesColor = clBlue
        Title = 'RS'
        Brush.Color = clBlue
        Pointer.HorizSize = 2
        Pointer.InflateMargins = True
        Pointer.Style = psTriangle
        Pointer.VertSize = 2
        Pointer.Visible = True
        XValues.Name = 'X'
        XValues.Order = loAscending
        YValues.Name = 'Y'
        YValues.Order = loNone
      end
    end
  end
  object Panel_Paint: TPanel
    Left = 0
    Top = 0
    Width = 611
    Height = 689
    Align = alLeft
    Color = clWhite
    TabOrder = 1
    OnMouseDown = Panel_PaintMouseDown
    OnMouseUp = Panel_PaintMouseUp
    object Panel_PBar: TPanel
      Left = 216
      Top = 289
      Width = 185
      Height = 58
      TabOrder = 0
      Visible = False
      object lbl_calcer: TLabel
        Left = 47
        Top = 8
        Width = 90
        Height = 13
        Caption = 'calculate pathes...'
      end
      object ProgressBar1: TProgressBar
        Left = 16
        Top = 27
        Width = 153
        Height = 17
        TabOrder = 0
      end
    end
  end
  object Panel2: TPanel
    Left = 616
    Top = 0
    Width = 289
    Height = 689
    Align = alLeft
    TabOrder = 2
    object PageControl1: TPageControl
      Left = 1
      Top = 155
      Width = 287
      Height = 333
      ActivePage = TabSheet1
      Align = alTop
      MultiLine = True
      TabOrder = 0
      object TabSheet1: TTabSheet
        Caption = 'development settings'
        object Lbl_Sphere: TLabel
          Left = 41
          Top = 11
          Width = 80
          Height = 13
          Alignment = taRightJustify
          Caption = 'max street step:'
        end
        object Label5: TLabel
          Left = 3
          Top = 62
          Width = 118
          Height = 13
          Alignment = taRightJustify
          Caption = 'centrifugal weight (w2) :'
        end
        object Label15: TLabel
          Left = 3
          Top = 39
          Width = 118
          Height = 13
          Alignment = taRightJustify
          Caption = 'centripetal weight (w1) :'
        end
        object Label14: TLabel
          Left = 4
          Top = 93
          Width = 117
          Height = 13
          Alignment = taRightJustify
          Caption = 'development threshold :'
        end
        object Label11: TLabel
          Left = 57
          Top = 126
          Width = 64
          Height = 13
          Alignment = taRightJustify
          Caption = 'growth rate :'
        end
        object Label2: TLabel
          Left = 57
          Top = 154
          Width = 67
          Height = 13
          Caption = 'auto-stop at :'
        end
        object Label20: TLabel
          Left = 174
          Top = 62
          Width = 57
          Height = 13
          Alignment = taRightJustify
          Caption = 'x  scale (B):'
        end
        object Label21: TLabel
          Left = 174
          Top = 39
          Width = 58
          Height = 13
          Alignment = taRightJustify
          Caption = 'x  scale (A):'
        end
        object Label29: TLabel
          Left = 54
          Top = 193
          Width = 70
          Height = 13
          Alignment = taRightJustify
          Caption = 'random scale :'
        end
        object SE_strStep: TSpinEdit
          Left = 127
          Top = 6
          Width = 44
          Height = 22
          MaxValue = 10000
          MinValue = 1
          TabOrder = 0
          Value = 3
        end
        object E_centriFu: TEdit
          Left = 127
          Top = 58
          Width = 39
          Height = 21
          TabOrder = 1
          Text = '1,0'
          OnChange = E_centriFuChange
        end
        object E_centriPe: TEdit
          Left = 127
          Top = 35
          Width = 39
          Height = 21
          TabOrder = 2
          Text = '2,0'
          OnChange = E_centriFuChange
        end
        object E_devThresh: TEdit
          Left = 127
          Top = 89
          Width = 39
          Height = 21
          TabOrder = 3
          Text = '0,1'
        end
        object SE_HWM_gRate: TSpinEdit
          Left = 127
          Top = 121
          Width = 44
          Height = 22
          MaxValue = 10000
          MinValue = 1
          TabOrder = 4
          Value = 5
        end
        object SE_stopAt: TSpinEdit
          Left = 127
          Top = 149
          Width = 57
          Height = 22
          Increment = 10
          MaxValue = 33000
          MinValue = 1
          TabOrder = 5
          Value = 500
        end
        object E_fuScale: TEdit
          Left = 234
          Top = 58
          Width = 39
          Height = 21
          TabOrder = 6
          Text = '2,0'
          OnChange = E_centriFuChange
        end
        object E_peScale: TEdit
          Left = 235
          Top = 35
          Width = 39
          Height = 21
          TabOrder = 7
          Text = '1,7'
          OnChange = E_centriFuChange
        end
        object GroupBox6: TGroupBox
          Left = 3
          Top = 212
          Width = 270
          Height = 72
          Caption = 'proportions'
          TabOrder = 8
          object Label28: TLabel
            Left = 56
            Top = 28
            Width = 125
            Height = 13
            Caption = 'w1/w2   |   A/B   |   w2/w1'
          end
          object lbl_rat1: TLabel
            Left = 64
            Top = 47
            Width = 35
            Height = 13
            Alignment = taCenter
            Caption = 'w1/w2 '
          end
          object lbl_rat2: TLabel
            Left = 112
            Top = 47
            Width = 32
            Height = 13
            Alignment = taCenter
            Caption = '  A/B   '
          end
          object lbl_rat3: TLabel
            Left = 158
            Top = 47
            Width = 32
            Height = 13
            Alignment = taCenter
            Caption = 'w2/w1'
          end
        end
        object E_rndScale: TEdit
          Left = 127
          Top = 189
          Width = 39
          Height = 21
          TabOrder = 9
          Text = '1,0'
          OnChange = E_centriFuChange
        end
        object cb_plotRnd: TCheckBox
          Left = 176
          Top = 191
          Width = 81
          Height = 17
          Caption = 'show in plot'
          TabOrder = 10
          OnClick = cb_plotRndClick
        end
      end
      object TabSheet4: TTabSheet
        Caption = 'field types'
        ImageIndex = 2
        object Label3: TLabel
          Left = 31
          Top = 163
          Width = 64
          Height = 13
          Caption = 'min Distance:'
        end
        object Label16: TLabel
          Left = 28
          Top = 198
          Width = 67
          Height = 13
          Alignment = taRightJustify
          Caption = 'noise weight :'
        end
        object Label18: TLabel
          Left = 26
          Top = 229
          Width = 69
          Height = 13
          Alignment = taRightJustify
          Caption = 'grow thresh. :'
        end
        object Label12: TLabel
          Left = 164
          Top = 161
          Width = 85
          Height = 13
          Caption = '(only for interlink)'
        end
        object Label19: TLabel
          Left = 146
          Top = 229
          Width = 96
          Height = 13
          Caption = '(=1 for higwayman)'
        end
        object Label22: TLabel
          Left = 49
          Top = 124
          Width = 46
          Height = 13
          Caption = 'start with'
        end
        object Label23: TLabel
          Left = 150
          Top = 124
          Width = 68
          Height = 13
          Caption = 'cluster rounds'
        end
        object SE_minDist: TSpinEdit
          Left = 101
          Top = 158
          Width = 57
          Height = 22
          MaxValue = 10000
          MinValue = 1
          TabOrder = 0
          Value = 3
        end
        object E_fieldW: TEdit
          Left = 101
          Top = 194
          Width = 40
          Height = 21
          TabOrder = 1
          Text = '0,1'
        end
        object E_nodeThresh: TEdit
          Left = 101
          Top = 225
          Width = 39
          Height = 21
          TabOrder = 2
          Text = '0,1'
        end
        object RadioGroup1: TRadioGroup
          Left = 19
          Top = 3
          Width = 246
          Height = 110
          Caption = 'choose active field-type'
          TabOrder = 3
        end
        object RB_boom: TRadioButton
          Left = 40
          Top = 48
          Width = 113
          Height = 17
          Caption = 'boom'
          TabOrder = 4
          OnClick = RB_boomClick
        end
        object RB_interlink: TRadioButton
          Left = 40
          Top = 65
          Width = 113
          Height = 17
          Caption = 'interlink'
          TabOrder = 5
          OnClick = RB_boomClick
        end
        object RB_cluster: TRadioButton
          Left = 40
          Top = 88
          Width = 113
          Height = 17
          Caption = 'cluster'
          Checked = True
          TabOrder = 6
          TabStop = True
          OnClick = RB_boomClick
        end
        object RB_netOnly: TRadioButton
          Left = 40
          Top = 25
          Width = 113
          Height = 17
          Caption = 'network only'
          TabOrder = 7
          OnClick = RB_boomClick
        end
        object se_clusterRds: TSpinEdit
          Left = 101
          Top = 119
          Width = 43
          Height = 22
          MaxValue = 10000
          MinValue = 0
          TabOrder = 8
          Value = 3
        end
      end
      object TabSheet2: TTabSheet
        Caption = 'analyse graph'
        ImageIndex = 4
        object GroupBox4: TGroupBox
          Left = 3
          Top = 3
          Width = 270
          Height = 78
          Caption = 'analyse'
          TabOrder = 0
          object B_CalcPathes: TButton
            Left = 3
            Top = 15
            Width = 160
            Height = 25
            Caption = 'calcPathes'
            TabOrder = 0
            OnClick = B_CalcPathesClick
          end
          object B_Analyse: TButton
            Left = 169
            Top = 15
            Width = 91
            Height = 25
            Caption = 'anal. minDist'
            TabOrder = 1
            OnClick = B_AnalyseClick
          end
          object Button2: TButton
            Left = 171
            Top = 45
            Width = 90
            Height = 25
            Caption = 'anal. graph size'
            TabOrder = 2
            OnClick = Button2Click
          end
          object CB_locMeas: TCheckBox
            Left = 3
            Top = 49
            Width = 109
            Height = 17
            Caption = 'use local measure:'
            Checked = True
            State = cbChecked
            TabOrder = 3
          end
          object SE_locRad: TSpinEdit
            Left = 118
            Top = 46
            Width = 46
            Height = 22
            MaxValue = 1000
            MinValue = 1
            TabOrder = 4
            Value = 4
          end
        end
        object GroupBox2: TGroupBox
          Left = 3
          Top = 87
          Width = 150
          Height = 195
          Caption = 'colour gradient'
          TabOrder = 1
          object ImageGradient: TImage
            Left = 104
            Top = 20
            Width = 35
            Height = 161
          end
          object Label4: TLabel
            Left = 75
            Top = 15
            Width = 23
            Height = 13
            Caption = '0.0 -'
          end
          object Lbl_half: TLabel
            Left = 78
            Top = 92
            Width = 23
            Height = 13
            Caption = '0.5 -'
          end
          object Label6: TLabel
            Left = 78
            Top = 170
            Width = 23
            Height = 13
            Caption = '1.0 -'
          end
          object Label8: TLabel
            Left = 4
            Top = 39
            Width = 34
            Height = 13
            Caption = 'adjust:'
          end
          object Lbl_colScal: TLabel
            Left = 50
            Top = 93
            Width = 12
            Height = 13
            Caption = 'XX'
          end
          object TB_color: TTrackBar
            Left = 3
            Top = 55
            Width = 45
            Height = 89
            Orientation = trVertical
            ParentShowHint = False
            Position = 5
            ShowHint = False
            TabOrder = 0
            OnChange = TB_colorChange
          end
        end
        object GroupBox5: TGroupBox
          Left = 159
          Top = 87
          Width = 114
          Height = 79
          Caption = 'graph characteristics'
          TabOrder = 2
          object Label9: TLabel
            Left = 33
            Top = 15
            Width = 33
            Height = 13
            Caption = 'nodes:'
          end
          object Lbl_nrNodes: TLabel
            Left = 72
            Top = 15
            Width = 40
            Height = 13
            Caption = 'nrNodes'
          end
          object Label10: TLabel
            Left = 33
            Top = 34
            Width = 33
            Height = 13
            Caption = 'edges:'
          end
          object lbl_nrEdges: TLabel
            Left = 72
            Top = 34
            Width = 39
            Height = 13
            Caption = 'nrEdges'
          end
          object Label17: TLabel
            Left = 3
            Top = 53
            Width = 63
            Height = 13
            Caption = 'mean length:'
          end
          object Lbl_ml: TLabel
            Left = 72
            Top = 53
            Width = 13
            Height = 13
            Caption = 'ML'
          end
        end
        object Button5: TButton
          Left = 159
          Top = 185
          Width = 114
          Height = 25
          Caption = 'show table'
          TabOrder = 3
          OnClick = Button5Click
        end
      end
      object TabSheet3: TTabSheet
        Caption = 'building'
        ImageIndex = 3
        object b_autoBuild: TSpeedButton
          Left = 16
          Top = 6
          Width = 97
          Height = 29
          AllowAllUp = True
          GroupIndex = 1
          Down = True
          Caption = 'auto build'
        end
        object b_rndBuild: TButton
          Left = 128
          Top = 6
          Width = 97
          Height = 29
          Caption = 'random buildings'
          TabOrder = 0
          OnClick = b_rndBuildClick
        end
        object GroupBox3: TGroupBox
          Left = 16
          Top = 41
          Width = 97
          Height = 132
          Caption = 'building rules'
          TabOrder = 1
          object Label24: TLabel
            Left = 10
            Top = 24
            Width = 32
            Height = 13
            Caption = 'gen A:'
          end
          object Label25: TLabel
            Left = 11
            Top = 49
            Width = 31
            Height = 13
            Caption = 'gen B:'
          end
          object Label26: TLabel
            Left = 10
            Top = 80
            Width = 32
            Height = 13
            Caption = 'gen C:'
          end
          object Label27: TLabel
            Left = 10
            Top = 104
            Width = 32
            Height = 13
            Caption = 'gen D:'
          end
          object SE_genA: TSpinEdit
            Left = 46
            Top = 19
            Width = 43
            Height = 22
            MaxValue = 8
            MinValue = 0
            TabOrder = 0
            Value = 7
          end
          object SE_genB: TSpinEdit
            Left = 46
            Top = 44
            Width = 43
            Height = 22
            MaxValue = 8
            MinValue = 0
            TabOrder = 1
            Value = 0
          end
          object SE_genC: TSpinEdit
            Left = 46
            Top = 75
            Width = 43
            Height = 22
            MaxValue = 8
            MinValue = 0
            TabOrder = 2
            Value = 1
          end
          object SE_genD: TSpinEdit
            Left = 46
            Top = 99
            Width = 43
            Height = 22
            MaxValue = 8
            MinValue = 0
            TabOrder = 3
            Value = 3
          end
        end
        object GroupBox8: TGroupBox
          Left = 16
          Top = 179
          Width = 230
          Height = 94
          Caption = 'neigbour conditions'
          TabOrder = 2
          object Label30: TLabel
            Left = 13
            Top = 28
            Width = 170
            Height = 13
            Caption = 'more than one build on neighbours:'
          end
          object Label31: TLabel
            Left = 13
            Top = 47
            Width = 170
            Height = 13
            Caption = 'more than two build on neighbours:'
          end
          object Label32: TLabel
            Left = 11
            Top = 66
            Width = 172
            Height = 13
            Caption = 'more than tree build on neighbours:'
          end
          object lbl_grOne: TLabel
            Left = 189
            Top = 28
            Width = 18
            Height = 13
            Caption = '___'
          end
          object lbl_grTwo: TLabel
            Left = 189
            Top = 47
            Width = 18
            Height = 13
            Caption = '___'
          end
          object lbl_grThree: TLabel
            Left = 189
            Top = 66
            Width = 18
            Height = 13
            Caption = '___'
          end
          object Label35: TLabel
            Left = 209
            Top = 28
            Width = 11
            Height = 13
            Caption = '%'
          end
          object Label36: TLabel
            Left = 209
            Top = 47
            Width = 11
            Height = 13
            Caption = '%'
          end
          object Label37: TLabel
            Left = 209
            Top = 66
            Width = 11
            Height = 13
            Caption = '%'
          end
        end
      end
      object TabSheet5: TTabSheet
        Caption = 'analyse structure'
        ImageIndex = 4
        object Button1: TButton
          Left = 3
          Top = 53
          Width = 75
          Height = 25
          Caption = 'show cluster'
          TabOrder = 0
          OnClick = Button1Click
        end
        object Button4: TButton
          Left = 3
          Top = 3
          Width = 75
          Height = 25
          Caption = 'fractal A.'
          TabOrder = 1
          OnClick = Button4Click
        end
        object Button3: TButton
          Left = 3
          Top = 84
          Width = 75
          Height = 25
          Caption = 'show states'
          TabOrder = 2
          OnClick = Button3Click
        end
        object ValueListEditor1: TValueListEditor
          Left = 104
          Top = 3
          Width = 169
          Height = 278
          DefaultRowHeight = 15
          Strings.Strings = (
            'Grid Analysis='
            'D_grid='
            'slope_grid='
            'Radial Analysis='
            'D_rad=0,33'
            'slope_rad=0,33'
            ''
            'Nodes (radial a.)='
            'D_nodes=0,33'
            'slope_nodes='
            'Edges (length, radial a.)='
            'D_edge='
            'slope_edge='
            ''
            'IS_developed_cells='
            'slope_rank=')
          TabOrder = 3
          TitleCaptions.Strings = (
            'Fractal Analysis'
            'Values')
          ColWidths = (
            124
            39)
        end
        object cb_centerGrav: TCheckBox
          Left = 3
          Top = 30
          Width = 95
          Height = 17
          Caption = 'center gravity'
          TabOrder = 4
        end
        object Button6: TButton
          Left = 3
          Top = 110
          Width = 75
          Height = 25
          Caption = 'sub states'
          TabOrder = 5
          OnClick = Button6Click
        end
        object Button7: TButton
          Left = 3
          Top = 141
          Width = 75
          Height = 25
          Caption = 'pot. field'
          TabOrder = 6
          OnClick = Button7Click
        end
        object Button8: TButton
          Left = 3
          Top = 172
          Width = 75
          Height = 25
          Caption = 'cand. sites'
          TabOrder = 7
          OnClick = Button8Click
        end
        object Button9: TButton
          Left = 3
          Top = 203
          Width = 75
          Height = 25
          Caption = 'gray agents'
          TabOrder = 8
          OnClick = Button9Click
        end
        object Button10: TButton
          Left = 3
          Top = 243
          Width = 95
          Height = 38
          Caption = 'Anal. Dev. Param.'
          TabOrder = 9
          OnClick = Button10Click
        end
      end
    end
    object GroupBox1: TGroupBox
      Left = 1
      Top = 1
      Width = 287
      Height = 154
      Align = alTop
      Caption = 'general settings'
      TabOrder = 1
      object Label1: TLabel
        Left = 182
        Top = 46
        Width = 40
        Height = 13
        Caption = 'cell size:'
      end
      object Label7: TLabel
        Left = 173
        Top = 23
        Width = 49
        Height = 13
        Caption = 'node size:'
      end
      object lbl_actTime: TLabel
        Left = 98
        Top = 130
        Width = 20
        Height = 13
        Alignment = taRightJustify
        BiDiMode = bdRightToLeft
        Caption = 'time'
        ParentBiDiMode = False
      end
      object Label13: TLabel
        Left = 15
        Top = 130
        Width = 80
        Height = 13
        Alignment = taRightJustify
        Caption = 'actual timestep :'
      end
      object B_setup: TButton
        Left = 15
        Top = 68
        Width = 152
        Height = 25
        Caption = 'new setup'
        TabOrder = 0
        OnClick = B_setupClick
      end
      object SE_nSz: TSpinEdit
        Left = 228
        Top = 19
        Width = 44
        Height = 22
        MaxValue = 1000
        MinValue = 1
        TabOrder = 1
        Value = 5
        OnChange = SE_nSzChange
      end
      object SE_cellScale: TSpinEdit
        Left = 228
        Top = 41
        Width = 44
        Height = 22
        MaxValue = 1000
        MinValue = 1
        TabOrder = 2
        Value = 24
      end
      object B_agRepaint: TButton
        Left = 176
        Top = 68
        Width = 97
        Height = 25
        Caption = 'rePaint nodes'
        TabOrder = 3
        OnClick = B_agRepaintClick
      end
      object cb_centerNode: TCheckBox
        Left = 16
        Top = 22
        Width = 137
        Height = 17
        Caption = 'start with initial street'
        Checked = True
        State = cbChecked
        TabOrder = 4
      end
      object CB_nodeLbl: TCheckBox
        Left = 16
        Top = 45
        Width = 137
        Height = 17
        Caption = 'run with node numbers'
        TabOrder = 5
      end
      object B_ITL_stop: TButton
        Left = 97
        Top = 99
        Width = 70
        Height = 25
        Caption = 'stop'
        TabOrder = 6
        OnClick = B_HWM_stopClick
      end
      object B_ITL_start: TButton
        Left = 15
        Top = 99
        Width = 70
        Height = 25
        Caption = 'start'
        TabOrder = 7
        OnClick = B_ITL_startClick
      end
      object CB_agLayer: TCheckBox
        Left = 176
        Top = 99
        Width = 105
        Height = 17
        Caption = 'show agent layer'
        Checked = True
        State = cbChecked
        TabOrder = 8
        OnClick = CB_agLayerClick
      end
      object CB_cellLayer: TCheckBox
        Left = 176
        Top = 114
        Width = 105
        Height = 17
        Caption = 'show cell layer'
        Checked = True
        State = cbChecked
        TabOrder = 9
        OnClick = CB_cellLayerClick
      end
    end
    object Chart_resForce: TChart
      Left = 1
      Top = 488
      Width = 287
      Height = 200
      Border.Visible = True
      Legend.Visible = False
      Title.Gradient.EndColor = clGray
      Title.Gradient.MidColor = clWhite
      Title.Gradient.StartColor = clSilver
      Title.Text.Strings = (
        'Resulting Force (from Centripetal and Centrifugal)')
      BottomAxis.ExactDateTime = False
      BottomAxis.Increment = 0.100000000000000000
      BottomAxis.MaximumOffset = 3
      BottomAxis.MinimumOffset = 3
      BottomAxis.Title.Caption = 'potential'
      DepthAxis.Automatic = False
      DepthAxis.AutomaticMaximum = False
      DepthAxis.AutomaticMinimum = False
      DepthAxis.Maximum = 0.890000000000001000
      DepthAxis.Minimum = -0.110000000000000300
      DepthTopAxis.Automatic = False
      DepthTopAxis.AutomaticMaximum = False
      DepthTopAxis.AutomaticMinimum = False
      DepthTopAxis.Maximum = 0.890000000000001000
      DepthTopAxis.Minimum = -0.110000000000000300
      LeftAxis.MaximumOffset = 3
      LeftAxis.MinimumOffset = 3
      LeftAxis.Title.Caption = 'force'
      RightAxis.Automatic = False
      RightAxis.AutomaticMaximum = False
      RightAxis.AutomaticMinimum = False
      View3D = False
      Zoom.UpLeftZooms = True
      Align = alClient
      Color = clWhite
      TabOrder = 2
      OnDblClick = Chart_resForceDblClick
      PrintMargins = (
        15
        32
        15
        32)
      object ser_custFkt: TLineSeries
        Marks.Callout.Brush.Color = clBlack
        Marks.Visible = False
        Pointer.InflateMargins = True
        Pointer.Style = psRectangle
        Pointer.Visible = False
        XValues.Name = 'X'
        XValues.Order = loAscending
        YValues.Name = 'Y'
        YValues.Order = loNone
        object TeeFunction8: TCustomTeeFunction
          Period = 1.000000000000000000
          NumPoints = 100
        end
      end
    end
  end
  object PageControl2: TPageControl
    Left = 910
    Top = 0
    Width = 682
    Height = 689
    ActivePage = TabSheet7
    Align = alClient
    TabOrder = 3
    object TabSheet6: TTabSheet
      Caption = 'land use and road network analysis'
      object Splitter6: TSplitter
        Left = 0
        Top = 214
        Width = 674
        Height = 3
        Cursor = crVSplit
        Align = alTop
      end
      object Splitter7: TSplitter
        Left = 0
        Top = 417
        Width = 674
        Height = 3
        Cursor = crVSplit
        Align = alBottom
        ExplicitTop = 416
      end
      object Splitter8: TSplitter
        Left = 354
        Top = 217
        Width = 5
        Height = 200
        Beveled = True
        ResizeStyle = rsLine
        ExplicitLeft = 851
        ExplicitTop = 6
        ExplicitHeight = 653
      end
      object Panel4: TPanel
        Left = 0
        Top = 0
        Width = 674
        Height = 214
        Align = alTop
        TabOrder = 0
        object Splitter12: TSplitter
          Left = 353
          Top = 1
          Width = 5
          Height = 212
          Beveled = True
          ResizeStyle = rsLine
          ExplicitLeft = 851
          ExplicitTop = 6
          ExplicitHeight = 653
        end
        object Ch_clusterSize: TChart
          Left = 358
          Top = 1
          Width = 315
          Height = 212
          Border.Visible = True
          Legend.Visible = False
          Title.Gradient.EndColor = clGray
          Title.Gradient.MidColor = clWhite
          Title.Gradient.StartColor = clSilver
          Title.Text.Strings = (
            'Cluster Sizes')
          BottomAxis.ExactDateTime = False
          BottomAxis.Increment = 1.000000000000000000
          BottomAxis.Title.Caption = 'cluster'
          DepthAxis.Automatic = False
          DepthAxis.AutomaticMaximum = False
          DepthAxis.AutomaticMinimum = False
          DepthAxis.Maximum = 1.100000000000001000
          DepthAxis.Minimum = 0.100000000000000100
          DepthTopAxis.Automatic = False
          DepthTopAxis.AutomaticMaximum = False
          DepthTopAxis.AutomaticMinimum = False
          DepthTopAxis.Maximum = 1.100000000000001000
          DepthTopAxis.Minimum = 0.100000000000000100
          LeftAxis.Title.Caption = 'number of cells'
          RightAxis.Automatic = False
          RightAxis.AutomaticMaximum = False
          RightAxis.AutomaticMinimum = False
          View3D = False
          Zoom.UpLeftZooms = True
          Align = alClient
          Color = clWhite
          TabOrder = 0
          PrintMargins = (
            15
            32
            15
            32)
          object bar_clusterSize: TBarSeries
            Depth = 0
            Marks.Callout.Brush.Color = clBlack
            Marks.Visible = True
            SeriesColor = clBlack
            Title = 'bar_clusterSize'
            Gradient.Direction = gdTopBottom
            MultiBar = mbNone
            XValues.Name = 'X'
            XValues.Order = loAscending
            YValues.Name = 'Bar'
            YValues.Order = loNone
          end
        end
        object Chart_nodes: TChart
          Left = 1
          Top = 1
          Width = 352
          Height = 212
          Border.Visible = True
          Legend.Visible = False
          Title.Gradient.EndColor = clGray
          Title.Gradient.MidColor = clWhite
          Title.Gradient.StartColor = clSilver
          Title.Text.Strings = (
            'Edges per Node')
          BottomAxis.ExactDateTime = False
          BottomAxis.Increment = 1.000000000000000000
          BottomAxis.Title.Caption = 'edges / node'
          DepthAxis.Automatic = False
          DepthAxis.AutomaticMaximum = False
          DepthAxis.AutomaticMinimum = False
          DepthAxis.Maximum = 0.890000000000001000
          DepthAxis.Minimum = -0.110000000000000300
          DepthTopAxis.Automatic = False
          DepthTopAxis.AutomaticMaximum = False
          DepthTopAxis.AutomaticMinimum = False
          DepthTopAxis.Maximum = 0.890000000000001000
          DepthTopAxis.Minimum = -0.110000000000000300
          LeftAxis.Title.Caption = 'number of nodes'
          RightAxis.Automatic = False
          RightAxis.AutomaticMaximum = False
          RightAxis.AutomaticMinimum = False
          View3D = False
          Zoom.UpLeftZooms = True
          Align = alLeft
          Color = clWhite
          TabOrder = 1
          PrintMargins = (
            15
            32
            15
            32)
          object Ser_Edges: TBarSeries
            Depth = 0
            Marks.Callout.Brush.Color = clBlack
            Marks.Visible = True
            SeriesColor = 33023
            Gradient.Direction = gdTopBottom
            MultiBar = mbNone
            XValues.Name = 'X'
            XValues.Order = loAscending
            YValues.Name = 'Bar'
            YValues.Order = loNone
          end
        end
      end
      object Chart_PotDens: TChart
        Left = 0
        Top = 217
        Width = 354
        Height = 200
        Border.Visible = True
        Legend.Visible = False
        Title.Gradient.EndColor = clGray
        Title.Gradient.MidColor = clWhite
        Title.Gradient.StartColor = clSilver
        Title.Text.Strings = (
          'Potential / Density')
        BottomAxis.Automatic = False
        BottomAxis.AutomaticMaximum = False
        BottomAxis.AutomaticMinimum = False
        BottomAxis.ExactDateTime = False
        BottomAxis.Maximum = 1.000000000000000000
        BottomAxis.MaximumOffset = 3
        BottomAxis.MinimumOffset = 3
        BottomAxis.Title.Caption = 'density'
        DepthAxis.Automatic = False
        DepthAxis.AutomaticMaximum = False
        DepthAxis.AutomaticMinimum = False
        DepthAxis.Maximum = 1.190000000000001000
        DepthAxis.Minimum = 0.190000000000000200
        DepthTopAxis.Automatic = False
        DepthTopAxis.AutomaticMaximum = False
        DepthTopAxis.AutomaticMinimum = False
        DepthTopAxis.Maximum = 1.190000000000001000
        DepthTopAxis.Minimum = 0.190000000000000200
        LeftAxis.Automatic = False
        LeftAxis.AutomaticMaximum = False
        LeftAxis.AutomaticMinimum = False
        LeftAxis.Maximum = 1.000000000000000000
        LeftAxis.MaximumOffset = 3
        LeftAxis.MinimumOffset = 3
        LeftAxis.Title.Caption = 'potential'
        RightAxis.Automatic = False
        RightAxis.AutomaticMaximum = False
        RightAxis.AutomaticMinimum = False
        View3D = False
        Zoom.UpLeftZooms = True
        Align = alLeft
        Color = clWhite
        TabOrder = 1
        PrintMargins = (
          15
          32
          15
          32)
        object ser_PotDense: TPointSeries
          Marks.Callout.Brush.Color = clBlack
          Marks.Visible = False
          ClickableLine = False
          Pointer.HorizSize = 2
          Pointer.InflateMargins = True
          Pointer.Style = psRectangle
          Pointer.VertSize = 2
          Pointer.Visible = True
          XValues.Name = 'X'
          XValues.Order = loAscending
          YValues.Name = 'Y'
          YValues.Order = loNone
        end
        object ser_PotDenseCorr: TLineSeries
          Active = False
          Marks.Callout.Brush.Color = clBlack
          Marks.Visible = False
          DataSource = ser_PotDense
          VertAxis = aRightAxis
          Pointer.InflateMargins = True
          Pointer.Style = psRectangle
          Pointer.Visible = False
          XValues.Name = 'X'
          XValues.Order = loAscending
          YValues.Name = 'Y'
          YValues.Order = loNone
          object TeeFunction1: TCorrelationFunction
          end
        end
      end
      object Chart_rank: TChart
        Left = 0
        Top = 420
        Width = 674
        Height = 241
        Border.Visible = True
        Legend.Visible = False
        Title.Gradient.EndColor = clGray
        Title.Gradient.MidColor = clWhite
        Title.Gradient.StartColor = clSilver
        Title.Text.Strings = (
          'Rank-Size (RS)')
        BottomAxis.ExactDateTime = False
        BottomAxis.MaximumOffset = 3
        BottomAxis.MinimumOffset = 3
        BottomAxis.Title.Caption = 'log rank'
        DepthAxis.Automatic = False
        DepthAxis.AutomaticMaximum = False
        DepthAxis.AutomaticMinimum = False
        DepthAxis.Maximum = 1.700000000000000000
        DepthAxis.Minimum = 0.699999999999995800
        DepthTopAxis.Automatic = False
        DepthTopAxis.AutomaticMaximum = False
        DepthTopAxis.AutomaticMinimum = False
        DepthTopAxis.Maximum = 1.700000000000000000
        DepthTopAxis.Minimum = 0.699999999999995800
        LeftAxis.MaximumOffset = 3
        LeftAxis.MinimumOffset = 3
        LeftAxis.Title.Caption = 'log cluster size'
        RightAxis.Automatic = False
        RightAxis.AutomaticMaximum = False
        RightAxis.AutomaticMinimum = False
        View3D = False
        Zoom.UpLeftZooms = True
        Align = alBottom
        Color = clWhite
        TabOrder = 2
        PrintMargins = (
          15
          32
          15
          32)
        object ser_rank: TLineSeries
          Depth = 0
          Marks.Callout.Brush.Color = clBlack
          Marks.Callout.Length = 20
          Marks.Visible = False
          SeriesColor = 64
          ClickableLine = False
          Pointer.Brush.Color = clRed
          Pointer.HorizSize = 2
          Pointer.InflateMargins = True
          Pointer.Style = psDiamond
          Pointer.VertSize = 2
          Pointer.Visible = True
          XValues.Name = 'X'
          XValues.Order = loAscending
          YValues.Name = 'Y'
          YValues.Order = loNone
        end
        object ser_rankCorr: TLineSeries
          Active = False
          Marks.Callout.Brush.Color = clBlack
          Marks.Visible = False
          DataSource = ser_rank
          VertAxis = aRightAxis
          Pointer.InflateMargins = True
          Pointer.Style = psRectangle
          Pointer.Visible = False
          XValues.Name = 'X'
          XValues.Order = loAscending
          YValues.Name = 'Y'
          YValues.Order = loNone
          object CorrelationFunction1: TCorrelationFunction
          end
        end
        object ser_rankTrend: TLineSeries
          Marks.Callout.Brush.Color = clBlack
          Marks.Visible = False
          DataSource = ser_rank
          Pointer.InflateMargins = True
          Pointer.Style = psRectangle
          Pointer.Visible = False
          XValues.Name = 'X'
          XValues.Order = loAscending
          YValues.Name = 'Y'
          YValues.Order = loNone
          object TeeFunction3: TTrendFunction
          end
        end
      end
      object Chart_ConnPot: TChart
        Left = 359
        Top = 217
        Width = 315
        Height = 200
        Border.Visible = True
        Legend.Visible = False
        Title.Gradient.EndColor = clGray
        Title.Gradient.MidColor = clWhite
        Title.Gradient.StartColor = clSilver
        Title.Text.Strings = (
          'Potential / Connectivity')
        BottomAxis.Automatic = False
        BottomAxis.AutomaticMaximum = False
        BottomAxis.AutomaticMinimum = False
        BottomAxis.ExactDateTime = False
        BottomAxis.Maximum = 1.000000000000000000
        BottomAxis.MaximumOffset = 3
        BottomAxis.MinimumOffset = 3
        BottomAxis.Title.Caption = 'connectivity'
        DepthAxis.Automatic = False
        DepthAxis.AutomaticMaximum = False
        DepthAxis.AutomaticMinimum = False
        DepthAxis.Maximum = 1.070000000000001000
        DepthAxis.Minimum = 0.070000000000000060
        DepthTopAxis.Automatic = False
        DepthTopAxis.AutomaticMaximum = False
        DepthTopAxis.AutomaticMinimum = False
        DepthTopAxis.Maximum = 1.070000000000001000
        DepthTopAxis.Minimum = 0.070000000000000060
        LeftAxis.Automatic = False
        LeftAxis.AutomaticMaximum = False
        LeftAxis.AutomaticMinimum = False
        LeftAxis.Maximum = 1.000000000000000000
        LeftAxis.MaximumOffset = 3
        LeftAxis.MinimumOffset = 3
        LeftAxis.Title.Caption = 'potential'
        RightAxis.Automatic = False
        RightAxis.AutomaticMaximum = False
        RightAxis.AutomaticMinimum = False
        View3D = False
        Zoom.UpLeftZooms = True
        Align = alClient
        Color = clWhite
        TabOrder = 3
        PrintMargins = (
          15
          32
          15
          32)
        object ser_ConnPot: TPointSeries
          Depth = 0
          Marks.Callout.Brush.Color = clBlack
          Marks.Callout.Length = 20
          Marks.Visible = False
          SeriesColor = 33023
          ClickableLine = False
          Pointer.Brush.Color = clRed
          Pointer.HorizSize = 2
          Pointer.InflateMargins = True
          Pointer.Style = psDiamond
          Pointer.VertSize = 2
          Pointer.Visible = True
          XValues.Name = 'X'
          XValues.Order = loAscending
          YValues.Name = 'Y'
          YValues.Order = loNone
        end
        object ser_ConnPotCorr: TLineSeries
          Active = False
          Marks.Callout.Brush.Color = clBlack
          Marks.Visible = False
          DataSource = ser_ConnPot
          VertAxis = aRightAxis
          Pointer.InflateMargins = True
          Pointer.Style = psRectangle
          Pointer.Visible = False
          XValues.Name = 'X'
          XValues.Order = loAscending
          YValues.Name = 'Y'
          YValues.Order = loNone
          object TeeFunction2: TCorrelationFunction
          end
        end
      end
    end
    object TabSheet7: TTabSheet
      Caption = 'building structure analysis'
      ImageIndex = 1
      object Splitter13: TSplitter
        Left = 0
        Top = 353
        Width = 674
        Height = 3
        Cursor = crVSplit
        Align = alTop
        ExplicitTop = 282
      end
      object Panel5: TPanel
        Left = 0
        Top = 0
        Width = 674
        Height = 353
        Align = alTop
        TabOrder = 0
        object Splitter14: TSplitter
          Left = 334
          Top = 1
          Height = 351
          ExplicitLeft = 593
          ExplicitHeight = 306
        end
        object Chart1: TChart
          Left = 337
          Top = 1
          Width = 336
          Height = 351
          Border.Visible = True
          Title.Gradient.EndColor = clGray
          Title.Gradient.MidColor = clWhite
          Title.Gradient.StartColor = clSilver
          Title.Text.Strings = (
            'ratio sub-types ')
          BottomAxis.ExactDateTime = False
          BottomAxis.Increment = 1.000000000000000000
          BottomAxis.Title.Caption = 'time'
          DepthAxis.Automatic = False
          DepthAxis.AutomaticMaximum = False
          DepthAxis.AutomaticMinimum = False
          DepthAxis.Maximum = 0.890000000000000800
          DepthAxis.Minimum = -0.110000000000000100
          DepthTopAxis.Automatic = False
          DepthTopAxis.AutomaticMaximum = False
          DepthTopAxis.AutomaticMinimum = False
          DepthTopAxis.Maximum = 0.890000000000000800
          DepthTopAxis.Minimum = -0.110000000000000100
          LeftAxis.Grid.Visible = False
          LeftAxis.MaximumOffset = 3
          LeftAxis.MinimumOffset = 3
          LeftAxis.Title.Caption = 'build on & free / all'
          RightAxis.MaximumOffset = 3
          RightAxis.MinimumOffset = 3
          RightAxis.Title.Caption = 'ratio build on / free'
          View3D = False
          Zoom.UpLeftZooms = True
          Align = alClient
          Color = clWhite
          TabOrder = 0
          OnDblClick = Chart_ISDblClick
          PrintMargins = (
            15
            32
            15
            32)
          object ser_green_all: TLineSeries
            Marks.Callout.Brush.Color = clBlack
            Marks.Visible = False
            SeriesColor = clGreen
            Title = 'free'
            Brush.Color = clGreen
            LinePen.Color = clGreen
            LinePen.Style = psDash
            LinePen.Width = 2
            Pointer.HorizSize = 2
            Pointer.InflateMargins = True
            Pointer.Style = psDiamond
            Pointer.VertSize = 2
            Pointer.Visible = False
            XValues.Name = 'X'
            XValues.Order = loAscending
            YValues.Name = 'Y'
            YValues.Order = loNone
          end
          object ser_blue_all: TLineSeries
            Marks.Callout.Brush.Color = clBlack
            Marks.Visible = False
            SeriesColor = clBlue
            Title = 'build'
            Brush.Color = clBlue
            LinePen.Color = clBlue
            LinePen.Style = psDashDot
            LinePen.Width = 2
            Pointer.HorizSize = 2
            Pointer.InflateMargins = True
            Pointer.Style = psTriangle
            Pointer.VertSize = 2
            Pointer.Visible = False
            XValues.Name = 'X'
            XValues.Order = loAscending
            YValues.Name = 'Y'
            YValues.Order = loNone
          end
          object ser_blue_green: TLineSeries
            Marks.Callout.Brush.Color = clBlack
            Marks.Visible = False
            Title = 'ratio'
            VertAxis = aRightAxis
            LinePen.Color = clRed
            LinePen.Width = 2
            Pointer.HorizSize = 2
            Pointer.InflateMargins = True
            Pointer.Style = psDiamond
            Pointer.VertSize = 2
            Pointer.Visible = False
            XValues.Name = 'X'
            XValues.Order = loAscending
            YValues.Name = 'Y'
            YValues.Order = loNone
          end
        end
        object Panel6: TPanel
          Left = 1
          Top = 1
          Width = 333
          Height = 351
          Align = alLeft
          TabOrder = 1
          object Splitter15: TSplitter
            Left = 1
            Top = 177
            Width = 331
            Height = 3
            Cursor = crVSplit
            Align = alTop
            ExplicitWidth = 334
          end
          object Chart2: TChart
            Left = 1
            Top = 1
            Width = 331
            Height = 176
            Border.Visible = True
            Title.Gradient.EndColor = clGray
            Title.Gradient.MidColor = clWhite
            Title.Gradient.StartColor = clSilver
            Title.Text.Strings = (
              'ratio to main-types to all cells')
            BottomAxis.ExactDateTime = False
            BottomAxis.Increment = 1.000000000000000000
            BottomAxis.Title.Caption = 'time'
            DepthAxis.Automatic = False
            DepthAxis.AutomaticMaximum = False
            DepthAxis.AutomaticMinimum = False
            DepthAxis.Maximum = 0.890000000000000800
            DepthAxis.Minimum = -0.110000000000000100
            DepthTopAxis.Automatic = False
            DepthTopAxis.AutomaticMaximum = False
            DepthTopAxis.AutomaticMinimum = False
            DepthTopAxis.Maximum = 0.890000000000000800
            DepthTopAxis.Minimum = -0.110000000000000100
            LeftAxis.MaximumOffset = 3
            LeftAxis.MinimumOffset = 3
            LeftAxis.Title.Caption = 'streets / free / buildings'
            RightAxis.Grid.Visible = False
            RightAxis.MaximumOffset = 3
            RightAxis.MinimumOffset = 3
            RightAxis.MinorTicks.Visible = False
            RightAxis.Title.Caption = 'empty'
            View3D = False
            Zoom.UpLeftZooms = True
            Align = alTop
            Color = clWhite
            TabOrder = 0
            PrintMargins = (
              15
              32
              15
              32)
            object ser_white_all: TLineSeries
              Marks.Callout.Brush.Color = clBlack
              Marks.Visible = False
              SeriesColor = clBlack
              Title = 'empty'
              VertAxis = aRightAxis
              LinePen.Style = psDot
              LinePen.Width = 3
              Pointer.HorizSize = 2
              Pointer.InflateMargins = True
              Pointer.Style = psCircle
              Pointer.VertSize = 2
              Pointer.Visible = False
              XValues.Name = 'X'
              XValues.Order = loAscending
              YValues.Name = 'Y'
              YValues.Order = loNone
            end
            object ser_street_all: TLineSeries
              Marks.Callout.Brush.Color = clBlack
              Marks.Visible = False
              SeriesColor = clYellow
              Title = 'streets'
              Brush.Color = clYellow
              LinePen.Color = clYellow
              LinePen.Width = 2
              Pointer.HorizSize = 2
              Pointer.InflateMargins = True
              Pointer.Style = psDiamond
              Pointer.VertSize = 2
              Pointer.Visible = False
              XValues.Name = 'X'
              XValues.Order = loAscending
              YValues.Name = 'Y'
              YValues.Order = loNone
            end
            object ser_dev_all: TLineSeries
              Marks.Callout.Brush.Color = clBlack
              Marks.Visible = False
              SeriesColor = clBlue
              Title = 'dev.'
              Brush.Color = clBlue
              LinePen.Color = clBlue
              LinePen.Style = psDashDot
              LinePen.Width = 2
              Pointer.HorizSize = 2
              Pointer.InflateMargins = True
              Pointer.Style = psDiamond
              Pointer.VertSize = 2
              Pointer.Visible = False
              XValues.Name = 'X'
              XValues.Order = loAscending
              YValues.Name = 'Y'
              YValues.Order = loNone
            end
          end
          object Chart_nNb: TChart
            Left = 1
            Top = 180
            Width = 331
            Height = 170
            Border.Visible = True
            Legend.Visible = False
            Title.Gradient.EndColor = clGray
            Title.Gradient.MidColor = clWhite
            Title.Gradient.StartColor = clSilver
            Title.Text.Strings = (
              ' build on cell neighbours per build on cell')
            BottomAxis.ExactDateTime = False
            BottomAxis.Increment = 1.000000000000000000
            BottomAxis.Title.Caption = 'build on cell-type'
            DepthAxis.Automatic = False
            DepthAxis.AutomaticMaximum = False
            DepthAxis.AutomaticMinimum = False
            DepthAxis.Maximum = 0.890000000000001000
            DepthAxis.Minimum = -0.110000000000000300
            DepthTopAxis.Automatic = False
            DepthTopAxis.AutomaticMaximum = False
            DepthTopAxis.AutomaticMinimum = False
            DepthTopAxis.Maximum = 0.890000000000001000
            DepthTopAxis.Minimum = -0.110000000000000300
            LeftAxis.Title.Caption = 'free von Neuman neighbours'
            RightAxis.Automatic = False
            RightAxis.AutomaticMaximum = False
            RightAxis.AutomaticMinimum = False
            View3D = False
            Zoom.UpLeftZooms = True
            Align = alClient
            Color = clWhite
            TabOrder = 1
            PrintMargins = (
              15
              32
              15
              32)
            object ser_freeNb: TBarSeries
              Depth = 0
              Marks.Callout.Brush.Color = clBlack
              Marks.Visible = True
              SeriesColor = clGreen
              Title = 'ser_freeNb'
              Gradient.Direction = gdTopBottom
              MultiBar = mbNone
              XValues.Name = 'X'
              XValues.Order = loAscending
              YValues.Name = 'Bar'
              YValues.Order = loNone
            end
          end
        end
      end
      object Panel3: TPanel
        Left = 0
        Top = 356
        Width = 674
        Height = 305
        Align = alClient
        TabOrder = 1
        object GroupBox7: TGroupBox
          Left = 488
          Top = 1
          Width = 185
          Height = 303
          Align = alRight
          Caption = 'analyse building rules'
          TabOrder = 0
          object Label33: TLabel
            Left = 71
            Top = 119
            Width = 73
            Height = 13
            Caption = 'rounds per rule'
          end
          object Label34: TLabel
            Left = 71
            Top = 142
            Width = 76
            Height = 13
            Caption = 'steps per round'
          end
          object cb_r8114: TCheckBox
            Left = 16
            Top = 24
            Width = 121
            Height = 17
            Caption = 'activate rule 1: 8114'
            Checked = True
            State = cbChecked
            TabOrder = 0
          end
          object cb_r7013: TCheckBox
            Left = 16
            Top = 40
            Width = 121
            Height = 17
            Caption = 'activate rule 2: 7013'
            Checked = True
            State = cbChecked
            TabOrder = 1
          end
          object cb_r5012: TCheckBox
            Left = 16
            Top = 56
            Width = 121
            Height = 17
            Caption = 'activate rule 3: 5012'
            Checked = True
            State = cbChecked
            TabOrder = 2
          end
          object cb_r3011: TCheckBox
            Left = 16
            Top = 72
            Width = 121
            Height = 17
            Caption = 'activate rule 4: 3011'
            Checked = True
            State = cbChecked
            TabOrder = 3
          end
          object SE_rdsPerVal: TSpinEdit
            Left = 16
            Top = 114
            Width = 49
            Height = 22
            MaxValue = 1000
            MinValue = 1
            TabOrder = 4
            Value = 10
            OnChange = SE_rdsPerValChange
          end
          object B_stopBuildAna: TButton
            Left = 97
            Top = 182
            Width = 70
            Height = 25
            Caption = 'start / stop'
            TabOrder = 5
            OnClick = B_stopBuildAnaClick
          end
          object B_startBuildAna: TButton
            Left = 15
            Top = 182
            Width = 70
            Height = 25
            Caption = 'new start'
            TabOrder = 6
            OnClick = B_startBuildAnaClick
          end
          object SE_stepsPerRd: TSpinEdit
            Left = 16
            Top = 138
            Width = 49
            Height = 22
            Increment = 10
            MaxValue = 1000
            MinValue = 1
            TabOrder = 7
            Value = 500
          end
          object cb_r3010: TCheckBox
            Left = 16
            Top = 89
            Width = 121
            Height = 17
            Caption = 'activate rule 5: 3010'
            Checked = True
            State = cbChecked
            TabOrder = 8
          end
          object Button11: TButton
            Left = 97
            Top = 264
            Width = 70
            Height = 25
            Caption = 'edit'
            TabOrder = 9
            OnClick = Button11Click
          end
        end
        object Chart_buildAna: TChart
          Left = 1
          Top = 1
          Width = 487
          Height = 303
          BackWall.Brush.Color = clWhite
          BackWall.Brush.Style = bsClear
          Border.Visible = True
          Gradient.Balance = 99
          Gradient.Direction = gdFromTopLeft
          Gradient.EndColor = 753908
          Gradient.MidColor = 16059031
          Gradient.StartColor = 14540754
          Title.Text.Strings = (
            'Analyse Building Rules')
          BottomAxis.ExactDateTime = False
          BottomAxis.Title.Caption = 'building rule '
          DepthAxis.Automatic = False
          DepthAxis.AutomaticMaximum = False
          DepthAxis.AutomaticMinimum = False
          DepthAxis.Maximum = 0.500000000000000000
          DepthAxis.Minimum = -0.500000000000000000
          DepthTopAxis.Automatic = False
          DepthTopAxis.AutomaticMaximum = False
          DepthTopAxis.AutomaticMinimum = False
          DepthTopAxis.Maximum = 0.500000000000000000
          DepthTopAxis.Minimum = -0.500000000000000000
          LeftAxis.Title.Caption = 'ratio B/G | >three | >two'
          RightAxis.Grid.Visible = False
          RightAxis.Title.Caption = 'mean length | D rad'
          TopAxis.Automatic = False
          TopAxis.AutomaticMaximum = False
          TopAxis.AutomaticMinimum = False
          TopAxis.Visible = False
          View3D = False
          Zoom.UpLeftZooms = True
          Align = alClient
          Color = clWhite
          TabOrder = 1
          OnDblClick = Chart_buildAnaDblClick
          PrintMargins = (
            15
            26
            15
            26)
          object ser_ratBlueGreen: TPointSeries
            Marks.Callout.Brush.Color = clBlack
            Marks.Visible = False
            Title = 'ratio B/G'
            ClickableLine = False
            Pointer.Brush.Color = clRed
            Pointer.HorizSize = 2
            Pointer.InflateMargins = True
            Pointer.Style = psRectangle
            Pointer.VertSize = 2
            Pointer.Visible = True
            XValues.Name = 'X'
            XValues.Order = loAscending
            YValues.Name = 'Y'
            YValues.Order = loNone
          end
          object ser_greaterThree: TPointSeries
            Marks.Callout.Brush.Color = clBlack
            Marks.Visible = False
            Title = '> three'
            ClickableLine = False
            Pointer.Brush.Color = clLime
            Pointer.HorizSize = 3
            Pointer.InflateMargins = True
            Pointer.Style = psTriangle
            Pointer.VertSize = 2
            Pointer.Visible = True
            XValues.Name = 'X'
            XValues.Order = loAscending
            YValues.Name = 'Y'
            YValues.Order = loNone
          end
          object ser_greaterTwo: TPointSeries
            Marks.Callout.Brush.Color = clBlack
            Marks.Visible = False
            SeriesColor = clBlue
            Title = '> two'
            ClickableLine = False
            Pointer.Brush.Color = clBlue
            Pointer.HorizSize = 3
            Pointer.InflateMargins = True
            Pointer.Style = psDownTriangle
            Pointer.VertSize = 2
            Pointer.Visible = True
            XValues.Name = 'X'
            XValues.Order = loAscending
            YValues.Name = 'Y'
            YValues.Order = loNone
          end
          object ser_bML: TPointSeries
            Marks.Callout.Brush.Color = clBlack
            Marks.Visible = False
            SeriesColor = clFuchsia
            Title = 'ML'
            VertAxis = aRightAxis
            ClickableLine = False
            Pointer.Brush.Color = 16744703
            Pointer.HorizSize = 3
            Pointer.InflateMargins = True
            Pointer.Style = psDiamond
            Pointer.VertSize = 3
            Pointer.Visible = True
            XValues.Name = 'X'
            XValues.Order = loAscending
            YValues.Name = 'Y'
            YValues.Order = loNone
          end
          object ser_D_rad: TPointSeries
            Marks.Callout.Brush.Color = clBlack
            Marks.Visible = False
            SeriesColor = clAqua
            Title = 'D rad'
            VertAxis = aRightAxis
            ClickableLine = False
            Pointer.Brush.Color = 16777088
            Pointer.HorizSize = 2
            Pointer.InflateMargins = True
            Pointer.Style = psLeftTriangle
            Pointer.VertSize = 3
            Pointer.Visible = True
            XValues.Name = 'X'
            XValues.Order = loAscending
            YValues.Name = 'Y'
            YValues.Order = loNone
          end
          object trend_ratBlueGreen: TLineSeries
            Active = False
            ColorEachLine = False
            Marks.Callout.Brush.Color = clBlack
            Marks.Visible = False
            DataSource = ser_ratBlueGreen
            SeriesColor = clRed
            Title = 'trend_ratio B/G'
            Brush.Color = clRed
            LinePen.Color = clRed
            LinePen.Width = 2
            LinePen.SmallDots = True
            Pointer.InflateMargins = True
            Pointer.Style = psRectangle
            Pointer.Visible = False
            XValues.Name = 'X'
            XValues.Order = loAscending
            YValues.Name = 'Y'
            YValues.Order = loNone
            object TrendFunction3: TTrendFunction
            end
          end
          object trend_greaterThree: TLineSeries
            Active = False
            Marks.Callout.Brush.Color = clBlack
            Marks.Visible = False
            DataSource = ser_greaterThree
            SeriesColor = clGreen
            Title = 'trend_> three'
            Brush.Color = clGreen
            LinePen.Color = clGreen
            LinePen.SmallDots = True
            Pointer.InflateMargins = True
            Pointer.Style = psRectangle
            Pointer.Visible = False
            XValues.Name = 'X'
            XValues.Order = loAscending
            YValues.Name = 'Y'
            YValues.Order = loNone
            object TrendFunction4: TTrendFunction
            end
          end
          object trend_greaterTwo: TLineSeries
            Active = False
            Marks.Callout.Brush.Color = clBlack
            Marks.Visible = False
            DataSource = ser_greaterTwo
            Title = 'trend_> Two'
            ValueFormat = '#,##0.#'
            Brush.Color = clBlue
            LinePen.Color = clBlue
            LinePen.Style = psDot
            LinePen.Width = 2
            LinePen.SmallDots = True
            OutLine.Color = clGreen
            Pointer.Brush.Color = clGreen
            Pointer.HorizSize = 2
            Pointer.InflateMargins = True
            Pointer.Style = psRectangle
            Pointer.VertSize = 2
            Pointer.Visible = False
            XValues.Name = 'X'
            XValues.Order = loAscending
            YValues.Name = 'Y'
            YValues.Order = loNone
            object TrendFunction5: TTrendFunction
            end
          end
          object trend_bML: TLineSeries
            Active = False
            ColorEachLine = False
            Marks.Callout.Brush.Color = clBlack
            Marks.Visible = False
            DataSource = ser_bML
            Title = 'trend_ML'
            VertAxis = aRightAxis
            Brush.Color = clFuchsia
            LinePen.Color = clFuchsia
            LinePen.SmallDots = True
            Pointer.InflateMargins = True
            Pointer.Style = psRectangle
            Pointer.Visible = False
            XValues.Name = 'X'
            XValues.Order = loAscending
            YValues.Name = 'Y'
            YValues.Order = loNone
            object TrendFunction6: TTrendFunction
            end
          end
          object trend_D_rad: TLineSeries
            Active = False
            Marks.Callout.Brush.Color = clBlack
            Marks.Visible = False
            DataSource = ser_D_rad
            SeriesColor = clAqua
            VertAxis = aRightAxis
            Brush.Color = clAqua
            LinePen.Color = clAqua
            LinePen.SmallDots = True
            Pointer.InflateMargins = True
            Pointer.Style = psRectangle
            Pointer.Visible = False
            XValues.Name = 'X'
            XValues.Order = loAscending
            YValues.Name = 'Y'
            YValues.Order = loNone
            object TrendFunction7: TTrendFunction
            end
          end
          object avg_ratBlueGreen: TLineSeries
            ColorEachLine = False
            Marks.Callout.Brush.Color = clBlack
            Marks.Callout.Length = 0
            Marks.Visible = False
            DataSource = ser_ratBlueGreen
            SeriesColor = clRed
            Title = 'avg_ratio B/G'
            Brush.Color = clRed
            ClickableLine = False
            LinePen.Color = clRed
            Pointer.Brush.Color = clRed
            Pointer.HorizSize = 2
            Pointer.InflateMargins = True
            Pointer.Style = psRectangle
            Pointer.VertSize = 2
            Pointer.Visible = False
            XValues.Name = 'X'
            XValues.Order = loAscending
            YValues.Name = 'Y'
            YValues.Order = loNone
            object AverageTeeFunction1: TAverageTeeFunction
            end
          end
          object avg_greaterThree: TLineSeries
            Marks.Callout.Brush.Color = clBlack
            Marks.Callout.Length = 0
            Marks.Visible = False
            DataSource = ser_greaterThree
            SeriesColor = clGreen
            Title = 'avg_> three'
            Brush.Color = clGreen
            ClickableLine = False
            LinePen.Color = clGreen
            LinePen.SmallDots = True
            Pointer.Brush.Color = clLime
            Pointer.HorizSize = 3
            Pointer.InflateMargins = True
            Pointer.Style = psTriangle
            Pointer.VertSize = 2
            Pointer.Visible = False
            XValues.Name = 'X'
            XValues.Order = loAscending
            YValues.Name = 'Y'
            YValues.Order = loNone
            object AverageTeeFunction2: TAverageTeeFunction
            end
          end
          object avg_greaterTwo: TLineSeries
            Marks.Callout.Brush.Color = clBlack
            Marks.Callout.Length = 0
            Marks.Visible = False
            DataSource = ser_greaterTwo
            SeriesColor = clBlue
            Title = 'avg_> two'
            Brush.Color = clBlue
            ClickableLine = False
            LinePen.Color = clBlue
            LinePen.Style = psDashDotDot
            Pointer.Brush.Color = clBlue
            Pointer.HorizSize = 3
            Pointer.InflateMargins = True
            Pointer.Style = psDownTriangle
            Pointer.VertSize = 2
            Pointer.Visible = False
            XValues.Name = 'X'
            XValues.Order = loAscending
            YValues.Name = 'Y'
            YValues.Order = loNone
            object TeeFunction9: TAverageTeeFunction
            end
          end
          object avg_bML: TLineSeries
            Marks.Callout.Brush.Color = clBlack
            Marks.Callout.Length = 0
            Marks.Visible = False
            DataSource = ser_bML
            SeriesColor = clFuchsia
            Title = 'avg_ML'
            VertAxis = aRightAxis
            Brush.Color = clFuchsia
            ClickableLine = False
            LinePen.Color = clFuchsia
            LinePen.Style = psDashDot
            Pointer.Brush.Color = 16744703
            Pointer.HorizSize = 3
            Pointer.InflateMargins = True
            Pointer.Style = psDiamond
            Pointer.VertSize = 3
            Pointer.Visible = False
            XValues.Name = 'X'
            XValues.Order = loAscending
            YValues.Name = 'Y'
            YValues.Order = loNone
            object TeeFunction10: TAverageTeeFunction
            end
          end
          object avg_D_rad: TLineSeries
            Marks.Callout.Brush.Color = clBlack
            Marks.Callout.Length = 0
            Marks.Visible = False
            DataSource = ser_D_rad
            SeriesColor = clAqua
            Title = 'avg_D rad'
            VertAxis = aRightAxis
            Brush.Color = clAqua
            ClickableLine = False
            LinePen.Color = clAqua
            LinePen.Style = psDot
            Pointer.Brush.Color = 16777088
            Pointer.HorizSize = 2
            Pointer.InflateMargins = True
            Pointer.Style = psLeftTriangle
            Pointer.VertSize = 3
            Pointer.Visible = False
            XValues.Name = 'X'
            XValues.Order = loAscending
            YValues.Name = 'Y'
            YValues.Order = loNone
            object TeeFunction11: TAverageTeeFunction
            end
          end
          object PageNumTool2: TPageNumTool
            Active = False
            Callout.Brush.Color = clBlack
            Callout.Arrow.Visible = False
            Text = 'Page %d of %d'
            Format = 'Page %d of %d'
          end
        end
      end
    end
  end
  object Timer1: TTimer
    Enabled = False
    Interval = 1
    OnTimer = Timer1Timer
    Left = 576
    Top = 624
  end
  object ChartEditor_IS: TChartEditor
    Chart = Chart_IS
    Left = 448
    Top = 632
  end
  object ChartEditor_fractGrid: TChartEditor
    Chart = Chart_FractGrid
    Left = 480
    Top = 632
  end
  object ChartEditor_fractRad: TChartEditor
    Chart = Chart_fractal
    Left = 512
    Top = 632
  end
  object ChartEditor_rank: TChartEditor
    Left = 560
    Top = 552
  end
  object ChartEditor_resForce: TChartEditor
    Chart = Chart_resForce
    Left = 560
    Top = 512
  end
  object ChartEditor_BuildAna: TChartEditor
    Chart = Chart_buildAna
    Left = 1416
    Top = 640
  end
  object Timer_buildAna: TTimer
    Enabled = False
    Interval = 1
    OnTimer = Timer_buildAnaTimer
    Left = 1448
    Top = 640
  end
end

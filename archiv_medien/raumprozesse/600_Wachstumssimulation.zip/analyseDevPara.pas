unit analyseDevPara;

interface

uses
  Windows, Messages, SysUtils, Variants, Classes, Graphics, Controls, Forms, teestore,
  Dialogs, Buttons, Spin, StdCtrls, TeeEdit, ExtCtrls, TeEngine, TeeTools, jpeg,
  TeePageNumTool, StatChar, CurvFitt, TeeFunci, Series, TeeProcs, Chart, math;

type
  TAnaDev = class(TForm)
    B_undoZ: TButton;
    Chart_devPara: TChart;
    TeeFunction6: TTrendFunction;
    PageNumTool2: TPageNumTool;
    GroupBox3: TGroupBox;
    CB_dataShow: TCheckBox;
    CB_avgShow: TCheckBox;
    CB_trendShow: TCheckBox;
    Button1: TButton;
    GroupBox1: TGroupBox;
    Label4: TLabel;
    Label3: TLabel;
    B_start: TButton;
    Timer4: TTimer;
    ChartEditor_devPara: TChartEditor;
    E0_valFrom: TEdit;
    Label5: TLabel;
    E0_valTo: TEdit;
    Label7: TLabel;
    E_incre: TEdit;
    Label15: TLabel;
    Label1: TLabel;
    E1_valFrom: TEdit;
    Label2: TLabel;
    E1_valTo: TEdit;
    Label6: TLabel;
    E2_valFrom: TEdit;
    Label9: TLabel;
    E2_valTo: TEdit;
    Label10: TLabel;
    E3_valFrom: TEdit;
    Label11: TLabel;
    E3_valTo: TEdit;
    SE_toSteps: TSpinEdit;
    SE_perVal: TSpinEdit;
    CB0_acti: TCheckBox;
    CB1_acti: TCheckBox;
    CB2_acti: TCheckBox;
    CB3_acti: TCheckBox;
    lbl_pSteps: TLabel;
    lbl_timesteps: TLabel;
    Lbl_akt: TLabel;
    Lbl_proceed: TLabel;
    Label8: TLabel;
    B_startStop: TSpeedButton;
    Label12: TLabel;
    Lbl_round: TLabel;
    trend_potConn: TLineSeries;
    trend_potDens: TLineSeries;
    trend_Connect: TLineSeries;
    trend_IS: TLineSeries;
    trend_Rank: TLineSeries;
    trend_FractGrid: TLineSeries;
    avg_FractGrid: TLineSeries;
    avg_Connect: TLineSeries;
    avg_Rank: TLineSeries;
    avg_IS: TLineSeries;
    avg_potDens: TLineSeries;
    avg_potConn: TLineSeries;
    ser_FractGrid: TPointSeries;
    ser_Connect: TPointSeries;
    ser_Rank: TPointSeries;
    ser_IS: TPointSeries;
    ser_potDens: TPointSeries;
    ser_potConn: TPointSeries;
    TeeFunction7: TAverageTeeFunction;
    TeeFunction8: TAverageTeeFunction;
    TeeFunction9: TAverageTeeFunction;
    TeeFunction10: TAverageTeeFunction;
    TeeFunction11: TAverageTeeFunction;
    TeeFunction12: TAverageTeeFunction;
    GroupBox2: TGroupBox;
    Cb_saveSnap: TCheckBox;
    Label13: TLabel;
    E_bName: TEdit;
    Lbl_mainRds: TLabel;
    TeeFunction1: TTrendFunction;
    TeeFunction2: TTrendFunction;
    TeeFunction4: TTrendFunction;
    TeeFunction5: TTrendFunction;
    TeeFunction3: TTrendFunction;
    cb_multiply: TCheckBox;
    CB4_acti: TCheckBox;
    Label14: TLabel;
    E4_valFrom: TEdit;
    Label16: TLabel;
    E4_valTo: TEdit;
    procedure FormClose(Sender: TObject; var Action: TCloseAction);
    procedure FormCreate(Sender: TObject);
    procedure Timer4Timer(Sender: TObject);
    procedure B_startStopClick(Sender: TObject);
    procedure Button1Click(Sender: TObject);
    procedure B_undoZClick(Sender: TObject);
    procedure B_startClick(Sender: TObject);
    procedure CB0_actiClick(Sender: TObject);
    procedure E0_valFromChange(Sender: TObject);
    procedure CB_dataShowClick(Sender: TObject);
    procedure E_bNameChange(Sender: TObject);
  private
    procedure newRound;
    procedure NewStart;
    procedure resetGraphs;
    procedure plotVals;
    procedure updProc;
    procedure updatePlots;
    procedure plotVisible;
    procedure saveAChart;
  public
    Procedure BmpToJpg(const Filename: String; Quality: TJPEGQualityRange=100);
    procedure saveBmp(zielF: TForm; id: String);
  end;

var
  AnaDev  : TAnaDev;
  rounds  : Cardinal;
  mainRds : Cardinal;
  globRds : Cardinal;
  pSteps  : Cardinal;
  curVal  : Array [0..4] of Single;
  valTo   : Array [0..4] of Single;
  valFrom : Array [0..4] of Single;
  valActi : Array [0..4] of Boolean;
  saveName : String;

implementation

{$R *.dfm}

uses Main, ConnTable, dijkstra;

//==============================================================================
procedure TAnaDev.FormClose(Sender: TObject; var Action: TCloseAction);
begin
  Timer4.enabled := false;
  Action := caFree;
end;

//==============================================================================
procedure TAnaDev.FormCreate(Sender: TObject);
begin
  Timer4.enabled := false;
  Form1.Timer1.enabled := false;
  saveName := E_bName.Text;
  //NewStart;
end;

//==============================================================================
procedure TAnaDev.B_startClick(Sender: TObject);
begin
   NewStart;
   Timer4.enabled := B_startStop.Down;
   saveName := E_bName.Text;
end;

//==============================================================================
procedure TAnaDev.NewStart;
begin
   Form1.Timer1.enabled := false;
   resetGraphs;
   pSteps  := 0;
   rounds  := 1;
   mainRds := 1;
   globRds := 1;
   lbl_pSteps.Caption := '0';
   Lbl_mainRds.Caption := '1 / ';
   curVal[0]  := roundTo(StrToFloat(E0_valFrom.Text),-4);
   curVal[1]  := roundTo(StrToFloat(E1_valFrom.Text),-4);
   curVal[2]  := roundTo(StrToFloat(E2_valFrom.Text),-4);
   curVal[3]  := roundTo(StrToFloat(E3_valFrom.Text),-4);
   curVal[4]  := roundTo(StrToFloat(E4_valFrom.Text),-4);
   valFrom[0] := StrToFloat(E0_valFrom.Text);
   valFrom[1] := StrToFloat(E1_valFrom.Text);
   valFrom[2] := StrToFloat(E2_valFrom.Text);
   valFrom[3] := StrToFloat(E3_valFrom.Text);
   valFrom[4] := StrToFloat(E4_valFrom.Text);
   updProc;
   newRound;
   Form1.deleteAll;
   Form1.Setup;
end;

//==============================================================================
procedure TAnaDev.resetGraphs;
begin
  with Chart_devPara do
  begin
    Title.Text.Clear;                                                         // -- Title of the Chart
    Title.Text.Add('Analyse Development Parameters');
    ser_FractGrid.Clear;
    ser_Connect.Clear;
    ser_Rank.Clear;
    ser_IS.Clear;
    ser_potDens.Clear;
    ser_potConn.Clear;
    trend_potConn.Clear;
    trend_potDens.Clear;
    trend_Connect.Clear;
    trend_IS.Clear;
    trend_Rank.Clear;
    trend_FractGrid.Clear;
    avg_FractGrid.Clear;
    avg_Connect.Clear;
    avg_Rank.Clear;
    avg_IS.Clear;
    avg_potDens.Clear;
    avg_potConn.Clear;

    avg_FractGrid.FunctionType.Period  := SE_toSteps.Value;
    avg_Connect.FunctionType.Period    := SE_toSteps.Value;
    avg_Rank.FunctionType.Period       := SE_toSteps.Value;
    avg_IS.FunctionType.Period         := SE_toSteps.Value;
    avg_potDens.FunctionType.Period    := SE_toSteps.Value;
    avg_potConn.FunctionType.Period    := SE_toSteps.Value;
  end;
end;

//==============================================================================
procedure TAnaDev.newRound;
begin
  Form1.DeleteAll;
  Form1.Setup;
  pSteps := 1;
  If valActi[0]=true Then Form1.E_centriFu.Text := FloatToStr(roundTo(curVal[0], -4));
  If valActi[1]=true Then Form1.E_centriPe.Text := FloatToStr(roundTo(curVal[1], -4));
  If valActi[2]=true Then Form1.E_fuScale.Text  := FloatToStr(roundTo(curVal[2], -4));
  If valActi[3]=true Then Form1.E_peScale.Text  := FloatToStr(roundTo(curVal[3], -4));
  If valActi[4]=true Then Form1.E_rndScale.Text := FloatToStr(roundTo(curVal[4], -4));
end;

//==============================================================================
procedure TAnaDev.Timer4Timer(Sender: TObject);
var
   I : SmallInt;
begin
   If pSteps > SE_toSteps.Value Then                                         // timesteps per value
   begin
      plotVals;
      Lbl_akt.Caption   := IntToStr(globRds);
      Lbl_round.Caption := IntToStr(rounds);
      inc(rounds);
      inc(globRds);
      If rounds > SE_perVal.Value Then                                       // calculations per value
      begin
         If Cb_saveSnap.Checked Then saveBmp(Form1, 'main');                 // make a snapshot of the main form
         inc(mainRds);
         Lbl_mainRds.Caption := IntToStr(mainRds) + ' ; ';
         updatePlots;
         rounds := 1;
         Lbl_round.Caption := IntToStr(rounds);
         For I := 0 To 4 Do
         begin
            If valActi[I] = true Then
            begin
               If cb_multiply.checked Then
               begin                                                         // increase the current value
                  curVal[I] := roundTo(curVal[I] * StrToFloat(E_incre.Text), -4);
               end else begin
                  curVal[I] := roundTo(curVal[I] + StrToFloat(E_incre.Text), -4);
               end;
               If curVal[I] > valTo[I] Then                                  // iterate the range from start value to end value
               begin
                  Timer4.enabled := false;
                  If Cb_saveSnap.Checked Then saveBmp(self, 'measure');
                  saveAChart;
                  exit;
               end;
            end;
         end;
      end;
      newRound;
   end;
   Form1.Execute_Step;
   lbl_pSteps.Caption := IntToStr (pSteps);
   inc(pSteps);
end;

//==============================================================================
procedure TAnaDev.plotVals;
var
   I : Integer;
   r2PotDense : Single;
   r2ConnPot  : Single;
begin
   CalculatePathes;
   ConnectivityTable.ListKonnVals;
   Form1.EdgesPerNode;
   If runMode > 1 Then Form1.measureDensity;
   Form1.fractalRad;
   Form1.fractalGrid;
   r2PotDense := Power(Form1.ser_PotDenseCorr.YValues[1], 2);
   r2ConnPot  := Power(Form1.ser_ConnPotCorr.YValues[1], 2);
   For I := 0 To 4 Do
   begin
      If valActi[I] = true Then
      begin
         ser_FractGrid.AddXY(curVal[I], StrToFloat(Form1.ValueListEditor1.Values['slope_grid'])); //D_grid
         ser_Connect.AddXY  (curVal[I], StrToFloat(ConnectivityTable.StringGrid1.Cells[NodeList.Count+2, NodeList.Count+1]));
         ser_Rank.AddXY     (curVal[I], StrToFloat(Form1.ValueListEditor1.Values['slope_rank'])* -1);
         ser_IS.AddXY       (curVal[I], StrToFloat(Form1.ValueListEditor1.Values['IS_developed_cells']));
         ser_potDens.AddXY  (curVal[I], r2PotDense);
         ser_potConn.AddXY  (curVal[I], r2ConnPot);
         Break;
      end;
   end;
   trend_potConn.CheckDataSource;
   trend_potDens.CheckDataSource;
   trend_Connect.CheckDataSource;
   trend_IS.CheckDataSource;
   trend_Rank.CheckDataSource;
   trend_FractGrid.CheckDataSource;
end;

//==============================================================================
procedure TAnaDev.updatePlots;
begin
   avg_FractGrid.FunctionType.Period := SE_perVal.Value;
   avg_Connect.FunctionType.Period   := SE_perVal.Value;
   avg_Rank.FunctionType.Period      := SE_perVal.Value;
   avg_IS.FunctionType.Period        := SE_perVal.Value;
   avg_potDens.FunctionType.Period   := SE_perVal.Value;
   avg_potConn.FunctionType.Period   := SE_perVal.Value;
   avg_FractGrid.CheckDataSource;
   avg_Connect.CheckDataSource;
   avg_Rank.CheckDataSource;
   avg_IS.CheckDataSource;
   avg_potDens.CheckDataSource;
   avg_potConn.CheckDataSource;
end;

//==============================================================================
procedure TAnaDev.updProc;
var
   I : SmallInt;
   minSteps : Integer;
   tmpSteps : Integer;
begin
   Lbl_akt.Caption := IntToStr(rounds);
   Lbl_round.Caption := IntToStr(globRds);
   valTo[0]   := StrToFloat(E0_valTo.Text);
   valTo[1]   := StrToFloat(E1_valTo.Text);
   valTo[2]   := StrToFloat(E2_valTo.Text);
   valTo[3]   := StrToFloat(E3_valTo.Text);
   valTo[4]   := StrToFloat(E4_valTo.Text);
   valActi[0] := CB0_acti.Checked;
   valActi[1] := CB1_acti.Checked;
   valActi[2] := CB2_acti.Checked;
   valActi[3] := CB3_acti.Checked;
   valActi[4] := CB4_acti.Checked;
   If Form1.RB_netOnly.Checked   Then runMode := 1;
   If Form1.RB_boom.Checked      Then runMode := 2;
   If Form1.RB_interlink.Checked Then runMode := 3;
   If Form1.RB_cluster.Checked   Then runMode := 4;
   Lbl_round.Caption := IntToStr(rounds);
   minSteps := 999999999;
   For I:=0 To 4 Do
   begin
      If valActi[I] = true Then
      begin
         tmpSteps := round((((valTo[I] - valFrom[I]) +1)/StrToFloat(E_incre.Text))*SE_perVal.Value);
         If tmpSteps < minSteps Then minSteps := tmpSteps;
      end;
   end;
   If minSteps < 999999999 Then
   begin
      Lbl_proceed.Caption := '/ ' + IntToStr(minSteps);
   end else begin
      Lbl_proceed.Caption := '/ 0';
   end;
end;

//==============================================================================
procedure TAnaDev.plotVisible;
begin
   ser_FractGrid.Visible   := CB_dataShow.Checked;
   ser_Connect.Visible     := CB_dataShow.Checked;
   ser_Rank.Visible        := CB_dataShow.Checked;
   ser_IS.Visible          := CB_dataShow.Checked;
   ser_potDens.Visible     := CB_dataShow.Checked;
   ser_potConn.Visible     := CB_dataShow.Checked;
   avg_FractGrid.Visible   := CB_avgShow.Checked;
   avg_Connect.Visible     := CB_avgShow.Checked;
   avg_Rank.Visible        := CB_avgShow.Checked;
   avg_IS.Visible          := CB_avgShow.Checked;
   avg_potDens.Visible     := CB_avgShow.Checked;
   avg_potConn.Visible     := CB_avgShow.Checked;
   trend_potConn.Visible   := CB_trendShow.Checked;
   trend_potDens.Visible   := CB_trendShow.Checked;
   trend_Connect.Visible   := CB_trendShow.Checked;
   trend_IS.Visible        := CB_trendShow.Checked;
   trend_Rank.Visible      := CB_trendShow.Checked;
   trend_FractGrid.Visible := CB_trendShow.Checked;
end;

//==============================================================================
//==============================================================save form as jgp
procedure TAnaDev.saveBmp(zielF: TForm; id: String);
var
   path    : String;
   Filename: String;
   Img     : TBitmap;
begin
   path := ExtractFilePath(Application.ExeName);
   Img  := TBitMap.Create;
   Img  := zielF.GetFormImage;                                                // save main window
   Filename := path+'pictures\' + saveName + '_'+id+'_'+IntToStr(mainRds)+'_'+IntToStr(pSteps-1);
   Img.SaveToFile(Filename+'.bmp');
   BmpToJpg(Filename, 100);
   Img.Free;
end;
//==============================================================================
Procedure TAnaDev.BmpToJpg(const Filename: String; Quality: TJPEGQualityRange=100);
var
  Bmp: TBitmap;
  Jpg: TJpegImage;
begin
  Bmp:=TBitmap.Create;
  Jpg:=TJpegImage.Create;
  try
    Bmp.LoadFromFile(Filename+'.bmp');
    Jpg.CompressionQuality:=Quality;
    Jpg.Assign(Bmp);
    Jpg.SaveToFile(ChangeFileExt(Filename, '.jpg' ));
  finally
    Jpg.Free;
    Bmp.Free;
  end;
  if FileExists(FileName+'.bmp')then deletefile(FileName+'.bmp');             // bitmap l�schen
end;

//==============================================================================
procedure TAnaDev.saveAChart;
var
   path    : String;
   Filename: String;
begin
   Chart_devPara.UndoZoom;
   path := ExtractFilePath(Application.ExeName);
   Filename := path+'data\' + saveName +'_'+IntToStr(mainRds);
   SaveChartToFile(Chart_devPara, Filename, true);
end;

//==============================================================================
procedure TAnaDev.B_undoZClick(Sender: TObject);
begin
  Chart_devPara.UndoZoom;
end;
//==============================================================================

procedure TAnaDev.CB0_actiClick(Sender: TObject);
begin
   updProc;
end;

procedure TAnaDev.CB_dataShowClick(Sender: TObject);
begin
   plotVisible;
end;

procedure TAnaDev.E0_valFromChange(Sender: TObject);
begin
   updProc;
end;

procedure TAnaDev.E_bNameChange(Sender: TObject);
begin
   saveName := E_bName.Text;
end;

procedure TAnaDev.Button1Click(Sender: TObject);
begin
   ChartEditor_devPara.Execute;
end;

procedure TAnaDev.B_startStopClick(Sender: TObject);
begin
  Timer4.enabled := B_startStop.Down; //  not(Timer4.enabled);
end;


end.

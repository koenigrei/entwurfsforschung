object ana_clusterGrow: Tana_clusterGrow
  Left = 0
  Top = 0
  Width = 1005
  Height = 435
  AutoScroll = True
  Caption = 'analyse cluster growth'
  Color = clBtnFace
  Constraints.MaxHeight = 435
  Constraints.MaxWidth = 1005
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -11
  Font.Name = 'Tahoma'
  Font.Style = []
  FormStyle = fsMDIChild
  OldCreateOrder = False
  Visible = True
  OnClose = FormClose
  PixelsPerInch = 96
  TextHeight = 13
  object lbl_pSteps: TLabel
    Left = 862
    Top = 199
    Width = 49
    Height = 13
    Alignment = taRightJustify
    Caption = 'lbl_pSteps'
  end
  object lbl_timesteps: TLabel
    Left = 917
    Top = 199
    Width = 53
    Height = 13
    Caption = ': timesteps'
  end
  object Label8: TLabel
    Left = 917
    Top = 218
    Width = 62
    Height = 13
    Caption = ': calculations'
  end
  object Lbl_proceed: TLabel
    Left = 892
    Top = 218
    Width = 19
    Height = 13
    Alignment = taRightJustify
    Caption = 'sum'
  end
  object Lbl_akt: TLabel
    Left = 854
    Top = 218
    Width = 19
    Height = 13
    Alignment = taRightJustify
    Caption = 'sum'
  end
  object B_undoZ: TButton
    Left = 800
    Top = 366
    Width = 75
    Height = 25
    Caption = 'undoZoom'
    TabOrder = 0
    OnClick = B_undoZClick
  end
  object Chart_growCluster: TChart
    Left = 8
    Top = 14
    Width = 786
    Height = 377
    BackWall.Brush.Color = clWhite
    BackWall.Brush.Style = bsClear
    Border.Visible = True
    Gradient.Balance = 99
    Gradient.Direction = gdFromTopLeft
    Gradient.EndColor = 753908
    Gradient.MidColor = 16059031
    Gradient.StartColor = 14540754
    Title.Text.Strings = (
      'growing cluster')
    BottomAxis.ExactDateTime = False
    BottomAxis.Increment = 1.000000000000000000
    BottomAxis.Title.Caption = 'cluster size '
    DepthAxis.Automatic = False
    DepthAxis.AutomaticMaximum = False
    DepthAxis.AutomaticMinimum = False
    DepthAxis.Maximum = 0.500000000000000000
    DepthAxis.Minimum = -0.500000000000000000
    DepthTopAxis.Automatic = False
    DepthTopAxis.AutomaticMaximum = False
    DepthTopAxis.AutomaticMinimum = False
    DepthTopAxis.Maximum = 0.500000000000000000
    DepthTopAxis.Minimum = -0.500000000000000000
    LeftAxis.Title.Caption = 'mean length (ml)'
    RightAxis.Grid.Visible = False
    RightAxis.Title.Caption = 'edges & borders'
    TopAxis.Automatic = False
    TopAxis.AutomaticMaximum = False
    TopAxis.AutomaticMinimum = False
    TopAxis.Visible = False
    View3D = False
    Zoom.UpLeftZooms = True
    Color = clWhite
    TabOrder = 1
    PrintMargins = (
      15
      26
      15
      26)
    object Series_Edges: TPointSeries
      Marks.Callout.Brush.Color = clBlack
      Marks.Visible = False
      Title = 'edges'
      VertAxis = aRightAxis
      ClickableLine = False
      Pointer.Brush.Color = clAqua
      Pointer.HorizSize = 2
      Pointer.InflateMargins = True
      Pointer.Style = psRectangle
      Pointer.VertSize = 2
      Pointer.Visible = True
      XValues.Name = 'X'
      XValues.Order = loAscending
      YValues.Name = 'Y'
      YValues.Order = loNone
    end
    object Series_Border: TPointSeries
      Marks.Callout.Brush.Color = clBlack
      Marks.Visible = False
      Title = 'border'
      VertAxis = aRightAxis
      ClickableLine = False
      Pointer.Brush.Color = clLime
      Pointer.HorizSize = 3
      Pointer.InflateMargins = True
      Pointer.Style = psTriangle
      Pointer.VertSize = 2
      Pointer.Visible = True
      XValues.Name = 'X'
      XValues.Order = loAscending
      YValues.Name = 'Y'
      YValues.Order = loNone
    end
    object Series_ML: TPointSeries
      Marks.Callout.Brush.Color = clBlack
      Marks.Visible = False
      Title = 'ML'
      ClickableLine = False
      Pointer.Brush.Color = clRed
      Pointer.HorizSize = 3
      Pointer.InflateMargins = True
      Pointer.Style = psCircle
      Pointer.VertSize = 3
      Pointer.Visible = True
      XValues.Name = 'X'
      XValues.Order = loAscending
      YValues.Name = 'Y'
      YValues.Order = loNone
    end
    object Series_ML_Avg: TLineSeries
      Marks.Callout.Brush.Color = clBlack
      Marks.Visible = False
      DataSource = Series_ML
      Title = 'avg ML'
      ValueFormat = '#,##0.#'
      Brush.Color = clGreen
      LinePen.Color = clGreen
      LinePen.Width = 2
      OutLine.Color = clGreen
      Pointer.Brush.Color = clGreen
      Pointer.HorizSize = 2
      Pointer.InflateMargins = True
      Pointer.Style = psRectangle
      Pointer.VertSize = 2
      Pointer.Visible = True
      XValues.Name = 'X'
      XValues.Order = loAscending
      YValues.Name = 'Y'
      YValues.Order = loNone
      object TeeFunction2: TAverageTeeFunction
      end
    end
    object Series_ML_Trend: TLineSeries
      Marks.Callout.Brush.Color = clBlack
      Marks.Visible = False
      DataSource = Series_ML
      SeriesColor = 33023
      Title = 'trend'
      LinePen.Color = 33023
      LinePen.Width = 2
      Pointer.InflateMargins = True
      Pointer.Style = psRectangle
      Pointer.Visible = False
      XValues.Name = 'X'
      XValues.Order = loAscending
      YValues.Name = 'Y'
      YValues.Order = loNone
      object TeeFunction6: TTrendFunction
      end
    end
    object Series_mean: TLineSeries
      Active = False
      Marks.Callout.Brush.Color = clBlack
      Marks.Visible = True
      DataSource = Series_ML
      VertAxis = aRightAxis
      Pointer.InflateMargins = True
      Pointer.Style = psRectangle
      Pointer.Visible = False
      XValues.Name = 'X'
      XValues.Order = loAscending
      YValues.Name = 'Y'
      YValues.Order = loNone
      object TeeFunction5: TAverageTeeFunction
      end
    end
    object Series_Correlation: TLineSeries
      Active = False
      Marks.Callout.Brush.Color = clBlack
      Marks.Visible = True
      DataSource = Series_ML
      VertAxis = aRightAxis
      LinePen.Color = clBlue
      LinePen.SmallDots = True
      Pointer.InflateMargins = True
      Pointer.Style = psRectangle
      Pointer.Visible = False
      XValues.Name = 'X'
      XValues.Order = loAscending
      YValues.Name = 'Y'
      YValues.Order = loNone
      object TeeFunction4: TCorrelationFunction
      end
    end
    object Series_StDv: TLineSeries
      Active = False
      Marks.Callout.Brush.Color = clBlack
      Marks.Visible = True
      DataSource = Series_ML
      VertAxis = aRightAxis
      LinePen.Color = clYellow
      LinePen.SmallDots = True
      Pointer.InflateMargins = True
      Pointer.Style = psRectangle
      Pointer.Visible = False
      XValues.Name = 'X'
      XValues.Order = loAscending
      YValues.Name = 'Y'
      YValues.Order = loNone
      object TeeFunction1: TStdDeviationFunction
      end
    end
    object PageNumTool2: TPageNumTool
      Active = False
      Callout.Brush.Color = clBlack
      Callout.Arrow.Visible = False
      Text = 'Page %d of %d'
      Format = 'Page %d of %d'
    end
  end
  object GroupBox3: TGroupBox
    Left = 800
    Top = 237
    Width = 192
    Height = 100
    Caption = 'chart'
    TabOrder = 2
    object CB_data_Seg: TCheckBox
      Left = 10
      Top = 24
      Width = 97
      Height = 17
      Caption = 'show data'
      Checked = True
      State = cbChecked
      TabOrder = 0
      OnClick = CB_data_SegClick
    end
    object CB_avg_Seg: TCheckBox
      Left = 10
      Top = 47
      Width = 97
      Height = 17
      Caption = 'show average'
      Checked = True
      State = cbChecked
      TabOrder = 1
      OnClick = CB_avg_SegClick
    end
    object CB_trend_Seg: TCheckBox
      Left = 10
      Top = 70
      Width = 97
      Height = 17
      Caption = 'show trend'
      TabOrder = 2
      OnClick = CB_trend_SegClick
    end
    object Button1: TButton
      Left = 136
      Top = 16
      Width = 43
      Height = 25
      Caption = 'edit'
      TabOrder = 3
      OnClick = Button1Click
    end
  end
  object GroupBox1: TGroupBox
    Left = 800
    Top = 8
    Width = 192
    Height = 185
    Caption = 'settings'
    TabOrder = 3
    object Label4: TLabel
      Left = 52
      Top = 110
      Width = 59
      Height = 13
      Caption = 'calculations:'
    end
    object Label3: TLabel
      Left = 60
      Top = 83
      Width = 51
      Height = 13
      Caption = 'grow until:'
    end
    object Label6: TLabel
      Left = 11
      Top = 20
      Width = 90
      Height = 13
      Caption = 'growing cluster:'
      Font.Charset = DEFAULT_CHARSET
      Font.Color = clWindowText
      Font.Height = -11
      Font.Name = 'Tahoma'
      Font.Style = [fsBold]
      ParentFont = False
    end
    object Label1: TLabel
      Left = 37
      Top = 49
      Width = 74
      Height = 13
      Caption = 'measure steps:'
    end
    object E_toSteps: TEdit
      Left = 117
      Top = 79
      Width = 44
      Height = 21
      TabOrder = 0
      Text = '1000'
      OnChange = E_calcValsChange
    end
    object E_calcVals: TEdit
      Left = 117
      Top = 106
      Width = 32
      Height = 21
      TabOrder = 1
      Text = '10'
      OnChange = E_calcValsChange
    end
    object B_start: TButton
      Left = 11
      Top = 143
      Width = 75
      Height = 25
      Caption = 'new start'
      TabOrder = 2
      OnClick = B_startClick
    end
    object B_break: TButton
      Left = 92
      Top = 143
      Width = 75
      Height = 25
      Caption = 'start / stop'
      TabOrder = 3
      OnClick = B_breakClick
    end
    object E_measureSt: TEdit
      Left = 117
      Top = 45
      Width = 32
      Height = 21
      TabOrder = 4
      Text = '10'
      OnChange = E_calcValsChange
    end
    object UpD_measureSt: TUpDown
      Left = 149
      Top = 45
      Width = 16
      Height = 21
      Associate = E_measureSt
      Min = 1
      Max = 10000
      Position = 10
      TabOrder = 5
    end
    object UpD_toSteps: TUpDown
      Left = 161
      Top = 79
      Width = 16
      Height = 21
      Associate = E_toSteps
      Min = 2
      Max = 32000
      Increment = 10
      Position = 1000
      TabOrder = 6
    end
    object UpD_calcVals: TUpDown
      Left = 149
      Top = 106
      Width = 16
      Height = 21
      Associate = E_calcVals
      Min = 1
      Max = 30000
      Position = 10
      TabOrder = 7
    end
  end
  object Timer3: TTimer
    Enabled = False
    Interval = 1
    OnTimer = Timer3Timer
    Left = 936
    Top = 370
  end
  object ChartEditor1: TChartEditor
    Chart = Chart_growCluster
    Left = 904
    Top = 368
  end
end

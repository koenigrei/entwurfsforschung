object Form2: TForm2
  Left = 0
  Top = 0
  Caption = 'Advanced Analysis'
  ClientHeight = 432
  ClientWidth = 1000
  Color = clBtnFace
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -11
  Font.Name = 'Tahoma'
  Font.Style = []
  OldCreateOrder = False
  OnCreate = FormCreate
  PixelsPerInch = 96
  TextHeight = 13
  object lbl_pSteps: TLabel
    Left = 860
    Top = 231
    Width = 49
    Height = 13
    Alignment = taRightJustify
    Caption = 'lbl_pSteps'
  end
  object lbl_timesteps: TLabel
    Left = 915
    Top = 231
    Width = 53
    Height = 13
    Caption = ': timesteps'
  end
  object Label8: TLabel
    Left = 915
    Top = 250
    Width = 62
    Height = 13
    Caption = ': calculations'
  end
  object Lbl_proceed: TLabel
    Left = 890
    Top = 250
    Width = 19
    Height = 13
    Alignment = taRightJustify
    Caption = 'sum'
  end
  object Lbl_akt: TLabel
    Left = 852
    Top = 250
    Width = 19
    Height = 13
    Alignment = taRightJustify
    Caption = 'sum'
  end
  object B_undoZ: TButton
    Left = 719
    Top = 397
    Width = 75
    Height = 25
    Caption = 'undoZoom'
    TabOrder = 0
    OnClick = B_undoZClick
  end
  object Chart_IS: TChart
    Left = 8
    Top = 14
    Width = 786
    Height = 377
    BackWall.Brush.Color = clWhite
    BackWall.Brush.Style = bsClear
    Border.Visible = True
    Gradient.Balance = 99
    Gradient.Direction = gdFromTopLeft
    Gradient.EndColor = 753908
    Gradient.MidColor = 16059031
    Gradient.StartColor = 14540754
    Legend.Visible = False
    Title.Text.Strings = (
      'TChart')
    BottomAxis.ExactDateTime = False
    BottomAxis.Increment = 1.000000000000000000
    BottomAxis.Title.Caption = 'values'
    DepthAxis.Automatic = False
    DepthAxis.AutomaticMaximum = False
    DepthAxis.AutomaticMinimum = False
    DepthAxis.Maximum = 0.500000000000000000
    DepthAxis.Minimum = -0.500000000000000000
    DepthTopAxis.Automatic = False
    DepthTopAxis.AutomaticMaximum = False
    DepthTopAxis.AutomaticMinimum = False
    DepthTopAxis.Maximum = 0.500000000000000000
    DepthTopAxis.Minimum = -0.500000000000000000
    LeftAxis.Title.Caption = 'segregation index (IS)'
    RightAxis.Grid.Visible = False
    TopAxis.Automatic = False
    TopAxis.AutomaticMaximum = False
    TopAxis.AutomaticMinimum = False
    TopAxis.Visible = False
    View3D = False
    Zoom.UpLeftZooms = True
    Color = clWhite
    TabOrder = 1
    PrintMargins = (
      15
      26
      15
      26)
    object Series_IS: TPointSeries
      Marks.Callout.Brush.Color = clBlack
      Marks.Visible = False
      ClickableLine = False
      Pointer.HorizSize = 3
      Pointer.InflateMargins = True
      Pointer.Style = psCircle
      Pointer.VertSize = 3
      Pointer.Visible = True
      XValues.Name = 'X'
      XValues.Order = loAscending
      YValues.Name = 'Y'
      YValues.Order = loNone
    end
    object Series_IS_Avg: TLineSeries
      Marks.Callout.Brush.Color = clBlack
      Marks.Visible = False
      DataSource = Series_IS
      Title = 'Series_IS_Avg'
      ValueFormat = '#,##0.#'
      LinePen.Color = clGreen
      LinePen.Width = 2
      Pointer.HorizSize = 2
      Pointer.InflateMargins = True
      Pointer.Style = psRectangle
      Pointer.VertSize = 2
      Pointer.Visible = True
      XValues.Name = 'X'
      XValues.Order = loAscending
      YValues.Name = 'Y'
      YValues.Order = loNone
      object TeeFunction2: TAverageTeeFunction
      end
    end
    object Series_IS_Fit: TLineSeries
      Marks.Callout.Brush.Color = clBlack
      Marks.Visible = False
      DataSource = Series_IS
      SeriesColor = 16744448
      LinePen.Color = 16744448
      LinePen.Width = 2
      Pointer.InflateMargins = True
      Pointer.Style = psRectangle
      Pointer.Visible = False
      XValues.Name = 'X'
      XValues.Order = loAscending
      YValues.Name = 'Y'
      YValues.Order = loNone
      object TeeFunction3: TCurveFittingFunction
        Period = 1.000000000000000000
      end
    end
    object Series_IS_Trend: TLineSeries
      Marks.Callout.Brush.Color = clBlack
      Marks.Visible = False
      DataSource = Series_IS
      SeriesColor = 33023
      LinePen.Color = 33023
      LinePen.Width = 2
      Pointer.InflateMargins = True
      Pointer.Style = psRectangle
      Pointer.Visible = False
      XValues.Name = 'X'
      XValues.Order = loAscending
      YValues.Name = 'Y'
      YValues.Order = loNone
      object TeeFunction6: TTrendFunction
      end
    end
    object Series_StDv: TLineSeries
      Marks.Callout.Brush.Color = clBlack
      Marks.Visible = True
      DataSource = Series_IS
      VertAxis = aRightAxis
      LinePen.Color = clYellow
      LinePen.SmallDots = True
      Pointer.InflateMargins = True
      Pointer.Style = psRectangle
      Pointer.Visible = False
      XValues.Name = 'X'
      XValues.Order = loAscending
      YValues.Name = 'Y'
      YValues.Order = loNone
      object TeeFunction1: TStdDeviationFunction
      end
    end
    object Series_Correlation: TLineSeries
      Marks.Callout.Brush.Color = clBlack
      Marks.Visible = True
      DataSource = Series_IS
      VertAxis = aRightAxis
      LinePen.Color = clBlue
      LinePen.SmallDots = True
      Pointer.InflateMargins = True
      Pointer.Style = psRectangle
      Pointer.Visible = False
      XValues.Name = 'X'
      XValues.Order = loAscending
      YValues.Name = 'Y'
      YValues.Order = loNone
      object TeeFunction4: TCorrelationFunction
      end
    end
    object Series_mean: TLineSeries
      Marks.Callout.Brush.Color = clBlack
      Marks.Visible = True
      DataSource = Series_IS
      VertAxis = aRightAxis
      Pointer.InflateMargins = True
      Pointer.Style = psRectangle
      Pointer.Visible = False
      XValues.Name = 'X'
      XValues.Order = loAscending
      YValues.Name = 'Y'
      YValues.Order = loNone
      object TeeFunction5: TAverageTeeFunction
      end
    end
    object PageNumTool2: TPageNumTool
      Active = False
      Callout.Brush.Color = clBlack
      Callout.Arrow.Visible = False
      Text = 'Page %d of %d'
      Format = 'Page %d of %d'
    end
  end
  object GroupBox3: TGroupBox
    Left = 800
    Top = 269
    Width = 192
    Height = 153
    Caption = 'segregation chart'
    TabOrder = 2
    object Label7: TLabel
      Left = 31
      Top = 121
      Width = 61
      Height = 13
      Caption = 'poly degree:'
    end
    object CB_data_Seg: TCheckBox
      Left = 10
      Top = 24
      Width = 97
      Height = 17
      Caption = 'show data'
      Checked = True
      State = cbChecked
      TabOrder = 0
      OnClick = CB_data_SegClick
    end
    object CB_avg_Seg: TCheckBox
      Left = 10
      Top = 47
      Width = 97
      Height = 17
      Caption = 'show average'
      Checked = True
      State = cbChecked
      TabOrder = 1
      OnClick = CB_avg_SegClick
    end
    object CB_trend_Seg: TCheckBox
      Left = 10
      Top = 70
      Width = 97
      Height = 17
      Caption = 'show trend'
      TabOrder = 2
      OnClick = CB_trend_SegClick
    end
    object CB_cFit_Seg: TCheckBox
      Left = 10
      Top = 93
      Width = 107
      Height = 17
      Caption = 'show curve fitting'
      TabOrder = 3
      OnClick = CB_cFit_SegClick
    end
    object UpD_polyDegSeg: TUpDown
      Left = 123
      Top = 116
      Width = 16
      Height = 21
      Associate = E_polyDegSeg
      Min = 2
      Max = 20
      Position = 3
      TabOrder = 4
      OnClick = UpD_polyDegSegClick
    end
    object E_polyDegSeg: TEdit
      Left = 98
      Top = 116
      Width = 25
      Height = 21
      TabOrder = 5
      Text = '3'
    end
    object Button1: TButton
      Left = 136
      Top = 16
      Width = 43
      Height = 25
      Caption = 'edit'
      TabOrder = 6
      OnClick = Button1Click
    end
  end
  object GroupBox1: TGroupBox
    Left = 800
    Top = 8
    Width = 192
    Height = 209
    Caption = 'settings'
    TabOrder = 3
    object Label1: TLabel
      Left = 11
      Top = 48
      Width = 60
      Height = 13
      Caption = 'values from:'
    end
    object Label2: TLabel
      Left = 115
      Top = 48
      Width = 14
      Height = 13
      Caption = 'to:'
    end
    object Label4: TLabel
      Left = 20
      Top = 136
      Width = 107
      Height = 13
      Caption = 'calculations per value:'
    end
    object Label5: TLabel
      Left = 76
      Top = 81
      Width = 51
      Height = 13
      Caption = 'increment:'
    end
    object Label3: TLabel
      Left = 20
      Top = 109
      Width = 107
      Height = 13
      Caption = 'steps until next value:'
    end
    object Label6: TLabel
      Left = 11
      Top = 20
      Width = 77
      Height = 13
      Caption = 'minDist Value'
      Font.Charset = DEFAULT_CHARSET
      Font.Color = clWindowText
      Font.Height = -11
      Font.Name = 'Tahoma'
      Font.Style = [fsBold]
      ParentFont = False
    end
    object E_valFrom: TEdit
      Left = 77
      Top = 44
      Width = 32
      Height = 21
      TabOrder = 0
      Text = '5'
      OnChange = E_calcValsChange
    end
    object E_valTo: TEdit
      Left = 135
      Top = 44
      Width = 32
      Height = 21
      TabOrder = 1
      Text = '12'
      OnChange = E_calcValsChange
    end
    object E_toSteps: TEdit
      Left = 133
      Top = 105
      Width = 32
      Height = 21
      TabOrder = 2
      Text = '3'
    end
    object E_calcVals: TEdit
      Left = 133
      Top = 132
      Width = 32
      Height = 21
      TabOrder = 3
      Text = '10'
      OnChange = E_calcValsChange
    end
    object B_start: TButton
      Left = 11
      Top = 167
      Width = 75
      Height = 25
      Caption = 'new start'
      TabOrder = 4
      OnClick = B_startClick
    end
    object B_break: TButton
      Left = 92
      Top = 167
      Width = 75
      Height = 25
      Caption = 'start / stop'
      TabOrder = 5
      OnClick = B_breakClick
    end
    object E_incre: TEdit
      Left = 133
      Top = 77
      Width = 32
      Height = 21
      TabOrder = 6
      Text = '1'
      OnChange = E_calcValsChange
    end
  end
  object Timer2: TTimer
    Interval = 1
    OnTimer = Timer2Timer
    Left = 680
    Top = 394
  end
  object ChartEditor1: TChartEditor
    Chart = Chart_IS
    Left = 648
    Top = 392
  end
end

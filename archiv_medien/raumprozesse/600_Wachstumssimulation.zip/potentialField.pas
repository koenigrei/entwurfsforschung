unit potentialField;

interface

uses
  Windows, Classes, Graphics, cell, agent, math, SysUtils;

var
  limboPot      : Array of Array of Single;
  PotCandList   : TList;
  ClustCandList : TList;

procedure equiPot;
procedure checkPot (K, I: Integer);
procedure dev_Cell;
procedure paint_Field;
function  checkNei (K, I: Integer): Boolean;
function  checkClust (K, I: Integer): Boolean;
function  checkDev (K, I: Integer): Boolean;
procedure findCandidates;
procedure dev_ClusterCell;
procedure findClusterCandidates;
procedure buildStreet(curCell : TCell);

implementation

uses Main, transferLine;

//=================================================calculate the potential field
procedure equiPot;
var
  K, I  : Integer;
begin
  for I := 0 to reih -1 do
  begin
    for K := 0 to spalt -1 do
    begin
      limboPot[K,I] := 0;
      If (cellList[K,I].buildDense > 0) then
      begin
         limboPot[K,I] := power((cellList[K,I].buildDense/9), 1-cellList[K,I].pot); //!*+'??!!!
      end;
      checkPot(K, I);                                                        // set limboPot
    end;
  end;
  for I := 0 to reih -1 do                                                   // limboPot to aktual pot-value
  begin
    for K := 0 to spalt -1 do
    begin
       cellList[K,I].Pot := limboPot[K, I];
       If cellList[K,I].Pot > 1 Then begin
         cellList[K,I].Pot := 1;
      end;
    end;
  end;
end;

//===============================Check Moore-Neigborhood for state and potential
procedure checkPot (K, I: Integer);
var
  v      : Integer;
  Xp, Yp : Integer;
  koNei  : Array [0..3] of TPoint;
  factor : SmallInt;
begin
  factor := 5;
  koNei[0].X := K;    koNei[0].Y := I + 1;
  koNei[1].X := K;    koNei[1].Y := I - 1;
  koNei[2].X := K+1;  koNei[2].Y := I;
  koNei[3].X := K-1;  koNei[3].Y := I;
  for v := 0 to 3 do
  begin
    Xp := koNei[v].X;
    Yp := koNei[v].Y;
    If Form1.wrap(Xp, Yp) = true Then                                        // wrap - no torus
    begin
      If Not ((Xp = K) and (Yp = I)) Then
      begin
         limboPot[K,I] := limboPot[K,I] + (cellList[Xp, Yp].Pot);
      end;
    end;
  end;
  limboPot[K,I] := limboPot[K,I] / factor;
end;

//======================================================find the candidate Cells
procedure findCandidates;
var
  curCell  : TCell;
  K, I     : Integer;
begin
  PotCandList.Clear;
  for I := 0 to reih*3 -1 do
  begin
    for K := 0 to spalt*3 -1 do
    begin
      curCell := smalGridList[K,I];
      If (curCell.cState = 0) AND checkNei(K, I)= true  then                  // if there is a street in the neighbourhood and the cell is empty
      begin
        PotCandList.Add(curCell);
      end;
    end;
  end;
end;

//=================================================find the cell for development
procedure dev_Cell;
var
  curCell, maxCell, primCell : TCell;
  I                  : Integer;
  maxPot, temp       : Extended;
  centriPe, centriFu : Extended;
  expoPe, expoFu     : Single;
  prScal, fuScal     : Single;
  rndScale           : Single;
begin
  rndScale := StrToFloat(Form1.E_rndScale.Text);
  randomize;
  expoPe := StrToFloat(Form1.E_centriPe.Text);
  expoFu := StrToFloat(Form1.E_centriFu.Text);
  prScal := StrToFloat(Form1.E_peScale.Text);
  fuScal := StrToFloat(Form1.E_fuScale.Text);
  maxPot := -999999999;
  If PotCandList.count <= 0 Then begin
    Form1.Timer1.Enabled := false;
    Exit;
  end;
  for I := 0 to PotCandList.count-1 do
  begin
    curCell := PotCandList.Items[I];
    If expoPe = 0 Then begin
      centriPe := 0;
    end else begin
      centriPe := prScal * (1-exp(-expoPe*curCell.Pot));
      centriPe := centriPe + rndScale*random();
      //centriPe := centriPe + curCell.basicRnd;
    end;

    If expoFu = 0 Then begin
      centriFu := 0;
    end else begin
      centriFu := fuScal * (1-exp(-expoFu*curCell.Pot));
      centriFu := centriFu + rndScale*random();
      //centriFu := centriFu + curCell.basicRnd;
    end;

    temp := centriPe - centriFu;
    If (temp) > maxPot Then
    begin
      maxPot   := temp;
      maxCell  := curCell;
    end;
  end;
  // -- settings for the developed cell --
  maxCell.cState := 2;  // built on state
  maxCell.subState := 2;
  maxCell.colr   := clBlue;
  maxCell.Paint(Image_SmalGrid.Canvas);
  primCell := CellList[floor(maxCell.Koord.X/3), floor(maxCell.Koord.Y/3)];
  inc(primCell.buildDense);
  primCell.cState := 2;
end;

//=====================================================paint the potential field
procedure paint_Field;
var
  curCell   : TCell;
  K, I, col : Integer;
begin
  for I := 0 to reih -1 do
  begin
    for K := 0 to spalt -1 do
    begin
      curCell      := cellList[K,I];
      col := round((curCell.Pot+0.5) * 170 );
      curCell.colr := RGB(col, col, col);
      curCell.Paint (Image_Cells.Canvas);
    end;
  end;
end;

//===============================Check Moore-Neigborhood for state and potential
function checkNei (K, I: Integer): Boolean;
var
  devThresh : Single;
  Xp, Yp, v : Integer;
  koNei     : Array [0..3] of TPoint;
begin
  devThresh := StrToFloat(Form1.E_devThresh.Text);
  Result := false;
  // --- Summe berechnen ---
  koNei[0].X := K;    koNei[0].Y := I + 1;
  koNei[1].X := K;    koNei[1].Y := I - 1;
  koNei[2].X := K+1;  koNei[2].Y := I;
  koNei[3].X := K-1;  koNei[3].Y := I;
  for v := 0 to 3 do
  begin
    Xp := koNei[v].X;
    Yp := koNei[v].Y;
    If Form1.smallGridWrap(Xp, Yp) = true Then                                // wrap - no torus
    begin
      If (smalGridList[Xp, Yp].cState = 1) Or
         ((smalGridList[Xp, Yp].cState = 2) And (smalGridList[Xp, Yp].pot > devThresh))
         Then Result := true; // neben stra�e oder haus
    end;
  end;
end;

//==============================================================================
//==============================================================================
//=================================find the candidate Cells for the cluster-type
procedure findClusterCandidates;
var
  curCell  : TCell;
  K, I     : Integer;
begin
  ClustCandList.Clear;
  for I := 0 to reih*3 -1 do
  begin
    for K := 0 to spalt*3 -1 do
    begin
      curCell := smalGridList[K,I];
      If (curCell.cState = 0)  then                                          // if the cell is empty
      begin
        ClustCandList.Add(curCell);
      end;
    end;
  end;
end;

//=================================================find the cell for development
procedure dev_ClusterCell;
var
  curCell, maxCell, primCell : TCell;
  I                  : Integer;
  maxPot, temp       : Extended;
  centriPe, centriFu : Extended;
  expoPe, expoFu     : Single;
  prScal, fuScal     : Single;
  rndScale           : Single;
begin
  rndScale := StrToFloat(Form1.E_rndScale.Text);
  randomize;
  expoPe := StrToFloat(Form1.E_centriPe.Text);
  expoFu := StrToFloat(Form1.E_centriFu.Text);
  prScal := StrToFloat(Form1.E_peScale.Text);
  fuScal := StrToFloat(Form1.E_fuScale.Text);
  maxPot := -999999999;
  If ClustCandList.count <= 0 Then begin
    Form1.Timer1.Enabled := false;
    Exit;
  end;
  for I := 0 to ClustCandList.count-1 do
  begin
    curCell := ClustCandList.Items[I];

    If expoPe = 0 Then begin
      centriPe := 0;
    end else begin
      centriPe := prScal * (1-exp(-expoPe*curCell.Pot));
      centriPe := centriPe + rndScale*random();
      //centriPe := curCell.Pot + rndScale * random();                        // for runs with random values only!
      //centriPe := centriPe + curCell.basicRnd;
    end;

    If expoFu = 0 Then begin
      centriFu := 0;
    end else begin
      centriFu := fuScal * (1-exp(-expoFu*curCell.Pot));
      centriFu := centriFu + rndScale*random();
      //centriFu := centriFu - curCell.basicRnd;
    end;

    temp := centriPe - centriFu;
    //temp := centriPe;                                                      // for runs with random values only!
    If (temp) > maxPot Then
    begin
      maxPot   := temp;
      maxCell  := curCell;
    end;
  end;
  // --- settings for the developed cell ---------------------------------------
  maxCell.cState := 2;
  maxCell.subState := 2;                                                     // built on state
  maxCell.colr   := clBlue;
  maxCell.Paint(Image_SmalGrid.Canvas);
  primCell := CellList[floor(maxCell.Koord.X/3), floor(maxCell.Koord.Y/3)];
  inc(primCell.buildDense);
  primCell.cState := 2;
  If checkClust(maxCell.Koord.X, maxCell.Koord.Y)=false Then                 // if the new build on cell have no neighbour
  begin
    If (primCell.State = 3) or (primCell.State = 0) Then                     // if a new node is allowed
    begin
      buildStreet(maxCell);
    end;
  end;
end;

//==============================================================================
procedure buildStreet(curCell : TCell);
var
  I       : Integer;
  zielCell, parCell : TCell;
  curNode, nearNode : TAgent;
  tmpDist : Cardinal;
  minDist : Cardinal;
  candclList : TList;
begin
  minDist := 999999999;
  IF NodeList.Count > 0 Then
  begin
    for I := 0 to NodeList.Count -1 do
    begin
      curNode := NodeList.Items[I];
      tmpDist := CalcDistance(curCell.Pos.X, curCell.Pos.Y, curNode.PositionX, curNode.PositionY);
      If tmpDist < minDist Then
      begin
        minDist  := tmpDist;
        nearNode := curNode;
      end;
    end;
  end;
  zielCell := cellList[nearNode.onCell.X, nearNode.onCell.Y];

  parCell := CellList[floor(curCell.Koord.X/3), floor(curCell.Koord.Y/3)];
  AgentsCreate(parCell);
  CurNode := NodeList.Last;
  subdivideEdge(zielCell, parCell);

  candclList := TList.Create;
  If NodeList.Count > 1 Then begin
    Form1.lookForOtherNodes(parCell.Koord.X, parCell.Koord.Y, candclList);   // look for other nodes in the neighbourhood
    Form1.InterLink(CurNode, candclList);
  end;
  candclList.Free;
end;

//=================Check Moore-Neigborhood if there is a build on or street cell
function checkClust (K, I: Integer): Boolean;
var
  Xp, Yp, v : Integer;
  koNei     : Array [0..3] of TPoint;
begin
  Result := false;
  // --- Summe berechnen ---
  koNei[0].X := K;    koNei[0].Y := I + 1;
  koNei[1].X := K;    koNei[1].Y := I - 1;
  koNei[2].X := K+1;  koNei[2].Y := I;
  koNei[3].X := K-1;  koNei[3].Y := I;
  for v := 0 to 3 do
  begin
    Xp := koNei[v].X;
    Yp := koNei[v].Y;
    If Form1.smallGridWrap(Xp, Yp) = true Then                               // wrap - no torus
    begin
      If Not (smalGridList[Xp, Yp].cState = 0) Then Result := true;          // beside street or house cell
    end;
  end;
end;

//===========================Check Moore-Neigborhood if there is a build on cell
function checkDev (K, I: Integer): Boolean;
var
  Xp, Yp, v : Integer;
  koNei     : Array [0..3] of TPoint;
begin
  Result := false;
  // --- Summe berechnen ---
  koNei[0].X := K;    koNei[0].Y := I + 1;
  koNei[1].X := K;    koNei[1].Y := I - 1;
  koNei[2].X := K+1;  koNei[2].Y := I;
  koNei[3].X := K-1;  koNei[3].Y := I;
  for v := 0 to 3 do
  begin
    Xp := koNei[v].X;
    Yp := koNei[v].Y;
    If Form1.smallGridWrap(Xp, Yp) = true Then                               // wrap - no torus
    begin
      If (smalGridList[Xp, Yp].cState = 2) Then Result := true;              // beside street cell
    end;
  end;
end;

end.

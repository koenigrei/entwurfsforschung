// *****************************************************************************
// ****************          Pathfinding with A-Stern           ****************
// *****************************************************************************
// --- Programming: Reinhard K�nig                                           ---
// --- Date       : 04.Jan.2007                                              ---
// -----------------------------------------------------------------------------
// --- Find the shortest path in the NodeList                                ---
// --- the findPath procedure returns the found path in the pfadList         ---
// --- beside the NodeList you have to define the startNode and zielNode     ---
// -----------------------------------------------------------------------------

unit raster_ASTern;

interface

uses
  Math, SysUtils, Types, Classes, cell;


{const
  DegToRad  = 3.141592654/180;
  RadToDeg  = 180/3.141592654;
  Pi        = 3.141592654;   }

var
  rFoundPath : Boolean;
  rOpenList  : TList;

procedure rSetup;
procedure rCheckNeighbour (parAgent, zielNode : TCell);
procedure rCalcF          (vorg, me, zielNode : TCell);
procedure rFindPath        (var rPfadList: TList; startNode, zielNode : TCell);
procedure rDeletePath;
function  rCompareByF     (Item1 : Pointer; Item2 : Pointer) : Integer;
function  rDistance       (pX1: Integer; pY1: Integer; pX2: Integer; pY2: Integer): Integer;

implementation

uses Main;

// *****************************************************************************
// ****************             A-Stern Berechnungen            ****************
// *****************************************************************************
//
procedure rSetup;
begin
  rOpenList := TList.Create;
end;
//==========================================================geht die Nodes durch
procedure rFindPath (var rPfadList: TList; startNode, zielNode : TCell);
var
  explNode : TCell;
  parAgent : TCell;
begin
  rFoundPath := false;
  rPfadList.Clear;
  rDeletePath;
  rOpenList.Add(startNode);
  //---------------Wdh. bis rOpenList vollst�ndig �berpr�ft => kein Pfad m�glich!
  //---------------oder bis zielNode erreicht -------------=> pfad gefunden.
  While ((rOpenList.count > 0) And (rFoundPath = false)) Do
  begin
    explNode := rOpenList.Items[rOpenList.count -1];
    explNode.closed := true;
    rCheckNeighbour (explNode, zielNode);
    rOpenList.Sort(rCompareByF);
    rOpenList.Remove(explNode);
  end;
  //----------------------------------------------------------speichere den Pfad
  explNode := zielNode;
  If rFoundPath = true Then begin
    repeat
      parAgent := explNode.Vorg;
      rPfadList.Add(explNode);
      explNode := explNode.Vorg;
    Until (explNode = startNode);
  end;
  rOpenList.Free;
end;

//=======================Node wird expandiert -&- die neuen Nodes werden gepr�ft
procedure rCheckNeighbour (parAgent, zielNode : TCell);
var
  I, U      : Integer;
  altG      : Integer;
  altH      : Integer;
  altF      : Integer;
  inOpen    : Boolean;
  cildAgent : TCell;

  v      : Integer;
  Xp, Yp : Integer;
  koNei  : Array [0..3] of TPoint;
begin
  koNei[0].X := parAgent.Koord.X;    koNei[0].Y := parAgent.Koord.Y + 1;
  koNei[1].X := parAgent.Koord.X;    koNei[1].Y := parAgent.Koord.Y - 1;
  koNei[2].X := parAgent.Koord.X+1;  koNei[2].Y := parAgent.Koord.Y;
  koNei[3].X := parAgent.Koord.X-1;  koNei[3].Y := parAgent.Koord.Y;

  for v := 0 to 3 do
  begin
    Xp := koNei[v].X;
    Yp := koNei[v].Y;
    If Form1.smallGridWrap(Xp, Yp) = true Then                               // wrap - no torus
    begin
    
    cildAgent := smalGridList[Xp, Yp];
    If (Not(cildAgent.cState = 2) and (cildAgent.Closed = false)) then
    begin
    //If (cildAgent.Closed = false) then                  // -- nicht untersucht werden W�nde und closed Nodes
      inOpen := false;
      for U := 0 To rOpenList.count -1 do                // -- pr�ft, ob Knoten bereits in rOpenList
      begin
        If (rOpenList.Items[U] = cildAgent) then begin
          inOpen := true;
        end;
      end;
      If inOpen = false then                            // -- wenn Node noch nicht in open List
      begin
        rCalcF (parAgent, cildAgent, zielNode);          // -- berechnet die Sch�tzwerte (Heuristik)
        cildAgent.Vorg := parAgent;                     // -- bestimmt den Vog�nger-VerweisNode
        rOpenList.Add(cildAgent);                        // -- nimmt Node in rOpenList auf
        If (cildAgent = zielNode) Then begin
          rFoundPath := true;                            // -- Ziel erreicht!
        end;
      end else begin                                    // -- wenn wenn Node bereits in open List
                                                        // -- pr�fe, ob G g�nstiger => ver�ndere Vorg
        altG := cildAgent.G;                            // +
        altH := cildAgent.H;                            // + speichert Werte vor der neuBerechnung
        altF := cildAgent.F;                            // +
        rCalcF (parAgent, cildAgent, zielNode);
        If (altG < cildAgent.G) Then begin              // -- setze alte Werte wieder ein
          cildAgent.G := altG;
          cildAgent.H := altH;
          cildAgent.F := altF;
        end else begin
          cildAgent.Vorg := parAgent;                   // -- falls neuer G-Wert g�nstiger, neuer Verweis auf Vorg�nger-Node
        end;
      end;
    end;
  end;

  end;
end;

//===========================================Berechnung der Heuristik: F = G + H
procedure rCalcF (vorg, me, zielNode : TCell);
var
  dist     : Integer;
begin
  // ----- Berechne G -----
  dist := rDistance(vorg.Pos.X, vorg.Pos.Y, me.Pos.X, me.Pos.Y);
  me.G := vorg.G + dist;
  // ----- Berechne H -----
  me.H := rDistance(zielNode.Pos.X, zielNode.Pos.Y, me.Pos.X, me.Pos.Y);
  // ----- Berechne F -----
  me.F := me.G + me.H;
end;

//================================TList sort routine : compare customers by name
//--------------------------------The returned integer has the following value :
//--------------------------------   > 0 : (positive) Item1 is less than Item2
//--------------------------------     0 : Item1 is equal to Item2
//--------------------------------   < 0 : (negative) Item1 is greater than Item2
function rCompareByF(Item1 : Pointer; Item2 : Pointer) : Integer;
var
  customer1, customer2 : TCell;
begin
  //-------------------We start by viewing the object pointers as TCell objects
  customer1 := TCell(Item1);
  customer2 := TCell(Item2);
  //-------------------------------------------Now compare by F - complete Kosts
  if   customer1.F < customer2.F
    then Result := 1
  else if customer1.F = customer2.F
    then Result := 0
  else   Result := -1;
end;

//=================================================================Pfade l�schen
procedure rDeletePath;
var
  I, K : Integer;
  AShape : TCell;
begin
  rOpenList := TList.Create;
  for I := 0 To reih*3 -1 do
  begin
    for K := 0 To spalt*3 -1 do
    begin
      smalGridList[K, I].F:= 0;
      smalGridList[K, I].G:= 0;
      smalGridList[K, I].H:= 0;
      smalGridList[K, I].closed:= false;
    end;
  end;

  {for I := 0 to NodeList.Count - 1 do
  begin
    AShape := NodeList.Items [I];
    AShape.F:= 0;
    AShape.G:= 0;
    AShape.H:= 0;
    AShape.closed:= false;
  end;   }
end;

//===================================================funktion zur Distanzmessung
function rDistance(pX1: Integer; pY1: Integer; pX2: Integer; pY2: Integer): Integer;
  var temp: double;
  begin
  temp := sqrt(Power((pX1 - pX2), 2) + Power((pY1 - pY2), 2));
  rDistance := Round(temp);
end;

end.

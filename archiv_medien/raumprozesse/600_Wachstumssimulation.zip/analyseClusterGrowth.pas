unit analyseClusterGrowth;

interface

uses
  Windows, Messages, SysUtils, Variants, Classes, Graphics, Controls, Forms, Math,
  Dialogs, TeEngine, TeeTools, TeePageNumTool, Series, ExtCtrls, TeeProcs, Chart,
  ComCtrls, StdCtrls, CurvFitt, TeeFunci, TeeEdit, StatChar;

type
  Tana_clusterGrow = class(TForm)
    Timer3: TTimer;
    lbl_pSteps          : TLabel;
    lbl_timesteps       : TLabel;
    Label8              : TLabel;
    Lbl_proceed         : TLabel;
    Lbl_akt             : TLabel;
    B_undoZ             : TButton;
    Chart_growCluster: TChart;
    Series_ML: TPointSeries;
    Series_ML_Avg: TLineSeries;
    TeeFunction2        : TAverageTeeFunction;
    Series_ML_Trend: TLineSeries;
    TeeFunction6        : TTrendFunction;
    PageNumTool2        : TPageNumTool;
    GroupBox3           : TGroupBox;
    CB_data_Seg         : TCheckBox;
    CB_avg_Seg          : TCheckBox;
    CB_trend_Seg        : TCheckBox;
    ChartEditor1        : TChartEditor;
    Button1             : TButton;
    Series_StDv         : TLineSeries;
    TeeFunction1        : TStdDeviationFunction;
    Series_Correlation  : TLineSeries;
    TeeFunction4        : TCorrelationFunction;
    Series_mean         : TLineSeries;
    TeeFunction5        : TAverageTeeFunction;
    GroupBox1           : TGroupBox;
    Label4              : TLabel;
    Label3              : TLabel;
    Label6              : TLabel;
    E_toSteps           : TEdit;
    E_calcVals          : TEdit;
    B_start             : TButton;
    B_break             : TButton;
    Label1: TLabel;
    E_measureSt: TEdit;
    UpD_measureSt: TUpDown;
    UpD_toSteps: TUpDown;
    UpD_calcVals: TUpDown;
    Series_Edges: TPointSeries;
    Series_Border: TPointSeries;
    procedure FormCreate(Sender: TObject);
    procedure B_startClick(Sender: TObject);
    procedure B_undoZClick(Sender: TObject);
    procedure Timer3Timer(Sender: TObject);
    procedure B_breakClick(Sender: TObject);
    procedure CB_data_SegClick(Sender: TObject);
    procedure CB_avg_SegClick(Sender: TObject);
    procedure CB_trend_SegClick(Sender: TObject);
    procedure E_calcValsChange(Sender: TObject);
    procedure Button1Click(Sender: TObject);
    procedure FormClose(Sender: TObject; var Action: TCloseAction);
  private
    procedure updProc;
    procedure resetGraphs;
  public
    measRds: Cardinal;
    Steps  : Integer;
    rounds : Cardinal;
    procedure NewStart;
    procedure plotVals;
    procedure newRound;
  end;

var
  ana_clusterGrow  : Tana_clusterGrow;

implementation

{$R *.dfm}
uses Main, dijkstra, ConnTable;

procedure Tana_clusterGrow.FormClose(Sender: TObject; var Action: TCloseAction);
begin
  Timer3.enabled := false;
  Action := caFree;
end;

procedure Tana_clusterGrow.FormCreate(Sender: TObject);
begin
  Timer3.enabled := false;
  lbl_pSteps.Caption := '0';
  Steps := 0;
  rounds := 1;
  Lbl_akt.Caption := IntToStr(rounds);
  Lbl_proceed.Caption := '/ ' + E_calcVals.Text;
end;

procedure Tana_clusterGrow.B_startClick(Sender: TObject);
begin
  NewStart;
  Timer3.Enabled := true;
end;

procedure Tana_clusterGrow.NewStart;
begin
  Form1.RB_netOnly.Checked := true;
  Form1.Timer1.enabled := false;
  resetGraphs;
  rounds := 1;
  measRds := 0;
  Lbl_akt.Caption := IntToStr(rounds);
  newRound;
  Form1.deleteAll;
  Form1.Setup;
  Form1.RB_netOnly.Checked := true;
end;

procedure Tana_clusterGrow.resetGraphs;
begin
  with Chart_growCluster do
  begin
    Title.Text.Clear;                                                         // -- Title of the Chart
    Title.Text.Add('growing cluster with minDist = '+IntToStr(Form1.SE_minDist.Value));
    Series_ML.Clear;
    Series_ML_Avg.Clear;
    Series_ML_Avg.Color := clGreen;
    Series_StDv.Clear;
    Series_Border.Clear;
    Series_Edges.Clear;
    Series_Correlation.Clear;
    Series_ML_Avg.FunctionType.Period := rounds;//round(UpD_toSteps.Position / UpD_measureSt.Position);
    Series_ML_Avg.Visible   := CB_avg_Seg.Checked;
    Series_ML_Trend.Visible := CB_trend_Seg.Checked;
  end;
end;

procedure Tana_clusterGrow.newRound;
begin
  Form1.DeleteAll;
  Form1.Setup;
  measRds := 0;
  Steps := 1;
end;

procedure Tana_clusterGrow.Timer3Timer(Sender: TObject);
begin
  If Steps >= UpD_toSteps.Position+1 Then                                    // timesteps per value
  begin
    Series_ML_Avg.CheckDataSource;
    Series_ML_Trend.CheckDataSource;
    Series_ML_Avg.FunctionType.Period := rounds;
    Lbl_akt.Caption := IntToStr(rounds);
    inc(rounds);
    If rounds > UpD_calcVals.Position Then                                   // calculations per value
    begin
      Series_StDv.CheckDataSource;
      Series_Correlation.CheckDataSource;
      Series_mean.CheckDataSource;
      Timer3.enabled := false;
      rounds := 1;
      exit;
    end;
    newRound;
  end;
  Form1.ExecuteInterlink;
  lbl_pSteps.Caption := IntToStr (Steps);
  inc(Steps);
  inc(measRds);
  If UpD_measureSt.Position <= measRds Then
  begin
    plotVals;
    measRds := 0;
  end;
end;

procedure Tana_clusterGrow.plotVals;
begin
  CalculatePathes;
  ConnectivityTable.ListKonnVals;
  Form1.EdgesPerNode;
  Series_ML.AddXY(steps, globML);
  Series_Border.AddXY(steps, Form1.Ser_Edges.YValue[0]);
  Series_Edges.AddXY(steps, conns);
end;

procedure Tana_clusterGrow.updProc;
begin
  Lbl_proceed.Caption := '/ ' + E_calcVals.Text;
end;

procedure Tana_clusterGrow.B_undoZClick(Sender: TObject);
begin
  Chart_growCluster.UndoZoom;
end;

procedure Tana_clusterGrow.Button1Click(Sender: TObject);
begin
  ChartEditor1.Execute;
end;

procedure Tana_clusterGrow.B_breakClick(Sender: TObject);
begin
  Timer3.enabled := not(Timer3.enabled);
end;

procedure Tana_clusterGrow.CB_data_SegClick(Sender: TObject);
begin
  If CB_data_Seg.Checked Then begin Series_ML.Visible := true;
  end else begin Series_ML.Visible := false;
  end;
end;

procedure Tana_clusterGrow.CB_avg_SegClick(Sender: TObject);
begin
  If CB_avg_Seg.Checked Then begin Series_ML_Avg.Visible := true;
  end else begin Series_ML_AVG.Visible := false;
  end;
end;

procedure Tana_clusterGrow.CB_trend_SegClick(Sender: TObject);
begin
  If CB_trend_Seg.Checked Then begin Series_ML_Trend.Visible := true;
  end else begin Series_ML_Trend.Visible := false;
  end;
end;

procedure Tana_clusterGrow.E_calcValsChange(Sender: TObject);
begin
  updProc;
end;

end.

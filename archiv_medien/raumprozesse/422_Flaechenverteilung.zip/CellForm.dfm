object Form1: TForm1
  Left = 120
  Top = 0
  Caption = 'Settlement_Pattern_04_Land Use'
  ClientHeight = 712
  ClientWidth = 731
  Color = clBtnFace
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -10
  Font.Name = 'Tahoma'
  Font.Style = []
  OldCreateOrder = False
  Position = poDesigned
  OnCreate = FormCreate
  OnDestroy = FormDestroy
  PixelsPerInch = 96
  TextHeight = 12
  object ZeichenPanel: TPanel
    Left = 16
    Top = 8
    Width = 404
    Height = 404
    BorderStyle = bsSingle
    DockSite = True
    TabOrder = 0
    OnMouseDown = ZeichenPanelMouseDown
    OnMouseMove = ZeichenPanelMouseMove
    OnMouseUp = ZeichenPanelMouseUp
  end
  object Chart1: TChart
    Left = 8
    Top = 423
    Width = 713
    Height = 281
    BackWall.Brush.Color = clWhite
    BackWall.Brush.Style = bsClear
    Border.Visible = True
    Title.Text.Strings = (
      'TChart')
    LeftAxis.Grid.Visible = False
    RightAxis.Automatic = False
    RightAxis.AutomaticMaximum = False
    RightAxis.AutomaticMinimum = False
    RightAxis.Maximum = 101.000000000000000000
    View3D = False
    BevelOuter = bvNone
    Color = clWhite
    TabOrder = 1
    object Series1: TLineSeries
      Marks.Callout.Brush.Color = clBlack
      Marks.Visible = False
      Pointer.InflateMargins = True
      Pointer.Style = psRectangle
      Pointer.Visible = False
      XValues.Name = 'X'
      XValues.Order = loAscending
      YValues.Name = 'Y'
      YValues.Order = loNone
    end
  end
  object PageControl1: TPageControl
    Left = 426
    Top = 8
    Width = 297
    Height = 360
    ActivePage = TabSheet2
    TabOrder = 2
    object TabSheet1: TTabSheet
      Caption = 'Setup'
      object RadioGroup_chem: TRadioGroup
        Left = 16
        Top = 167
        Width = 257
        Height = 52
        Caption = 'sniff chemicals with'
        TabOrder = 0
      end
      object rb_rulette: TRadioButton
        Left = 32
        Top = 191
        Width = 81
        Height = 17
        Caption = 'rulette wheel'
        TabOrder = 1
      end
      object rb_hill: TRadioButton
        Left = 144
        Top = 191
        Width = 81
        Height = 17
        Caption = 'hill climbing'
        Checked = True
        TabOrder = 2
        TabStop = True
      end
      object GroupBox1: TGroupBox
        Tag = 1
        Left = 16
        Top = 8
        Width = 257
        Height = 153
        Caption = 'setup settings'
        TabOrder = 3
        object Lbl_TextAnzahl: TLabel
          Left = 62
          Top = 100
          Width = 151
          Height = 12
          Caption = ': number of max agents in system'
        end
        object Label2: TLabel
          Left = 62
          Top = 124
          Width = 127
          Height = 12
          Caption = ': cell size -> number of cells '
        end
        object B_setup: TButton
          Left = 6
          Top = 24
          Width = 75
          Height = 25
          Caption = 'new Setup'
          TabOrder = 0
          OnClick = B_setupClick
        end
        object B_stop: TButton
          Left = 86
          Top = 24
          Width = 75
          Height = 25
          Caption = 'start / stop'
          TabOrder = 1
          OnClick = B_stopClick
        end
        object B_oneStep: TButton
          Left = 166
          Top = 24
          Width = 75
          Height = 25
          Caption = 'one step'
          TabOrder = 2
          OnClick = B_oneStepClick
        end
        object Edit_anzAg: TEdit
          Left = 16
          Top = 96
          Width = 41
          Height = 20
          TabOrder = 3
          Text = '2400'
        end
        object Edit_size: TEdit
          Left = 15
          Top = 122
          Width = 41
          Height = 20
          TabOrder = 4
          Text = '2'
          OnChange = Edit_sizeChange
        end
        object CB_actAna2: TCheckBox
          Left = 16
          Top = 73
          Width = 97
          Height = 17
          Caption = 'activate analysis 2'
          TabOrder = 5
          OnClick = CB_actAna2Click
        end
        object CB_actAna1: TCheckBox
          Left = 16
          Top = 55
          Width = 97
          Height = 17
          Caption = 'activate analysis 1'
          TabOrder = 6
          OnClick = CB_actAna1Click
        end
      end
      object GroupBox3: TGroupBox
        Left = 16
        Top = 225
        Width = 257
        Height = 105
        Caption = 'create per time step'
        TabOrder = 4
        object Label8: TLabel
          Left = 38
          Top = 52
          Width = 188
          Height = 12
          Caption = ': service recources                           | red'
        end
        object Label9: TLabel
          Left = 38
          Top = 28
          Width = 199
          Height = 12
          Caption = ': population agents / residental cells  | green'
        end
        object Label10: TLabel
          Left = 38
          Top = 76
          Width = 194
          Height = 12
          Caption = ': industrial resources                         | blue'
        end
        object E_crServ: TEdit
          Left = 8
          Top = 48
          Width = 25
          Height = 20
          TabOrder = 0
          Text = '1'
          OnChange = Edit_sizeChange
        end
        object E_crAgs: TEdit
          Left = 8
          Top = 24
          Width = 25
          Height = 20
          TabOrder = 1
          Text = '3'
        end
        object E_crIndu: TEdit
          Left = 8
          Top = 72
          Width = 25
          Height = 20
          TabOrder = 2
          Text = '1'
          OnChange = Edit_sizeChange
        end
      end
    end
    object TabSheet2: TTabSheet
      Caption = 'Settings'
      ImageIndex = 1
      DesignSize = (
        289
        333)
      object Label7: TLabel
        Left = 183
        Top = 62
        Width = 86
        Height = 12
        Caption = ': consume Probab.'
      end
      object Label6: TLabel
        Left = 183
        Top = 86
        Width = 61
        Height = 12
        Caption = ': return noise'
      end
      object Lbl_wiggle: TLabel
        Left = 226
        Top = 13
        Width = 15
        Height = 12
        Caption = '___'
      end
      object Label3: TLabel
        Left = 144
        Top = 13
        Width = 81
        Height = 12
        Caption = 'wiggle threshold :'
      end
      object Lbl_B: TLabel
        Left = 90
        Top = 13
        Width = 15
        Height = 12
        Caption = '___'
      end
      object Label1: TLabel
        Left = 8
        Top = 13
        Width = 76
        Height = 12
        Caption = 'angle threshold :'
      end
      object CB_migrate: TCheckBox
        Left = 47
        Top = 84
        Width = 90
        Height = 17
        Caption = ': migrat. thresh'
        TabOrder = 0
      end
      object E_migTh: TEdit
        Left = 8
        Top = 82
        Width = 33
        Height = 20
        TabOrder = 1
        Text = '2'
      end
      object E_CProbab: TEdit
        Left = 144
        Top = 57
        Width = 33
        Height = 20
        TabOrder = 2
        Text = '0,1'
      end
      object CB_decay: TCheckBox
        Left = 47
        Top = 60
        Width = 82
        Height = 17
        Caption = ': path decay '
        TabOrder = 3
      end
      object E_decay: TEdit
        Left = 8
        Top = 58
        Width = 33
        Height = 20
        TabOrder = 4
        Text = '0,99'
      end
      object E_noise: TEdit
        Left = 144
        Top = 82
        Width = 33
        Height = 20
        TabOrder = 5
        Text = '30'
        OnChange = E_noiseChange
      end
      object SB_wiggle: TScrollBar
        Left = 144
        Top = 32
        Width = 113
        Height = 17
        LargeChange = 5
        Max = 180
        PageSize = 0
        Position = 20
        TabOrder = 6
        OnChange = SB_wiggleChange
      end
      object TrB_thresh: TScrollBar
        Left = 8
        Top = 32
        Width = 113
        Height = 17
        LargeChange = 5
        Max = 180
        PageSize = 0
        Position = 22
        TabOrder = 7
        OnChange = TrB_threshChange
      end
      object StringGrid1: TStringGrid
        Left = 8
        Top = 201
        Width = 281
        Height = 88
        BevelEdges = [beRight, beBottom]
        BevelInner = bvSpace
        BevelOuter = bvSpace
        BiDiMode = bdLeftToRight
        ColCount = 6
        DefaultColWidth = 45
        DefaultRowHeight = 20
        RowCount = 4
        Font.Charset = DEFAULT_CHARSET
        Font.Color = clWindowText
        Font.Height = -11
        Font.Name = 'Tahoma'
        Font.Orientation = 1
        Font.Style = []
        Options = [goFixedVertLine, goFixedHorzLine, goVertLine, goHorzLine, goRangeSelect, goEditing]
        ParentBiDiMode = False
        ParentFont = False
        ScrollBars = ssNone
        TabOrder = 8
        OnKeyUp = StringGrid1KeyUp
      end
      object B_reset: TButton
        Left = 8
        Top = 176
        Width = 75
        Height = 25
        Caption = 'reset values'
        TabOrder = 9
        OnClick = B_resetClick
      end
      object RadioGroup_return: TRadioGroup
        Tag = 1
        Left = 8
        Top = 109
        Width = 273
        Height = 52
        Caption = 'return mode'
        TabOrder = 10
      end
      object rb_direct: TRadioButton
        Left = 24
        Top = 133
        Width = 81
        Height = 17
        Caption = 'direct way'
        TabOrder = 11
        OnClick = RadioGroup2Click
      end
      object rb_hillCl: TRadioButton
        Left = 144
        Top = 133
        Width = 105
        Height = 17
        Caption = 'use existing tracks'
        Checked = True
        TabOrder = 12
        TabStop = True
        OnClick = RadioGroup2Click
      end
      object B_saveBmp: TButton
        Left = 11
        Top = 295
        Width = 75
        Height = 25
        Caption = 'save bmp'
        TabOrder = 13
        OnClick = B_saveBmpClick
      end
      object E_pName: TEdit
        Left = 88
        Top = 296
        Width = 105
        Height = 20
        Anchors = [akLeft, akBottom]
        BevelEdges = [beLeft, beBottom]
        BevelInner = bvLowered
        BiDiMode = bdLeftToRight
        ParentBiDiMode = False
        TabOrder = 14
        Text = '001_pic_'
      end
      object B_saveXML: TButton
        Left = 211
        Top = 295
        Width = 75
        Height = 25
        Caption = 'save xls'
        TabOrder = 15
        OnClick = B_saveXMLClick
      end
    end
    object TabSheet3: TTabSheet
      Caption = 'Graphic'
      ImageIndex = 2
      object GroupBox4: TGroupBox
        Left = 8
        Top = 8
        Width = 273
        Height = 185
        Caption = 'output'
        TabOrder = 0
        object CB_noTracks: TCheckBox
          Left = 8
          Top = 16
          Width = 113
          Height = 17
          Caption = 'all cells white'
          TabOrder = 0
          OnClick = CB_noTracksClick
        end
        object CB_gravity: TCheckBox
          Left = 8
          Top = 160
          Width = 145
          Height = 17
          Caption = 'show gravity linies   |   size:'
          Enabled = False
          TabOrder = 1
          OnClick = CB_gravityClick
        end
        object CB_showAB: TCheckBox
          Left = 8
          Top = 48
          Width = 129
          Height = 17
          Caption = 'show only return tracks'
          Checked = True
          State = cbChecked
          TabOrder = 2
          OnClick = CB_showABClick
        end
        object CB_showAg: TCheckBox
          Left = 8
          Top = 144
          Width = 81
          Height = 17
          Caption = 'show agents'
          TabOrder = 3
        end
        object E_grav: TEdit
          Left = 152
          Top = 160
          Width = 25
          Height = 20
          Enabled = False
          TabOrder = 4
          Text = '5'
          OnChange = E_gravChange
        end
        object CB_showOrig: TCheckBox
          Left = 8
          Top = 32
          Width = 121
          Height = 17
          Caption = 'show no tracks'
          Checked = True
          State = cbChecked
          TabOrder = 5
          OnClick = CB_showABClick
        end
        object B_repaint: TButton
          Left = 190
          Top = 16
          Width = 75
          Height = 49
          Caption = 'repaint all'
          TabOrder = 6
          OnClick = B_repaintClick
        end
        object cb_noDesti: TCheckBox
          Left = 8
          Top = 64
          Width = 129
          Height = 17
          Caption = 'show no destinations'
          TabOrder = 7
          OnClick = CB_showABClick
        end
        object CB_potField: TCheckBox
          Left = 8
          Top = 112
          Width = 121
          Height = 17
          Caption = 'show potential field nr.'
          TabOrder = 8
          OnClick = CB_showABClick
        end
        object CB_FieldNr: TComboBox
          Left = 136
          Top = 112
          Width = 33
          Height = 20
          ItemHeight = 12
          TabOrder = 9
          Text = 'Choose SetupMode'
        end
        object Cb_allBlack: TCheckBox
          Left = 8
          Top = 80
          Width = 129
          Height = 17
          Caption = 'all destinations black'
          TabOrder = 10
          OnClick = Cb_allBlackClick
        end
      end
      object B_rankSize: TButton
        Left = 198
        Top = 199
        Width = 75
        Height = 25
        Caption = 'rank size '
        TabOrder = 1
        OnClick = B_rankSizeClick
      end
    end
    object TabSheet4: TTabSheet
      Caption = 'Analysis 1'
      ImageIndex = 3
      object Label11: TLabel
        Left = 8
        Top = 25
        Width = 133
        Height = 12
        Caption = 'tile size for rank-size measure:'
      end
      object E_tileSz: TEdit
        Left = 154
        Top = 21
        Width = 25
        Height = 20
        TabOrder = 0
        Text = '20'
        OnChange = E_tileSzChange
      end
      object UpD_tileSz: TUpDown
        Left = 179
        Top = 21
        Width = 16
        Height = 20
        Associate = E_tileSz
        Min = 2
        Max = 50
        Position = 20
        TabOrder = 1
        OnClick = UpD_tileSzClick
      end
      object GroupBox5: TGroupBox
        Left = 3
        Top = 56
        Width = 283
        Height = 265
        Caption = 'parameter space for weights'
        TabOrder = 2
        object Label5: TLabel
          Left = 51
          Top = 25
          Width = 81
          Height = 12
          Caption = 'timesteps per run:'
        end
        object Label13: TLabel
          Left = 143
          Top = 101
          Width = 13
          Height = 12
          Caption = 'to:'
        end
        object Label14: TLabel
          Left = 39
          Top = 101
          Width = 56
          Height = 12
          Caption = 'values from:'
        end
        object Label12: TLabel
          Left = 77
          Top = 57
          Width = 55
          Height = 12
          Caption = 'end at runs:'
        end
        object Label15: TLabel
          Left = 46
          Top = 237
          Width = 159
          Height = 12
          Caption = 'start at setup and activate analysis 1'
        end
        object E_toSteps: TEdit
          Left = 138
          Top = 22
          Width = 37
          Height = 20
          TabOrder = 0
          Text = '800'
        end
        object E_valFrom: TEdit
          Left = 105
          Top = 97
          Width = 32
          Height = 20
          TabOrder = 1
          Text = '-1,0'
        end
        object E_valTo: TEdit
          Left = 162
          Top = 97
          Width = 32
          Height = 20
          TabOrder = 2
          Text = '1,0'
        end
        object UpD_toSteps: TUpDown
          Left = 175
          Top = 22
          Width = 16
          Height = 20
          Associate = E_toSteps
          Min = 1
          Max = 32000
          Position = 800
          TabOrder = 3
        end
        object GroupBox6: TGroupBox
          Left = 34
          Top = 136
          Width = 183
          Height = 89
          Caption = 'random values for'
          TabOrder = 4
          object CB_pop: TCheckBox
            Left = 16
            Top = 24
            Width = 82
            Height = 17
            Caption = 'population'
            Checked = True
            State = cbChecked
            TabOrder = 0
          end
          object CB_serv: TCheckBox
            Left = 16
            Top = 40
            Width = 82
            Height = 17
            Caption = 'service'
            Checked = True
            State = cbChecked
            TabOrder = 1
          end
          object CB_indu: TCheckBox
            Left = 16
            Top = 56
            Width = 73
            Height = 17
            Caption = 'industry'
            Checked = True
            State = cbChecked
            TabOrder = 2
          end
          object CB_popNull: TCheckBox
            Left = 104
            Top = 24
            Width = 65
            Height = 17
            Caption = 'set to null'
            TabOrder = 3
          end
          object CB_servNull: TCheckBox
            Left = 104
            Top = 40
            Width = 65
            Height = 17
            Caption = 'set to null'
            TabOrder = 4
          end
          object CB_induNull: TCheckBox
            Left = 104
            Top = 56
            Width = 73
            Height = 17
            Caption = 'set to null'
            TabOrder = 5
          end
        end
        object E_runs: TEdit
          Left = 138
          Top = 54
          Width = 37
          Height = 20
          TabOrder = 5
          Text = '32.700'
        end
        object UpD_runs: TUpDown
          Left = 175
          Top = 54
          Width = 16
          Height = 20
          Associate = E_runs
          Min = 1
          Max = 32700
          Position = 32700
          TabOrder = 6
        end
      end
    end
    object TabSheet5: TTabSheet
      Caption = 'Analysis 2'
      ImageIndex = 4
      object Label16: TLabel
        Left = 8
        Top = 25
        Width = 133
        Height = 12
        Caption = 'tile size for rank-size measure:'
      end
      object E_tileSz2: TEdit
        Left = 154
        Top = 21
        Width = 25
        Height = 20
        TabOrder = 0
        Text = '20'
        OnChange = E_tileSzChange
      end
      object UpD_tileSz2: TUpDown
        Left = 179
        Top = 21
        Width = 16
        Height = 20
        Associate = E_tileSz2
        Min = 2
        Max = 50
        Position = 20
        TabOrder = 1
        OnClick = UpD_tileSzClick
      end
      object GroupBox7: TGroupBox
        Left = 3
        Top = 47
        Width = 283
        Height = 266
        Caption = 'parameter space for noise'
        TabOrder = 2
        object Label17: TLabel
          Left = 51
          Top = 33
          Width = 81
          Height = 12
          Caption = 'timesteps per run:'
        end
        object Label18: TLabel
          Left = 143
          Top = 101
          Width = 13
          Height = 12
          Caption = 'to:'
        end
        object Label19: TLabel
          Left = 39
          Top = 101
          Width = 56
          Height = 12
          Caption = 'values from:'
        end
        object Label21: TLabel
          Left = 46
          Top = 237
          Width = 159
          Height = 12
          Caption = 'start at setup and activate analysis 2'
        end
        object Label20: TLabel
          Left = 44
          Top = 66
          Width = 48
          Height = 12
          Caption = 'increment:'
        end
        object E_toSteps2: TEdit
          Left = 138
          Top = 30
          Width = 37
          Height = 20
          TabOrder = 0
          Text = '800'
        end
        object E_valFrom2: TEdit
          Left = 105
          Top = 97
          Width = 32
          Height = 20
          TabOrder = 1
          Text = '0,0'
        end
        object E_valTo2: TEdit
          Left = 162
          Top = 97
          Width = 32
          Height = 20
          TabOrder = 2
          Text = '12,0'
        end
        object UpD_toSteps2: TUpDown
          Left = 175
          Top = 30
          Width = 16
          Height = 20
          Associate = E_toSteps2
          Min = 1
          Max = 32000
          Position = 800
          TabOrder = 3
        end
        object E_incre: TEdit
          Left = 105
          Top = 62
          Width = 32
          Height = 20
          TabOrder = 4
          Text = '1'
        end
        object RadioGroup1: TRadioGroup
          Left = 34
          Top = 136
          Width = 185
          Height = 95
          Caption = 'values for'
          TabOrder = 5
        end
        object RB_serv: TRadioButton
          Left = 98
          Top = 177
          Width = 79
          Height = 17
          Caption = 'service'
          TabOrder = 6
        end
        object RB_indu: TRadioButton
          Left = 98
          Top = 200
          Width = 79
          Height = 17
          Caption = 'industry'
          TabOrder = 7
        end
        object RB_pop: TRadioButton
          Left = 98
          Top = 158
          Width = 79
          Height = 17
          Caption = 'population'
          Checked = True
          TabOrder = 8
          TabStop = True
        end
      end
    end
  end
  object GroupBox2: TGroupBox
    Tag = 1
    Left = 424
    Top = 373
    Width = 297
    Height = 41
    Caption = 'timesteps'
    ParentBackground = False
    TabOrder = 3
    object lbl_Steps: TLabel
      Left = 48
      Top = 18
      Width = 39
      Height = 12
      Alignment = taCenter
      BiDiMode = bdRightToLeft
      Caption = 'lbl_Steps'
      ParentBiDiMode = False
    end
    object Label4: TLabel
      Left = 144
      Top = 18
      Width = 58
      Height = 12
      Caption = 'stop at time :'
    end
    object E_stop: TEdit
      Left = 208
      Top = 13
      Width = 57
      Height = 20
      TabOrder = 0
      Text = '800'
      OnChange = E_stopChange
    end
  end
  object Timer1: TTimer
    Enabled = False
    Interval = 1
    OnTimer = Timer1Timer
    Left = 696
    Top = 408
  end
end

unit RankSize;

interface

uses
  Windows, Messages, SysUtils, Variants, Classes, Graphics, Controls, Forms, Grids,
  Dialogs, ExtCtrls, TeeProcs, TeEngine, Chart, Series, Math, StdCtrls, CurvFitt;

type
  TForm2 = class(TForm)
    C_RankSize: TChart;
    B_undoZoom: TButton;
    Series1: TLineSeries;
    C_Linear: TChart;
    LineSeries1: TLineSeries;
    SG_Ana1: TStringGrid;
    SG_Ana2: TStringGrid;
    procedure FormCreate(Sender: TObject);
    procedure B_undoZoomClick(Sender: TObject);
  private
    { Private declarations }
  public
    procedure newSerie;
    procedure resetGraph;
  end;

var
  Form2: TForm2;
  sSer  : Array of TLineSeries;    //-- series for graph-plotting
  lSer  : Array of TLineSeries;

implementation

{$R *.dfm}
uses CellForm;

var
  trendFunkt : TTrendFunction;
  tendSeries : TLineSeries;
  corFunkt   : TCorrelationFunction;
  corSeries  : TLineSeries;
  changeSeries  : TLineSeries;

procedure TForm2.B_undoZoomClick(Sender: TObject);
begin
  C_RankSize.UndoZoom;
  C_Linear.UndoZoom;
end;

procedure TForm2.FormCreate(Sender: TObject);
begin
  resetGraph;
end;

procedure TForm2.resetGraph;
var
 I, K : Integer;
begin
  SetLength (sSer, 0);
  with C_RankSize do
  begin
    RemoveAllSeries;
    Title.Text.Clear;
    //RightAxis.Grid.Visible := false;
    Title.Text.Add('log-log distribution');
  end;
  tendSeries:=TLineSeries.Create(self);
  tendSeries.ParentChart := C_RankSize;
  trendFunkt := TTrendFunction.Create(self);
  trendFunkt.ParentSeries := tendSeries;
  corSeries:=TLineSeries.Create(self);
  corSeries.ParentChart := C_RankSize;
  corSeries.VertAxis := aRightAxis;
  corFunkt := TCorrelationFunction.Create(self);
  corFunkt.ParentSeries := corSeries;
  corSeries.Visible := false;
  changeSeries :=TLineSeries.Create(self);
  with changeSeries do
  begin
    Clear;                                      // Clear it
    ParentChart := C_RankSize;                      // determine the chart, this series belongs to
    VertAxis := aRightAxis;
    Color    := clBlue;
  end;
  with C_Linear do
  begin
    RemoveAllSeries;
    Title.Text.Clear;                                                         // -- Title of the Chart
    Title.Text.Add('linear distribution');
  end;
  with SG_Ana1 do
  begin
    RowCount := 2;
    Cells[0, 0]:='time';
    Cells[1, 0]:='intercept K';
    Cells[2, 0]:='correlation r�';
    Cells[3, 0]:='slope';
    Cells[0, 1]:='';
    Cells[1, 1]:='';
    Cells[2, 1]:='';
    Cells[3, 1]:='';
  end;
  with SG_Ana2 do
  begin
    RowCount := 2;
    Cells[0, 0]:='rank';
    Cells[1, 0]:='popul. in sim';
    Cells[2, 0]:='ideal distrib.';
    Cells[3, 0]:='difference';
    Cells[0, 1]:='';
    Cells[1, 1]:='';
    Cells[2, 1]:='';
    Cells[3, 1]:='';
  end;
end;

procedure TForm2.newSerie;
var
  I, K : Integer;
  DevelVal : PTile;
  correlat  : Double;
  intercept : Real;
  last      : Real;
  steig     : Double;
  nrSer     : Integer;
  idealVal  : Double;
  sumDif    : Real;
begin
  SetLength (sSer, length(sSer)+1);
  nrSer := high(sSer);
  sSer[nrSer] := TLineSeries.Create(self);
  changeSeries.clear;
  with sSer[nrSer] do
  begin
    Clear;
    ParentChart := C_RankSize;
    VertAxis := aLeftAxis;
    Color    := clBlack;
    Pointer.Style := psCross;
    Pointer.Visible := True;
    Pointer.Size := 2;
    For I:=0 To TileList.Count -1 Do
    begin
      DevelVal := PTile(TileList.Items[I]);
      If DevelVal.nrDev > 1 Then AddXY (Log10(I+1), Log10(DevelVal.nrDev));   // -- plot if mor then one cell per tile is developed
      If DevelVal.oldRank > 0 Then changeSeries.AddXY (Log10(I+1), DevelVal.aktChange); //Log10(DevelVal.nrDev));
    end;
  end;
  tendSeries.DataSources.Clear;
  tendSeries.DataSources.Add( sSer[high(sSer)] );
  corSeries.DataSources.Clear;
  corSeries.DataSources.Add( sSer[high(sSer)] );
  intercept := roundTo(tendSeries.YValues[0],-3);
  last      := roundTo(tendSeries.YValues[1],-3);
  steig     := roundTo((last - intercept)/Log10(TileList.Count -1),-3);
  correlat  := roundTo(corSeries.YValues[0],-3);
  with SG_Ana1 do                                                             // -- values into table
  begin
    RowCount := nrSer+2;
    Cells[0, nrSer+1]:= IntToStr(steps);
    Cells[1, nrSer+1]:= FloatToStr(intercept);
    Cells[2, nrSer+1]:= FloatToStr(correlat);
    Cells[3, nrSer+1]:= FloatToStr(steig);
  end;
  SetLength (lSer, length(lSer)+1);
  lSer[high(lSer)] := TLineSeries.Create(self);
  with lSer[high(lSer)] do
  begin
    Clear;
    ParentChart := C_Linear;
    VertAxis := aLeftAxis;
    Color    := clBlack;
    Pointer.Style := psCross;
    Pointer.Visible := True;
    Pointer.Size := 2;
    For I:=0 To TileList.Count -1 Do
    begin
      DevelVal := PTile(TileList.Items[I]);
      AddXY (I+1, DevelVal.nrDev);
    end;
  end;
  sumDif := 0;
  with SG_Ana2 do                                                             // -- values into table
  begin
    RowCount := TileList.Count +2;
    For I:=0 To TileList.Count -1 Do
    begin
      Cells[0, I+1]:= IntToStr(I+1);
      DevelVal := PTile(TileList.Items[I]);
      Cells[1, I+1]:= IntToStr(DevelVal.nrDev);
      idealVal := Power(10, intercept) * Power((I+1), steig);
      idealVal := round(idealVal);
      Cells[2, I+1]:= FloatToStr(idealVal);
      Cells[3, I+1]:= FloatToStr(idealVal-DevelVal.nrDev);
      sumDif := sumDif + abs(idealVal-DevelVal.nrDev);
    end;
    sumDif := roundTo(sumDif / TileList.Count, -3);
    Cells[0, TileList.Count +1]:= 'avg. diff.';
    Cells[3, TileList.Count +1]:= FloatToStr(sumDif);
  end;
end;

end.

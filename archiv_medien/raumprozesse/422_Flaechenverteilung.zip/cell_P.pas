unit cell_P;

interface

uses
  Windows, Graphics, Classes, Math;

type
  TPot = Array [0..2] of Double;

type
  TCell = class
  private
  public
    Dist       : Integer;            // -- Distance to nexgt market
    colr       : Integer;            // -- color value of the cell
    markA      : Double;             // -- mark of all Agents
    markB      : Double;             // -- mark of returning Agents
    markH      : Double;             // -- the home gradient
    desiNr     : Integer;            // -- number of the destination                - 0 : Free
    Besetzt    : Integer;            // -- number of agents on the cell             - 1 : Blocked
    potent     : TPot;               // -- the potential values for new development - 2 : Population
    plotPNr    : Integer;            //                                             - 3 : Ressource
    //potentI    : Double;             //                                           - 5 : Industrie
    //potentS    : Double;             //                                           - 4 : Service
    //AgNr       : Integer;            // -- Index of the agent on the cell
    allBlack   : boolean;
    oldMark    : Double;
    maxM       : Extended;
    minM       : Extended;
    FPos       : TPoint;
    FSize      : Integer;
    FFillColor : Integer;
    State      : Integer;            // -- typ of the cell
    procedure Paint         (Canvas: TCanvas; what: Integer; noOrg: Boolean);
    procedure rePaint       (Canvas: TCanvas; what: Integer; noOrg: Boolean);
    procedure SetPositionX  (const Value: Integer);
    procedure SetPositionY  (const Value: Integer);
    procedure SetSize       (const Value: Integer);
    procedure SetFillColor  (const Value: Integer);
    constructor create      (xPos, yPos, size, colr: Integer);
  published
    property PositionX: Integer read FPos.X     write SetPositionX;
    property PositionY: Integer read FPos.Y     write SetPositionY;
    property Size     : Integer read FSize      write SetSize;
    property FillColor: Integer read FFillColor write SetFillColor;
  end;

// ---------------------------------------------------------------------------//

implementation

constructor TCell.create(xPos, yPos, size, colr: Integer);
begin
  inherited create;
  FPos.X := xPos;
  FPos.Y := yPos;
  FSize  := size;
  FFillColor := colr;
end;

//------------------------------------------------------------------------------

procedure TCell.SetPositionX(const Value: Integer);
begin
  FPos.X := Value;
end;

procedure TCell.SetPositionY(const Value: Integer);
begin
  FPos.Y := Value;
end;

procedure TCell.SetSize(const Value: Integer);
begin
  FSize := Value;
end;

procedure TCell.SetFillColor(const Value: Integer);
begin
  FFillColor := Value;
end;

procedure TCell.Paint(Canvas: TCanvas; what: Integer; noOrg: Boolean);
begin
  If (abs(markA - oldMark) > 1) Then rePaint(Canvas, what, noOrg);
end;

procedure TCell.rePaint(Canvas: TCanvas; what: Integer; noOrg: Boolean);
var
  scalF : Double;
  tmp   : Double;
  mark  : Double;
  tmpState : Integer;
begin
  Canvas.Pen.Width := 0;
  tmpState := state;
  If noOrg AND (state >= 2) Then tmpState := 0;
  If ((allBlack = true) AND ((state >=2) )) Then begin
    If state=3 then tmpState := 7 else tmpState := 6;
  end;
  case tmpState of
  0 : begin
      scalF := 255 / (maxM-minM);
      case what of
        0 : mark := markA;
        1 : mark := markB;
        2 : mark := potent[plotPNr];
      end;

      tmp   := (mark - minM)* scalF;
      //If mark > 0 Then tmp := tmp+10;
      If tmp > 255 then tmp := 255;
      colr  := round(255 - tmp);
      //colr  := round(tmp);
      Canvas.Pen.Color   := RGB (colr, colr, colr);
      Canvas.Brush.Color := RGB (colr, colr, colr);
    end;
  1 : begin
      Canvas.Pen.Color   := clNavy;// RGB (120, 0, 0);
      Canvas.Brush.Color := clNavy;// RGB (120, 0, 0);
    end;
  2 : begin
      Canvas.Pen.Color   := clGreen;
      Canvas.Brush.Color := clGreen;
    end;
  3 : begin
      Canvas.Pen.Color   := clLime; //clFuchsia;
      Canvas.Brush.Color := clLime; //clFuchsia;
    end;
  4 : begin
      Canvas.Pen.Color   := clRed;
      Canvas.Brush.Color := clRed;
    end;
  5 : begin
      Canvas.Pen.Color   := clHotLight;
      Canvas.Brush.Color := clHotLight;
    end;
  6 : begin
      Canvas.Pen.Color   := clBlack;
      Canvas.Brush.Color := clBlack;
    end;
  7 : begin
      Canvas.Pen.Color   := clWhite;
      Canvas.Brush.Color := clWhite;
    end;
  end;
  Canvas.Rectangle (FPos.X - FSize , FPos.Y - FSize, FPos.X + FSize, FPos.Y + FSize);
  oldMark := markA;
end;

end.

unit UsageData;

interface

uses
  SysUtils, Classes, Controls, ExtCtrls, Graphics, Windows, Forms, Dialogs, Messages;

type
  TUsageData = class(TImage)
  private
    { Private-Deklarationen }
  protected
    { Protected-Deklarationen }
  public
    { Public-Deklarationen }
    used : Integer;
    _Name      : String;
    _Competent : Integer; //Array [0..14] of Integer;
    _Connect   : Integer;
    //constructor Create(id: Integer; name: String; competent, connect: Integer);
    constructor Create(AOwner: TComponent);
  published
    { Published-Deklarationen }
  end;

implementation

constructor TUsageData.Create(AOwner: TComponent);
var
  rect   : Trect;
begin
  inherited Create (Aowner);
end;

end.

program Settlement_Pattern_05;

{%File 'ModelSupport\agenten\agenten.txvpck'}
{%File 'ModelSupport\Calcer\Calcer.txvpck'}
{%File 'ModelSupport\CellForm\CellForm.txvpck'}
{%File 'ModelSupport\cell_P\cell_P.txvpck'}
{%File 'ModelSupport\default.txvpck'}

uses
  Forms,
  CellForm in 'CellForm.pas' {Form1},
  cell_P in 'cell_P.pas',
  agenten in 'agenten.pas',
  Calcer in 'Calcer.pas',
  RankSize in 'RankSize.pas' {Form2};

{$R *.res}

begin
  Application.Initialize;
  Application.CreateForm(TForm1, Form1);
  Application.CreateForm(TForm2, Form2);
  Application.Run;
end.

(********************************************************************)
(*                                                                  *) 
(*                                                                  *)
(*                      Settlement Patterns                         *)
(*                          Version 5.0                             *)
(*                                                                  *)
(*                                                                  *)
(*     Programmierer: Reinhard K�nig                       Okt 2006 *)
(*                    http://www.entwurfsforschung.de               *)
(*                                                                  *)
(*     Last Update: Okt-02, 2006                                    *)
(*                                                                  *)
(********************************************************************) 
{revision history:

1.0     [Jun-11, 2006]
        first release to the public:
        Emergence of Interaction
1.1     [Jun-24, 2006]
        Probabilistic Interaction and Manhattan Landscape
1.2     [Jun-24, 2006]
        Evolution of Settlement Patterns
2.0     [Jun-28, 2006]
        Migration of the Origins
3.0     [Jul-11, 2006]
        Settle in Potential Field
4.0     [Jul-14, 2006]
        Different Land Use
5.0     [Okt-02, 2006]
        Analysation - Rank Size and Change
}

unit CellForm;

interface

uses
  Windows, Messages, SysUtils, Classes, Graphics, Controls, Forms, Series ,
  Dialogs, StdCtrls, cell_P, ExtCtrls, Math, agenten, calcer, TeeProcs,
  TeEngine, Chart, ComCtrls, Grids, DBGrids, TeeStore, jpeg;

type 
  PTile = ^TTile;
  TTile = Record
    nrDev    : Integer;
    oldRank  : Integer;
    aktRank  : Integer;
    aktChange: Integer;
    allChange: Integer;
    order    : Integer;
  end;

type
  TForm1 = class(TForm)
    ZeichenPanel      : TPanel;
    Timer1            : TTimer;
    Chart1            : TChart;
    Series1           : TLineSeries;
    PageControl1      : TPageControl;
    TabSheet1         : TTabSheet;
    TabSheet2         : TTabSheet;
    RadioGroup_chem   : TRadioGroup;
    rb_rulette        : TRadioButton;
    rb_hill           : TRadioButton;
    GroupBox1         : TGroupBox;
    Lbl_TextAnzahl    : TLabel;
    Label2            : TLabel;
    B_setup           : TButton;
    B_stop            : TButton;
    B_oneStep         : TButton;
    Edit_anzAg        : TEdit;
    Edit_size         : TEdit;
    GroupBox2         : TGroupBox;
    lbl_Steps         : TLabel;
    Label4            : TLabel;
    E_stop            : TEdit;
    TabSheet3         : TTabSheet;
    GroupBox4         : TGroupBox;
    CB_noTracks       : TCheckBox;
    CB_gravity        : TCheckBox;
    CB_showAB         : TCheckBox;
    CB_showAg         : TCheckBox;
    E_grav            : TEdit;
    CB_showOrig       : TCheckBox;
    B_repaint         : TButton;
    cb_noDesti        : TCheckBox;
    CB_potField       : TCheckBox;
    CB_FieldNr        : TComboBox;
    CB_migrate        : TCheckBox;
    E_migTh           : TEdit;
    E_CProbab         : TEdit;
    Label7            : TLabel;
    CB_decay          : TCheckBox;
    E_decay           : TEdit;
    E_noise           : TEdit;
    Label6            : TLabel;
    SB_wiggle         : TScrollBar;
    Lbl_wiggle        : TLabel;
    Label3            : TLabel;
    TrB_thresh        : TScrollBar;
    Lbl_B             : TLabel;
    Label1            : TLabel;
    GroupBox3         : TGroupBox;
    E_crServ          : TEdit;
    E_crAgs           : TEdit;
    Label8            : TLabel;
    Label9            : TLabel;
    Label10           : TLabel;
    E_crIndu          : TEdit;
    StringGrid1       : TStringGrid;
    B_reset           : TButton;
    Cb_allBlack       : TCheckBox;
    RadioGroup_return : TRadioGroup;
    rb_direct         : TRadioButton;
    rb_hillCl         : TRadioButton;
    B_rankSize        : TButton;
    B_saveBmp         : TButton;
    E_pName           : TEdit;
    TabSheet4         : TTabSheet;
    E_tileSz          : TEdit;
    UpD_tileSz        : TUpDown;
    GroupBox5         : TGroupBox;
    Label11           : TLabel;
    Label5            : TLabel;
    E_toSteps         : TEdit;
    E_valFrom         : TEdit;
    Label13           : TLabel;
    E_valTo           : TEdit;
    Label14           : TLabel;
    UpD_toSteps       : TUpDown;
    GroupBox6         : TGroupBox;
    CB_pop            : TCheckBox;
    CB_serv           : TCheckBox;
    CB_indu           : TCheckBox;
    CB_popNull        : TCheckBox;
    CB_servNull       : TCheckBox;
    CB_induNull       : TCheckBox;
    Label12           : TLabel;
    E_runs            : TEdit;
    UpD_runs          : TUpDown;
    CB_actAna2        : TCheckBox;
    Label15           : TLabel;
    TabSheet5         : TTabSheet;
    Label16           : TLabel;
    E_tileSz2         : TEdit;
    UpD_tileSz2       : TUpDown;
    GroupBox7         : TGroupBox;
    Label17           : TLabel;
    Label18           : TLabel;
    Label19           : TLabel;
    Label21           : TLabel;
    E_toSteps2        : TEdit;
    E_valFrom2        : TEdit;
    E_valTo2          : TEdit;
    UpD_toSteps2      : TUpDown;
    E_incre           : TEdit;
    Label20           : TLabel;
    RadioGroup1       : TRadioGroup;
    RB_serv           : TRadioButton;
    RB_indu           : TRadioButton;
    RB_pop            : TRadioButton;
    CB_actAna1        : TCheckBox;
    B_saveXML         : TButton;
    procedure ZeichenPanelMouseUp   (Sender: TObject; Button: TMouseButton; Shift: TShiftState; X, Y: Integer);
    procedure ZeichenPanelMouseMove (Sender: TObject; Shift: TShiftState; X, Y: Integer);
    procedure ZeichenPanelMouseDown (Sender: TObject; Button: TMouseButton; Shift: TShiftState; X, Y: Integer);
    procedure RadioGroup2Click(Sender: TObject);
    procedure Cb_allBlackClick(Sender: TObject);
    procedure B_resetClick    (Sender: TObject);
    procedure StringGrid1KeyUp(Sender: TObject; var Key: Word; Shift: TShiftState);
    procedure E_gravChange    (Sender: TObject);
    procedure CB_gravityClick (Sender: TObject);
    procedure CB_noTracksClick(Sender: TObject);
    procedure E_stopChange    (Sender: TObject);
    procedure B_repaintClick  (Sender: TObject);
    procedure CB_showABClick  (Sender: TObject);
    procedure E_noiseChange   (Sender: TObject);
    procedure Edit_sizeChange (Sender: TObject);
    procedure SB_wiggleChange (Sender: TObject);
    procedure B_oneStepClick  (Sender: TObject);
    procedure TrB_threshChange(Sender: TObject);
    procedure B_stopClick     (Sender: TObject);
    procedure B_setupClick    (Sender: TObject);
    procedure Timer1Timer     (Sender: TObject);
    procedure FormDestroy     (Sender: TObject);
    procedure FormCreate      (Sender: TObject);
    procedure B_rankSizeClick (Sender: TObject);
    procedure B_saveBmpClick  (Sender: TObject);
    procedure UpD_tileSzClick (Sender: TObject; Button: TUDBtnType);
    procedure E_tileSzChange  (Sender: TObject);
    procedure CB_actAna1Click (Sender: TObject);
    procedure CB_actAna2Click (Sender: TObject);
    procedure B_saveXMLClick  (Sender: TObject);
  private
    AgentList  : TList;
    cellList   : TCellList;
    limboWorld : TLimbo;
    destiList  : Array of TDestiList;
    procedure createPaintImg;
    procedure createRaster;
    procedure createAgents;
    procedure setupCells;
    procedure setupAgents(I: Integer; M: Integer);
    procedure calcAgents;
    procedure repaintAgents;
    procedure repaintCells;
    procedure checkArea   (I : Integer);
    procedure calculate;
    procedure settings;
    procedure deleter;
    procedure calcCellDist;
    procedure findMaxMin;
    procedure setDestinations;
    procedure setOrigins(Xp, Yp: Integer; M: Integer);
    procedure repaintAllCells;
    procedure whiteAgImg;
    procedure drawConns;
    procedure resetGraph;
    procedure drawCh(value1, value2, value3, value4, value5 : Integer);
    procedure calcGraph;
    procedure decayMarks;
    procedure markCell (X, Y: Integer);
    procedure newDesti(X, Y: Integer);
    procedure migrationTest (curAgent: TAgent);
    procedure maxPotPlace (var maxPlace: TPoint; var maxPot: Double; M: Integer);
    procedure setNewDestinations;
    procedure diffuse;
    procedure setGridValues;
    procedure setupGrid;
    procedure rescalePot;
    procedure rescaleMarks;
    procedure rankSize;
    procedure setupAna1;
    procedure Analysis1;
    procedure newWeightRound;
    procedure setupAna2;
    procedure Analysis2;
    procedure newNoiseRound(aktVal: Real);
    procedure saveBmp;
    procedure speedMeasure;
    procedure setupRankList;
    procedure saveXLS;
    Procedure BmpToJpg(const Filename: String; Quality: TJPEGQualityRange=100);
  public

end;

var
  Form1    : TForm1;
  paintImg : TImage;
  agentImg : TImage;
  TileList : TList;
  steps    : Integer;

implementation

{$R *.dfm}
uses RankSize;

const
  AgSize = 2;                    //-- Agenten gr��e

var
  reih     : Integer;            //-- Zellen-Reihen gesamt
  spalt    : Integer;            //-- Zellen-Spalten gesamt
  sSteps   : Integer;
  cellScal : Integer;            //-- Zellen  gr��e
  halfScal : Integer;
  maxM     : Extended;           //-- maximal mark value
  minM     : Extended;           //-- minimal mark value
  stopTime : Integer;
  aktDesti : Integer;            // actual Desination number for the new destination
  sSer, tSer, eSer, xSer, cSer : TLineSeries;    //-- series for graph-plotting
  rDown, lDown, sDown : Boolean;     //-- for mouse interaction
  diffCoef : Array [0..2] of Real;   //-- diffusion coefficiernts
  wghtPop  : Array [0..2] of Real;   //-- weights for population
  wghtServ : Array [0..2] of Real;   //-- weights for services
  wghtInd  : Array [0..2] of Real;   //-- weights for industries
  noise    : Array [0..2] of Real;
  homeMode : Integer;                //-- if agents walk home directly 0 or use existing tracks 1
  nbS      : Cardinal;               // -- tile size for the rank-size
  Frames, StartTick : Cardinal;           // -- for the fps measure
  ana1, ana2 : Boolean;
  aktVal     : Real;
  who        : Byte;
  whoR       : Array [0..2] of Boolean;
  gProced    : Cardinal;

// ---------------------------------------------------------------------------//
// *** Initialisierung *********************************************************
procedure TForm1.FormCreate(Sender: TObject);
begin
  settings;
  CB_FieldNr.AddItem('1', Sender);
  CB_FieldNr.AddItem('2', Sender);
  CB_FieldNr.AddItem('3', Sender);
  CB_FieldNr.ItemIndex := 0;
  setupGrid;
  setGridValues;
end;

// *****************************************************************************
procedure TForm1.settings;
var
  I : Integer;
begin
  cellScal  := StrToInt(Edit_size.Text) ;
  halfScal  := Floor(cellScal/2);
  spalt     := round (ZeichenPanel.Width / cellScal);
  reih      := round (ZeichenPanel.Height / cellScal);
  stopTime  := StrToInt(E_stop.Text);
  Lbl_B.Caption := IntToStr(TrB_thresh.Position) + ' Grad';
  Lbl_wiggle.Caption := IntToStr(SB_wiggle.Position) + ' Grad';
  AgentList := TList.Create;
  SetLength(cellList, spalt, reih);
  For I := 0 To 2 do SetLength(limboWorld[I], spalt, reih);
  If rb_direct.checked Then homeMode := 0;
  If rb_hillCl.checked Then homeMode := 1;
  createPaintImg;
  CreateRaster;
  //CreateAgents;
  ZeichenPanel.Enabled := true;
  ZeichenPanel.DoubleBuffered := True;
  steps := 0;
  //calcCellDist;
  setDestinations;
  //setOrigins;
  resetGraph;
  nbS  := UpD_tileSz.Position;
  ana1 := CB_actAna1.Checked;
  ana2 := CB_actAna2.Checked;
  gProced := 0;
  setupRankList;
end;
// ---------------------------------------------------------------------------//
// ------------------------- Elemente erstellen ------------------------------//
// ---------------------------------------------------------------------------//

// *** Legt eine leere Zeichenfl�che �ber das Zeichenpanel *********************
procedure TForm1.createPaintImg;
begin
  paintImg        := TImage.Create(self);
  paintImg.Parent := ZeichenPanel;
  paintImg.top    := 0;
  paintImg.Left   := 0;
  paintImg.Height := ZeichenPanel.Height;
  paintImg.Width  := ZeichenPanel.Width;
  paintImg.Enabled:= False;                  // -- does not reakt on mouseEvents

  agentImg        := TImage.Create(self);
  agentImg.Parent := ZeichenPanel;
  agentImg.top    := 0;
  agentImg.Left   := 0;
  agentImg.Height := ZeichenPanel.Height;
  agentImg.Width  := ZeichenPanel.Width;
  agentImg.Transparent := true;
  agentImg.Enabled:= False;
end;

// *****************************************************************************
procedure TForm1.CreateAgents;
var
  I, M, L  : Integer;
  curAgent : TAgent;
begin
  M := 0;
  for L := 1 to StrToInt(E_crAgs.Text) do  // -- three population units for one industrial
  begin
    curAgent := TAgent.Create;
    AgentList.Add (curAgent);
    I := AgentList.Count-1;
    setupAgents(I, M);
  end;
  setNewDestinations;
end;

// *** Agenten initialisieren **************************************************
procedure TForm1.setupAgents(I: Integer; M: Integer);
var
  curAgent : TAgent;
  curCell  : TCell;
  maxPlace : TPoint;
  maxPot   : Double;
begin
  curAgent := AgentList.Items [I];
  maxPotPlace (maxPlace, maxPot, M);
  curAgent.onCell.X := maxPlace.X;
  curAgent.onCell.Y := maxPlace.Y;
  curCell           := CellList[curAgent.onCell.X, curAgent.onCell.Y];
  curCell.Besetzt   := curCell.Besetzt + 1;
  curAgent.Home.X   := curAgent.onCell.X;
  curAgent.Home.Y   := curAgent.onCell.Y;
  curAgent.PosX     := curAgent.onCell.X * cellScal + halfScal;
  curAgent.PosY     := curAgent.onCell.Y * cellScal + halfScal;
  curAgent.Size     := AgSize;
  curAgent.succeed  := 0;
  curAgent.Heading  := random (360);
  curAgent.Modus    := 0;                       // --- 0 for exploration mode // --- 1 for returning mode
  curAgent.settled  := 0;
  curAgent.travTime := 0;
  repaintAgents;
  setOrigins(curAgent.Home.X, curAgent.Home.Y, M);
end;

// *** set the origin places **********************************************
procedure TForm1.setOrigins(Xp, Yp: Integer; M: Integer);
var
  curCell : TCell;
  bVal    : Real;
begin
  //torus(Xp, Yp, spalt, reih);
  bVal := 1;
  curCell           := cellList[Xp, Yp];                     // --- 3 for ressource
  curCell.state     := 2;//;3 + M;                           // --- 2 for population | 4 for service | 5 for industry
  curCell.potent[0] := curCell.potent[0] + wghtPop[0]  * bVal;
  curCell.potent[1] := curCell.potent[1] + wghtServ[0] * bVal;
  curCell.potent[2] := curCell.potent[2] + wghtInd[0]  * bVal;
  curCell.rePaint(paintImg.Canvas, 0, cb_noDesti.Checked);
end;

// *** Agenten initialisieren **************************************************
procedure TForm1.setNewDestinations;
var
  curCell  : TCell;
  maxPlace : TPoint;
  maxPot   : Double;
  M, L     : Integer;
  bVal     : Real;
begin
  bVal := 1;
  // -- with each new population-agent one industrial and ond service resource are to create--
  for L := 1 to StrToInt(E_crServ.Text) do  // -- eg three population units for one industrial
  begin
    M := 1;
    maxPotPlace (maxPlace, maxPot, M);
    curCell           := cellList[maxPlace.X, maxPlace.Y];
    curCell.state     := 4; //3 + M;                     // --- 4 for service
    curCell.potent[0] := curCell.potent[0] + wghtPop[1]  * bVal;
    curCell.potent[1] := curCell.potent[1] + wghtServ[1] * bVal;
    curCell.potent[2] := curCell.potent[2] + wghtInd[1]  * bVal;
    curCell.rePaint(paintImg.Canvas, 0, cb_noDesti.Checked);
  end;
  for L := 1 to StrToInt(E_crIndu.Text) do
  begin
    M := 2;
    maxPotPlace (maxPlace, maxPot, M);
    curCell           := cellList[maxPlace.X, maxPlace.Y];
    curCell.state     := 5; //3 + M;                     // --- 5 for industry
    curCell.potent[0] := curCell.potent[0] + wghtPop[2]  * bVal;
    curCell.potent[1] := curCell.potent[1] + wghtServ[2] * bVal;
    curCell.potent[2] := curCell.potent[2] + wghtInd[2]  * bVal;
    curCell.rePaint(paintImg.Canvas, 0, cb_noDesti.Checked);
  end;
end;

// *** find the place with the max potential and the corresponding value *******
procedure TForm1.maxPotPlace (var maxPlace: TPoint; var maxPot: Double; M: Integer);
var
  curCell : TCell;
  I, K    : Integer;
begin
  maxPot     := 0;
  maxPlace.X := 0;
  maxPlace.Y := 0;
  for I := 0 to reih -1 do
  begin
    for K := 0 to spalt -1 do
    begin
      curCell   := cellList[K,I];
      If curCell.potent[M] > maxPot Then
      begin
        If curCell.state = 0 Then begin
          maxPot     := curCell.potent[M];
          maxPlace.X := K;
          maxPlace.Y := I;
        end;
      end;
    end;
  end;
end;

// *** Zellen erstellen ********************************************************
procedure TForm1.CreateRaster;
var
  curCell : TCell;
  I       : Integer;
  K       : Integer;
begin
  for I := 0 to reih -1 do
  begin
    for K := 0 to spalt -1 do
    begin
      curCell := TCell.Create(halfScal + K * cellScal, halfScal + I * cellScal, halfScal, 0);
      cellList[K,I] := curCell;
    end;
  end;
  setupCells;
end;

// *** Zellen initialisieren ***************************************************
procedure TForm1.setupCells;
var
  curCell : TCell;
  I, K    : Integer;
begin
  //Randomize();
  for I := 0 to reih -1 do
  begin
    for K := 0 to spalt -1 do
    begin
      curCell         := cellList[K,I];
      curCell.colr    := 255;
      curCell.state   := 0;
      curCell.maxM    := 1;
      curCell.markA   := 0;
      curCell.markB   := curCell.markA;
      curCell.oldMark := curCell.markA;
      curCell.Besetzt := 0;
      curCell.allBlack := Cb_allBlack.Checked;
    end;
  end;
  findMaxMin;
  repaintCells;
end;

// *****************************************************************************
procedure TForm1.calcCellDist;
var
  onCell   : TCell;
  curCell  : TCell;
  I, K     : Integer;
  cellPos  : TPoint;
begin
  onCell    := cellList[round(spalt/2), round(reih/2)];
  for I := 0 to reih -1 do
  begin
    for K := 0 to spalt -1 do
    begin
      curCell   := cellList[K,I];
      cellPos.X := curCell.FPos.X;
      cellPos.Y := curCell.FPos.Y;
      // -- calculate and sum the distances --
      curCell.Dist    := calcDistance(cellPos.X, cellPos.Y, onCell.FPos.X,onCell.FPos.Y);
      curCell.markH   := (1000 - curCell.Dist)*10;
    end;
  end;
end;

// *** set the destination places **********************************************
procedure TForm1.setDestinations;
var
  curCell : TCell;
  pos     : TPoint;
  Xp, Yp  : Integer;
  M, I, K : Integer;
begin
  //Randomize();
  SetLength (destiList, 0);
  // --- 10 random destinations ---
  for M := 0 to 9 do
  begin
    pos.X := random(spalt);
    pos.Y := random(reih);
    SetLength (destiList, length(destiList)+1);                               // -- save the coordinates of the destination-core in a list
    destiList[high(destiList)].Pos.X   := pos.X * cellScal + halfScal;
    destiList[high(destiList)].Pos.Y   := pos.Y * cellScal + halfScal;
    destiList[high(destiList)].numbers := 0;
    for I := -1 to 1 do
    begin
      for K := -1 to 1 do
      begin
        Xp := pos.X + K;
        Yp := pos.Y + I;
        torus(Xp, Yp, spalt, reih);
        curCell         := cellList[Xp, Yp];
        curCell.state   := 3;
        //curCell.markB   := 10;                                            // --- 3 for destination-state
        curCell.desiNr  := M;
        curCell.potent[2] := curCell.potent[2] + 1;
        curCell.rePaint(paintImg.Canvas, 0, cb_noDesti.Checked);
      end;
    end;
  end;
end;

// ---------------------------------------------------------------------------//
// ---------------------------- Berechnungen ---------------------------------//
// ---------------------------------------------------------------------------//

// *** Rekursive Befehle ausf�hren *********************************************
procedure TForm1.Timer1Timer(Sender: TObject);
begin
  calculate;
end;

// *** Rekursive Befehle ausf�hren ***
procedure TForm1.whiteAgImg;
begin
  agentImg.Canvas.brush.Color := clWhite;
  agentImg.Canvas.pen.Color   := clWhite;
  agentImg.Canvas.Rectangle(0,0,ZeichenPanel.Height,ZeichenPanel.Width);
end;

// *****************************************************************************
procedure TForm1.calculate;
begin
  diffuse;
  //calcCellDist;
  If AgentList.Count < StrToInt(Edit_anzAg.Text) Then CreateAgents;
  rescalePot;
  findMaxMin;
  whiteAgImg;
  repaintCells;
  If CB_gravity.Checked = True Then drawConns;
  If CB_showAg.Checked  = True Then repaintAgents;
  calcAgents; // -- ver�ndert die Position der Agenten
  If CB_decay.Checked Then
  begin
    decayMarks;
  end else begin
    rescaleMarks;
  end;
  steps := steps +1;
  lbl_Steps.Caption := intToStr (steps);
  calcGraph;
  inc(sSteps);
  If sSteps = 100 Then begin
    rankSize;                                                                 // -- rank-size calculation
    sSteps := 0;
  end;
  If ana1 Then Analysis1;
  If ana2 Then Analysis2;
  If steps = stopTime Then timer1.enabled := false;
  speedMeasure;
end;

// *** fps measure *************************************************************
procedure TForm1.speedMeasure;
var
  Framespersecond   : Cardinal;
begin
  Inc(Frames);
  if GetTickCount - StartTick >=1000 then
  begin  
    Framespersecond:= round(Frames/(GetTickCount - StartTick)*1000);
    StartTick := GetTickCount;
    Frames := 0;
    Form1.Caption := 'Group seperation || ' + 'fps= ' + IntToStr(Framespersecond);
  end;
end;

// *****************************************************************************
// ********************* Analysis 1 ********************************************
// *****************************************************************************
procedure TForm1.setupAna1;
begin
  If CB_pop.Checked  Then whoR[0] := true Else whoR[0] := false;
  If CB_serv.Checked Then whoR[1] := true Else whoR[1] := false;
  If CB_indu.Checked Then whoR[2] := true Else whoR[2] := false;
  If CB_popNull.Checked Then begin
    StringGrid1.Cells[2, 1]:='0,0';
    StringGrid1.Cells[3, 1]:='0,0';
    StringGrid1.Cells[4, 1]:='0,0';
    E_crAgs.Text := '0';
  end;
  If CB_servNull.Checked Then begin
    StringGrid1.Cells[2, 2]:='0,0';
    StringGrid1.Cells[3, 2]:='0,0';
    StringGrid1.Cells[4, 2]:='0,0';
    E_crServ.Text := '0';
  end;
  If CB_induNull.Checked Then begin
    StringGrid1.Cells[2, 3]:='0,0';
    StringGrid1.Cells[3, 3]:='0,0';
    StringGrid1.Cells[4, 3]:='0,0';
    E_crIndu.Text := '0';
  end;
  aktVal := StrToFloat(E_valFrom2.Text);
  newWeightRound;
  E_stop.Text := E_toSteps2.Text;
  setGridValues;
end;

// *****************************************************************************
procedure TForm1.Analysis1;
begin
  If Steps >= StrToInt(E_toSteps.Text) Then                                   // -- timesteps per value
  begin
    saveBmp;                                                                  // -- save the forms as bitmaps
    If gProced > UpD_runs.Position Then                                       // -- all rounds calculated
    begin
      Timer1.enabled := false;
      exit;
    end;
    steps := 0;
    newWeightRound;
    inc(gProced);
  end;
end;

// *****************************************************************************
procedure TForm1.newWeightRound;
var
  I, K : Byte;
  fromV, toV, newV: Real;
begin
  fromV := StrToFloat(E_valFrom.Text);
  toV   := StrToFloat(E_valTo.Text);
  E_pName.Text := '';
  For K:=0 To 2 Do
  begin
    If whoR[K] Then
    begin
      E_pName.Text := E_pName.Text + 'V' + FloatToStr(K+1);
      For I:=0 To 2 Do
      begin
        newV := roundTo((Random() * (toV-fromV))+fromV, -2);
        E_pName.Text := E_pName.Text + '_' +FloatToStr(newV)+'_';
        StringGrid1.Cells[I+2, K+1]:=FloatToStr(newV);
      end;
    end;
  end;
  E_pName.Text := E_pName.Text +'pic_';
  deleter;
  settings;
  Form2.resetGraph;
  setGridValues;
end;

// *****************************************************************************
// ********************* Analysis 2 ********************************************
// *****************************************************************************
procedure TForm1.setupAna2;
begin
  If RB_pop.Checked  Then who := 1;
  If RB_serv.Checked Then who := 2;
  If RB_indu.Checked Then who := 3;
  aktVal := StrToFloat(E_valFrom2.Text);
  newNoiseRound(aktVal);
  E_stop.Text := E_toSteps2.Text;
  setGridValues;
end;

// *****************************************************************************
procedure TForm1.Analysis2;
begin
  If Steps >= StrToInt(E_toSteps2.Text) Then                                  // -- timesteps per value
  begin
    E_pName.Text := FloatToStr(who)+'_'+FloatToStr(aktVal)+'_pic_';           // -- save the forms as bitmaps
    saveBmp;
    saveXLS;
    aktVal := aktVal + StrToFloat(E_incre.Text);
    If aktVal > StrToFloat(E_valTo2.Text) Then                                // -- iterate the range from start value to end value
    begin
      Timer1.enabled := false;
      exit;
    end;
    steps := 0;
    newNoiseRound(aktVal);
  end;
end;

// *****************************************************************************
procedure TForm1.newNoiseRound(aktVal: Real);
begin
  StringGrid1.Cells[5, who]:= FloatToStr(aktVal);
  deleter;
  settings;
  Form2.resetGraph;
  setGridValues;
end;

// *****************************************************************************
// *****************************************************************************
// *****************************************************************************
Function CompareTiles (Item1, Item2 : Pointer) : Integer;
var
  val1, val2 : PTile;
Begin
  val1 := PTile(Item1);
  val2 := PTile(Item2);
  if val1.nrDev > val2.nrDev Then
    Result := -1
  Else if val1.nrDev < val2.nrDev Then
    Result := +1
  Else
    Result := 0;
End;

// *****************************************************************************
Function CompareOrder (Item1, Item2 : Pointer) : Integer;
var
  val1, val2 : PTile;
Begin
  val1 := PTile(Item1);
  val2 := PTile(Item2);
  if val1.order > val2.order Then
    Result := +1
  Else if val1.order < val2.order Then
    Result := -1
  Else
    Result := 0;
End;

// *****************************************************************************
procedure TForm1.setupRankList;
var
  L, M  : Integer;
  tiles : Cardinal;
  fDevel: ^TTile;
  idx   : Integer;
begin
  TileList  := TList.Create;
  tiles := Floor((reih) / nbS);
  //setLength(TileOrder, tiles*tiles);
  idx :=0;
  For L := 0 to tiles-1 Do
  begin
    For M := 0 to tiles-1 Do
    begin
      new(fDevel);
      fDevel.oldRank :=0;
      fDevel.aktRank :=0;
      fDevel.aktChange := 0;
      fDevel.allChange := 0;
      fDevel.order   := idx;
      //TileOrder[idx] := idx;    // -- first setting
      TileList.Add (fDevel);
      inc(idx);
    end;
  end;
end;

// *****************************************************************************
procedure TForm1.rankSize;
var
  curCell    : TCell;
  I, K, L, M : Integer;
  tiles            : Cardinal;
  inReih, inSpalt  : Cardinal;
  nbSizeR, nbSizeS : Cardinal;
  fDevel   : PTile;
  histoDev : PTile;
  idx      : Integer;
  which    : Integer;
begin
  nbSizeR := nbS;
  nbSizeS := nbS;
  inSpalt := 0;
  inReih  := 0;
  tiles   := Floor((reih) / nbS);
  idx     := 0;
  For L := 0 to tiles-1 Do
  begin
    For M := 0 to tiles-1 Do
    begin
      // --- one tile ------------------------
      fDevel := PTile(TileList.Items[idx]);
      fDevel.nrDev := 0;
      For I := inReih to inReih + nbSizeR-1 do                                // -- reihe
      begin
        For K := inSpalt to inSpalt + nbSizeS-1 do                            // -- spalte
        begin
          curCell := cellList[K,I];
          IF (curCell.state > 1) and Not(curCell.state =3) Then begin         // -- include the resources, state 3
            inc(fDevel.nrDev);
          end;
        end;
      end;
      inc(idx);
      // -------------------------------------
      inSpalt := inSpalt + nbSizeS;
      If (inSpalt + nbSizeS) > spalt-1 Then nbSizeS := (spalt - inSpalt);
    end;
    inReih  := inReih + nbSizeR;
    inSpalt := 0;
    nbSizeS := nbS;
    If (inReih + nbSizeR) > reih-1 Then nbSizeR := (reih - inReih);
  end;
  TileList.Sort (CompareTiles);                                               // -- sort the ranks
  for I:=0 to TileList.Count-1 do
  begin
    histoDev := PTile(TileList.Items[I]);                                     // -- tileOrder save the original tile order
    If histoDev.nrDev > 1 Then
    begin                                                                     // -- save new and old rank
      histoDev.aktRank :=I+1;
    end;
    If histoDev.oldRank > 0 Then
    begin
      histoDev.aktChange := 0;
      histoDev.aktChange := histoDev.aktRank - histoDev.oldRank;            // -- calculate the changes
      histoDev.allChange := histoDev.allChange + histoDev.aktChange;
    end;
    histoDev.oldRank := histoDev.aktRank;
  end;
  Form2.newSerie;
  TileList.Sort (CompareOrder);                                               // -- "sort back" to the original order
end;

// *** scale the potential values **********************************************
procedure TForm1.rescalePot;
var
  curCell : TCell;
  I, K, M : Integer;
  maxPot  : TPot;
  minPot  : TPot;
  scalF   : Double;
begin
  for M := 0 to 2 do
    begin
    maxPot[M] := 0.00000001;
    minPot[M] := 9999999999;
    // -- find the max potential --
    for I := 0 to reih -1 do
    begin
      for K := 0 to spalt -1 do
      begin
        curCell   := cellList[K,I];
        If curCell.potent[M] > maxPot[M] Then maxPot[M] := curCell.potent[M];
        If curCell.potent[M] < minPot[M] Then minPot[M] := curCell.potent[M];
      end;
    end;
    // -- scale the potential values --
    scalF := 10 / (maxPot[M]-minPot[M]);
    for I := 0 to reih -1 do
    begin
      for K := 0 to spalt -1 do
      begin
        curCell   := cellList[K,I];
        curCell.potent[M] := (curCell.potent[M] - minPot[M]) * scalF;
      end;
    end;
  end;
end;

// *** find the max and min of the mark values *********************************
procedure TForm1.rescaleMarks;
var
  curCell : TCell;
  I, K, M : Integer;
  scalF   : Double;
  maxMark : Array[0..1] of Double;
  minMark : Array[0..1] of Double;
begin
  for M := 0 to 1 do begin
    maxMark[M] := 0.1;
    minMark[M] := 99999999999;
  end;
  for I := 0 to reih -1 do
  begin
    for K := 0 to spalt -1 do
    begin
      curCell   := cellList[K,I];
      // -- find the max. and min. markA & B values --
      If curCell.markA > maxMark[1] Then maxMark[1] := curCell.markA;
      If curCell.markA < minMark[1] Then minMark[1] := curCell.markA;
      If curCell.markB > maxMark[0] Then maxMark[0] := curCell.markB;
      If curCell.markB < minMark[0] Then minMark[0] := curCell.markB;
    end;
  end;
  // -- scale the markA & B values --
  for M := 0 to 1 do
  begin
    scalF := 255 / (maxMark[M]-minMark[M]);
    for I := 0 to reih -1 do
    begin
      for K := 0 to spalt -1 do
      begin
        curCell   := cellList[K,I];
        If M = 0 Then begin
          IF curCell.markB > 0 Then
            curCell.markB := (curCell.markB - minMark[M]) * scalF;
        end else begin
          curCell.markA := (curCell.markA - minMark[M]) * scalF;
        end
      end;
    end;
  end;
end;

// *** find the max and min of the mark values *********************************
procedure TForm1.findMaxMin;
var
  curCell : TCell;
  I, K    : Integer;
  fieldNr : Integer;
begin
  fieldNr := CB_FieldNr.ItemIndex;
  maxM      := 0.1;
  minM      := 99999999999;
  for I := 0 to reih -1 do
  begin
    for K := 0 to spalt -1 do
    begin
      curCell   := cellList[K,I];
      curCell. plotPNr := fieldNr;
      If curCell.state = 0 Then begin
        If CB_potField.Checked Then begin
          If curCell.potent[fieldNr] > maxM Then maxM := curCell.potent[fieldNr];
          If curCell.potent[fieldNr] < minM Then minM := curCell.potent[fieldNr];
        end else begin
          If CB_showAB.Checked Then begin
            If curCell.markB > maxM Then maxM := curCell.markB;
            If curCell.markB < minM Then minM := curCell.markB;
          end else begin
            If curCell.markA > maxM Then maxM := curCell.markA;
            If curCell.markA < minM Then minM := curCell.markA;
          end;
        end;
      end;
    end;
  end;
end;

// *** diffuse the mark-values *************************************************
procedure TForm1.diffuse;
var
  curCell  : TCell;
  I, K     : Integer;
  randomW  : Double;
begin
  for I := 0 to reih -1 do
  begin
    for K := 0 to spalt -1 do
    begin
      checkNei (K, I, spalt, reih, limboWorld, cellList);
    end;
  end;
  for I := 0 to reih -1 do
  begin
    for K := 0 to spalt -1 do
    begin
      curCell := cellList[K,I];
      randomW := random();
      curCell.potent[0] := curCell.potent[0] + diffCoef[0]* limboWorld[0, K, I] +(randomW * noise[0]); // -- dVal is here the stregth of the error term
      curCell.potent[1] := curCell.potent[1] + diffCoef[1]* limboWorld[1, K, I] +(randomW * noise[1]);
      curCell.potent[2] := curCell.potent[2] + diffCoef[2]* limboWorld[2, K, I] +(randomW * noise[2]);
    end;
  end;
end;

//******************************************************************************
procedure TForm1.calcGraph;
var
  curAgent   : TAgent;
  I          : Integer;
  allsucceed : Integer;
  numAg      : Integer;
  returnAg   : Integer;
  migSum     : Integer;
  nrReturn   : Integer;
begin
  numAg      := AgentList.Count;
  allsucceed := 0;
  returnAg   := 0;
  migSum     := 0;
  nrReturn   := 0;
  for I := 0 to AgentList.Count - 1 do
  begin
    curAgent   := AgentList.Items [I];
    nrReturn   := nrReturn + curAgent.modus;
    allsucceed := allsucceed + curAgent.succeed;
    returnAg   := returnAg + curAgent.travTime;
    migSum     := migSum + curAgent.settled;
  end;
  If migSum     > 0 Then migSum     := round((migSum     / numAg) *100);
  If allsucceed > 0 Then allsucceed := round((allsucceed / numAg) *100);
  If returnAg   > 0 Then returnAg   := round((returnAg   / numAg) *100);
  If nrReturn   > 0 Then nrReturn   := round((nrReturn   / numAg) *100);
  drawCh(allsucceed, returnAg, 0, migSum, nrReturn);
end;

// ---------------------------------------------------------------------------//
// ---------------------------------------------------------------------------//
//--- Ausgabe in Graph --- *****************************************************
procedure TForm1.drawCh(value1, value2, value3, value4, value5 : Integer);
begin
  sSer.AddXY(steps, value1);
  eSer.AddXY(steps, value2);
  //tSer.AddXY(steps, maxM);
  xSer.AddXY(steps, value4);
  cSer.AddXY(steps, value5);
end;

//******************************************************************************
procedure TForm1.resetGraph;
begin
  with Chart1 do
  begin
    RemoveAllSeries;
    Title.Text.Clear;                                // Title of the Chart
    Title.Text.Add('average values');

    sSer := TLineSeries.Create(nil);                 // Create first Series
    sSer.Clear;                                      // Clear it
    sSer.Title := 'successful Ag`s';                 // set the title
    sSer.ParentChart := Chart1;                      // determine the chart, this series belongs to
    sSer.VertAxis := aRightAxis;

    tSer := TLineSeries.Create(nil);                 // create the second Series
    tSer.Clear;
    tSer.Title       := 'max mark';
    tSer.ParentChart := Chart1;
    tSer.VertAxis := aRightAxis;                     // this series uses the right axis
    tSer.LinePen.Width := 1;

    eSer := TLineSeries.Create(nil);                 // create the second Series
    eSer.Clear;
    eSer.Title       := 'avg travel time';
    eSer.ParentChart := Chart1;
    eSer.VertAxis := aLeftAxis;
    eSer.LinePen.Width := 2;

    xSer := TLineSeries.Create(nil);                 // create the second Series
    xSer.Clear;
    xSer.Title       := 'migrated Ag`s';
    xSer.ParentChart := Chart1;
    xSer.VertAxis := aRightAxis;
    xSer.LinePen.Width := 1;

    cSer := TLineSeries.Create(nil);                 // create the second Series
    cSer.Clear;
    cSer.Title       := 'returning';                 // all agents on the way home
    cSer.ParentChart := Chart1;
    cSer.VertAxis := aRightAxis;
    cSer.LinePen.Width := 2;
  end;
end;

// *****************************************************************************
// *** Ver�ndert die Position der Agenten **************************************
// *****************************************************************************
procedure TForm1.calcAgents;
var
  curAgent : TAgent;
  fromCell : TCell;
  curCell  : TCell;
  I        : Integer;
  tempPos  : TPoint;
  horizon  : Integer;
  wiggle   : Integer;
  method   : Integer;
  noise    : Integer;
  cProbab  : Real;
  dX, dY : Integer;
begin
  horizon := TrB_thresh.Position;
  wiggle  := SB_wiggle.Position;
  noise   := round(StrToFloat(E_noise.Text));
  cProbab := StrToFloat(E_cProbab.Text);
  If rb_rulette.Checked = true Then begin method := 1; end
  else begin If rb_hill.Checked = true Then method := 2; end;
  for I := 0 to AgentList.Count - 1 do
  begin
    curAgent := AgentList.Items [I];
    // --- look to home cell in returning mode ---
    If curAgent.Modus = 1 Then
    begin
      dX := curAgent.Home.X - curAgent.onCell.X;
      dY := curAgent.Home.Y - curAgent.onCell.Y;
      curAgent.Heading := round((arcTan2(dY, dX)) *RadToDeg);
    end;
    // --- where to go ---
    checkArea (I);
    curAgent.ChangeHeading(horizon, homeMode, wiggle, method, noise);         // -- Richtungsspektrum und Distanz
    // --- execute the step ----
    tempPos.X := curAgent.onCell.X + curAgent.stepX;
    tempPos.Y := curAgent.onCell.Y + curAgent.stepY;
    inc(curAgent.travTime);
    torus     (tempPos.X, tempPos.Y, spalt, reih);                            // -- Torus --
    curCell   := cellList[tempPos.X, tempPos.Y];
    fromCell  := cellList[curAgent.onCell.X, curAgent.onCell.Y];
    If (curAgent.Modus = 1)  Then fromCell.markB := fromCell.markB + 10;      // -- mark the way home
    // --- change the agent's mode ---
    If (curAgent.Modus = 1) And (curAgent.onCell.X = curAgent.Home.X) AND (curAgent.onCell.Y = curAgent.Home.Y) Then
    begin
      curAgent.Modus   := 0;                                                  // -- agent is at home again
      curAgent.succeed := 1;
      curAgent.heading := curAgent.heading + 180;
      inc(destiList[curAgent.DestiNr].numbers);
      curAgent.travTime := 0;
    end;
    If (curCell.State >= 3) And (curAgent.Modus = 0) And
       (cProbab >= random()) Then                                             // -- probability to consume the resource
    begin
      curAgent.Modus   := 1;                                                  // -- agents has found a destination an has to return home
      curAgent.DestiNr := curCell.desiNr;
    end;                                                                      // -- Wenn Zelle frei, Agent bewegen
    If NOT (curCell.State = 1) Then
    begin
      fromCell.markA   := fromCell. markA + 1;                               // -- mark all visited places
      curAgent.onCell.X  := tempPos.X;
      curAgent.onCell.Y  := tempPos.Y;
      curAgent.PosX      := curAgent.onCell.X * cellScal + halfScal;
      curAgent.PosY      := curAgent.onCell.Y * cellScal + halfScal;
      fromCell.Besetzt   := fromCell.Besetzt - 1;
      curCell.Besetzt    := curCell.Besetzt + 1;                              // -- Zelle unter Agent als besetzt markieren.
      //curCell.AgNr       := I;
    end else begin
      curAgent.Heading := curAgent.Heading + random(360);
      angelBorder (curAgent.FHeading);
    end;
    If (curAgent.settled = 0) AND CB_migrate.checked Then migrationTest(curAgent);
  end;
end;

// *** test for migration ******************************************************
procedure TForm1.migrationTest (curAgent: TAgent);
var
  sum     : Integer;
  thresh  : Integer;
  curCell : TCell;
  oldState: Integer;
begin
  sum     := 0;
  thresh  := StrToInt(E_migTh.Text);
  checkNeiAg (curAgent.onCell.X, curAgent.onCell.Y, spalt, reih, sum, cellList);
  curCell := CellList[curAgent.onCell.X, curAgent.onCell.Y];
  If (sum >= thresh) And (curCell.State = 0) Then                    // -- migrate only to empty cells
  begin
    curCell          := CellList[curAgent.Home.X, curAgent.Home.Y];
    oldState         := curCell.state;
    curCell.state    := 0;                                           // -- leave the old origin
    If curCell.potent[oldState -2] > 1 Then
      curCell.potent[oldState -2] := curCell.potent[oldState -3] -1
      else curCell.potent[oldState -2] := 0;
    curAgent.Home.X  := curAgent.onCell.X;                           // -- set the new origin
    curAgent.Home.Y  := curAgent.onCell.Y;
    curAgent.settled := 1;                                           // -- migration ist possible only once
    curCell          := CellList[curAgent.Home.X, curAgent.Home.Y];
    curCell.state    := oldState;                                    // --- 3 for origin-state population
    curCell.potent[oldState -2]   := curCell.potent[oldState -2] + 1;
    curCell.rePaint(paintImg.Canvas, 0, cb_noDesti.Checked);
  end;
end;

// *****************************************************************************
procedure TForm1.drawConns;
var
  I        : Integer;
  homePos  : TPoint;
  scale    : Real;
begin
  scale := StrToFloat(E_grav.Text);
  paintImg.Canvas.Pen.Color := clMaroon;
  paintImg.Canvas.Pen.Style := psSolid;
  homePos.X := round(spalt/2)* cellScal + halfScal;;
  homePos.Y := round(reih/2) * cellScal + halfScal;;
  for I := 0 to High(destiList) do
  begin
    IF destiList[I].numbers > 1 Then
    begin
      paintImg.Canvas.Pen.Width := round(destiList[I].numbers/steps * scale);
      paintImg.Canvas.MoveTo(destiList[I].Pos.X, destiList[I].Pos.Y);
      paintImg.Canvas.LineTo(homePos.X, homePos.Y);
    end;
  end;
end;

// *****************************************************************************
procedure TForm1.repaintCells;
var
  curCell  : TCell;
  I, K     : Integer;
  what     : Integer;
  rect     : TRect;
begin
  If (CB_noTracks.checked) OR (CB_showOrig.checked)Then begin
    rect.Left := 0; rect.Top := 0; rect.Right := ZeichenPanel.Width; rect.Bottom := ZeichenPanel.Height;
    paintImg.Canvas.Brush.Color := clWhite;
    paintImg.Canvas.FillRect(rect);
  end;
  If NOT (CB_noTracks.checked)Then begin
    If CB_potField.Checked Then begin
      repaintAllCells;
    end else If CB_showAB.Checked Then begin
      what := 1;
    end else begin
      what := 0;
    end;

    for I := 0 to reih -1 do
    begin
      for K := 0 to spalt -1 do
      begin
        curCell := cellList[K,I];
        curCell.maxM := maxM;
        curCell.minM := minM;
        If CB_showOrig.checked Then begin
          If NOT (curCell.State = 0) Then begin
            curCell.rePaint (paintImg.Canvas, what, cb_noDesti.Checked);
          end;
        end else begin
          curCell.Paint (paintImg.Canvas, what, cb_noDesti.Checked);
        end;
      end;
    end;
  end;
end;

// *****************************************************************************
procedure TForm1.decayMarks;
var
  curCell : TCell;
  I, K    : Integer;
  dRate   : Real;
begin
  dRate := StrToFloat(E_decay.Text);
  for I := 0 to reih -1 do
  begin
    for K := 0 to spalt -1 do
    begin
      curCell := cellList[K,I];
      curCell.markA := curCell.markA * dRate;
      curCell.markB := curCell.markB * dRate;
    end;
  end;
end;

// *****************************************************************************
procedure TForm1.repaintAllCells;
var
  curCell  : TCell;
  I, K     : Integer;
  what     : Integer;
begin
  If CB_potField.Checked Then begin
      what := 2;
    end else If CB_showAB.Checked Then begin
      what := 1;
    end else begin
      what := 0;
    end;
  for I := 0 to reih -1 do
  begin
    for K := 0 to spalt -1 do
    begin
      curCell := cellList[K,I];
      curCell.maxM := maxM;
      curCell.minM := minM;
      curCell.rePaint (paintImg.Canvas, what, cb_noDesti.Checked);
    end;
  end;
end;

// *****************************************************************************
procedure TForm1.repaintAgents;
var
  curAgent : TAgent;
  I        : Integer;
begin
  for I := 0 to AgentList.Count - 1 do
  begin
    curAgent := AgentList.Items [I];
    curAgent.Paint (agentImg.Canvas);
  end;
end;

// *****************************************************************************
// *** look at the cells in the neigbourhood defined by the horizon-parameter **
// *****************************************************************************
procedure TForm1.checkArea (I : Integer);
var
  curCell  : TCell;
  curAgent : TAgent;
  M        : Integer;
  Angle    : Array [0..1] of Real;
  horizon  : Integer;
  neib     : TPoint;
  comper   : Real;
  wList    : Array of Double;
  wSum     : Double;
  tmP      : TPoint;
  fromTo   : Array [0..1] of Integer;
  curNr    : Integer;
  noise    : Double;
  strN     : Real;
begin
  horizon := TrB_thresh.Position;
  curAgent := AgentList.Items [I];
  Angle[0] := curAgent.Heading - horizon - 22.5;     // -- minAngle
  Angle[1] := curAgent.Heading + horizon - 22.5;     // -- maxAngle
  angelBorder (Angle[0]);
  angelBorder (Angle[1]);
  //-- find the cells to look at
  SetLength(curAgent.lookToList, 0);

  for M := 0 to 1 do
  begin
    comper   := Angle[M];
    case round(comper) of           // find start and end field (cell)
      0..45:    fromTo[M] := 1;
      46..90:   fromTo[M] := 2;
      91..135:  fromTo[M] := 3;
      136..180: fromTo[M] := 4;
      181..225: fromTo[M] := 5;
      226..270: fromTo[M] := 6;
      271..315: fromTo[M] := 7;
      316..360: fromTo[M] := 8;
    end;
  end;

  curNr := fromTo[0] -1;
  repeat
  inc(curNr);
  If curNr > 8 Then curNr := 1;
    case curNr of                   // set the direction to the cell-positions
      1: begin neib.X := 1;  neib.Y := 1;  end;
      2: begin neib.X := 0;  neib.Y := 1;  end;
      3: begin neib.X := -1; neib.Y := 1;  end;
      4: begin neib.X := -1; neib.Y := 0;  end;
      5: begin neib.X := -1; neib.Y := -1; end;
      6: begin neib.X := 0;  neib.Y := -1; end;
      7: begin neib.X := 1;  neib.Y := -1; end;
      8: begin neib.X := 1;  neib.Y := 0;  end;
    end;
    SetLength(curAgent.lookToList, length(curAgent.lookToList) + 1);
    curAgent.lookToList[High(curAgent.lookToList)] := neib;
  until curNr = fromTo[1];

  SetLength(wList, length(curAgent.lookToList));
  wSum := 0;
  curAgent.sumChem := 0;
  strN := 0.1; //minM+1;
  For M := 0 To High(curAgent.lookToList) Do
  begin
    noise := strN*(random()-0.5);
    tmP.X := curAgent.onCell.X + curAgent.lookToList[M].X;
    tmP.Y := curAgent.onCell.Y + curAgent.lookToList[M].Y;
    torus (tmP.X, tmP.Y, spalt, reih);
    curCell := cellList[tmP.X, tmP.Y];
    //If curAgent.Modus = 0 Then           // -- exploration Mode
    //begin
      curAgent.sumChem := curAgent.sumChem + curCell.markB + noise;
      wSum := wSum + curCell.markB + noise;
      wList[M] := curCell.markB + noise;
    //end else If curAgent.Modus = 1 Then  // -- return Mode
    //begin
      //curAgent.sumChem := curAgent.sumChem + curCell.markH + noise;  // -- was curCell.markH
      //wSum := wSum + curCell.markH + noise;
      //wList[M] := curCell.markH + noise;
    //end;
  end;

  SetLength(curAgent.weightList, 0);
  SetLength(curAgent.weightList, length(curAgent.lookToList));
  For M := 0 To High(curAgent.lookToList) Do
  begin
    // --- write in the agent's weight list ---
    curAgent.weightList[M] := wList[M]/wSum * 100;
  end;
end;

// *****************************************************************************
// *** the mouse interactions **************************************************
// *****************************************************************************
procedure TForm1.ZeichenPanelMouseDown(Sender: TObject; Button: TMouseButton;
  Shift: TShiftState; X, Y: Integer);
begin
   If Button = mbRight then  rDown := true;
   If Button = mbLeft  then  lDown := true;
   If ssCtrl in shift  then begin
     newDesti(X, Y);
     sDown := true;
   end;
end;

procedure TForm1.newDesti(X, Y: Integer);
begin
  SetLength (destiList, length(destiList)+1);
  destiList[high(destiList)].Pos.X   := X;
  destiList[high(destiList)].Pos.Y   := Y;
  destiList[high(destiList)].numbers := 0;
  aktDesti := high(destiList);
end;

// *****************************************************************************
procedure TForm1.ZeichenPanelMouseMove(Sender: TObject; Shift: TShiftState; X, Y: Integer);
begin
  If (rDown = true) or (lDown = true) Then
  begin
    markCell (X, Y);
  end;
end;
// *****************************************************************************
procedure TForm1.ZeichenPanelMouseUp(Sender: TObject; Button: TMouseButton;
  Shift: TShiftState; X, Y: Integer);
begin
  rDown := false;
  lDown := false;
  sDown := false;
end;
// *****************************************************************************
procedure TForm1.markCell (X, Y: Integer);
var
  curCell : TCell;
  cPos    : TPoint;
  mPos    : TPoint;
  I, K    : Integer;
begin
  cPos.X  := round(X / cellScal);
  cPos.Y  := round(Y / cellScal);
  curCell := cellList[cPos.X, cPos.Y];
  If (lDown = true) and (sDown = false) Then
  begin
    for I := -1 to 1 do
    begin
      for K := -1 to 1 do
      begin
        mPos.X  := cPos.X+K;
        mPos.Y  := cPos.Y+I;
        torus (mPos.X, mPos.Y, spalt, reih);
        curCell := cellList[mPos.X, mPos.Y];
        curCell.state := 1;
        curCell.rePaint (paintImg.Canvas, 0, cb_noDesti.Checked);
      end;
    end;
  end else
  If (rDown = true) Then
  begin
    curCell.state := 0;
    curCell.rePaint (paintImg.Canvas, 0, cb_noDesti.Checked);
  end else
  If (lDown = true) and (sDown = true) Then
  begin
    curCell.state   := 2;
    curCell.desiNr  := aktDesti;
    curCell.rePaint (paintImg.Canvas, 0, cb_noDesti.Checked);
  end else
end;

// ---------------------------------------------------------------------------//
// ------------------------------ StringGrid ---------------------------------//
// ---------------------------------------------------------------------------//
procedure TForm1.StringGrid1KeyUp(Sender: TObject; var Key: Word;
  Shift: TShiftState);
begin
  setGridValues;
end;
// *****************************************************************************
procedure TForm1.setGridValues;
begin
  diffCoef[0] := StrToFloat(StringGrid1.Cells[1, 1]);
  diffCoef[1] := StrToFloat(StringGrid1.Cells[1, 2]);
  diffCoef[2] := StrToFloat(StringGrid1.Cells[1, 3]);

  wghtPop[0] := StrToFloat(StringGrid1.Cells[2, 1]);
  wghtPop[1] := StrToFloat(StringGrid1.Cells[3, 1]);
  wghtPop[2] := StrToFloat(StringGrid1.Cells[4, 1]);

  wghtServ[0] := StrToFloat(StringGrid1.Cells[2, 2]);
  wghtServ[1] := StrToFloat(StringGrid1.Cells[3, 2]);
  wghtServ[2] := StrToFloat(StringGrid1.Cells[4, 2]);

  wghtInd[0] := StrToFloat(StringGrid1.Cells[2, 3]);
  wghtInd[1] := StrToFloat(StringGrid1.Cells[3, 3]);
  wghtInd[2] := StrToFloat(StringGrid1.Cells[4, 3]);

  noise[0] := StrToFloat(StringGrid1.Cells[5, 1]);
  noise[1] := StrToFloat(StringGrid1.Cells[5, 2]);
  noise[2] := StrToFloat(StringGrid1.Cells[5, 3]);
end;
// *****************************************************************************
procedure TForm1.setupGrid;
var
  basicNoise : Real;
begin
  StringGrid1.Cells[0, 0]:='usage';
  StringGrid1.Cells[1, 0]:='diff. c.';
  StringGrid1.Cells[2, 0]:='w. pop.';
  StringGrid1.Cells[3, 0]:='w. serv.';
  StringGrid1.Cells[4, 0]:='w. ind.';
  StringGrid1.Cells[5, 0]:='noise';

  StringGrid1.Cells[0, 1]:='populat.';
  StringGrid1.Cells[0, 2]:='service';
  StringGrid1.Cells[0, 3]:='industry';

  StringGrid1.Cells[1, 1]:='1';
  StringGrid1.Cells[1, 2]:='1';
  StringGrid1.Cells[1, 3]:='1';

  StringGrid1.Cells[2, 1]:='1,0';
  StringGrid1.Cells[3, 1]:='0,5';
  StringGrid1.Cells[4, 1]:='0,0';
  StringGrid1.Cells[5, 1]:='6,0';

  //basicNoise := StrToFloat(StringGrid1.Cells[5, 1]);

  StringGrid1.Cells[2, 2]:='0,5';
  StringGrid1.Cells[3, 2]:='1,0';
  StringGrid1.Cells[4, 2]:='0';
  StringGrid1.Cells[5, 2]:='5,0'; // FloatToStr(basicNoise-1);

  StringGrid1.Cells[2, 3]:='0,5';
  StringGrid1.Cells[3, 3]:='0';
  StringGrid1.Cells[4, 3]:='1,0';
  StringGrid1.Cells[5, 3]:='4,8'; // FloatToStr(basicNoise-1);

  setGridValues;
end;
// *****************************************************************************
procedure TForm1.B_resetClick(Sender: TObject);
begin
  setupGrid;
end;

// ---------------------------------------------------------------------------//
// ------------------------------- Schalter ----------------------------------//
// ---------------------------------------------------------------------------//
procedure TForm1.B_setupClick(Sender: TObject);
begin
  deleter;
  settings;
  Form2.resetGraph;
end;
// *****************************************************************************
procedure TForm1.B_stopClick(Sender: TObject);
begin
  Form2.show;
  If ana1 Then setupAna1;
  If ana2 Then setupAna2;
  Timer1.enabled := not(Timer1.enabled);
  If Timer1.enabled = true Then PageControl1.ActivePageIndex := 1;
end;
// *****************************************************************************
procedure TForm1.TrB_threshChange(Sender: TObject);
begin
  Lbl_B.Caption := IntToStr(TrB_thresh.Position) + ' Grad';
end;
// *****************************************************************************
procedure TForm1.UpD_tileSzClick(Sender: TObject; Button: TUDBtnType);
begin
  nbS := UpD_tileSz.Position;
end;
// *****************************************************************************
procedure TForm1.SB_wiggleChange(Sender: TObject);
begin
  Lbl_wiggle.Caption := IntToStr(SB_wiggle.Position) + ' Grad';
end;
// *****************************************************************************
procedure TForm1.B_rankSizeClick(Sender: TObject);
begin
  Form2.show;
end;
// *****************************************************************************
procedure TForm1.B_saveBmpClick(Sender: TObject);
begin
  saveBmp;
end;
// *****************************************************************************
procedure TForm1.B_saveXMLClick(Sender: TObject);
begin
  saveXLS;
end;
// *****************************************************************************
procedure TForm1.saveXLS;
var
  path : String;
begin
  path := ExtractFilePath(Application.ExeName);
  with TSeriesDataXLS.Create(Form2.C_RankSize, nil) do
  try
    IncludeHeader:=True;
    SaveToFile(path+'data\'+E_pName.Text +'3.xls');
  finally
    Free;
  end;
  with TSeriesDataXML.Create(Form2.C_Linear, nil) do
  try
    IncludeHeader:=True;
    SaveToFile(path+'data\'+E_pName.Text +'4.xls');
  finally
    Free;
  end;
  with TSeriesDataXML.Create(Chart1, nil) do
  try
    IncludeHeader:=True;
    SaveToFile(path+'data\'+E_pName.Text +'5.xls');
  finally
    Free;
  end;
end;
// *****************************************************************************
procedure TForm1.saveBmp;
var
  img1: TBitmap;
  img2: TBitmap;
  path : String;
  Filename : String;
begin
  path := ExtractFilePath(Application.ExeName);
  img1 := TBitMap.Create;
  img1 := Form1.GetFormImage;
  Filename := path+'pictures\'+E_pName.Text +'1';
  img1.SaveToFile(Filename+'.bmp');
  BmpToJpg(Filename, 100);
  img2 := TBitMap.Create;
  img2 := Form2.GetFormImage;
  Filename := path+'pictures\'+E_pName.Text +'2';
  img2.SaveToFile(Filename +'.bmp');
  BmpToJpg(Filename, 100);
end;
// *****************************************************************************
Procedure TForm1.BmpToJpg(const Filename: String; Quality: TJPEGQualityRange=100);
var
  Bmp: TBitmap;
  Jpg: TJpegImage;
begin
  Bmp:=TBitmap.Create;
  Jpg:=TJpegImage.Create;
  try
    Bmp.LoadFromFile(Filename+'.bmp');
    Jpg.CompressionQuality:=Quality;
    Jpg.Assign(Bmp);
    Jpg.SaveToFile(ChangeFileExt(Filename, '.jpg' ));
  finally
    Jpg.Free;
    Bmp.Free;
  end;
  if FileExists(FileName+'.bmp')then deletefile(FileName+'.bmp');             // -- bitmap l�schen 
end;
// *****************************************************************************
procedure TForm1.B_oneStepClick(Sender: TObject);
begin
  calculate;
end;
// *****************************************************************************
procedure TForm1.Edit_sizeChange(Sender: TObject);
begin
  If StrToInt(Edit_size.Text) > 10 Then Edit_size.Text := '10';
  If StrToInt(Edit_size.Text) < 2  Then Edit_size.Text := '2';
end;
// *****************************************************************************
procedure TForm1.E_noiseChange(Sender: TObject);
begin
  If (E_noise.text = '') Then E_noise.text := '0';
end;
// *****************************************************************************
procedure TForm1.CB_showABClick(Sender: TObject);
begin
  findMaxMin;
  repaintAllCells;
end;
// *****************************************************************************
procedure TForm1.B_repaintClick(Sender: TObject);
begin
  findMaxMin;
  whiteAgImg;
  If CB_showAg.Checked = True Then begin
    repaintAgents;
  end;
  If CB_noTracks.Checked Then begin repaintCells;
  end else begin
    repaintAllCells;
  end;
  If CB_gravity.Checked = True Then drawConns;
end;
// *****************************************************************************
procedure TForm1.E_stopChange(Sender: TObject);
begin
  stopTime := StrToInt(E_stop.Text);
end;
// *****************************************************************************
procedure TForm1.E_tileSzChange(Sender: TObject);
begin
  nbS := UpD_tileSz.Position;
end;
// *****************************************************************************
procedure TForm1.CB_noTracksClick(Sender: TObject);
begin
  repaintAllCells;
end;
// *****************************************************************************
procedure TForm1.CB_gravityClick(Sender: TObject);
begin
  repaintAllCells;
  If CB_gravity.Checked = True Then drawConns;
end;
// *****************************************************************************
procedure TForm1.E_gravChange(Sender: TObject);
begin
  repaintAllCells;
end;
// *****************************************************************************
procedure TForm1.FormDestroy(Sender: TObject);
begin
  deleter;
  ZeichenPanel.Free;
end;
// *****************************************************************************
procedure TForm1.deleter;
var
  I, K     : Integer;
  curCell  : TCell;
  curAgent : TAgent;
  fDevel   : PTile;
begin
  for I := 0 to reih -1 do
  begin
    for K := 0 to spalt -1 do
    begin
      curCell := cellList[K,I];
      curCell.Free;
    end;
  end;
  SetLength(cellList, 0, 0);
  for I := 0 to AgentList.Count - 1 do
  begin
    curAgent := AgentList.Items [I];
    curAgent.Free;
  end;
  while AgentList.Count>0 do AgentList.Delete(0);
  AgentList.Free;
  paintImg.Free;
  agentImg.Free;
  steps := 0;
  For I := 0 To 2 do SetLength(limboWorld[I], 0, 0);
  for I:=0 to TileList.Count-1 do
  begin
    fDevel := PTile(TileList.Items[I]);
    Dispose(fDevel);
  end;
  while TileList.Count>0 do TileList.Delete(0);
  TileList.Free;
  steps := 0;
end;
// *****************************************************************************
procedure TForm1.CB_actAna1Click(Sender: TObject);
begin
  ana1 := CB_actAna1.Checked;
end;
// *****************************************************************************
procedure TForm1.CB_actAna2Click(Sender: TObject);
begin
  ana2 := CB_actAna2.Checked;
end;
// *****************************************************************************
procedure TForm1.Cb_allBlackClick(Sender: TObject);
var
  curCell : TCell;
  I       : Integer;
  K       : Integer;
begin
  for I := 0 to reih -1 do
  begin
    for K := 0 to spalt -1 do
    begin
      curCell := CellList[K,I];
      curCell.allBlack := Cb_allBlack.Checked;
    end;
  end;
end;
// *****************************************************************************
procedure TForm1.RadioGroup2Click(Sender: TObject);
begin
  If rb_direct.checked Then homeMode := 0;
  If rb_hillCl.checked Then homeMode := 1;
end;

end.


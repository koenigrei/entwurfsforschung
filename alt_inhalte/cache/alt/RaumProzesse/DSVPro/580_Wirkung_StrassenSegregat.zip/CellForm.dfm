object Form1: TForm1
  Left = 600
  Top = 0
  Caption = 'Segregation by Move '
  ClientHeight = 711
  ClientWidth = 924
  Color = clBtnFace
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -10
  Font.Name = 'Tahoma'
  Font.Style = []
  OldCreateOrder = False
  Position = poDesigned
  OnCreate = FormCreate
  OnDestroy = FormDestroy
  PixelsPerInch = 96
  TextHeight = 12
  object lbl_Steps: TLabel
    Left = 767
    Top = 495
    Width = 39
    Height = 12
    Alignment = taRightJustify
    Caption = 'lbl_Steps'
  end
  object lbl_timesteps: TLabel
    Left = 812
    Top = 495
    Width = 47
    Height = 12
    Caption = ': timesteps'
  end
  object Label5: TLabel
    Left = 835
    Top = 656
    Width = 76
    Height = 12
    Caption = ': stop at timestep'
  end
  object Lbl_cellS: TLabel
    Left = 791
    Top = 611
    Width = 39
    Height = 12
    Alignment = taRightJustify
    Caption = 'lbl_Steps'
  end
  object Label10: TLabel
    Left = 836
    Top = 611
    Width = 50
    Height = 12
    Caption = ': cell-space'
  end
  object Lbl_strCell: TLabel
    Left = 791
    Top = 629
    Width = 39
    Height = 12
    Alignment = taRightJustify
    Caption = 'lbl_Steps'
  end
  object Label19: TLabel
    Left = 836
    Top = 629
    Width = 52
    Height = 12
    Caption = ': street cells'
  end
  object ZeichenPanel: TPanel
    Left = 8
    Top = 9
    Width = 694
    Height = 694
    BorderStyle = bsSingle
    DockSite = True
    TabOrder = 0
    OnMouseDown = ZeichenPanelMouseDown
    OnMouseMove = ZeichenPanelMouseMove
    OnMouseUp = ZeichenPanelMouseUp
  end
  object PageControl1: TPageControl
    Left = 711
    Top = 8
    Width = 205
    Height = 481
    ActivePage = TabSheet1
    TabOrder = 1
    object TabSheet1: TTabSheet
      Caption = 'setup'
      object GroupBox1: TGroupBox
        Left = 3
        Top = 3
        Width = 191
        Height = 198
        Caption = 'setup settings'
        TabOrder = 0
        object Lbl_TextAnzahl: TLabel
          Left = 72
          Top = 24
          Width = 86
          Height = 12
          Caption = ': number of agents'
        end
        object Label2: TLabel
          Left = 72
          Top = 50
          Width = 39
          Height = 12
          Caption = ': cell size'
        end
        object Label3: TLabel
          Left = 72
          Top = 76
          Width = 89
          Height = 12
          Caption = ': number of groups'
        end
        object Label1: TLabel
          Left = 72
          Top = 102
          Width = 93
          Height = 12
          Caption = ': radius neighbourh.'
        end
        object Label4: TLabel
          Left = 72
          Top = 128
          Width = 71
          Height = 12
          Caption = ': move distance'
        end
        object Edit_anzAg: TEdit
          Left = 9
          Top = 21
          Width = 41
          Height = 20
          TabOrder = 0
          Text = '12000'
          OnChange = Edit_anzAgChange
        end
        object Edit_cellSiz: TEdit
          Left = 26
          Top = 47
          Width = 24
          Height = 20
          TabOrder = 1
          Text = '6'
          OnChange = Edit_cellSizChange
        end
        object Edit_anzGr: TEdit
          Left = 26
          Top = 73
          Width = 24
          Height = 20
          TabOrder = 2
          Text = '6'
          OnChange = Edit_anzGrChange
        end
        object Edit_nRad: TEdit
          Left = 26
          Top = 99
          Width = 24
          Height = 20
          TabOrder = 3
          Text = '5'
          OnChange = Edit_nRadChange
        end
        object Edit_mDist: TEdit
          Left = 26
          Top = 125
          Width = 24
          Height = 20
          TabOrder = 4
          Text = '54'
          OnChange = Edit_mDistChange
        end
        object CB_graphicUpd: TCheckBox
          Left = 9
          Top = 151
          Width = 133
          Height = 17
          Caption = 'run with graphic (slower)'
          Checked = True
          State = cbChecked
          TabOrder = 5
        end
        object UpD_polyDegClust: TUpDown
          Left = 50
          Top = 125
          Width = 16
          Height = 20
          Associate = Edit_mDist
          Min = 2
          Max = 1000
          Position = 54
          TabOrder = 6
        end
        object UpDown1: TUpDown
          Left = 50
          Top = 99
          Width = 16
          Height = 20
          Associate = Edit_nRad
          Min = 1
          Max = 1000
          Position = 5
          TabOrder = 7
        end
        object UpDown2: TUpDown
          Left = 50
          Top = 73
          Width = 16
          Height = 20
          Associate = Edit_anzGr
          Min = 2
          Max = 1000
          Position = 6
          TabOrder = 8
        end
        object UpDown3: TUpDown
          Left = 50
          Top = 47
          Width = 16
          Height = 20
          Associate = Edit_cellSiz
          Min = 1
          Max = 50
          Position = 6
          TabOrder = 9
        end
        object CB_strOcc: TCheckBox
          Left = 9
          Top = 174
          Width = 166
          Height = 17
          Caption = 'allow street occupation'
          TabOrder = 10
        end
      end
      object GroupBox3: TGroupBox
        Left = 3
        Top = 207
        Width = 191
        Height = 118
        Caption = 'growth'
        TabOrder = 1
        object Label11: TLabel
          Left = 43
          Top = 64
          Width = 77
          Height = 12
          Caption = 'start with agents:'
        end
        object Label12: TLabel
          Left = 10
          Top = 90
          Width = 110
          Height = 12
          Caption = 'add agents per timestep:'
        end
        object Lbl_nrAgents: TLabel
          Left = 39
          Top = 40
          Width = 42
          Height = 12
          Alignment = taRightJustify
          Caption = 'nr agents'
        end
        object Label6: TLabel
          Left = 87
          Top = 40
          Width = 29
          Height = 12
          Caption = 'agents'
        end
        object E_startGrowWith: TEdit
          Left = 126
          Top = 60
          Width = 33
          Height = 20
          TabOrder = 0
          Text = '100'
          OnChange = Edit_anzAgChange
        end
        object E_growRate: TEdit
          Left = 126
          Top = 86
          Width = 33
          Height = 20
          TabOrder = 1
          Text = '10'
          OnChange = Edit_anzAgChange
        end
        object CB_actiGrow: TCheckBox
          Left = 25
          Top = 17
          Width = 56
          Height = 17
          Caption = 'activate'
          TabOrder = 2
        end
        object UpDown6: TUpDown
          Left = 159
          Top = 60
          Width = 16
          Height = 20
          Associate = E_startGrowWith
          Min = 1
          Max = 32000
          Increment = 10
          Position = 100
          TabOrder = 3
        end
        object UpDown7: TUpDown
          Left = 159
          Top = 86
          Width = 16
          Height = 20
          Associate = E_growRate
          Min = 1
          Max = 32000
          Increment = 5
          Position = 10
          TabOrder = 4
        end
      end
    end
    object TabSheet2: TTabSheet
      Caption = 'parameter'
      ImageIndex = 1
      object GroupBox2: TGroupBox
        Left = 11
        Top = 16
        Width = 166
        Height = 97
        Caption = 'tolerance settings'
        TabOrder = 0
        object Label8: TLabel
          Left = 16
          Top = 28
          Width = 49
          Height = 12
          Caption = 'threshold :'
        end
        object Lbl_P: TLabel
          Left = 71
          Top = 28
          Width = 15
          Height = 12
          Caption = '___'
        end
        object Label9: TLabel
          Left = 92
          Top = 28
          Width = 10
          Height = 12
          Caption = '%'
        end
        object TrB_thresh: TTrackBar
          Left = 3
          Top = 46
          Width = 160
          Height = 41
          Max = 100
          PageSize = 5
          Frequency = 10
          Position = 30
          TabOrder = 0
          OnChange = TrB_threshChange
        end
      end
      object RadioGroup1: TRadioGroup
        Left = 11
        Top = 126
        Width = 166
        Height = 105
        Caption = 'handle free cells'
        TabOrder = 1
      end
      object RB_count_no: TRadioButton
        Left = 16
        Top = 152
        Width = 137
        Height = 17
        Caption = 'do not count empty cells'
        Checked = True
        TabOrder = 2
        TabStop = True
      end
      object RB_count_diff: TRadioButton
        Left = 16
        Top = 175
        Width = 157
        Height = 17
        Caption = 'count empty cells as different'
        TabOrder = 3
      end
      object RB_count_simi: TRadioButton
        Left = 16
        Top = 198
        Width = 157
        Height = 17
        Caption = 'count empty cells as similar'
        TabOrder = 4
      end
    end
    object TabSheet3: TTabSheet
      Caption = 'analysis'
      ImageIndex = 2
      object Label7: TLabel
        Left = 130
        Top = 55
        Width = 55
        Height = 12
        Caption = ': cluster thr.'
      end
      object Label14: TLabel
        Left = 131
        Top = 83
        Width = 43
        Height = 12
        Caption = ': grid size'
      end
      object Button1: TButton
        Left = 3
        Top = 15
        Width = 75
        Height = 25
        Caption = 'show charts'
        TabOrder = 0
        OnClick = Button1Click
      end
      object B_cluster: TBitBtn
        Left = 3
        Top = 46
        Width = 75
        Height = 26
        Caption = 'cluster analysis'
        Font.Charset = DEFAULT_CHARSET
        Font.Color = clWindowText
        Font.Height = -10
        Font.Name = 'Tahoma'
        Font.Style = []
        ParentFont = False
        TabOrder = 1
        OnClick = B_clusterClick
      end
      object Button2: TButton
        Left = 3
        Top = 78
        Width = 75
        Height = 25
        Caption = 'dissimilar'
        TabOrder = 2
        OnClick = Button2Click
      end
      object E_clusterT: TEdit
        Left = 84
        Top = 51
        Width = 25
        Height = 20
        TabOrder = 3
        Text = '1'
      end
      object E_nbSize: TEdit
        Left = 84
        Top = 79
        Width = 25
        Height = 20
        TabOrder = 4
        Text = '20'
        OnChange = E_nbSizeChange
      end
      object ana_ps: TButton
        Left = 12
        Top = 142
        Width = 80
        Height = 25
        Caption = 'analyse ps'
        TabOrder = 5
        OnClick = ana_psClick
      end
      object ana_growth: TButton
        Left = 98
        Top = 142
        Width = 80
        Height = 25
        Caption = 'analyse growth'
        TabOrder = 6
        OnClick = ana_growthClick
      end
      object UpD_clS: TUpDown
        Left = 109
        Top = 51
        Width = 16
        Height = 20
        Associate = E_clusterT
        Min = 1
        Max = 10000
        Position = 1
        TabOrder = 7
      end
      object UpDown5: TUpDown
        Left = 109
        Top = 79
        Width = 16
        Height = 20
        Associate = E_nbSize
        Min = 1
        Max = 10000
        Position = 20
        TabOrder = 8
      end
      object B_anaStr: TButton
        Left = 98
        Top = 173
        Width = 80
        Height = 25
        Caption = 'analyse streets'
        TabOrder = 9
        OnClick = B_anaStrClick
      end
    end
    object TabSheet4: TTabSheet
      Caption = 'streets'
      ImageIndex = 3
      object colCode1: TLabel
        Left = 151
        Top = 112
        Width = 21
        Height = 12
        Caption = '       '
        Color = clWhite
        Font.Charset = DEFAULT_CHARSET
        Font.Color = clMaroon
        Font.Height = -10
        Font.Name = 'Tahoma'
        Font.Style = []
        ParentColor = False
        ParentFont = False
      end
      object colCode2: TLabel
        Left = 151
        Top = 133
        Width = 21
        Height = 12
        Caption = '       '
        Color = clWhite
        Font.Charset = DEFAULT_CHARSET
        Font.Color = clMaroon
        Font.Height = -10
        Font.Name = 'Tahoma'
        Font.Style = []
        ParentColor = False
        ParentFont = False
      end
      object colCode3: TLabel
        Left = 151
        Top = 154
        Width = 21
        Height = 12
        Caption = '       '
        Color = clWhite
        Font.Charset = DEFAULT_CHARSET
        Font.Color = clMaroon
        Font.Height = -10
        Font.Name = 'Tahoma'
        Font.Style = []
        ParentColor = False
        ParentFont = False
      end
      object colCode4: TLabel
        Left = 151
        Top = 176
        Width = 21
        Height = 12
        Caption = '       '
        Color = clWhite
        Font.Charset = DEFAULT_CHARSET
        Font.Color = clMaroon
        Font.Height = -10
        Font.Name = 'Tahoma'
        Font.Style = []
        ParentColor = False
        ParentFont = False
      end
      object colCode5: TLabel
        Left = 151
        Top = 197
        Width = 21
        Height = 12
        Caption = '       '
        Color = clWhite
        Font.Charset = DEFAULT_CHARSET
        Font.Color = clMaroon
        Font.Height = -10
        Font.Name = 'Tahoma'
        Font.Style = []
        ParentColor = False
        ParentFont = False
      end
      object colCode6: TLabel
        Left = 151
        Top = 218
        Width = 21
        Height = 12
        Caption = '       '
        Color = clWhite
        Font.Charset = DEFAULT_CHARSET
        Font.Color = clMaroon
        Font.Height = -10
        Font.Name = 'Tahoma'
        Font.Style = []
        ParentColor = False
        ParentFont = False
      end
      object colCode7: TLabel
        Left = 151
        Top = 240
        Width = 21
        Height = 12
        Caption = '       '
        Color = clWhite
        Font.Charset = DEFAULT_CHARSET
        Font.Color = clMaroon
        Font.Height = -10
        Font.Name = 'Tahoma'
        Font.Style = []
        ParentColor = False
        ParentFont = False
      end
      object b_delStr: TButton
        Left = 3
        Top = 423
        Width = 75
        Height = 25
        Caption = 'delete streets'
        TabOrder = 0
        OnClick = b_delStrClick
      end
      object GroupBox4: TGroupBox
        Left = 3
        Top = 3
        Width = 191
        Height = 54
        Caption = 'draw streets'
        TabOrder = 1
        object CB_strType: TComboBox
          Left = 11
          Top = 24
          Width = 158
          Height = 20
          ItemHeight = 12
          TabOrder = 0
          Text = ' choose street type'
        end
      end
      object SG_weight: TStringGrid
        Left = 16
        Top = 86
        Width = 129
        Height = 173
        BevelEdges = [beRight, beBottom]
        BevelInner = bvSpace
        BevelOuter = bvSpace
        BiDiMode = bdLeftToRight
        ColCount = 2
        DefaultColWidth = 60
        DefaultRowHeight = 20
        RowCount = 8
        Font.Charset = DEFAULT_CHARSET
        Font.Color = clWindowText
        Font.Height = -11
        Font.Name = 'Tahoma'
        Font.Orientation = 1
        Font.Style = []
        Options = [goFixedVertLine, goFixedHorzLine, goVertLine, goHorzLine, goRangeSelect, goEditing]
        ParentBiDiMode = False
        ParentFont = False
        ScrollBars = ssNone
        TabOrder = 2
        RowHeights = (
          20
          20
          20
          20
          20
          20
          20
          20)
      end
      object GroupBox5: TGroupBox
        Left = 3
        Top = 265
        Width = 191
        Height = 152
        Caption = 'predefined layouts'
        TabOrder = 3
        object Label13: TLabel
          Left = 119
          Top = 23
          Width = 29
          Height = 12
          Caption = ': rows'
        end
        object Label15: TLabel
          Left = 119
          Top = 109
          Width = 54
          Height = 12
          Caption = ': street type'
        end
        object Label16: TLabel
          Left = 119
          Top = 77
          Width = 35
          Height = 12
          Caption = ': streets'
        end
        object Label17: TLabel
          Left = 119
          Top = 49
          Width = 44
          Height = 12
          Caption = ': columns'
        end
        object B_randStr: TButton
          Left = 11
          Top = 71
          Width = 56
          Height = 24
          Caption = 'random'
          TabOrder = 0
          OnClick = B_randStrClick
        end
        object B_drawGrid: TButton
          Left = 11
          Top = 20
          Width = 56
          Height = 45
          Caption = 'draw grid'
          TabOrder = 1
          OnClick = B_drawGridClick
        end
        object Ed_rows: TEdit
          Left = 73
          Top = 19
          Width = 25
          Height = 20
          TabOrder = 2
          Text = '5'
        end
        object UpD_rows: TUpDown
          Left = 98
          Top = 19
          Width = 16
          Height = 20
          Associate = Ed_rows
          Min = 1
          Max = 10000
          Position = 5
          TabOrder = 3
        end
        object Ed_strType: TEdit
          Left = 73
          Top = 105
          Width = 25
          Height = 20
          TabOrder = 4
          Text = '3'
        end
        object UpD_strType: TUpDown
          Left = 98
          Top = 105
          Width = 16
          Height = 20
          Associate = Ed_strType
          Min = -3
          Max = 3
          Position = 3
          TabOrder = 5
        end
        object Ed_nrStr: TEdit
          Left = 73
          Top = 73
          Width = 25
          Height = 20
          TabOrder = 6
          Text = '20'
        end
        object UpD_nrStr: TUpDown
          Left = 98
          Top = 73
          Width = 16
          Height = 20
          Associate = Ed_nrStr
          Min = 1
          Max = 10000
          Increment = 5
          Position = 20
          TabOrder = 7
        end
        object Ed_cols: TEdit
          Left = 73
          Top = 45
          Width = 25
          Height = 20
          TabOrder = 8
          Text = '5'
        end
        object UpD_cols: TUpDown
          Left = 98
          Top = 45
          Width = 16
          Height = 20
          Associate = Ed_cols
          Min = 1
          Max = 10000
          Position = 5
          TabOrder = 9
        end
        object CB_rndTyp: TCheckBox
          Left = 72
          Top = 127
          Width = 116
          Height = 17
          Caption = 'random street types'
          Checked = True
          State = cbChecked
          TabOrder = 10
        end
      end
      object CB_hideAgs: TCheckBox
        Left = 16
        Top = 63
        Width = 129
        Height = 17
        Caption = 'draw without agents'
        Checked = True
        State = cbChecked
        TabOrder = 4
      end
      object B_imprint: TButton
        Left = 144
        Top = 423
        Width = 50
        Height = 25
        Caption = 'imprint'
        TabOrder = 5
        OnClick = B_imprintClick
      end
    end
  end
  object B_setup: TButton
    Left = 812
    Top = 519
    Width = 74
    Height = 25
    Caption = 'new Setup'
    TabOrder = 2
    OnClick = B_setupClick
  end
  object B_repaint: TButton
    Left = 724
    Top = 558
    Width = 82
    Height = 25
    Caption = 'repaint all'
    TabOrder = 3
    OnClick = B_repaintClick
  end
  object E_stopT: TEdit
    Left = 788
    Top = 653
    Width = 41
    Height = 20
    TabOrder = 4
    Text = '500'
    OnChange = E_stopTChange
  end
  object B_stop: TBitBtn
    Left = 724
    Top = 519
    Width = 82
    Height = 25
    Caption = 'start / stop'
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clGreen
    Font.Height = -10
    Font.Name = 'Tahoma'
    Font.Style = []
    ParentFont = False
    TabOrder = 5
    OnClick = B_stopClick
  end
  object Timer1: TTimer
    Interval = 1
    OnTimer = Timer1Timer
    Left = 720
    Top = 664
  end
end

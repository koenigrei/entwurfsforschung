unit Parameterspace;

interface

uses
  Windows, Messages, SysUtils, Variants, Classes, Graphics, Controls, Forms,
  Dialogs, StdCtrls, TeEngine, TeeTools, TeePageNumTool, Series, ExtCtrls,
  TeeProcs, Chart, TeeFunci, CurvFitt, ComCtrls, Math;

type
  TForm3 = class(TForm)
    GroupBox1       : TGroupBox;
    CB_param        : TComboBox;
    Label1          : TLabel;
    E_valFrom       : TEdit;
    Label2          : TLabel;
    E_valTo         : TEdit;
    Label3          : TLabel;
    E_toSteps       : TEdit;
    Label4          : TLabel;
    E_calcVals      : TEdit;
    B_start         : TButton;
    Chart_Cluster   : TChart;
    PageNumTool1    : TPageNumTool;
    Chart_IS        : TChart;
    PageNumTool2    : TPageNumTool;
    Series_Avg      : TPointSeries;
    Series_IS       : TPointSeries;
    Timer2          : TTimer;
    B_break         : TButton;
    Series_AvgClust : TLineSeries;
    TeeFunction1    : TAverageTeeFunction;
    Series_IS_Avg   : TLineSeries;
    lbl_pSteps      : TLabel;
    lbl_timesteps   : TLabel;
    Label5          : TLabel;
    E_incre         : TEdit;
    TeeFunction2    : TAverageTeeFunction;
    Series_IS_Fit   : TLineSeries;
    Series_AvgFit   : TLineSeries;
    TeeFunction4    : TCurveFittingFunction;
    TeeFunction3    : TCurveFittingFunction;
    Series_AvgTrend : TLineSeries;
    TeeFunction5    : TTrendFunction;
    Series_IS_Trend : TLineSeries;
    TeeFunction6    : TTrendFunction;
    GroupBox2       : TGroupBox;
    CB_data_Clust   : TCheckBox;
    CB_avg_Clust    : TCheckBox;
    CB_trend_Clust  : TCheckBox;
    CB_cFit_Clust   : TCheckBox;
    Label6          : TLabel;
    UpD_polyDegClust: TUpDown;
    E_polyDegClust  : TEdit;
    GroupBox3       : TGroupBox;
    Label7          : TLabel;
    CB_data_Seg     : TCheckBox;
    CB_avg_Seg      : TCheckBox;
    CB_trend_Seg    : TCheckBox;
    CB_cFit_Seg     : TCheckBox;
    UpD_polyDegSeg  : TUpDown;
    E_polyDegSeg    : TEdit;
    Label8          : TLabel;
    Lbl_proceed     : TLabel;
    Lbl_akt         : TLabel;
    B_undoZ         : TButton;
    procedure FormCreate(Sender: TObject);
    procedure B_startClick(Sender: TObject);
    procedure Timer2Timer(Sender: TObject);
    procedure B_breakClick(Sender: TObject);
    procedure UpD_polyDegClustClick(Sender: TObject; Button: TUDBtnType);
    procedure CB_cFit_ClustCli(Sender: TObject);
    procedure CB_data_ClustClick(Sender: TObject);
    procedure CB_avg_ClustClick(Sender: TObject);
    procedure CB_trend_ClustClick(Sender: TObject);
    procedure CB_data_SegClick(Sender: TObject);
    procedure CB_avg_SegClick(Sender: TObject);
    procedure CB_trend_SegClick(Sender: TObject);
    procedure CB_cFit_SegClick(Sender: TObject);
    procedure UpD_polyDegSegClick(Sender: TObject; Button: TUDBtnType);
    procedure E_calcValsChange(Sender: TObject);
    procedure B_undoZClick(Sender: TObject);
  private
    procedure plotVals;
    procedure newRound(aktVal: Integer);
    procedure resetGraphs;
    procedure updProc;
  public

  end;

var
  Form3  : TForm3;
  pSteps : Integer;
  rounds : Cardinal;
  aktVal : Integer;
  clusterFunct  : TCurveFittingFunction;
  segregatFunct : TCurveFittingFunction;
  toCalc : Cardinal;

implementation

{$R *.dfm}
uses CellForm, Analyse;

procedure TForm3.FormCreate(Sender: TObject);
begin
  Timer2.enabled := false;
  lbl_pSteps.Caption := '0';
  CB_param.AddItem(' number of groups', Sender);
  CB_param.AddItem(' radius neighbourhood', Sender);
  CB_param.AddItem(' move distance', Sender);
  CB_param.AddItem(' tolerance threshold', Sender);
  pSteps := 0;
  Steps  := 0;
  clusterFunct := TCurveFittingFunction.Create(self);
  clusterFunct.PolyDegree:=UpD_polyDegClust.Position;
  segregatFunct := TCurveFittingFunction.Create(self);
  segregatFunct.PolyDegree := 3;
  toCalc := 0;
  Lbl_akt.Caption := IntToStr(toCalc);
  Lbl_proceed.Caption := '/ ' + IntToStr( Ceil((StrToInt(E_valTo.Text) - StrToInt(E_valFrom.Text)+1)/
                         StrToInt(E_incre.Text)) * StrToInt(E_calcVals.Text));
end;

procedure TForm3.updProc;
begin
  Lbl_proceed.Caption := '/ ' + IntToStr( Ceil((StrToInt(E_valTo.Text) - StrToInt(E_valFrom.Text)+1)/
                         StrToInt(E_incre.Text)) * StrToInt(E_calcVals.Text));
end;

procedure TForm3.B_startClick(Sender: TObject);
begin
  Form1.Timer1.enabled := false;
  pSteps := 0;
  Steps := 0;
  If CB_param.ItemIndex = -1 Then
  begin
    MessageBox(MB_Ok, 'please select a parameter', 'missing value', MB_Ok);
    exit;
  end;
  resetGraphs;
  rounds := 1;
  toCalc := 0;
  Lbl_akt.Caption := IntToStr(toCalc);
  aktVal := StrToInt(E_valFrom.Text);
  Form1.E_stopT.Text := E_toSteps.Text;
  newRound(aktVal);
  Timer2.Enabled := true;
end;

procedure TForm3.B_undoZClick(Sender: TObject);
begin
  Chart_Cluster.UndoZoom;
  Chart_IS.UndoZoom;
end;

procedure TForm3.newRound(aktVal: Integer);
begin
  case CB_param.ItemIndex of
    0: Form1.Edit_anzGr.Text := IntToStr(aktVal);
    1: Form1.Edit_nRad.Text  := IntToStr(aktVal);
    2: Form1.Edit_mDist.Text := IntToStr(aktVal);
    3: Form1.TrB_thresh.Position := aktVal;
  end;
  Form1.deleter;
end;

procedure TForm3.resetGraphs;
begin
  with Chart_Cluster do
  begin
    Series_Avg.Clear;
    Series_AvgClust.Clear;
    Series_AvgFit.Clear;
    Title.Text.Clear;                                                         // -- Title of the Chart
    Title.Text.Add('clusters per value | cluster threshold = '+ Form1.E_clusterT.Text);
    Series_AvgClust.FunctionType.Period := (StrToInt(E_calcVals.Text));
    clusterFunct.ParentSeries := Series_AvgFit;
  end;
  with Chart_IS do
  begin
    Series_IS.Clear;
    Series_IS_Avg.Clear;
    Series_IS_Fit.Clear;
    Title.Text.Clear;                                                         // -- Title of the Chart
    Title.Text.Add('segregation per value');
    Series_IS_Avg.FunctionType.Period := (StrToInt(E_calcVals.Text));
    segregatFunct.ParentSeries := Series_IS_Fit;
  end;
end;

procedure TForm3.Timer2Timer(Sender: TObject);
begin
  If pSteps >= StrToInt(E_toSteps.Text) Then                                  // -- timesteps per value
  begin
    plotVals;
    inc(rounds);
    inc(toCalc);
    Lbl_akt.Caption := IntToStr(toCalc);
    If rounds > StrToInt(E_calcVals.Text) Then                                // -- calculations per value
    begin
      aktVal := aktVal + StrToInt(E_incre.Text);                              // -- raise aktual value by increment
      If aktVal > StrToInt(E_valTo.Text) Then                                 // -- iterate the range from start value to end value
      begin
        Form1.startCAna;
        Series_IS_Fit.CheckDataSource;
        Series_AvgFit.CheckDataSource;
        Timer2.enabled := false;
        exit;
      end;
      rounds := 1;
    end;
    pSteps := 0;
    newRound(aktVal);
  end;
  Form1.actions;
  lbl_pSteps.Caption := IntToStr (pSteps);
  inc(pSteps);
end;

procedure TForm3.plotVals;
var
  I : Integer;
  sumIS   : Extended;
begin
  sumIS   := 0;
  For I := 0 To ngGroups-1 Do
  begin
    sumIS   := sumIS + isSer[I].YValues[pSteps-1];
  end;
  sumIS := sumIS / ngGroups;
  Series_Avg.AddXY(aktVal, tmpBarSeries.XValues.Count);                       // -- all clusters over threshold from the barSeries
  Series_AvgClust.CheckDataSource;
  Series_AvgTrend.CheckDataSource;
  Series_IS.AddXY(aktVal, sumIS);
  Series_IS_Avg.CheckDataSource;
  Series_IS_Trend.CheckDataSource;
end;

// *****************************************************************************
// ******* Buttons *************************************************************
// *****************************************************************************

procedure TForm3.B_breakClick(Sender: TObject);
begin
  Timer2.enabled := not(Timer2.enabled);
  {pSteps := 0;
  Steps := 0;
  rounds := 1;}
end;

// *** Clusters ****************************************************************

procedure TForm3.CB_data_ClustClick(Sender: TObject);
begin
  If CB_data_Clust.Checked Then begin Series_Avg.Visible := true;
  end else begin Series_Avg.Visible := false;
  end;
end;

procedure TForm3.CB_avg_ClustClick(Sender: TObject);
begin
  If CB_avg_Clust.Checked Then begin Series_AvgClust.Visible := true;
  end else begin Series_AvgClust.Visible := false;
  end;
end;

procedure TForm3.CB_trend_ClustClick(Sender: TObject);
begin
  If CB_trend_Clust.Checked Then begin Series_AvgTrend.Visible := true;
  end else begin Series_AvgTrend.Visible := false;
  end;
end;

procedure TForm3.CB_cFit_ClustCli(Sender: TObject);
begin  
  If CB_cFit_Clust.Checked Then begin Series_AvgFit.Visible := true;
  end else begin Series_AvgFit.Visible := false;
  end;
end;

procedure TForm3.UpD_polyDegClustClick(Sender: TObject; Button: TUDBtnType);
begin
  if UpD_polyDegClust.Position>1 then
     clusterFunct.PolyDegree:=UpD_polyDegClust.Position;
end;

// *** Segregation *************************************************************

procedure TForm3.CB_data_SegClick(Sender: TObject);
begin
  If CB_data_Seg.Checked Then begin Series_IS.Visible := true;
  end else begin Series_IS.Visible := false;
  end;
end;

procedure TForm3.CB_avg_SegClick(Sender: TObject);
begin
  If CB_avg_Seg.Checked Then begin Series_IS_Avg.Visible := true;
  end else begin Series_IS_AVG.Visible := false;
  end;
end;

procedure TForm3.CB_trend_SegClick(Sender: TObject);
begin
  If CB_trend_Seg.Checked Then begin Series_IS_Trend.Visible := true;
  end else begin Series_IS_Trend.Visible := false;
  end;
end;

procedure TForm3.E_calcValsChange(Sender: TObject);
begin
  updProc;
end;

procedure TForm3.CB_cFit_SegClick(Sender: TObject);
begin
  If CB_cFit_Seg.Checked Then begin Series_IS_Fit.Visible := true;
  end else begin Series_IS_Fit.Visible := false;
  end;
end;

procedure TForm3.UpD_polyDegSegClick(Sender: TObject; Button: TUDBtnType);
begin
  if UpD_polyDegClust.Position>1 then
     segregatFunct.PolyDegree:=UpD_polyDegSeg.Position;
end;

end.

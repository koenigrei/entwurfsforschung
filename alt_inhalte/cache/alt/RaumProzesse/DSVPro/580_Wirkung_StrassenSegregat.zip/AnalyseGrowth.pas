unit AnalyseGrowth;

interface

uses
  Windows, Messages, SysUtils, Variants, Classes, Graphics, Controls, Forms,
  Dialogs, StdCtrls, ComCtrls, TeEngine, TeeTools, TeePageNumTool, CurvFitt,
  TeeFunci, Series, ExtCtrls, TeeProcs, Chart, Math;

type
  TForm4 = class(TForm)
    GroupBox1: TGroupBox;
    Label1: TLabel;
    Label2: TLabel;
    Label3: TLabel;
    Label4: TLabel;
    Label5: TLabel;
    E_valFrom: TEdit;
    E_valTo: TEdit;
    E_toSteps: TEdit;
    E_calcVals: TEdit;
    B_start: TButton;
    B_break: TButton;
    E_incre: TEdit;
    lbl_pSteps: TLabel;
    lbl_timesteps: TLabel;
    Label8: TLabel;
    Lbl_akt: TLabel;
    Lbl_proceed: TLabel;
    B_undoZ: TButton;
    Chart_Growth: TChart;
    Series_Avg: TPointSeries;
    PageNumTool1: TPageNumTool;
    Timer3: TTimer;
    procedure Timer3Timer(Sender: TObject);
    procedure FormCreate(Sender: TObject);
    procedure B_startClick(Sender: TObject);
    procedure E_calcValsChange(Sender: TObject);
    procedure E_increChange(Sender: TObject);
    procedure B_undoZClick(Sender: TObject);
    procedure B_breakClick(Sender: TObject);
  private
    procedure newRound(aktVal: Integer);
    procedure updProc;
    procedure resetGraphs;
    procedure tmpPlotVals;
    procedure plotVals;
  public
    { Public declarations }
  end;

var
  Form4   : TForm4;
  pSteps  : Integer;
  rounds  : Cardinal;
  subrds  : Cardinal;
  mesrds  : Cardinal;
  aktVal  : Integer;
  toCalc  : Cardinal;
  colSer  : Array of TPointSeries;
  growSer : Array of TLineSeries;
  colSer2 : Array of TPointSeries;
  avgSer  : Array of TLineSeries;
  densSer : TLineSeries;

implementation

{$R *.dfm}
uses CellForm, Analyse;

//==============================================================================
procedure TForm4.FormCreate(Sender: TObject);
begin
  Timer3.enabled := false;
  lbl_pSteps.Caption := '0';
  pSteps := 0;
  Steps  := 0;
  toCalc := 0;
  subrds := 0;
  mesrds := 0;
  Lbl_akt.Caption := IntToStr(toCalc);
  Lbl_proceed.Caption := '/ ' + IntToStr( Ceil((StrToInt(E_valTo.Text) - StrToInt(E_valFrom.Text)+1)/
                         StrToInt(E_incre.Text)) * StrToInt(E_calcVals.Text));
end;

//------------------------------------------------------------------------------
procedure TForm4.resetGraphs;
var
  I : Integer;
  calcs : Integer;
begin
  with Chart_Growth do
  begin
    RemoveAllSeries;
    Title.Text.Clear;                                                         // -- Title of the Chart
    Title.Text.Add('segregation index with different densities');
    densSer := TLineSeries.Create(self);
    densSer.Clear;
    densSer.VertAxis := aLeftAxis;
    densSer.ParentChart := Chart_Growth;
    densSer.Title := 'dense';
    densSer.Color := clYellow;

    calcs := Ceil((StrToInt(E_valTo.Text) - StrToInt(E_valFrom.Text)+1)/ StrToInt(E_incre.Text));
    SetLength (avgSer, 0);
    SetLength (colSer2, 0);
    SetLength (avgSer, calcs);
    SetLength (colSer2, calcs);
    For I := 0 To calcs -1 Do
    begin
      colSer2[I]:= TPointSeries.Create(self);
      colSer2[I].Clear;
      avgSer[I]:= TLineSeries.Create(self);
      avgSer[I].Clear;
      avgSer[I].VertAxis := aRightAxis;
      avgSer[I].ParentChart := Chart_Growth;
      avgSer[I].SetFunction(TAverageTeeFunction.Create(self));
      avgSer[I].FunctionType.Period := StrToInt(E_calcVals.Text);
      avgSer[I].Title := 'toler';
    end;

    SetLength (growSer, 0);
    SetLength (colSer, 0);
    SetLength (growSer, StrToInt(E_calcVals.Text));
    SetLength (colSer, StrToInt(E_calcVals.Text));
    For I := 0 To high(growSer) Do
    begin
      colSer[I]:= TPointSeries.Create(self);
      colSer[I].Clear;
      growSer[I]:= TLineSeries.Create(self);
      growSer[I].Clear;
      growSer[I].VertAxis := aRightAxis;
      growSer[I].ParentChart := Chart_Growth;
      growSer[I].SetFunction(TAverageTeeFunction.Create(self));
      growSer[I].FunctionType.Period := ngGroups;
      growSer[I].Title := 'temp';
    end;
  end;
end;


procedure TForm4.B_breakClick(Sender: TObject);
begin
  Timer3.enabled := not(Timer3.enabled);
  {pSteps := 0;
  Steps := 0;
  rounds := 1; }
end;

procedure TForm4.B_startClick(Sender: TObject);
begin
  pSteps := 0;
  Steps  := 0;
  rounds := 1;
  toCalc := 0;
  subrds := 0;
  mesrds := 0;
  resetGraphs;
  Lbl_akt.Caption := IntToStr(toCalc);
  aktVal := StrToInt(E_valFrom.Text);
  Form1.E_stopT.Text := E_toSteps.Text;
  newRound(aktVal);
  Timer3.Enabled := true;
end;

procedure TForm4.Timer3Timer(Sender: TObject);
var
  I : Integer;
begin
  If pSteps >= StrToInt(E_toSteps.Text) Then                                  // -- timesteps per value
  begin
    tmpPlotVals;
    inc(rounds);
    inc(toCalc);
    inc(subrds);
    If subrds = StrToInt(E_calcVals.Text) Then
    begin
      plotVals;
      inc(mesrds);
      For I := 0 To high(growSer) Do                                          // -- delete the temporary series
      begin
        growSer[I].Clear;
        colSer[I].Clear;
      end;
      subrds := 0;
    end;

    Lbl_akt.Caption := IntToStr(toCalc);
    If rounds > StrToInt(E_calcVals.Text) Then                                // -- calculations per value
    begin
      aktVal := aktVal + StrToInt(E_incre.Text);                              // -- raise aktual value by increment
      If aktVal > StrToInt(E_valTo.Text) Then                                 // -- iterate the range from start value to end value
      begin
        Form1.startCAna;
        Timer3.enabled := false;
        exit;
      end;
      rounds := 1;
    end;
    pSteps := 0;
    newRound(aktVal);
  end;
  Form1.actions;
  lbl_pSteps.Caption := IntToStr (pSteps);
  inc(pSteps);
end;

procedure TForm4.plotVals;
var
  I, K : Integer;
begin
  For I := 0 To StrToInt(E_calcVals.Text)-1 Do
  begin
    For K := 0 To StrToInt(E_toSteps.Text)-1 Do
    begin
      colSer2[mesrds].AddXY (growSer[I].XValues[K], growSer[I].YValues[K]);
    end;
  end;
  avgSer[mesrds].DataSource := colSer2[mesrds];
  avgSer[mesrds].CheckDataSource;
  avgSer[mesrds].Title := IntToStr(aktVal);
end;

procedure TForm4.tmpPlotVals;
var
  I, K : Integer;
begin
  densSer.DataSource := csSer[3];
  densSer.CheckDataSource;
  For I := 0 To ngGroups-1 Do
  begin
    For K := 0 To StrToInt(E_toSteps.Text)-1 Do
    begin
      colSer[subrds].AddXY (isSer[I].XValues[K], isSer[I].YValues[K]);
    end;
  end;
  growSer[subrds].DataSource := colSer[subrds];
  growSer[subrds].CheckDataSource;
end;

procedure TForm4.newRound(aktVal: Integer);
begin
  Form1.TrB_thresh.Position := aktVal;
  Form1.deleter;
end;

procedure TForm4.B_undoZClick(Sender: TObject);
begin
  Chart_Growth.UndoZoom;
end;

procedure TForm4.E_calcValsChange(Sender: TObject);
begin
  updProc;
end;

procedure TForm4.E_increChange(Sender: TObject);
begin
  updProc;
end;

procedure TForm4.updProc;
begin
  Lbl_proceed.Caption := '/ ' + IntToStr( Ceil((StrToInt(E_valTo.Text) - StrToInt(E_valFrom.Text)+1)/
                         StrToInt(E_incre.Text)) * StrToInt(E_calcVals.Text));
end;

end.

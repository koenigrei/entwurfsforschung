unit agenten;

interface

uses
  Windows, Graphics;

type
  colList = Array of TColor;

type
  TAgent = class
  private
    function  rndN(lower : Integer; upper : Integer):Integer;
  public
    Stopped    : Boolean;
    onCell     : TPoint;
    satisf     : Double;
    State      : Integer;
    FColor     : TColor;
    FPosX      : Integer;
    FPosY      : Integer;
    FSize      : Integer;
    FHeading   : Integer;                           // -- Anfangsausrichtung
    FStepX     : Integer;
    FStepY     : Integer;
    procedure Paint       (Canvas: TCanvas);
    procedure SetColor    (const Value: TColor);
    procedure SetPosX     (const Value: Integer);
    procedure SetPosY     (const Value: Integer);
    procedure SetStepX    (const Value: Integer);
    procedure SetStepY    (const Value: Integer);
    procedure SetHeading  (const Value: Integer);
    procedure SetSize     (const Value: Integer);
  published
    property Color   : TColor  read FColor   write SetColor;
    property PosX    : Integer read FPosX    write SetPosX;
    property PosY    : Integer read FPosY    write SetPosY;
    property StepX   : Integer read FStepX   write SetStepX;
    property StepY   : Integer read FStepY   write SetStepY;
    property Heading : Integer read FHeading write SetHeading;
    property Size    : Integer read FSize    write SetSize;
    procedure ChangeHeading(const degree: Integer; const dist: Integer); // -- Maximale Richtungs�nderung angeben
  end;

implementation

function TAgent.rndN(lower : Integer; upper : Integer):Integer;
begin
  Result := round ((upper - lower + 1) * Random() + lower);
end;

procedure TAgent.SetHeading(const Value: Integer);
begin
  FHeading := Value;
end;

procedure TAgent.ChangeHeading(const degree: Integer; const dist: Integer);
begin
  SetStepX(dist);
  SetStepY(dist);
end;

procedure TAgent.SetStepX(const Value: Integer);
begin
  FStepX := (rndN(-Value -1, Value));
end;

procedure TAgent.SetStepY(const Value: Integer);
begin
  FStepY := (rndN(-Value -1, Value));;
end;

procedure TAgent.SetPosX(const Value: Integer);
begin
  FPosX := Value;
end;

procedure TAgent.SetPosY(const Value: Integer);
begin
  FPosY := Value;
end;

procedure TAgent.SetSize(const Value: Integer);
begin
  FSize := Value;
end;

procedure TAgent.SetColor(const Value: TColor);
begin
  FColor := Value;
end;

procedure TAgent.Paint (Canvas: TCanvas);
begin
  Canvas.Pen.Width := 1;
  Canvas.Pen.Color := FColor; // RGB (100, 100, 100);
  Canvas.Brush.Color := FColor;
  Canvas.Ellipse (FPosX - FSize , FPosY - (FSize), FPosX + (FSize), FPosY + (FSize));
end;

end.

unit cell_P;

interface

uses
  Windows, Graphics, Classes, Math;

type
  TCell = class
  private
  public
    wghtList   : Array of Real;      // -- the values for the negative streets OR the positive values
    street     : Integer;            // -- cell-state for a street
    sWeight    : Real;               // -- weight for a kommunicative street (positive streets)
    satisfied  : Double;
    sameNB     : Array of TPoint;    // -- neighbours with same state
    countType  : Array of Integer;   // -- count the different neighbour-types (states) of a cell
    clCeck     : Boolean;            // -- checked for cluster
    AgNr       : Integer;            // -- Nummer der Agenten auf einer Zelle
    neighSum   : Integer;            // -- Status-Summe in der Nachbarschaft
    neighSimi  : Real;               // -- Summe der gleichen Agenten in der Nachbarschaft
    neighDiff  : Real;               // -- Summe der andersartigen Agenten in der Nachbarschaft
    besetzt    : Boolean;            // -- in an agent is on the cell
    colr       : TColor;            // -- Farbwert der Zelle
    reiSpa     : TPoint;
    FPos       : TPoint;
    FSize      : Integer;
    FFillColor : Integer;
    FState     : Integer;            // -- Status speichert die Anzahl der Agenten auf Zelle
    procedure Paint         (Canvas: TCanvas);
    procedure SetPositionX  (const Value: Integer);
    procedure SetPositionY  (const Value: Integer);
    procedure SetSize       (const Value: Integer);
    procedure SetFillColor  (const Value: Integer);
    procedure SetState      (const Value: Integer);
    constructor create      (xPos, yPos, size, colr: Integer);
  published
    property PositionX: Integer read FPos.X     write SetPositionX;
    property PositionY: Integer read FPos.Y     write SetPositionY;
    property Size     : Integer read FSize      write SetSize;
    property FillColor: Integer read FFillColor write SetFillColor;
    property State    : Integer read FState     write SetState;
  end;

// ---------------------------------------------------------------------------//

implementation

constructor TCell.create(xPos, yPos, size, colr: Integer);
begin
  inherited create;
  FPos.X := xPos;
  FPos.Y := yPos;
  FSize  := size;
  FFillColor := colr;
end;

//------------------------------------------------------------------------------

procedure TCell.SetPositionX(const Value: Integer);
begin
  FPos.X := Value;
end;

procedure TCell.SetPositionY(const Value: Integer);
begin
  FPos.Y := Value;
end;

procedure TCell.SetSize(const Value: Integer);
begin
  FSize := Value;
end;

procedure TCell.SetFillColor(const Value: Integer);
begin
  FFillColor := Value;
end;

procedure TCell.SetState(const Value: Integer);
begin
  FState := Value;
end;

procedure TCell.Paint(Canvas: TCanvas);

begin
  Canvas.Pen.Width := 0;
  Canvas.Pen.Color := clSilver; //clgray;
  Canvas.Brush.Color := colr;   //RGB (colr, colr, colr);
  Canvas.Rectangle (FPos.X - FSize , FPos.Y - FSize, FPos.X + FSize, FPos.Y + FSize);
end;

end.

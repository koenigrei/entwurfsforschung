object Form5: TForm5
  Left = 0
  Top = 0
  Caption = 'Analyse Street Effects'
  ClientHeight = 360
  ClientWidth = 1024
  Color = clBtnFace
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -11
  Font.Name = 'Tahoma'
  Font.Style = []
  OldCreateOrder = False
  OnCreate = FormCreate
  PixelsPerInch = 96
  TextHeight = 13
  object lbl_pSteps: TLabel
    Left = 883
    Top = 271
    Width = 49
    Height = 13
    Alignment = taRightJustify
    Caption = 'lbl_pSteps'
  end
  object lbl_timesteps: TLabel
    Left = 938
    Top = 271
    Width = 53
    Height = 13
    Caption = ': timesteps'
  end
  object Label8: TLabel
    Left = 938
    Top = 290
    Width = 62
    Height = 13
    Caption = ': calculations'
  end
  object Lbl_akt: TLabel
    Left = 872
    Top = 290
    Width = 19
    Height = 13
    Alignment = taRightJustify
    Caption = 'sum'
  end
  object Lbl_proceed: TLabel
    Left = 910
    Top = 290
    Width = 19
    Height = 13
    Alignment = taRightJustify
    Caption = 'sum'
  end
  object Chart_Streets: TChart
    Left = 8
    Top = 8
    Width = 810
    Height = 340
    BackWall.Brush.Color = clWhite
    BackWall.Brush.Style = bsClear
    Border.Visible = True
    Gradient.Balance = 99
    Gradient.Direction = gdFromTopLeft
    Gradient.EndColor = 753908
    Gradient.MidColor = 16059031
    Gradient.StartColor = 14540754
    Legend.CheckBoxesStyle = cbsRadio
    Legend.Visible = False
    Title.Text.Strings = (
      'Streets - Clusters Relationship')
    BottomAxis.ExactDateTime = False
    BottomAxis.Increment = 1.000000000000000000
    BottomAxis.Title.Caption = 'Streets'
    DepthAxis.Automatic = False
    DepthAxis.AutomaticMaximum = False
    DepthAxis.AutomaticMinimum = False
    DepthAxis.Maximum = 0.500000000000000000
    DepthAxis.Minimum = -0.500000000000000000
    DepthTopAxis.Automatic = False
    DepthTopAxis.AutomaticMaximum = False
    DepthTopAxis.AutomaticMinimum = False
    DepthTopAxis.Maximum = 0.500000000000000000
    DepthTopAxis.Minimum = -0.500000000000000000
    LeftAxis.ExactDateTime = False
    LeftAxis.Grid.ZPosition = 100.000000000000000000
    LeftAxis.Title.Caption = 'Clusters'
    RightAxis.Title.Caption = 'segregation index'
    TopAxis.Automatic = False
    TopAxis.AutomaticMaximum = False
    TopAxis.AutomaticMinimum = False
    TopAxis.Visible = False
    View3D = False
    Zoom.UpLeftZooms = True
    Color = clWhite
    TabOrder = 0
    object Series_street: TPointSeries
      Marks.Callout.Brush.Color = clBlack
      Marks.Visible = False
      ClickableLine = False
      Pointer.HorizSize = 3
      Pointer.InflateMargins = True
      Pointer.Style = psCircle
      Pointer.VertSize = 3
      Pointer.Visible = True
      XValues.Name = 'X'
      XValues.Order = loAscending
      YValues.Name = 'Y'
      YValues.Order = loNone
    end
    object Series_strTrend: TLineSeries
      Marks.Callout.Brush.Color = clBlack
      Marks.Visible = False
      DataSource = Series_street
      Title = 'Series_strTrend'
      Pointer.InflateMargins = True
      Pointer.Style = psRectangle
      Pointer.Visible = False
      XValues.Name = 'X'
      XValues.Order = loAscending
      YValues.Name = 'Y'
      YValues.Order = loNone
      object TeeFunction1: TTrendFunction
      end
    end
    object PageNumTool1: TPageNumTool
      Active = False
      Callout.Brush.Color = clBlack
      Callout.Arrow.Visible = False
      Text = 'Page %d of %d'
    end
  end
  object GroupBox1: TGroupBox
    Left = 824
    Top = 8
    Width = 192
    Height = 257
    Caption = 'settings'
    TabOrder = 1
    object Label1: TLabel
      Left = 10
      Top = 99
      Width = 80
      Height = 13
      Caption = 'rows / cols from:'
    end
    object Label2: TLabel
      Left = 133
      Top = 95
      Width = 14
      Height = 13
      Caption = 'to:'
    end
    object Label3: TLabel
      Left = 29
      Top = 163
      Width = 98
      Height = 13
      Caption = 'timesteps per value:'
    end
    object Label4: TLabel
      Left = 20
      Top = 190
      Width = 107
      Height = 13
      Caption = 'calculations per value:'
    end
    object Label5: TLabel
      Left = 76
      Top = 135
      Width = 51
      Height = 13
      Caption = 'increment:'
    end
    object Label6: TLabel
      Left = 10
      Top = 84
      Width = 77
      Height = 13
      Caption = 'nr. of streets or'
    end
    object E_valFrom: TEdit
      Left = 96
      Top = 91
      Width = 32
      Height = 21
      TabOrder = 0
      Text = '10'
      OnChange = E_valFromChange
    end
    object E_valTo: TEdit
      Left = 153
      Top = 91
      Width = 32
      Height = 21
      TabOrder = 1
      Text = '60'
      OnChange = E_valFromChange
    end
    object E_toSteps: TEdit
      Left = 133
      Top = 159
      Width = 32
      Height = 21
      TabOrder = 2
      Text = '500'
    end
    object E_calcVals: TEdit
      Left = 133
      Top = 186
      Width = 32
      Height = 21
      TabOrder = 3
      Text = '10'
      OnChange = E_valFromChange
    end
    object S_start: TButton
      Left = 11
      Top = 222
      Width = 75
      Height = 25
      Caption = 'new start'
      TabOrder = 4
      OnClick = S_startClick
    end
    object S_break: TButton
      Left = 92
      Top = 222
      Width = 75
      Height = 25
      Caption = 'start / stop'
      TabOrder = 5
      OnClick = S_breakClick
    end
    object E_incre: TEdit
      Left = 133
      Top = 131
      Width = 32
      Height = 21
      TabOrder = 6
      Text = '1'
      OnChange = E_valFromChange
    end
    object RadioGroup1: TRadioGroup
      Left = 16
      Top = 16
      Width = 105
      Height = 62
      Caption = 'street layout'
      TabOrder = 7
    end
    object RB_grid: TRadioButton
      Left = 40
      Top = 36
      Width = 65
      Height = 17
      Caption = 'grid'
      Checked = True
      TabOrder = 8
      TabStop = True
    end
    object RB_rnd: TRadioButton
      Left = 40
      Top = 57
      Width = 65
      Height = 17
      Caption = 'random'
      TabOrder = 9
    end
  end
  object B_undoZ: TButton
    Left = 935
    Top = 325
    Width = 75
    Height = 25
    Caption = 'undoZoom'
    TabOrder = 2
    OnClick = B_undoZClick
  end
  object Timer4: TTimer
    Interval = 1
    OnTimer = Timer4Timer
    Left = 896
    Top = 322
  end
end

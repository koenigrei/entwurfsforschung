object Form4: TForm4
  Left = 0
  Top = 0
  Caption = 'Form4'
  ClientHeight = 358
  ClientWidth = 1024
  Color = clBtnFace
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -11
  Font.Name = 'Tahoma'
  Font.Style = []
  OldCreateOrder = False
  OnCreate = FormCreate
  PixelsPerInch = 96
  TextHeight = 13
  object lbl_pSteps: TLabel
    Left = 892
    Top = 191
    Width = 49
    Height = 13
    Alignment = taRightJustify
    Caption = 'lbl_pSteps'
  end
  object lbl_timesteps: TLabel
    Left = 947
    Top = 191
    Width = 53
    Height = 13
    Caption = ': timesteps'
  end
  object Label8: TLabel
    Left = 947
    Top = 210
    Width = 62
    Height = 13
    Caption = ': calculations'
  end
  object Lbl_akt: TLabel
    Left = 881
    Top = 210
    Width = 19
    Height = 13
    Alignment = taRightJustify
    Caption = 'sum'
  end
  object Lbl_proceed: TLabel
    Left = 919
    Top = 210
    Width = 19
    Height = 13
    Alignment = taRightJustify
    Caption = 'sum'
  end
  object GroupBox1: TGroupBox
    Left = 824
    Top = 8
    Width = 192
    Height = 177
    Caption = 'settings'
    TabOrder = 0
    object Label1: TLabel
      Left = 8
      Top = 24
      Width = 74
      Height = 13
      Caption = 'tolerance from:'
    end
    object Label2: TLabel
      Left = 123
      Top = 24
      Width = 14
      Height = 13
      Caption = 'to:'
    end
    object Label3: TLabel
      Left = 29
      Top = 85
      Width = 98
      Height = 13
      Caption = 'timesteps per value:'
    end
    object Label4: TLabel
      Left = 20
      Top = 112
      Width = 107
      Height = 13
      Caption = 'calculations per value:'
    end
    object Label5: TLabel
      Left = 76
      Top = 57
      Width = 51
      Height = 13
      Caption = 'increment:'
    end
    object E_valFrom: TEdit
      Left = 85
      Top = 20
      Width = 32
      Height = 21
      TabOrder = 0
      Text = '10'
      OnChange = E_increChange
    end
    object E_valTo: TEdit
      Left = 143
      Top = 20
      Width = 32
      Height = 21
      TabOrder = 1
      Text = '60'
      OnChange = E_increChange
    end
    object E_toSteps: TEdit
      Left = 133
      Top = 81
      Width = 32
      Height = 21
      TabOrder = 2
      Text = '1300'
    end
    object E_calcVals: TEdit
      Left = 133
      Top = 108
      Width = 32
      Height = 21
      TabOrder = 3
      Text = '10'
      OnChange = E_increChange
    end
    object B_start: TButton
      Left = 11
      Top = 144
      Width = 75
      Height = 25
      Caption = 'new start'
      TabOrder = 4
      OnClick = B_startClick
    end
    object B_break: TButton
      Left = 92
      Top = 144
      Width = 75
      Height = 25
      Caption = 'start / stop'
      TabOrder = 5
      OnClick = B_breakClick
    end
    object E_incre: TEdit
      Left = 133
      Top = 53
      Width = 32
      Height = 21
      TabOrder = 6
      Text = '10'
      OnChange = E_increChange
    end
  end
  object B_undoZ: TButton
    Left = 935
    Top = 325
    Width = 75
    Height = 25
    Caption = 'undoZoom'
    TabOrder = 1
    OnClick = B_undoZClick
  end
  object Chart_Growth: TChart
    Left = 8
    Top = 8
    Width = 810
    Height = 340
    BackWall.Brush.Color = clWhite
    BackWall.Brush.Style = bsClear
    Border.Visible = True
    Gradient.Balance = 99
    Gradient.Direction = gdFromTopLeft
    Gradient.EndColor = 753908
    Gradient.MidColor = 16059031
    Gradient.StartColor = 14540754
    Legend.CheckBoxesStyle = cbsRadio
    Title.Text.Strings = (
      'TChart')
    BottomAxis.ExactDateTime = False
    BottomAxis.Increment = 1.000000000000000000
    BottomAxis.Title.Caption = 'time'
    DepthAxis.Automatic = False
    DepthAxis.AutomaticMaximum = False
    DepthAxis.AutomaticMinimum = False
    DepthAxis.Maximum = 0.500000000000000000
    DepthAxis.Minimum = -0.500000000000000000
    DepthTopAxis.Automatic = False
    DepthTopAxis.AutomaticMaximum = False
    DepthTopAxis.AutomaticMinimum = False
    DepthTopAxis.Maximum = 0.500000000000000000
    DepthTopAxis.Minimum = -0.500000000000000000
    LeftAxis.ExactDateTime = False
    LeftAxis.Grid.Visible = False
    LeftAxis.Grid.ZPosition = 100.000000000000000000
    LeftAxis.Title.Caption = 'density in %'
    RightAxis.Title.Caption = 'segregation index'
    TopAxis.Automatic = False
    TopAxis.AutomaticMaximum = False
    TopAxis.AutomaticMinimum = False
    TopAxis.Visible = False
    View3D = False
    Zoom.UpLeftZooms = True
    Color = clWhite
    TabOrder = 2
    object Series_Avg: TPointSeries
      Marks.Callout.Brush.Color = clBlack
      Marks.Visible = False
      Title = 'Series_Avg'
      ClickableLine = False
      Pointer.HorizSize = 3
      Pointer.InflateMargins = True
      Pointer.Style = psCircle
      Pointer.VertSize = 3
      Pointer.Visible = True
      XValues.Name = 'X'
      XValues.Order = loAscending
      YValues.Name = 'Y'
      YValues.Order = loNone
    end
    object PageNumTool1: TPageNumTool
      Active = False
      Callout.Brush.Color = clBlack
      Callout.Arrow.Visible = False
      Text = 'Page %d of %d'
    end
  end
  object Timer3: TTimer
    Interval = 1
    OnTimer = Timer3Timer
    Left = 896
    Top = 322
  end
end

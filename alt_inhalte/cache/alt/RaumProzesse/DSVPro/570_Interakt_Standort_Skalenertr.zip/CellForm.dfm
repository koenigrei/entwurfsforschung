object Form1: TForm1
  Left = 0
  Top = 0
  Width = 800
  Height = 724
  Caption = 'Segregation and Economies of Scale'
  Color = clBtnFace
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -10
  Font.Name = 'Tahoma'
  Font.Style = []
  OldCreateOrder = False
  OnCreate = FormCreate
  OnDestroy = FormDestroy
  PixelsPerInch = 96
  TextHeight = 12
  object lbl_Steps: TLabel
    Left = 646
    Top = 88
    Width = 39
    Height = 12
    Alignment = taRightJustify
    Caption = 'lbl_Steps'
  end
  object lbl_timesteps: TLabel
    Left = 688
    Top = 88
    Width = 47
    Height = 12
    Caption = ': timesteps'
  end
  object Lbl_TextAnzahl: TLabel
    Left = 472
    Top = 88
    Width = 129
    Height = 12
    Caption = ': number of agents for setup'
  end
  object ZeichenPanel: TPanel
    Left = 8
    Top = 9
    Width = 404
    Height = 404
    BorderStyle = bsSingle
    DockSite = True
    TabOrder = 0
  end
  object B_setup: TButton
    Left = 428
    Top = 8
    Width = 75
    Height = 25
    Caption = 'new Setup'
    TabOrder = 1
    OnClick = B_setupClick
  end
  object B_stop: TButton
    Left = 508
    Top = 8
    Width = 75
    Height = 25
    Caption = 'start / stop'
    TabOrder = 2
    OnClick = B_stopClick
  end
  object RChart1: TRChart
    Left = 8
    Top = 424
    Width = 777
    Height = 265
    AllocSize = 1000
    AutoRedraw = True
    RRim = 20
    TRim = 20
    BRim = 40
    BackGroundImg.IncludePath = False
    BackGroundImg.FillMode = bfStretch
    ClassDefault = 0
    GridStyle = gsNone
    Isometric = False
    JointLayers.L01xControlledBy = 1
    JointLayers.L01yControlledBy = 1
    JointLayers.L02xControlledBy = 2
    JointLayers.L02yControlledBy = 2
    Caption = 'yellow market -> red : customers  ||  green : bid price'
    CaptionPosX = 0
    CaptionPosY = -16
    CaptionAlignment = taRightJustify
    CaptionAnchorHoriz = cahChartRight
    CaptionAnchorVert = cavChartTop
    CrossHair1.Color = clBlack
    CrossHair1.Layer = 1
    CrossHair1.Mode = chOff
    CrossHair1.LineType = psSolid
    CrossHair1.LineWid = 1
    CrossHair2.Color = clBlack
    CrossHair2.Layer = 2
    CrossHair2.Mode = chOff
    CrossHair2.LineType = psSolid
    CrossHair2.LineWid = 1
    CrossHair3.Color = clBlack
    CrossHair3.Layer = 3
    CrossHair3.Mode = chOff
    CrossHair3.LineType = psSolid
    CrossHair3.LineWid = 1
    CrossHair4.Color = clBlack
    CrossHair4.Layer = 4
    CrossHair4.Mode = chOff
    CrossHair4.LineType = psSolid
    CrossHair4.LineWid = 1
    MouseAction = maNone
    MouseCursorFixed = True
    Scale1X.CaptionPosX = 0
    Scale1X.CaptionPosY = 22
    Scale1X.CaptionAlignment = taCenter
    Scale1X.CaptionAnchor = uaSclCenter
    Scale1X.ColorScale = clBlack
    Scale1X.DateFormat.TimeFormat = tfHHMMSS
    Scale1X.DateFormat.DateSeparator = '-'
    Scale1X.DateFormat.TimeSeparator = ':'
    Scale1X.DateFormat.YearLength = ylYYYY
    Scale1X.DateFormat.MonthName = True
    Scale1X.DateFormat.DateOrder = doDDMMYY
    Scale1X.DateFormat.DateForTime = dtOnePerDay
    Scale1X.DecPlaces = -2
    Scale1X.Font.Charset = DEFAULT_CHARSET
    Scale1X.Font.Color = clWindowText
    Scale1X.Font.Height = -11
    Scale1X.Font.Name = 'Tahoma'
    Scale1X.Font.Style = []
    Scale1X.Logarithmic = False
    Scale1X.LabelType = ftNum
    Scale1X.MinTicks = 3
    Scale1X.MinRange = 0.000000000100000000
    Scale1X.RangeHigh = 1.000000000000000000
    Scale1X.ShortTicks = True
    Scale1X.ScalePos = 0
    Scale1X.Visible = True
    Scale1X.ScaleLocation = slBottom
    Scale1Y.CaptionPosX = 0
    Scale1Y.CaptionPosY = -16
    Scale1Y.CaptionAlignment = taLeftJustify
    Scale1Y.CaptionAnchor = uaSclTopLft
    Scale1Y.ColorScale = clBlack
    Scale1Y.DateFormat.TimeFormat = tfHHMMSS
    Scale1Y.DateFormat.DateSeparator = '-'
    Scale1Y.DateFormat.TimeSeparator = ':'
    Scale1Y.DateFormat.YearLength = ylYYYY
    Scale1Y.DateFormat.MonthName = True
    Scale1Y.DateFormat.DateOrder = doDDMMYY
    Scale1Y.DateFormat.DateForTime = dtOnePerDay
    Scale1Y.DecPlaces = -2
    Scale1Y.Font.Charset = DEFAULT_CHARSET
    Scale1Y.Font.Color = clWindowText
    Scale1Y.Font.Height = -11
    Scale1Y.Font.Name = 'Tahoma'
    Scale1Y.Font.Style = []
    Scale1Y.Logarithmic = False
    Scale1Y.LabelType = ftNum
    Scale1Y.MinTicks = 3
    Scale1Y.MinRange = 0.000000000100000000
    Scale1Y.RangeHigh = 1.000000000000000000
    Scale1Y.ShortTicks = True
    Scale1Y.ScalePos = 0
    Scale1Y.Visible = True
    Scale1Y.ScaleLocation = slLeft
    Scale2X.CaptionPosX = 10
    Scale2X.CaptionPosY = 100
    Scale2X.CaptionAlignment = taCenter
    Scale2X.CaptionAnchor = uaSclCenter
    Scale2X.ColorScale = clMaroon
    Scale2X.DateFormat.TimeFormat = tfHHMMSS
    Scale2X.DateFormat.DateSeparator = '-'
    Scale2X.DateFormat.TimeSeparator = ':'
    Scale2X.DateFormat.YearLength = ylYYYY
    Scale2X.DateFormat.MonthName = True
    Scale2X.DateFormat.DateOrder = doDDMMYY
    Scale2X.DateFormat.DateForTime = dtOnePerDay
    Scale2X.DecPlaces = -2
    Scale2X.Font.Charset = DEFAULT_CHARSET
    Scale2X.Font.Color = clWindowText
    Scale2X.Font.Height = -11
    Scale2X.Font.Name = 'Tahoma'
    Scale2X.Font.Style = []
    Scale2X.Logarithmic = False
    Scale2X.LabelType = ftNum
    Scale2X.MinTicks = 3
    Scale2X.MinRange = 0.000000000100000000
    Scale2X.RangeHigh = 1.000000000000000000
    Scale2X.ShortTicks = True
    Scale2X.ScalePos = 0
    Scale2X.Visible = False
    Scale2X.ScaleLocation = slBottom
    Scale2Y.CaptionPosX = 10
    Scale2Y.CaptionPosY = 100
    Scale2Y.CaptionAlignment = taRightJustify
    Scale2Y.CaptionAnchor = uaSclTopLft
    Scale2Y.ColorScale = clMaroon
    Scale2Y.DateFormat.TimeFormat = tfHHMMSS
    Scale2Y.DateFormat.DateSeparator = '-'
    Scale2Y.DateFormat.TimeSeparator = ':'
    Scale2Y.DateFormat.YearLength = ylYYYY
    Scale2Y.DateFormat.MonthName = True
    Scale2Y.DateFormat.DateOrder = doDDMMYY
    Scale2Y.DateFormat.DateForTime = dtOnePerDay
    Scale2Y.DecPlaces = -2
    Scale2Y.Font.Charset = DEFAULT_CHARSET
    Scale2Y.Font.Color = clWindowText
    Scale2Y.Font.Height = -11
    Scale2Y.Font.Name = 'Tahoma'
    Scale2Y.Font.Style = []
    Scale2Y.Logarithmic = False
    Scale2Y.LabelType = ftNum
    Scale2Y.MinTicks = 3
    Scale2Y.MinRange = 0.000000000100000000
    Scale2Y.RangeHigh = 1.000000000000000000
    Scale2Y.ShortTicks = True
    Scale2Y.ScalePos = 0
    Scale2Y.Visible = False
    Scale2Y.ScaleLocation = slLeft
    ShadowStyle = ssFlying
    ShadowColor = clGrayText
    ShadowBakColor = clBtnFace
    TextFontStyle = []
    TextBkStyle = tbClear
    TextBkColor = clWhite
    TextAlignment = taCenter
  end
  object Edit_anzAg: TEdit
    Left = 428
    Top = 80
    Width = 41
    Height = 20
    TabOrder = 4
    Text = '800'
  end
  object B_oneStep: TButton
    Left = 508
    Top = 40
    Width = 75
    Height = 25
    Caption = 'one step'
    TabOrder = 5
    OnClick = B_oneStepClick
  end
  object GroupBox3: TGroupBox
    Left = 424
    Top = 260
    Width = 354
    Height = 117
    Caption = 'Economies of Scale : Parameters'
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clMenuText
    Font.Height = -11
    Font.Name = 'Tahoma'
    Font.Style = []
    ParentFont = False
    TabOrder = 6
    object Label4: TLabel
      Left = 22
      Top = 35
      Width = 83
      Height = 13
      Caption = 'production costs:'
      Font.Charset = DEFAULT_CHARSET
      Font.Color = clBlack
      Font.Height = -11
      Font.Name = 'Tahoma'
      Font.Style = []
      ParentFont = False
    end
    object Lbl_ProdKost: TLabel
      Left = 115
      Top = 35
      Width = 24
      Height = 13
      Caption = '____'
      Font.Charset = DEFAULT_CHARSET
      Font.Color = clBlack
      Font.Height = -11
      Font.Name = 'Tahoma'
      Font.Style = []
      ParentFont = False
    end
    object Label9: TLabel
      Left = 21
      Top = 61
      Width = 84
      Height = 13
      Caption = ' travel expenses:'
      Font.Charset = DEFAULT_CHARSET
      Font.Color = clBlack
      Font.Height = -11
      Font.Name = 'Tahoma'
      Font.Style = []
      ParentFont = False
    end
    object Lbl_FahrtKost: TLabel
      Left = 115
      Top = 61
      Width = 24
      Height = 13
      Caption = '____'
      Font.Charset = DEFAULT_CHARSET
      Font.Color = clBlack
      Font.Height = -11
      Font.Name = 'Tahoma'
      Font.Style = []
      ParentFont = False
    end
    object Label12: TLabel
      Left = 26
      Top = 87
      Width = 79
      Height = 13
      Caption = 'returns to scale:'
      Font.Charset = DEFAULT_CHARSET
      Font.Color = clBlack
      Font.Height = -11
      Font.Name = 'Tahoma'
      Font.Style = []
      ParentFont = False
    end
    object Lbl_Skalen: TLabel
      Left = 115
      Top = 87
      Width = 24
      Height = 13
      Caption = '____'
      Font.Charset = DEFAULT_CHARSET
      Font.Color = clBlack
      Font.Height = -11
      Font.Name = 'Tahoma'
      Font.Style = []
      ParentFont = False
    end
    object SB_ProdKost: TScrollBar
      Left = 148
      Top = 32
      Width = 197
      Height = 15
      LargeChange = 10
      Max = 500
      Min = 1
      PageSize = 8
      Position = 100
      TabOrder = 0
      OnChange = SB_ProdKostChange
    end
    object SB_FahrtKost: TScrollBar
      Left = 148
      Top = 58
      Width = 197
      Height = 15
      LargeChange = 5
      Min = 1
      PageSize = 8
      Position = 50
      TabOrder = 1
      OnChange = SB_FahrtKostChange
    end
    object SB_Skalen: TScrollBar
      Left = 148
      Top = 84
      Width = 197
      Height = 15
      LargeChange = 5
      Max = 400
      PageSize = 8
      Position = 100
      TabOrder = 2
      OnChange = SB_SkalenChange
    end
  end
  object GroupBox1: TGroupBox
    Left = 424
    Top = 128
    Width = 354
    Height = 113
    Caption = 'Segregation : Parameters'
    TabOrder = 7
    object Lbl_TextSwelle: TLabel
      Left = 18
      Top = 29
      Width = 49
      Height = 12
      Caption = 'threshold :'
    end
    object Lbl_B: TLabel
      Left = 74
      Top = 29
      Width = 15
      Height = 12
      Caption = '__8'
    end
    object Label2: TLabel
      Left = 98
      Top = 29
      Width = 7
      Height = 12
      Caption = '='
    end
    object Lbl_P: TLabel
      Left = 110
      Top = 29
      Width = 15
      Height = 12
      Caption = '___'
    end
    object Label5: TLabel
      Left = 130
      Top = 29
      Width = 10
      Height = 12
      Caption = '%'
    end
    object Cb_segregat: TCheckBox
      Left = 168
      Top = 16
      Width = 161
      Height = 17
      Caption = 'activate: segregation'
      Checked = True
      State = cbChecked
      TabOrder = 0
    end
    object Cb_toCenters: TCheckBox
      Left = 168
      Top = 40
      Width = 161
      Height = 17
      Caption = 'activate: look for centers'
      Checked = True
      State = cbChecked
      TabOrder = 1
    end
    object Cb_showCatch: TCheckBox
      Left = 168
      Top = 64
      Width = 161
      Height = 17
      Caption = 'show catchment areas'
      Checked = True
      State = cbChecked
      TabOrder = 2
    end
    object Cb_locP: TCheckBox
      Left = 168
      Top = 88
      Width = 161
      Height = 17
      Caption = 'show local price scape'
      TabOrder = 3
    end
    object Button2: TButton
      Left = 80
      Top = 88
      Width = 75
      Height = 17
      Caption = 'gray cells'
      TabOrder = 4
      OnClick = Button2Click
    end
    object TrB_thresh: TTrackBar
      Left = 8
      Top = 48
      Width = 153
      Height = 41
      Max = 8
      Position = 3
      TabOrder = 5
      OnChange = TrB_threshChange
    end
  end
  object Timer1: TTimer
    Interval = 1
    OnTimer = Timer1Timer
    Left = 760
    Top = 8
  end
end

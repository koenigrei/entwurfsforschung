unit cell_P;

interface

uses
  Windows, Graphics, Classes, node, Math;

type
  TCell = class
  private
  public
    AgNr       : Integer;            // -- Nummer der Agenten auf einer Zelle
    neighSum   : Integer;            // -- Status-Summe in der Nachbarschaft
    neighSimi  : Integer;            // -- Summe der wei�en Zellen in der Nachbarschaft
    neighDiff  : Integer;            // -- Summe der Agenten in der Nachbarschaft
    cent       : Boolean;            // -- in the cell is a market cell.
    Dist       : Double;            // -- Distance to nexgt market
    distM      : Array [0..9] of Double;  // -- distances to all markets
    indM       : Integer;            // -- index of the next market
    besetzt    : Boolean;            // -- in an agent is on the cell
    colr       : Integer;            // -- Farbwert der Zelle
    cstms      : Integer;            // -- number of customers if the cell is chosen as marketplace
    angebPr    : Double;           // -- bid price, if the cell is chosen as marketplace
    locPrice   : Double;           // -- the local price in each cell.
    FPos       : TPoint;
    FSize      : Integer;
    FFillColor : Integer;
    FState     : Integer;            // -- Status speichert die Anzahl der Agenten auf Zelle
    procedure Paint         (Canvas: TCanvas; bunt: boolean);
    procedure SetPositionX  (const Value: Integer);
    procedure SetPositionY  (const Value: Integer);
    procedure SetSize       (const Value: Integer);
    procedure SetFillColor  (const Value: Integer);
    procedure SetState      (const Value: Integer);
    constructor create      (xPos, yPos, size, colr: Integer);
  published
    property PositionX: Integer read FPos.X     write SetPositionX;
    property PositionY: Integer read FPos.Y     write SetPositionY;
    property Size     : Integer read FSize      write SetSize;
    property FillColor: Integer read FFillColor write SetFillColor;
    property State    : Integer read FState     write SetState;
  end;

// ---------------------------------------------------------------------------//

implementation

constructor TCell.create(xPos, yPos, size, colr: Integer);
begin
  inherited create;
  FPos.X := xPos;
  FPos.Y := yPos;
  FSize  := size;
  FFillColor := colr;
end;

//------------------------------------------------------------------------------
procedure TCell.SetPositionX(const Value: Integer);
begin
  FPos.X := Value;
end;

procedure TCell.SetPositionY(const Value: Integer);
begin
  FPos.Y := Value;
end;

procedure TCell.SetSize(const Value: Integer);
begin
  FSize := Value;
end;

procedure TCell.SetFillColor(const Value: Integer);
begin
  FFillColor := Value;
end;

procedure TCell.SetState(const Value: Integer);
begin
  FState := Value;
end;

procedure TCell.Paint(Canvas: TCanvas; bunt: boolean);
var
  colTo : Integer;
  colTo2 : Integer;
begin
  Canvas.Pen.Width := 0;
  Canvas.Pen.Color := clgray; //clgreen;
  {If indM < 5 then begin
    colTo1 := 50 + indM * 28;
    colTo2 := 150;   //255 - indM * 28;
    colr   := 150;   //indM * 28;
  end else begin
    colTo1 := 150;
    colTo2 := 500 + indM * 28;
    colr   := 150;  //- indM * 28;
  end;  }
  If bunt = true then
  begin
    case indM of
      0: colTo := clSkyBlue;   //Canvas.Brush.Color := clRed;
      1: colTo := clBlue;
      2: colTo := clYellow;
      3: colTo := clGreen;
      4: colTo := clTeal;
      5: colTo := clOlive;
      6: colTo := clLime;
      7: colTo := clFuchsia;
      8: colTo := clAqua;
      9: colTo := clPurple;
    end;
    Canvas.Brush.Color := colTo; //RGB (colTo, colTo2, colTo1);
  end else begin
    //colr := 180;
    Canvas.Brush.Color := RGB (colr, colr, colr);
  end;

  If cent = true then begin
    Canvas.Pen.Color := clred;
    Canvas.Pen.Width := 2;
  end;
  //Canvas.Pen.Color   := RGB (colr, colr, colr);
  Canvas.Rectangle (FPos.X - FSize , FPos.Y - FSize, FPos.X + FSize, FPos.Y + FSize);
end;

end.

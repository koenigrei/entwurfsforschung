(********************************************************************)
(*                                                                  *) 
(*                                                                  *)
(*          Economies of Scale and Segregation by Move              *)
(*                          Version 1.01                            *)
(*                                                                  *)
(*                                                                  *)
(*     Programmierer: Reinhard K�nig                     March 2006 *)
(*                    http://www.entwurfsforschung.de               *)
(*                                                                  *)
(*     Last Update: March-25, 2005                                  *)
(*                                                                  *)
(********************************************************************) 
{revision history:

1.0     [March-23, 2005]
        first release to the public
        zu verbessern ist die changeHeadin prozedur bei den agenten
1.01    [March-25, 2005]
        correction of the visualization sequence
        more precisely input for the threshold value
}

unit CellForm;

interface

uses
  Windows, Messages, SysUtils, Variants, Classes, Graphics, Controls, Forms,
  Dialogs, StdCtrls, cell_P, ExtCtrls, ButtonGroup, ComCtrls, Math, ToolWin,
  ImgList, Epina.SDL.rchart, agenten, TeeProcs, TeEngine, Chart,
  XPStyleActnCtrls, ActnList, ActnMan, Series;

type
  TForm1 = class(TForm)
    ZeichenPanel   : TPanel;
    Timer1         : TTimer;
    lbl_Steps      : TLabel;
    B_setup        : TButton;
    lbl_timesteps  : TLabel;
    B_stop         : TButton;
    RChart1        : TRChart;
    Lbl_TextAnzahl : TLabel;
    Edit_anzAg     : TEdit;
    B_oneStep      : TButton;
    GroupBox3      : TGroupBox;
    Label4         : TLabel;
    Lbl_ProdKost   : TLabel;
    Label9         : TLabel;
    Lbl_FahrtKost  : TLabel;
    Label12        : TLabel;
    Lbl_Skalen     : TLabel;
    SB_ProdKost    : TScrollBar;
    SB_FahrtKost   : TScrollBar;
    SB_Skalen      : TScrollBar;
    GroupBox1      : TGroupBox;
    Lbl_TextSwelle : TLabel;
    Cb_segregat    : TCheckBox;
    Cb_toCenters   : TCheckBox;
    Cb_showCatch   : TCheckBox;
    Cb_locP        : TCheckBox;
    Button2        : TButton;
    TrB_thresh     : TTrackBar;
    Lbl_B          : TLabel;
    Label2         : TLabel;
    Lbl_P          : TLabel;
    Label5         : TLabel;
    procedure TrB_threshChange(Sender: TObject);
    procedure Button2Click(Sender: TObject);
    procedure SB_FahrtKostChange(Sender: TObject);
    procedure SB_ProdKostChange(Sender: TObject);
    procedure B_oneStepClick(Sender: TObject);
    procedure SB_SkalenChange(Sender: TObject);
    procedure B_stopClick   (Sender: TObject);
    procedure B_setupClick  (Sender: TObject);
    procedure Timer1Timer   (Sender: TObject);
    procedure FormDestroy   (Sender: TObject);
    procedure FormCreate    (Sender: TObject);
  private
    AgentList    : TList;
    cellList     : Array of Array of TCell;
    limboWorld   : Array of Array of Extended;
    function  CalcDistance  (pAX: Integer; pAY: Integer; pBX: Integer; pBY: Integer): Double;
    function  rndN          (lower: Integer; upper: Integer):Integer;
    procedure checkNei      (K, I: Integer);
    procedure torus         (var Xp: Integer; var Yp: Integer);
    procedure createPaintImg;
    procedure createRaster;
    procedure createAgents;
    procedure setupCells;
    procedure setupAgents;
    procedure calcAgents;
    procedure calcCells;
    procedure compareLoc;
    procedure drawCh;
    procedure calcBidPrice;
    procedure setLocP;
    procedure bestMarket(K , I : Integer);
    procedure repaintZells;
    procedure resetGraph;
    procedure prodScape;
    procedure execPerStep;
    procedure repaintAgents;
    procedure changeArea (curCell: TCell; oldM: Integer);
  public
end;

var
  Form1    : TForm1;
  paintImg : TImage;

implementation

{$R *.dfm}

const                            //-- globale Konstanten
  cellScal = 10;                  //-- Zellen  gr��e
  AgSize   = 4;                  //-- Agenten gr��e
  halfScal = round(cellScal/2);

var                              //-- globale Variablen
  reih    : Integer;             //-- Zellen-Reihen gesamt
  spalt   : Integer;             //-- Zellen-Spalten gesamt
  steps   : Integer;
  Xmax    : Integer;
  Ymax    : Integer;
  cellSum : Integer;
  OldY1   : Double;              //-- Speichert die Position t-1 f�r Graphen
  OldY2   : Double;              //-- Speichert die Position t-1 f�r Graphen
  happy   : Integer;             // -- z�hlt die angelagerten Agenten
  unhappy : Integer;             // -- z�hlt die noch freien Agenten
  market  : Array [0..9] of TPoint;
  //sumC    : Integer;
  res       : Integer;
// ---------------------------------------------------------------------------//
// *** Initialisierung ***
procedure TForm1.FormCreate(Sender: TObject);
begin
  spalt     := round (ZeichenPanel.Width / cellScal);
  reih      := round (ZeichenPanel.Height / cellScal);
  Xmax      := (spalt) * cellScal;
  Ymax      := (reih ) * cellScal;
  AgentList := TList.Create;
  SetLength(cellList, spalt, reih);
  SetLength(limboWorld, spalt, reih);
  createPaintImg;
  CreateRaster;
  CreateAgents;
  ZeichenPanel.DoubleBuffered := True;       //-- Verhindert Flackern der Zellen
  steps := 0;
  res   := 0;
  Lbl_Skalen.Caption    := FloatToStr(1 + SB_Skalen.Position/1000 -0.1);
  Lbl_ProdKost.Caption  := IntToStr(SB_ProdKost.Position);
  Lbl_FahrtKost.Caption := FloatToStr(SB_FahrtKost.Position*2/100);
  Lbl_B.Caption         := IntToStr(TrB_thresh.Position) + '/' + '8';
  Lbl_P.Caption         := FloatToStr(TrB_thresh.Position * 12.5);
  // -- Diagramm initialisieren --
  RChart1.Scale1X.RangeLow  := 0;     { range of chart area }
  RChart1.Scale1X.RangeHigh := 500;   //-- Maximale Reichweite = 1000 bei Testversion!!!
  RChart1.Scale1Y.RangeLow  := -10;
  RChart1.Scale1Y.RangeHigh := 200;//StrToInt(Edit_anzAg.Text);
  RChart1.ShowGraf;
end;

// ---------------------------------------------------------------------------//
// ------------------------- Elemente erstellen ------------------------------//
// ---------------------------------------------------------------------------//

// *** Legt eine leere Zeichenfl�che �ber das Zeichenpanel ***
procedure TForm1.createPaintImg;
begin
  paintImg        := TImage.Create(self);
  paintImg.Parent := ZeichenPanel;
  paintImg.top    := 0;
  paintImg.Left   := 0;
  paintImg.Height := ZeichenPanel.Height;
  paintImg.Width  := ZeichenPanel.Width;
end;

procedure TForm1.CreateAgents;
var
  I        : Integer;
  curAgent : TAgent;
begin
  for I := 0 to StrToInt(Edit_anzAg.Text)-1 do //   StrToInt(Edi_NrRed.Text) Do
  begin
    curAgent := TAgent.Create;
    AgentList.Add (curAgent);     // ---  add to the list
  end;
  setupAgents;
end;

// *** Agenten initialisieren ***
procedure TForm1.setupAgents;
var
  curAgent : TAgent;
  curCell  : TCell;
  I        : Integer;
begin
  Randomize();
  for I := 0 to AgentList.Count - 1 do
  begin
    curAgent := AgentList.Items [I];
    repeat
      curAgent.onCell.X := random (spalt);
      curAgent.onCell.Y := random (reih);
      curCell := cellList[curAgent.onCell.X, curAgent.onCell.Y];
    until (curCell.besetzt = false);
    curAgent.PosX     := curAgent.onCell.X * cellScal + halfScal;
    curAgent.PosY     := curAgent.onCell.Y * cellScal + halfScal;
    curAgent.Size     := AgSize;
    curAgent.State    := random(2);
    curAgent.Stopped  := true;//false;
    curAgent.Paint   (paintImg.Canvas);
    curCell.State     := curAgent.State;
    curCell.AgNr      := I;
    curCell.besetzt := true;
    curCell := cellList[market[curCell.indM].X, market[curCell.indM].Y];
               curCell.cstms := curCell.cstms +1;                          // -- count the agents in the catchment area of a market
  end;
end;

// *** Zellen erstellen ***
procedure TForm1.CreateRaster;
var
  curCell : TCell;
  I       : Integer;
  K       : Integer;
  upperB  : Integer;
  lowerB  : Integer;
begin
  for I := 0 to reih -1 do
  begin
    for K := 0 to spalt -1 do
    begin
      curCell := TCell.Create(halfScal + K * cellScal, halfScal + I * cellScal, halfScal, 0);
      cellList[K,I] := curCell;
    end;
  end;
  setupCells;
end;

// *** Zellen initialisieren ***
procedure TForm1.setupCells;
var
  curCell : TCell;
  I, K, M : Integer;

begin
  OldY1   := 0; // -- Ausgangswert t=0 f�r Graphen
  cellSum := spalt * reih;
  Randomize();
  for I := 0 to 9 do
  begin
    market[I].X := random(spalt);
    market[I].Y := random(reih);
  end;
  for I := 0 to reih -1 do
  begin
    for K := 0 to spalt -1 do
    begin
      curCell         := cellList[K,I];
      curCell.besetzt := false;
      curCell.colr    := 180;
      curCell.cent    := false;
      curCell.Dist    := 10000;
      curCell.indM    := 0;
      curCell.angebPr := 1;   // -- Calculate the distances to each market and find the nearest
      bestMarket (K, I);
      curCell.Paint(paintImg.Canvas, Cb_showCatch.Checked);
    end;
  end;
  // -- mark the centerCells --
  for I := 0 to 9 do
  begin
    cellList[market[I].X,market[I].Y].cent := true;
    cellList[market[I].X,market[I].Y].Paint(paintImg.Canvas, Cb_showCatch.Checked);
  end;

  RChart1.ClearGraf;      { initialize chart }
  RChart1.MoveTo (0,0);
end;

// ---------------------------------------------------------------------------//
// ---------------------------- Berechnungen ---------------------------------//
// ---------------------------------------------------------------------------//

// *** Rekursive Befehle ausf�hren ***
procedure TForm1.Timer1Timer(Sender: TObject);
begin
  execPerStep;
end;

procedure TForm1.execPerStep;
begin
  calcBidPrice;                       // -- set the local bid price in each market

  setLocP;                            // -- set the local price in each market

  If Cb_locP.Checked = true Then
  prodScape;                          // -- landscape of local product costs

  repaintZells;                       // -- the name says it all!

  calcAgents;                         // -- ver�ndert die Position der Agenten

  If Cb_segregat.Checked = true Then
  calcCells;                          // -- berechnet die Zellennachbarschaften

  If Cb_toCenters.Checked = true Then
  compareLoc;                         // -- looks if there is a better location

  repaintAgents;                      // -- the name says it all!

  steps := steps +1;
  lbl_Steps.Caption := intToStr (steps);

  drawCh;
end;

procedure TForm1.prodScape;
var
  curCell : TCell;
  I, K : Integer;
begin
  for I := 0 to reih -1 do
  begin
    for K := 0 to spalt -1 do
    begin
      curCell := cellList[K,I];
      curCell.colr := round(curCell.locPrice * 9);
    end;
  end;
end;

procedure TForm1.repaintZells;
var
  curCell  : TCell;
  I, K     : Integer;
begin
  for I := 0 to reih -1 do
  begin
    for K := 0 to spalt -1 do
    begin
      curCell := cellList[K,I];
      curCell.Paint (paintImg.Canvas, Cb_showCatch.Checked);
    end;
  end;
end;

procedure TForm1.repaintAgents;
var
  curAgent : TAgent;
  I        : Integer;
begin
  for I := 0 to AgentList.Count - 1 do
  begin
    curAgent := AgentList.Items [I];
    curAgent.Paint (paintImg.Canvas);
  end;
end;

procedure TForm1.bestMarket (K , I : Integer);
var
  curCell : TCell;
  M       : Integer;
begin
  curCell := cellList[K,I];
  for M := 0 to 9 do
  begin
    curCell.distM[M] := calcDistance(K, I, market[M].X, market[M].Y);           // -- distance to center for every cell
    if curCell.distM[M] < curCell.Dist then
    begin
      curCell.Dist := curCell.distM[M];
      curCell.indM := M;
    end;
  end;
end;

// *** calculate the local price for each cell ***
procedure TForm1.setLocP;
var
  curCell   : TCell;
  oldM      : Integer;
  I, K, M   : Integer;
  spacePr   : Double;
  bestPrice : Double;
  tmpXPr    : Double;
  travelE : Real;
begin
  spacePr := 0;
  tmpXPr  := 0;
  travelE := StrToFloat(Lbl_FahrtKost.Caption);
  for I := 0 to reih -1 do
  begin
    for K := 0 to spalt -1 do
    begin
      curCell   := cellList[K,I];
      oldM      := curCell.indM;
      bestPrice := 9999;
      for M := 0 to 9 do
      begin
        spacePr := curCell.distM[M] * travelE;
        tmpXPr  := cellList[market[M].X, market[M].Y].angebPr + spacePr;
        If tmpXPr < bestPrice Then
        begin
          bestPrice        := tmpXPr;
          curCell.locPrice := tmpXPr;
          curCell.indM     := M;                                                // -- adapt the belonging of a customer
        end;
      end;
      If curCell.besetzt = true then
      begin
        changeArea (curCell, oldM);  //-- customer on another cell
      end;
    end;
  end;
end;

// *** correct the numbers of customers in the market ***
procedure TForm1.changeArea (curCell: TCell; oldM: Integer);
begin
  cellList[market[oldM].X, market[oldM].Y].cstms :=                             // -- no longer customer here
           cellList[market[oldM].X, market[oldM].Y].cstms -1;
  cellList[market[curCell.indM].X, market[curCell.indM].Y].cstms :=             // -- new customer here
           cellList[market[curCell.indM].X, market[curCell.indM].Y].cstms +1;
end;

// *** calculate the bid price for each market ***
procedure TForm1.calcBidPrice;
var
  scale   : Real;
  prodC   : Real;
  curCell : TCell;
  U       : Integer;
begin
  scale   := StrToFloat(Lbl_Skalen.Caption);// := FloatToStr(1 + SB_Skalen.Position/1000);
  prodC   := StrToFloat(Lbl_ProdKost.Caption);
  for U := 0 to 9 do
  begin
    curCell := cellList[market[U].X, market[U].Y];
    If curCell.cstms <= 0 then
    begin
      curCell.angebPr := prodC;
    end else begin
      curCell.angebPr := ((curCell.cstms / Power(curCell.cstms, scale)) * prodC);
    end;
  end;
end;

// *** look for a better location ***
procedure TForm1.compareLoc;
var
  curCell   : TCell;
  oldCell   : TCell;
  curAgent  : TAgent;
  I,K       : Integer;
  nTest     : Integer;  //-- look for n-times for a better location
  curLoc    : Double;   //-- distance to center at the current location
  newLoc    : Double;   //-- distance to center at the possible new location
  tmpPos    : TPoint;   //-- reih & spalt coordinates of the explored cell
begin
  nTest := 9;
  for I := 0 to AgentList.Count - 1 do
  begin
    curAgent := AgentList.Items [I];
    If curAgent.Stopped = true then
    begin
      curLoc := cellList[curAgent.onCell.X, curAgent.onCell.Y].locPrice;
      for K := 0 to nTest do
      begin
        //curAgent.ChangeHeading(180, 10);                                      // -- change direction and distance values
        tmpPos.X := curAgent.onCell.X + random(20)-10;//curAgent.stepX;
        tmpPos.Y := curAgent.onCell.Y + random(20)-10;//curAgent.stepY;
        torus (tmpPos.X, tmpPos.Y);                                             // -- check Torus
        curCell := cellList[tmpPos.X, tmpPos.Y];                                // -- the explored cell
        newLoc  := curCell.locPrice;
        If (newLoc < curLoc) and (curCell.besetzt = false) then
        begin
          oldCell := cellList[curAgent.onCell.X, curAgent.onCell.Y];
          oldCell.besetzt := false;                                             // -- alte Zelle wieder leer
          oldCell.Paint (paintImg.Canvas, Cb_showCatch.Checked);
          curAgent.onCell.X := tmpPos.X;
          curAgent.onCell.Y := tmpPos.Y;
          curAgent.PosX     := tmpPos.X * cellScal + halfScal;                  // -- Wenn Zelle frei, Agent bewegen ---
          curAgent.PosY     := tmpPos.Y * cellScal + halfScal;
          curCell.Besetzt   := true;                                            // -- Zelle unter Agent als besetzt markieren.
          curCell.State     := curAgent.State;
          curCell.AgNr      := I;
          changeArea (curCell, oldCell.indM);  //-- customer on another cell
          break;
        end;
      end;
    end;
  end;
end;

// *** Ver�ndert die Position der Agenten ***
procedure TForm1.calcAgents;
var
  curCell     : TCell;
  oldCell     : TCell;
  curAgent    : TAgent;
  I           : Integer;
  agCount     : Integer;
  tempPos     : TPoint;
  resc        : Integer;
begin
  agCount := 0;
  happy   := 0;
  unhappy := 0;
  for I := 0 to AgentList.Count - 1 do
  begin
    curAgent := AgentList.Items [I];
    If curAgent.Stopped = false then                                            // -- Wenn Agent noch nicht angelagert,
    begin                                                                       // -- zuf�llig weiterbewegen
      agCount := agCount +1;
      unhappy := unhappy +1;
      resc := 0;
      repeat
        resc := resc +1;
        If resc > 100 then break;                                               // -- break condition
        //curAgent.ChangeHeading(180, 10);                                      // -- Richtungsspektrum und Distanz
        tempPos.X := curAgent.onCell.X + random(20)-10;//curAgent.stepX;
        tempPos.Y := curAgent.onCell.Y + random(20)-10;//curAgent.stepY;
        torus (tempPos.X, tempPos.Y);                                           // -- Torus --
        curCell := cellList[tempPos.X, tempPos.Y];
      until curCell.besetzt = false;                                            // -- wiederholen, bis freie Zelle gefunden
      oldCell := cellList[curAgent.onCell.X, curAgent.onCell.Y];
      oldCell.besetzt := false;                                                 // -- alte Zelle wieder leer
      oldCell.Paint (paintImg.Canvas, Cb_showCatch.Checked);                                          // -- neu zeichnen!
      curAgent.onCell.X := tempPos.X;
      curAgent.onCell.Y := tempPos.Y;
      curAgent.PosX     := curAgent.onCell.X * cellScal + halfScal;             // -- Wenn Zelle frei, Agent bewegen ---
      curAgent.PosY     := curAgent.onCell.Y * cellScal + halfScal;
      curCell.Besetzt   := true;                                                // -- Zelle unter Agent als besetzt markieren.
      curCell.State     := curAgent.State;
      curCell.AgNr      := I;                                                   // -- Agenten index in Zelle speichern
      changeArea (curCell, oldCell.indM);                                       // -- customer on another cell
    end else begin                                                              // -- Wenn Agent bereits angehalten
      cellList[curAgent.onCell.X, curAgent.onCell.Y].AgNr    := I;              // -- Agenten index in Zelle speichern
      cellList[curAgent.onCell.X, curAgent.onCell.Y].State   := curAgent.State;
      cellList[curAgent.onCell.X, curAgent.onCell.Y].besetzt := true;
      happy := happy +1;
    end;
  end;
  // -- Wenn alle Agenten angelagert sind, anhalten
  //If agCount = 0 then Timer1.enabled := false;
end;

// *** Berechnet die Zellen ***
procedure TForm1.calcCells;
var
  curCell     : TCell;
  curAgent    : TAgent;
  I, K        : Integer;
  thresh      : Real;
  nSum        : Integer;
  similar     : Double;
begin
  thresh := StrToFloat(Lbl_P.Caption);
  for I := 0 to reih -1 do
  begin
    for K := 0 to spalt -1 do
    begin
      curCell := cellList[K,I];

      If curCell.besetzt = true Then
      begin
        checkNei(K, I);                             // -- Vergleicht die Agenten in der Moore Nachbarschaft
        nSum := curCell.neighSimi + curCell.neighDiff;

        If nSum > 0 then begin
          similar := (curCell.neighSimi/nSum) * 100;
        end else begin
          similar := 0
        end;

        curAgent := AgentList.Items [curCell.AgNr]; // -- Agenten �ber Zelle ermitteln
        If (similar > thresh) then                  // -- Wenn Anzahl Summe > Threshold
        begin
          curAgent.stopped := true;                 // -- Agent anhalten
        end else begin
          curAgent.stopped := false;                // -- Agent weiterlaufen
        end;
      end;
    end;
  end;
end;

// --- Moorsche Nachbarschaft, mit den Abstand 1 �berpr�fen
procedure TForm1.checkNei (K, I: Integer);
var
  u  : Integer;
  v  : Integer;
  Xp : Integer;
  Yp : Integer;
begin
  cellList[K,I].neighSimi := 0;
  cellList[K,I].neighDiff := 0;
  // --- Summe berechnen ---
  for v := -1 to 1 do
  begin
    for u := -1 to 1 do
    begin
      Xp := K + u;
      Yp := I + v;
      torus(Xp, Yp);                                               // -- Torus edges
      If (cellList[Xp, Yp].besetzt = true) then
      begin
        If (cellList[Xp, Yp].state = cellList[K, I].state) then begin
          cellList[K,I].neighSimi := cellList[K,I].neighSimi +1;   // -- z�hlt Zellen mit gleichem Status
        end else begin
          cellList[K,I].neighDiff := cellList[K,I].neighDiff +1;   // -- z�hlt Zellen mit anderem Status
        end;
      end;

    end;
  end;
  cellList[K,I].neighSimi := cellList[K,I].neighSimi -1;           // -- zieht sich selbst wieder ab
end;

//--- Ausgabe in Graph ---
procedure TForm1.drawCh;
var
  curCell   : TCell;
  cSteps    : Integer;
begin
  if steps mod 499 = 0 then begin // > RChart1.Scale1X.RangeHigh-1 then begin // -- Plotten bis
    resetGraph;
    res := res + 1;
  end;
  cSteps := Steps -(res * 500);
  curCell := cellList[market[2].X, market[2].Y];
  RChart1.ActiveLayer:= 1;
  RChart1.DataColor := clRed;
  If (curCell.cstms > RChart1.Scale1Y.RangeHigh) Then RChart1.Scale1Y.RangeHigh := curCell.cstms + 50;
  If (curCell.angebPr > RChart1.Scale1Y.RangeHigh) Then RChart1.Scale1Y.RangeHigh := curCell.angebPr + 50;
  RChart1.Line(cSteps-1, OldY1, cSteps, curCell.cstms);
  OldY1 := curCell.cstms;
  RChart1.ActiveLayer:= 3;
  RChart1.DataColor := clGreen;
  RChart1.Line(cSteps-1, OldY2, cSteps, curCell.angebPr);
  OldY2 := curCell.angebPr;
end;

procedure TForm1.resetGraph;
begin
  RChart1.Scale1Y.RangeHigh := 200;
  RChart1.ClearGraf;      
  RChart1.MoveTo (0,0);
end;

// ---------------------------------------------------------------------------//
// -------------------------- Funktionen -------------------------------------//
// ---------------------------------------------------------------------------//
// *** Torusfunktion ***
procedure TForm1.torus (var Xp: Integer; var Yp: Integer);
begin
  if Xp < 0     then begin
     Xp := spalt + Xp;
  end else
  if Xp > spalt-1  then begin
     Xp := 0 + (Xp - spalt) ;
  end;
  if Yp < 0     then begin
     Yp := reih + Yp;
  end else
  if Yp > reih-1  then begin
     Yp := 0 + (Yp - reih) ;
  end;
end;

// *** Entferung berechnen ***
function TForm1.CalcDistance(pAX: Integer; pAY: Integer; pBX: Integer; pBY: Integer): Double;
var
  temp : double;
begin
  temp := sqrt(Power((pAX - pBX), 2) + Power((pAY - pBY), 2));
  Result := (temp);
end;

// *** Zufallszahl innerhalb eines Bereichs berechnen ***
function TForm1.rndN(lower : Integer; upper : Integer):Integer;
begin
  Result := round ((upper - lower + 1) * Random() + lower);
end;

// ---------------------------------------------------------------------------//
// ------------------------------- Schalter ----------------------------------//
// ---------------------------------------------------------------------------//
procedure TForm1.B_setupClick(Sender: TObject);
begin
  steps := 0;
  AgentList.Destroy;
  AgentList := TList.Create;
  RChart1.Scale1Y.RangeHigh := 200;
  setupCells;
  createAgents;
  res := 0;
end;

procedure TForm1.B_oneStepClick(Sender: TObject);
begin
  Timer1.enabled := false;
  execPerStep;
end;

procedure TForm1.B_stopClick(Sender: TObject);
begin
  Timer1.enabled := not(Timer1.enabled);
end;

procedure TForm1.FormDestroy(Sender: TObject);
begin
  paintImg.Free;
  ZeichenPanel.Free;
  AgentList.Destroy;
end;

procedure TForm1.SB_SkalenChange(Sender: TObject);
begin
  Lbl_Skalen.Caption := FloatToStr(1 + SB_Skalen.Position/1000 -0.1);
end;

procedure TForm1.SB_ProdKostChange(Sender: TObject);
begin
  Lbl_ProdKost.Caption := IntToStr(SB_ProdKost.Position);
end;

procedure TForm1.SB_FahrtKostChange(Sender: TObject);
begin
  Lbl_FahrtKost.Caption       := FloatToStr(SB_FahrtKost.Position*2/100);
end;

procedure TForm1.Button2Click(Sender: TObject);
var
  curCell : TCell;
  I, K : Integer;
begin
  for I := 0 to reih -1 do
  begin
    for K := 0 to spalt -1 do
    begin
      curCell := cellList[K,I];
      curCell.colr := 180;
    end;
  end;
end;

procedure TForm1.TrB_threshChange(Sender: TObject);
begin
  Lbl_B.Caption := IntToStr(TrB_thresh.Position) + '/' + '8';
  Lbl_P.Caption := FloatToStr(TrB_thresh.Position * 12.5);
end;

end.
